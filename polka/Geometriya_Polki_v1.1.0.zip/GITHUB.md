# Как выложить «Геометрию Полки» на GitHub

Нужно один раз создать репозиторий, загрузить файлы и включить GitHub Pages. После этого проект открывается
по ссылке из любого браузера.

## Вариант 1. Через сайт, без программ (проще всего, лучше с компьютера)

1. Распакуйте `geometriya_polki_v1_1_0.zip` в любую папку.
2. Зайдите на https://github.com и войдите в аккаунт.
3. Нажмите **+** в правом верхнем углу, затем **New repository**.
4. Repository name: `geometriya-polki`. Доступ **Public** (для бесплатных Pages репозиторий должен быть публичным).
   Галочки README, .gitignore, license не ставьте. Нажмите **Create repository**.
5. На открывшейся странице нажмите ссылку **uploading an existing file**.
6. Перетащите в окно браузера всё содержимое распакованной папки: `index.html`, `README.txt`, `GITHUB.md`,
   `GOOGLE_SHEETS.md` и папки `vendor` и `covers` целиком. Проверьте, что в списке есть `vendor/jszip.min.js`
   и файлы `covers/*.jpg` (28 штук, около 0,5 МБ).
7. Внизу в поле Commit напишите `Геометрия Полки 1.1.0` и нажмите **Commit changes**.
8. Откройте **Settings**, слева **Pages**. В блоке *Build and deployment*: Source **Deploy from a branch**,
   Branch **main**, папка **/ (root)**, нажмите **Save**.
9. Через 1–2 минуты вверху страницы Pages появится адрес сайта:
   `https://<ваш-логин>.github.io/geometriya-polki/`
   (у вашего аккаунта, судя по другим репозиториям, это `https://drakkkkon.github.io/geometriya-polki/`).

С телефона папку `vendor` через сайт загрузить нельзя. Либо делайте шаги 5–7 с компьютера, либо создайте
файлы по одному: **Add file → Create new file**, имя `vendor/jszip.min.js` (слэш создаёт папку), вставьте
содержимое файла из архива.

## Вариант 2. Через командную строку (нужен установленный git)

```
cd путь/к/распакованной/папке
git init
git add .
git commit -m "Геометрия Полки 1.1.0"
git branch -M main
git remote add origin https://github.com/Drakkkkon/geometriya-polki.git
git push -u origin main
```

Репозиторий `geometriya-polki` создайте заранее на github.com (шаги 3–4 выше). Затем включите Pages (шаг 8).

## Как обновлять версию

- Через сайт: в репозитории **Add file → Upload files**, перетащите новые файлы с теми же именами,
  **Commit changes**. Сайт обновится через минуту-две.
- Через git: замените файлы и выполните
  ```
  git add .
  git commit -m "Геометрия Полки 1.1.1"
  git push
  ```

## Если что-то не работает

- Сайт показывает 404: проверьте, что `index.html` лежит в корне репозитория, а не в подпапке, и что в
  Pages выбран branch `main`, папка `/ (root)`.
- Кнопки Excel пишут про библиотеку: на GitHub нет папки `vendor`, загрузите её (шаг 6).
- Нет фото обложек: на GitHub нет папки `covers` или имена файлов не `<номер>.jpg`.
- Вход в Google не работает: в Google Cloud в «Разрешённых источниках JavaScript» должен быть `https://drakkkkon.github.io`
  (подробно в `GOOGLE_SHEETS.md`).
- Старая версия после обновления: обновите страницу с очисткой кэша (Ctrl+F5, на телефоне откройте в
  приватной вкладке).
