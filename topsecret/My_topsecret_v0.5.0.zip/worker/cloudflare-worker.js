/* My_topsecret · мост (Cloudflare Worker), версия 0.3.0
 *
 * Зачем он нужен. Страница сайта не может сама читать чужие сайты и файлы: браузер запрещает (CORS) и многие сайты не пускают во фрейм.
 * Мост делает это на сервере и отдаёт ответ вашему сайту с разрешающими заголовками. Он даёт три вещи:
 *   /get?url=...       скачивание любого файла (файлы Telegram, любые ZIP/CBZ) со стороны сервера
 *   /page?url=...      просмотр сайта внутри приложения (вкладка «Браузер»)
 *   /oauth/code        постоянный вход в Google Диск без повторных подтверждений (по желанию)
 *   /oauth/refresh
 *
 * Настройка (5 минут, бесплатно): dash.cloudflare.com → Workers & Pages → Create → Hello World → Deploy → Edit code →
 * вставьте этот файл целиком → Deploy. Затем Settings → Variables and Secrets, добавьте:
 *   ALLOW_ORIGIN         адрес вашего сайта без слэша на конце, например https://name.github.io (обязательно: закрывает мост от чужих сайтов)
 *   KEY                  любой длинный секретный набор символов; тот же вставьте в приложении (Настройки → Мост)
 *   GOOGLE_CLIENT_ID     только для постоянного входа в Google: тот же Client ID, что в приложении
 *   GOOGLE_CLIENT_SECRET только для постоянного входа в Google: Client secret из Google Cloud Console (тип «Веб-приложение»), как Secret
 * Адрес воркера (https://....workers.dev) вставьте в приложении: Настройки → Мост.
 */
const MAX_HTML = 4000000;
const UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36';

/* Скрипт, который мост добавляет в каждую страницу внутри приложения: ссылки и формы превращаются в сообщения приложению. */
const CLIENT = `(function(){
var P=parent;function send(m){try{P.postMessage(m,'*')}catch(e){}}
var FILE=/\\.(zip|cbz|cbr|rar|7z)(?:[?#]|$)/i;
function abs(h){try{return new URL(h,document.baseURI).href}catch(e){return''}}
document.addEventListener('click',function(e){
var a=e.target&&e.target.closest?e.target.closest('a[href]'):null;if(!a)return;
var h=a.getAttribute('href');if(!h||h.charAt(0)==='#'||/^(javascript|mailto|tel|data|blob):/i.test(h))return;
var u=abs(h);if(!/^https?:/i.test(u))return;
e.preventDefault();e.stopPropagation();
if(FILE.test(u)||a.hasAttribute('download'))send({t:'file',url:u,name:a.getAttribute('download')||''});else send({t:'nav',url:u});
},true);
document.addEventListener('submit',function(e){
var f=e.target;if(!f||f.tagName!=='FORM')return;e.preventDefault();
if((f.method||'get').toLowerCase()!=='get'){send({t:'msg',text:'Формы с отправкой данных (POST) в этом браузере не поддерживаются.'});return}
var u=new URL(f.getAttribute('action')||'',document.baseURI),q=new URLSearchParams(u.search);
new FormData(f).forEach(function(v,k){if(typeof v==='string')q.set(k,v)});u.search=q.toString();send({t:'nav',url:u.href});
},true);
window.addEventListener('load',function(){send({t:'title',title:document.title,url:document.baseURI})});
})();`;

const escAttr = s => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
const json = (o, status, h) => new Response(JSON.stringify(o), { status: status || 200, headers: Object.assign({ 'content-type': 'application/json; charset=utf-8' }, h) });

function blockedHost(h) {
  h = h.toLowerCase();
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal')) return true;
  if (/^\[.*\]$/.test(h)) return true;
  const m = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/.exec(h);
  if (m) {
    const a = +m[1], b = +m[2];
    if (a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168)) return true;
  }
  return false;
}
function targetOf(u) {
  let t;
  try { t = new URL(u.searchParams.get('url') || ''); } catch (e) { return null; }
  if (!/^https?:$/.test(t.protocol) || blockedHost(t.hostname)) return null;
  return t;
}
export function rewriteHtml(html, base, js) {
  html = html.replace(/<meta[^>]+http-equiv\s*=\s*["']?(?:content-security-policy|refresh|x-frame-options)[^>]*>/gi, '');
  html = html.replace(/<base\b[^>]*>/gi, '');
  if (!js) html = html.replace(/<script\b[\s\S]*?<\/script\s*>/gi, '').replace(/\son[a-z]+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');
  const inject = '<base href="' + escAttr(base) + '"><meta name="referrer" content="no-referrer"><script>' + CLIENT + '</script>';
  return /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, m => m + inject) : inject + html;
}
function decode(buf, ctype) {
  let cs = /charset\s*=\s*["']?([\w-]+)/i.exec(ctype || '');
  if (!cs) { const head = new TextDecoder('latin1').decode(buf.slice(0, 2048)); cs = /<meta[^>]+charset\s*=\s*["']?([\w-]+)/i.exec(head); }
  try { return new TextDecoder(cs ? cs[1] : 'utf-8').decode(buf); } catch (e) { return new TextDecoder('utf-8').decode(buf); }
}

export default {
  async fetch(req, env) {
    env = env || {};
    const u = new URL(req.url);
    const allow = env.ALLOW_ORIGIN && env.ALLOW_ORIGIN !== '*' ? env.ALLOW_ORIGIN : '*';
    const cors = {
      'Access-Control-Allow-Origin': allow,
      'Access-Control-Allow-Headers': 'x-key, content-type, range',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Expose-Headers': 'content-length, content-type, content-disposition, x-final-url',
      'Vary': 'Origin'
    };
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    const key = req.headers.get('x-key') || u.searchParams.get('k') || '';
    if (env.KEY && key !== env.KEY) return json({ error: 'forbidden' }, 403, cors);
    const origin = req.headers.get('Origin');
    if (origin && allow !== '*' && origin !== allow) return json({ error: 'origin' }, 403, cors);

    if (u.pathname === '/' || u.pathname === '') {
      return json({ ok: true, name: 'My_topsecret bridge', v: 1, oauth: !!(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET) }, 200, cors);
    }

    if (u.pathname === '/get') {
      const t = targetOf(u);
      if (!t) return json({ error: 'bad url' }, 400, cors);
      let up;
      try { up = await fetch(t.href, { redirect: 'follow', headers: { 'User-Agent': UA, 'Accept': '*/*' } }); }
      catch (e) { return json({ error: 'fetch failed' }, 502, cors); }
      const h = Object.assign({}, cors, { 'x-final-url': up.url || t.href });
      for (const k of ['content-type', 'content-length', 'content-disposition']) { const v = up.headers.get(k); if (v) h[k] = v; }
      return new Response(up.body, { status: up.status, headers: h });
    }

    if (u.pathname === '/page') {
      const t = targetOf(u);
      if (!t) return json({ error: 'bad url' }, 400, cors);
      const js = u.searchParams.get('js') === '1';
      let up;
      try { up = await fetch(t.href, { redirect: 'follow', headers: { 'User-Agent': UA, 'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8', 'Accept-Language': 'ru,en;q=0.8' } }); }
      catch (e) { return pageMsg('Сайт не ответил: ' + t.host); }
      const final = up.url || t.href, ct = up.headers.get('content-type') || '', cd = up.headers.get('content-disposition') || '';
      const isHtml = /text\/html|application\/xhtml/i.test(ct) && !/attachment/i.test(cd);
      if (!isHtml) {
        try { up.body && up.body.cancel(); } catch (e) {}
        const nm = (/filename\*?=(?:UTF-8'')?["']?([^"';]+)/i.exec(cd) || [])[1] || '';
        return new Response('<!doctype html><meta charset="utf-8"><body style="font:15px system-ui;padding:16px;color:#333"><p>Это файл. Открываю окно скачивания…</p><script>parent.postMessage({t:"file",url:' + JSON.stringify(final) + ',name:' + JSON.stringify(decodeURIComponent(nm)) + '},"*")</script>',
          { headers: { 'content-type': 'text/html; charset=utf-8' } });
      }
      const buf = await up.arrayBuffer();
      if (buf.byteLength > MAX_HTML) return pageMsg('Страница слишком большая для просмотра. Откройте её в новой вкладке.');
      return new Response(rewriteHtml(decode(buf, ct), final, js), { status: up.status, headers: { 'content-type': 'text/html; charset=utf-8', 'x-final-url': final, 'cache-control': 'no-store' } });
    }

    if (u.pathname === '/oauth/code' || u.pathname === '/oauth/refresh') {
      if (req.method !== 'POST') return json({ error: 'method' }, 405, cors);
      if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) return json({ error: 'not_configured', error_description: 'В мосте не заданы GOOGLE_CLIENT_ID и GOOGLE_CLIENT_SECRET' }, 501, cors);
      let body = {};
      try { body = await req.json(); } catch (e) {}
      const form = new URLSearchParams({ client_id: env.GOOGLE_CLIENT_ID, client_secret: env.GOOGLE_CLIENT_SECRET });
      if (u.pathname === '/oauth/code') {
        if (!body.code) return json({ error: 'no code' }, 400, cors);
        form.set('code', body.code); form.set('grant_type', 'authorization_code'); form.set('redirect_uri', 'postmessage');
      } else {
        if (!body.refresh_token) return json({ error: 'no token' }, 400, cors);
        form.set('refresh_token', body.refresh_token); form.set('grant_type', 'refresh_token');
      }
      const r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: form });
      const j = await r.json().catch(() => ({}));
      const out = {};
      for (const k of ['access_token', 'expires_in', 'refresh_token', 'scope', 'error', 'error_description']) if (j[k] !== undefined) out[k] = j[k];
      return json(out, r.ok ? 200 : (r.status === 400 ? 400 : 502), cors);
    }

    return json({ error: 'not found' }, 404, cors);
  }
};
function pageMsg(text) {
  return new Response('<!doctype html><meta charset="utf-8"><body style="font:15px system-ui;padding:16px;color:#333"><p>' + escAttr(text) + '</p>', { headers: { 'content-type': 'text/html; charset=utf-8' } });
}
