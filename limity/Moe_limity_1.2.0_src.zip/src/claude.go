//go:build windows

package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"time"
)

// Работает так же, как страница «Настройки → Использование» на claude.ai:
// приложение обращается к claude.ai от вашего имени по ключу сессии (sessionKey).
// Это неофициальный способ — если Anthropic поменяет сайт, может понадобиться обновление.

type claudeAPI struct{ hc *http.Client }

func newClaudeAPI() *claudeAPI {
	return &claudeAPI{hc: &http.Client{Timeout: 25 * time.Second}}
}

type apiErr struct {
	Status int
	Msg    string
}

func (e *apiErr) Error() string { return e.Msg }

func (a *claudeAPI) get(key, path string, v interface{}) error {
	req, _ := http.NewRequest("GET", "https://claude.ai"+path, nil)
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0")
	req.Header.Set("Accept", "application/json, text/plain, */*")
	req.Header.Set("Accept-Language", "ru-RU,ru;q=0.9,en;q=0.8")
	req.Header.Set("Referer", "https://claude.ai/settings/usage")
	req.Header.Set("Origin", "https://claude.ai")
	req.Header.Set("anthropic-client-platform", "web_claude_ai")
	req.Header.Set("Content-Type", "application/json")
	req.AddCookie(&http.Cookie{Name: "sessionKey", Value: strings.TrimSpace(key)})

	resp, err := a.hc.Do(req)
	if err != nil {
		return &apiErr{0, "Нет связи с claude.ai. Проверьте интернет."}
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 30<<20))
	switch {
	case resp.StatusCode == 401:
		return &apiErr{401, "Ключ не подошёл или устарел. Возьмите новый sessionKey (см. инструкцию в Настройках)."}
	case resp.StatusCode == 403:
		if strings.Contains(strings.ToLower(string(body)), "cloudflare") || strings.Contains(string(body), "<html") {
			return &apiErr{403, "claude.ai временно не пускает приложение (защита Cloudflare). Откройте claude.ai в браузере, подождите пару минут и обновите."}
		}
		return &apiErr{403, "Доступ запрещён. Скорее всего, ключ устарел — вставьте новый sessionKey."}
	case resp.StatusCode == 429:
		return &apiErr{429, "Слишком частые запросы. Увеличьте интервал обновления."}
	case resp.StatusCode >= 400:
		return &apiErr{resp.StatusCode, fmt.Sprintf("claude.ai ответил ошибкой %d.", resp.StatusCode)}
	}
	if err := json.Unmarshal(body, v); err != nil {
		return &apiErr{0, "Не удалось прочитать ответ claude.ai (возможно, сайт изменился — нужна новая версия программы)."}
	}
	return nil
}

type org struct {
	UUID         string   `json:"uuid"`
	Name         string   `json:"name"`
	Capabilities []string `json:"capabilities"`
}

type KeyCheck struct {
	OK      bool   `json:"ok"`
	Error   string `json:"error,omitempty"`
	OrgID   string `json:"orgId,omitempty"`
	OrgName string `json:"orgName,omitempty"`
}

func (a *claudeAPI) pickOrg(key string) (org, error) {
	var orgs []org
	if err := a.get(key, "/api/organizations", &orgs); err != nil {
		return org{}, err
	}
	if len(orgs) == 0 {
		return org{}, &apiErr{0, "В аккаунте не найдено ни одной организации."}
	}
	for _, o := range orgs {
		for _, c := range o.Capabilities {
			if c == "chat" || c == "claude_pro" || c == "claude_max" {
				return o, nil
			}
		}
	}
	return orgs[0], nil
}

func (a *claudeAPI) checkKey(key string) KeyCheck {
	key = strings.TrimSpace(key)
	key = strings.TrimPrefix(key, "sessionKey=")
	if key == "" {
		return KeyCheck{Error: "Вставьте ключ."}
	}
	o, err := a.pickOrg(key)
	if err != nil {
		return KeyCheck{Error: err.Error()}
	}
	return KeyCheck{OK: true, OrgID: o.UUID, OrgName: o.Name}
}

type UsageItem struct {
	Key      string  `json:"key"`
	Percent  float64 `json:"percent"`
	ResetsAt string  `json:"resetsAt"`
}

type ChatInfo struct {
	Name      string `json:"name"`
	UUID      string `json:"uuid"`
	Model     string `json:"model"`
	Messages  int    `json:"messages"`
	Chars     int    `json:"chars"`
	Files     int    `json:"files"`
	Tokens    int    `json:"tokens"`
	UpdatedAt string `json:"updatedAt"`
	Detected  bool   `json:"detected"` // true — найден по открытому окну браузера
	Max       int    `json:"max"`      // размер окна контекста модели
}

type FetchResult struct {
	OK        bool        `json:"ok"`
	Error     string      `json:"error,omitempty"`
	NeedKey   bool        `json:"needKey,omitempty"`
	OrgID     string      `json:"-"`
	Usage     []UsageItem `json:"usage"`
	Extra     *ExtraUsage `json:"extra,omitempty"`
	Chat      *ChatInfo   `json:"chat,omitempty"`
	ChatError string      `json:"chatError,omitempty"`
	FetchedAt string      `json:"fetchedAt"`
}

type ExtraUsage struct {
	Enabled bool     `json:"enabled"`
	Limit   *float64 `json:"limit"`
	Used    *float64 `json:"used"`
	Percent *float64 `json:"percent"`
}

func (a *claudeAPI) fetchAll(cfg *Config, active string) FetchResult {
	res := FetchResult{FetchedAt: time.Now().Format(time.RFC3339)}
	if cfg.SessionKey == "" {
		res.NeedKey = true
		res.Error = "Вставьте ключ в Настройках, чтобы увидеть свои лимиты."
		return res
	}
	orgID := cfg.OrgID
	if orgID == "" {
		o, err := a.pickOrg(cfg.SessionKey)
		if err != nil {
			res.Error = err.Error()
			return res
		}
		orgID = o.UUID
	}
	res.OrgID = orgID

	var raw map[string]json.RawMessage
	if err := a.get(cfg.SessionKey, "/api/organizations/"+url.PathEscape(orgID)+"/usage", &raw); err != nil {
		if e, ok := err.(*apiErr); ok && (e.Status == 401 || e.Status == 403) && !strings.Contains(e.Msg, "Cloudflare") {
			res.NeedKey = true
		}
		res.Error = err.Error()
		return res
	}
	for k, v := range raw {
		var item struct {
			Utilization *float64 `json:"utilization"`
			ResetsAt    *string  `json:"resets_at"`
			IsEnabled   *bool    `json:"is_enabled"`
			Monthly     *float64 `json:"monthly_limit"`
			Used        *float64 `json:"used_credits"`
		}
		if json.Unmarshal(v, &item) != nil {
			continue
		}
		if k == "extra_usage" {
			if item.IsEnabled != nil && *item.IsEnabled {
				res.Extra = &ExtraUsage{true, item.Monthly, item.Used, item.Utilization}
			}
			continue
		}
		if item.Utilization == nil {
			continue
		}
		ui := UsageItem{Key: k, Percent: *item.Utilization}
		if item.ResetsAt != nil {
			ui.ResetsAt = *item.ResetsAt
		}
		res.Usage = append(res.Usage, ui)
	}
	order := map[string]int{"five_hour": 0, "seven_day": 1, "seven_day_opus": 2, "seven_day_sonnet": 3}
	sort.Slice(res.Usage, func(i, j int) bool {
		oi, ok1 := order[res.Usage[i].Key]
		oj, ok2 := order[res.Usage[j].Key]
		if !ok1 {
			oi = 99
		}
		if !ok2 {
			oj = 99
		}
		if oi != oj {
			return oi < oj
		}
		return res.Usage[i].Key < res.Usage[j].Key
	})
	res.OK = true

	chat, err := a.findChat(cfg.SessionKey, orgID, active)
	if err != nil {
		res.ChatError = err.Error()
	} else {
		res.Chat = chat
	}
	return res
}

// fetchChatOnly — быстро обновить только чат (когда вы переключились на другой чат).
func (a *claudeAPI) fetchChatOnly(cfg *Config, active string) FetchResult {
	res := FetchResult{FetchedAt: time.Now().Format(time.RFC3339)}
	if cfg.SessionKey == "" || cfg.OrgID == "" {
		return res
	}
	chat, err := a.findChat(cfg.SessionKey, cfg.OrgID, active)
	if err != nil {
		res.ChatError = err.Error()
	} else {
		res.OK, res.Chat = true, chat
	}
	return res
}

// --- анализ текущего чата ---

type convSummary struct {
	UUID      string `json:"uuid"`
	Name      string `json:"name"`
	UpdatedAt string `json:"updated_at"`
	Model     string `json:"model"`
}

func norm(s string) string { return strings.ToLower(strings.Join(strings.Fields(s), " ")) }

func (a *claudeAPI) findChat(key, orgID, active string) (*ChatInfo, error) {
	var list []convSummary
	if err := a.get(key, "/api/organizations/"+url.PathEscape(orgID)+"/chat_conversations?limit=60", &list); err != nil {
		return nil, err
	}
	if len(list) == 0 {
		return nil, &apiErr{0, "Чатов пока нет."}
	}
	sort.Slice(list, func(i, j int) bool { return list[i].UpdatedAt > list[j].UpdatedAt })
	c, detected := list[0], false
	if n := norm(active); n != "" {
		for _, it := range list { // точное совпадение названия
			if norm(it.Name) == n {
				c, detected = it, true
				break
			}
		}
		if !detected && len([]rune(n)) >= 6 { // название в заголовке могло обрезаться
			for _, it := range list {
				m := norm(it.Name)
				if m != "" && (strings.HasPrefix(m, n) || strings.HasPrefix(n, m)) {
					c, detected = it, true
					break
				}
			}
		}
	}

	var conv struct {
		Name         string            `json:"name"`
		Model        string            `json:"model"`
		ChatMessages []json.RawMessage `json:"chat_messages"`
	}
	path := "/api/organizations/" + url.PathEscape(orgID) + "/chat_conversations/" + url.PathEscape(c.UUID) +
		"?tree=True&rendering_mode=messages&render_all_tools=true"
	if err := a.get(key, path, &conv); err != nil {
		return nil, err
	}
	info := &ChatInfo{Name: firstNonEmpty(conv.Name, c.Name, "Без названия"), UUID: c.UUID,
		Model: firstNonEmpty(conv.Model, c.Model), UpdatedAt: c.UpdatedAt, Messages: len(conv.ChatMessages),
		Detected: detected, Max: 200000}

	for _, m := range conv.ChatMessages {
		var msg struct {
			Text        string            `json:"text"`
			Content     []json.RawMessage `json:"content"`
			Attachments []struct {
				Extracted string `json:"extracted_content"`
			} `json:"attachments"`
			Files []json.RawMessage `json:"files"`
			FilesV2 []json.RawMessage `json:"files_v2"`
		}
		if json.Unmarshal(m, &msg) != nil {
			continue
		}
		if len(msg.Content) == 0 {
			info.Chars += len([]rune(msg.Text))
		}
		for _, blk := range msg.Content {
			var b struct {
				Type     string          `json:"type"`
				Text     string          `json:"text"`
				Thinking string          `json:"thinking"`
				Input    json.RawMessage `json:"input"`
				Content  json.RawMessage `json:"content"`
			}
			if json.Unmarshal(blk, &b) != nil {
				continue
			}
			switch b.Type {
			case "thinking":
				// размышления модели обычно не перечитываются в следующих ходах — не считаем
			case "tool_use":
				info.Chars += len([]rune(string(b.Input)))
			case "tool_result":
				info.Chars += len([]rune(string(b.Content))) / 2
			default:
				info.Chars += len([]rune(b.Text))
			}
		}
		for _, at := range msg.Attachments {
			info.Chars += len([]rune(at.Extracted))
		}
		n := len(msg.Files)
		if len(msg.FilesV2) > n {
			n = len(msg.FilesV2)
		}
		info.Files += n
	}
	// грубая оценка: ~3 символа на токен для смеси русского и английского,
	// + ~1500 токенов за каждую картинку/файл без извлечённого текста
	info.Tokens = info.Chars/3 + info.Files*1500
	return info, nil
}

func firstNonEmpty(s ...string) string {
	for _, v := range s {
		if strings.TrimSpace(v) != "" {
			return v
		}
	}
	return ""
}
