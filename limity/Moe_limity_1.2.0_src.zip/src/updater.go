//go:build windows

// Автообновление: программа проверяет файл updates/limity.json на GitHub (в репозитории МайМани),
// скачивает новый установщик, сверяет контрольную сумму и тихо ставит его поверх.
package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

// Где лежит описание последней версии. Сначала GitHub Pages, потом «сырой» файл из репозитория.
var updateManifestURLs = []string{
	"https://drakkkkon.github.io/maymani/updates/limity.json",
	"https://raw.githubusercontent.com/Drakkkkon/maymani/main/updates/limity.json",
}

type UpdateManifest struct {
	Version string   `json:"version"`
	URL     string   `json:"url"`
	SHA256  string   `json:"sha256"`
	Notes   []string `json:"notes"`
}

type UpdateState struct {
	Current   string   `json:"current"`
	Latest    string   `json:"latest"`
	Available bool     `json:"available"`
	Notes     []string `json:"notes"`
	Status    string   `json:"status"` // idle | checking | downloading | installing | uptodate | error
	Progress  int      `json:"progress"`
	Error     string   `json:"error"`
	CheckedAt string   `json:"checkedAt"`
}

type updater struct {
	mu       sync.Mutex
	st       UpdateState
	man      *UpdateManifest
	client   *http.Client
	onChange func(UpdateState)
	onQuit   func()
}

func newUpdater() *updater {
	return &updater{
		st:     UpdateState{Current: AppVersion, Status: "idle"},
		client: &http.Client{Timeout: 5 * time.Minute},
	}
}

func (u *updater) state() UpdateState { u.mu.Lock(); defer u.mu.Unlock(); return u.st }

func (u *updater) set(f func(s *UpdateState)) {
	u.mu.Lock()
	f(&u.st)
	s := u.st
	u.mu.Unlock()
	if u.onChange != nil {
		u.onChange(s)
	}
}

// «1.10.0» больше «1.9.3».
func newerVersion(a, b string) bool {
	pa, pb := strings.Split(strings.TrimPrefix(a, "v"), "."), strings.Split(strings.TrimPrefix(b, "v"), ".")
	for i := 0; i < len(pa) || i < len(pb); i++ {
		var x, y int
		if i < len(pa) {
			x, _ = strconv.Atoi(pa[i])
		}
		if i < len(pb) {
			y, _ = strconv.Atoi(pb[i])
		}
		if x != y {
			return x > y
		}
	}
	return false
}

func (u *updater) fetchManifest() (*UpdateManifest, error) {
	var lastErr error
	for _, url := range updateManifestURLs {
		req, _ := http.NewRequest("GET", url+"?t="+strconv.FormatInt(time.Now().Unix(), 10), nil)
		req.Header.Set("Cache-Control", "no-cache")
		req.Header.Set("User-Agent", "Moe_limity/"+AppVersion)
		resp, err := u.client.Do(req)
		if err != nil {
			lastErr = err
			continue
		}
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 64<<10))
		resp.Body.Close()
		if resp.StatusCode != 200 {
			lastErr = fmt.Errorf("сервер ответил %d", resp.StatusCode)
			continue
		}
		var m UpdateManifest
		if err := json.Unmarshal(body, &m); err != nil || m.Version == "" || m.URL == "" {
			lastErr = errors.New("файл с версией повреждён")
			continue
		}
		return &m, nil
	}
	return nil, lastErr
}

// Проверить, есть ли новая версия. Возвращает true, если есть.
func (u *updater) check() bool {
	s := u.state()
	if s.Status == "downloading" || s.Status == "installing" || s.Status == "checking" {
		return s.Available
	}
	u.set(func(s *UpdateState) { s.Status, s.Error = "checking", "" })
	m, err := u.fetchManifest()
	now := time.Now().Format(time.RFC3339)
	if err != nil {
		u.set(func(s *UpdateState) {
			s.Status, s.Error, s.CheckedAt = "error", "Не удалось проверить обновления: "+err.Error(), now
		})
		return false
	}
	avail := newerVersion(m.Version, AppVersion)
	u.mu.Lock()
	u.man = m
	u.mu.Unlock()
	u.set(func(s *UpdateState) {
		s.Latest, s.Available, s.Notes, s.CheckedAt = m.Version, avail, m.Notes, now
		if avail {
			s.Status = "idle"
		} else {
			s.Status = "uptodate"
		}
	})
	return avail
}

type progressWriter struct {
	total, done int64
	last        int
	cb          func(int)
}

func (p *progressWriter) Write(b []byte) (int, error) {
	p.done += int64(len(b))
	if p.total > 0 {
		if pc := int(p.done * 100 / p.total); pc != p.last {
			p.last = pc
			p.cb(pc)
		}
	}
	return len(b), nil
}

// Скачать установщик, проверить его и запустить тихую установку. Программа после этого закроется,
// а установщик сам запустит новую версию.
func (u *updater) install() {
	u.mu.Lock()
	m := u.man
	u.mu.Unlock()
	if m == nil || !newerVersion(m.Version, AppVersion) {
		return
	}
	s := u.state()
	if s.Status == "downloading" || s.Status == "installing" {
		return
	}
	fail := func(msg string) {
		u.set(func(s *UpdateState) { s.Status, s.Error, s.Progress = "error", msg, 0 })
	}
	u.set(func(s *UpdateState) { s.Status, s.Error, s.Progress = "downloading", "", 0 })

	req, _ := http.NewRequest("GET", m.URL, nil)
	req.Header.Set("User-Agent", "Moe_limity/"+AppVersion)
	resp, err := u.client.Do(req)
	if err != nil {
		fail("Не удалось скачать обновление: " + err.Error())
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		fail(fmt.Sprintf("Не удалось скачать обновление (ответ %d).", resp.StatusCode))
		return
	}
	dir := filepath.Join(os.TempDir(), "Moe_limity_update")
	_ = os.MkdirAll(dir, 0o700)
	path := filepath.Join(dir, "Moe_limity_Setup_"+m.Version+".exe")
	f, err := os.Create(path)
	if err != nil {
		fail("Не удалось сохранить обновление: " + err.Error())
		return
	}
	h := sha256.New()
	pw := &progressWriter{total: resp.ContentLength, cb: func(p int) {
		u.set(func(s *UpdateState) { s.Progress = p })
	}}
	_, err = io.Copy(io.MultiWriter(f, h, pw), io.LimitReader(resp.Body, 200<<20))
	f.Close()
	if err != nil {
		os.Remove(path)
		fail("Обновление скачалось не полностью. Попробуйте ещё раз.")
		return
	}
	if m.SHA256 != "" && !strings.EqualFold(hex.EncodeToString(h.Sum(nil)), strings.TrimSpace(m.SHA256)) {
		os.Remove(path)
		fail("Файл обновления не прошёл проверку — установка отменена.")
		return
	}

	u.set(func(s *UpdateState) { s.Status, s.Progress = "installing", 100 })
	cmd := exec.Command(path, "/S")
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	if err := cmd.Start(); err != nil {
		fail("Не удалось запустить установщик: " + err.Error())
		return
	}
	time.Sleep(700 * time.Millisecond)
	if u.onQuit != nil {
		u.onQuit()
	}
}

// Фоновая проверка: через 15 секунд после запуска и потом каждые 6 часов.
func (u *updater) loop(auto func() bool) {
	time.Sleep(15 * time.Second)
	for {
		if u.check() && auto() {
			u.install()
		}
		time.Sleep(6 * time.Hour)
	}
}

// Удалить скачанные установщики от прошлых обновлений.
func cleanupUpdates() {
	_ = os.RemoveAll(filepath.Join(os.TempDir(), "Moe_limity_update"))
}
