//go:build windows

// Мое_лимиты — маленький виджет для Windows 10/11:
// показывает лимиты Claude из вашего аккаунта, следит, в каком чате вы работаете,
// и подсказывает, когда начать новый чат.
package main

import (
	_ "embed"
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"

	webview2 "github.com/jchv/go-webview2"
)

const AppVersion = "1.2.0"
const windowTitle = "Мое_лимиты"

//go:embed ui.html
var uiHTML string

var (
	user32                  = syscall.NewLazyDLL("user32.dll")
	kernel32                = syscall.NewLazyDLL("kernel32.dll")
	procSetWindowPos        = user32.NewProc("SetWindowPos")
	procMessageBoxW         = user32.NewProc("MessageBoxW")
	procGetForegroundWindow = user32.NewProc("GetForegroundWindow")
	procGetWindowTextW      = user32.NewProc("GetWindowTextW")
	procFindWindowW         = user32.NewProc("FindWindowW")
	procShowWindow          = user32.NewProc("ShowWindow")
	procSetForegroundWindow = user32.NewProc("SetForegroundWindow")
	procCreateMutexW        = kernel32.NewProc("CreateMutexW")
)

func appDir() string {
	base, err := os.UserConfigDir() // %APPDATA%
	if err != nil {
		base = "."
	}
	d := filepath.Join(base, "Moe_limity")
	_ = os.MkdirAll(d, 0o700)
	return d
}

func messageBox(title, text string) {
	t, _ := syscall.UTF16PtrFromString(title)
	m, _ := syscall.UTF16PtrFromString(text)
	procMessageBoxW.Call(0, uintptr(unsafe.Pointer(m)), uintptr(unsafe.Pointer(t)), 0x40)
}

func setTopmost(hwnd unsafe.Pointer, on bool) {
	const swpNoSize, swpNoMove = 0x0001, 0x0002
	after := ^uintptr(1) // HWND_NOTOPMOST = -2
	if on {
		after = ^uintptr(0) // HWND_TOPMOST = -1
	}
	procSetWindowPos.Call(uintptr(hwnd), after, 0, 0, 0, 0, swpNoSize|swpNoMove)
}

func openURL(u string) {
	_ = exec.Command("rundll32", "url.dll,FileProtocolHandler", u).Start()
}

func foregroundTitle() string {
	h, _, _ := procGetForegroundWindow.Call()
	if h == 0 {
		return ""
	}
	buf := make([]uint16, 512)
	n, _, _ := procGetWindowTextW.Call(h, uintptr(unsafe.Pointer(&buf[0])), 512)
	return syscall.UTF16ToString(buf[:n])
}

// Из заголовка окна браузера («Название чата - Claude — Google Chrome») достаём название чата.
func chatNameFromTitle(t string) (string, bool) {
	t = strings.ReplaceAll(t, "​", "")
	for _, sep := range []string{" - Claude", " – Claude", " — Claude"} {
		if i := strings.Index(t, sep); i >= 0 {
			rest := t[i+len(sep):]
			// после «Claude» должен идти конец строки или хвост браузера, а не продолжение слова
			if rest == "" || strings.HasPrefix(rest, " ") {
				return strings.TrimSpace(t[:i]), true
			}
		}
	}
	return "", false
}

// Только одна копия программы: при повторном запуске показываем уже открытое окно.
func alreadyRunning() bool {
	name, _ := syscall.UTF16PtrFromString("Local\\Moe_limity_single")
	procCreateMutexW.Call(0, 0, uintptr(unsafe.Pointer(name)))
	if syscall.GetLastError() == syscall.ERROR_ALREADY_EXISTS {
		t, _ := syscall.UTF16PtrFromString(windowTitle)
		if h, _, _ := procFindWindowW.Call(0, uintptr(unsafe.Pointer(t))); h != 0 {
			procShowWindow.Call(h, 9) // SW_RESTORE
			procSetForegroundWindow.Call(h)
		}
		return true
	}
	return false
}

func main() {
	if alreadyRunning() {
		return
	}
	_, statErr := os.Stat(configPath())
	cfg := loadConfig()
	if cfg.SeenVersion == "" {
		if statErr != nil {
			cfg.SeenVersion = AppVersion // первая установка — «Что нового» не нужен
		} else {
			cfg.SeenVersion = "1.1.0" // обновились с версии без автообновления
		}
		saveConfig(cfg)
	}

	w := webview2.NewWithOptions(webview2.WebViewOptions{
		AutoFocus: true,
		DataPath:  filepath.Join(appDir(), "webview"),
		WindowOptions: webview2.WindowOptions{
			Title:  windowTitle,
			Width:  340,
			Height: 340,
			IconId: 1,
			Center: true,
		},
	})
	if w == nil {
		messageBox("Мое_лимиты", "Не найден компонент Microsoft Edge WebView2.\n\n"+
			"Установите его бесплатно с сайта Microsoft:\nhttps://developer.microsoft.com/microsoft-edge/webview2/\n\n"+
			"(На Windows 11 он обычно уже есть.)")
		openURL("https://developer.microsoft.com/microsoft-edge/webview2/")
		return
	}
	defer w.Destroy()
	w.SetSize(280, 220, webview2.HintMin)

	api := newClaudeAPI()

	// автообновление
	go func() { time.Sleep(time.Minute); cleanupUpdates() }()
	upd := newUpdater()
	upd.onChange = func(s UpdateState) {
		js, _ := json.Marshal(s)
		w.Dispatch(func() { w.Eval("window.onUpdate && window.onUpdate(" + string(js) + ")") })
	}
	upd.onQuit = func() { w.Dispatch(func() { w.Terminate() }) }
	go upd.loop(func() bool { return cfg.AutoUpdate })

	// какой чат открыт сейчас (по заголовку окна браузера)
	var mu sync.Mutex
	active := ""
	getActive := func() string { mu.Lock(); defer mu.Unlock(); return active }

	go func() {
		for {
			time.Sleep(1500 * time.Millisecond)
			name, ok := chatNameFromTitle(foregroundTitle())
			if !ok {
				continue
			}
			mu.Lock()
			changed := name != active
			active = name
			mu.Unlock()
			if changed {
				js, _ := json.Marshal(name)
				w.Dispatch(func() { w.Eval("window.onActiveChat && window.onActiveChat(" + string(js) + ")") })
			}
		}
	}()

	w.Bind("getConfig", func() string {
		b, _ := json.Marshal(cfg.public())
		return string(b)
	})

	w.Bind("saveSettings", func(refreshMin int, theme string, topmost bool) string {
		if refreshMin < 1 {
			refreshMin = 1
		}
		cfg.RefreshMin, cfg.Theme, cfg.Topmost = refreshMin, theme, topmost
		saveConfig(cfg)
		hwnd := w.Window()
		w.Dispatch(func() { setTopmost(hwnd, topmost) })
		return "ok"
	})

	w.Bind("setKey", func(key string) string {
		res := api.checkKey(key)
		if res.OK {
			cfg.SessionKey = strings.TrimPrefix(strings.TrimSpace(key), "sessionKey=")
			cfg.OrgID, cfg.OrgName = res.OrgID, res.OrgName
			saveConfig(cfg)
		}
		b, _ := json.Marshal(res)
		return string(b)
	})

	w.Bind("forgetKey", func() string {
		cfg.SessionKey, cfg.OrgID, cfg.OrgName = "", "", ""
		saveConfig(cfg)
		return "ok"
	})

	w.Bind("fetchAll", func() string {
		out := api.fetchAll(cfg, getActive())
		if out.OrgID != "" && out.OrgID != cfg.OrgID {
			cfg.OrgID = out.OrgID
			saveConfig(cfg)
		}
		b, _ := json.Marshal(out)
		return string(b)
	})

	w.Bind("fetchChat", func() string {
		out := api.fetchChatOnly(cfg, getActive())
		b, _ := json.Marshal(out)
		return string(b)
	})

	w.Bind("setAutoUpdate", func(on bool) string {
		cfg.AutoUpdate = on
		saveConfig(cfg)
		return "ok"
	})

	w.Bind("updateState", func() string {
		b, _ := json.Marshal(upd.state())
		return string(b)
	})

	// проверить сейчас; если есть новая версия и включено автообновление — сразу поставить
	w.Bind("checkUpdate", func() string {
		go func() {
			if upd.check() && cfg.AutoUpdate {
				upd.install()
			}
		}()
		return "ok"
	})

	w.Bind("installUpdate", func() string {
		go func() {
			if upd.state().Latest == "" {
				upd.check()
			}
			upd.install()
		}()
		return "ok"
	})

	// «Что нового» показали — запомнить
	w.Bind("newsSeen", func() string {
		cfg.SeenVersion = AppVersion
		saveConfig(cfg)
		return "ok"
	})

	w.Bind("openURL", func(u string) string { openURL(u); return "ok" })

	w.SetHtml(uiHTML)
	if cfg.Topmost {
		setTopmost(w.Window(), true)
	}
	w.Run()
}
