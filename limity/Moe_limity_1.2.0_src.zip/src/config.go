//go:build windows

package main

import (
	"encoding/base64"
	"encoding/json"
	"os"
	"path/filepath"
	"unsafe"

	"golang.org/x/sys/windows"
)

type Config struct {
	SessionKeyEnc string `json:"session_key_enc"` // ключ, зашифрованный средствами Windows (DPAPI)
	OrgID         string `json:"org_id"`
	OrgName       string `json:"org_name"`
	RefreshMin    int    `json:"refresh_min"`
	Theme         string `json:"theme"` // auto | light | dark
	Topmost       bool   `json:"topmost"`
	AutoUpdate    bool   `json:"auto_update"`  // ставить обновления сами
	SeenVersion   string `json:"seen_version"` // версия, для которой уже показали «Что нового»

	SessionKey string `json:"-"`
}

type PublicConfig struct {
	HasKey     bool   `json:"hasKey"`
	OrgName    string `json:"orgName"`
	RefreshMin int    `json:"refreshMin"`
	Theme      string `json:"theme"`
	Topmost    bool   `json:"topmost"`
	Version    string `json:"version"`
	AutoUpdate bool   `json:"autoUpdate"`
	ShowNews   bool   `json:"showNews"`
}

func (c *Config) public() PublicConfig {
	return PublicConfig{c.SessionKey != "", c.OrgName, c.RefreshMin, c.Theme, c.Topmost, AppVersion,
		c.AutoUpdate, c.SeenVersion != "" && c.SeenVersion != AppVersion}
}

func configPath() string { return filepath.Join(appDir(), "config.json") }

func loadConfig() *Config {
	c := &Config{RefreshMin: 3, Theme: "auto", Topmost: true, AutoUpdate: true}
	if b, err := os.ReadFile(configPath()); err == nil {
		_ = json.Unmarshal(b, c)
	}
	if c.SessionKeyEnc != "" {
		c.SessionKey = unprotect(c.SessionKeyEnc)
	}
	if c.RefreshMin < 1 {
		c.RefreshMin = 3
	}
	return c
}

func saveConfig(c *Config) {
	c.SessionKeyEnc = ""
	if c.SessionKey != "" {
		c.SessionKeyEnc = protect(c.SessionKey)
	}
	b, _ := json.MarshalIndent(c, "", "  ")
	_ = os.WriteFile(configPath(), b, 0o600)
}

// DPAPI: расшифровать ключ сможет только ваш пользователь Windows на этом компьютере.
func protect(s string) string {
	in := windows.DataBlob{Size: uint32(len(s)), Data: unsafe.SliceData([]byte(s))}
	var out windows.DataBlob
	if err := windows.CryptProtectData(&in, nil, nil, 0, nil, 0, &out); err != nil {
		return ""
	}
	defer windows.LocalFree(windows.Handle(unsafe.Pointer(out.Data)))
	return base64.StdEncoding.EncodeToString(unsafe.Slice(out.Data, out.Size))
}

func unprotect(enc string) string {
	raw, err := base64.StdEncoding.DecodeString(enc)
	if err != nil || len(raw) == 0 {
		return ""
	}
	in := windows.DataBlob{Size: uint32(len(raw)), Data: &raw[0]}
	var out windows.DataBlob
	if err := windows.CryptUnprotectData(&in, nil, nil, 0, nil, 0, &out); err != nil {
		return ""
	}
	defer windows.LocalFree(windows.Handle(unsafe.Pointer(out.Data)))
	return string(unsafe.Slice(out.Data, out.Size))
}
