const books = [
    { id: 1, title: "Мастер и Маргарита", author: "Михаил Булгаков", price: "2500 ₸" },
    { id: 2, title: "Преступление и наказание", author: "Федор Достоевский", price: "2000 ₸" },
    { id: 3, title: "1984", author: "Джордж Оруэлл", price: "3000 ₸" },
    { id: 4, title: "Граф Монте-Кристо", author: "Александр Дюма", price: "4500 ₸" }
];

let cart = [];

function switchTab(tab, event) {
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    if(event) {
        event.currentTarget.classList.add('active');
    }
    
    const content = document.getElementById('app-content');
    content.innerHTML = '';

    if (tab === 'home') {
        content.innerHTML = `
            <div class="container">
                <div class="welcome-card">
                    <h2>Добро пожаловать в Букинист!</h2>
                    <p style="margin-top:10px; color:#666;">Ваш личный каталог книг. Здесь вы можете найти, выбрать и заказать интересующую вас литературу.</p>
                </div>
            </div>
        `;
    } else if (tab === 'catalog') {
        let html = '<div class="container">';
        books.forEach(book => {
            html += `
                <div class="book-card">
                    <div class="book-info">
                        <div class="book-title">${book.title}</div>
                        <div class="book-author">${book.author}</div>
                        <div class="book-price">${book.price}</div>
                    </div>
                    <button class="buy-btn" onclick="addToCart(${book.id})">В корзину</button>
                </div>
            `;
        });
        html += '</div>';
        content.innerHTML = html;
    } else if (tab === 'cart') {
        if (cart.length === 0) {
            content.innerHTML = '<div class="container"><div class="welcome-card">Ваша корзина пуста</div></div>';
        } else {
            let html = '<div class="container"><h2>Ваша корзина</h2><br>';
            cart.forEach(item => {
                html += `
                    <div class="book-card" style="align-items: center;">
                        <div class="book-info">
                            <div class="book-title">${item.title}</div>
                            <div class="book-price">${item.price}</div>
                        </div>
                    </div>
                `;
            });
            html += '</div>';
            content.innerHTML = html;
        }
    }
}

function addToCart(id) {
    const book = books.find(b => b.id === id);
    cart.push(book);
    alert(`Книга "${book.title}" добавлена в корзину!`);
}

window.onload = () => switchTab('home');
