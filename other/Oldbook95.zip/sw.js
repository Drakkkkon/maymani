// Service worker Oldbook 95: свежие файлы из сети, без интернета — из кэша. Внешних запросов у приложения нет.
const CACHE = 'oldbook95-v1';
const CORE = [
    './', 'index.html', 'manifest.webmanifest',
    'css/win95.css', 'css/oldbook.css',
    'js/util.js', 'js/store.js', 'js/win95.js', 'js/charts.js', 'js/form.js', 'js/history.js', 'js/stats.js', 'js/share.js', 'js/app.js',
    'images/icon-192.png', 'images/icon-512.png'
];

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE)
            .then(cache => Promise.all(CORE.map(url => cache.add(new Request(url, { cache: 'reload' })).catch(() => null))))
            .then(() => self.skipWaiting())
    );
});

self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', event => {
    const req = event.request;
    if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
    event.respondWith(
        fetch(req).then(res => {
            if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
            return res;
        }).catch(() => caches.match(req).then(hit => hit || caches.match('index.html')))
    );
});
