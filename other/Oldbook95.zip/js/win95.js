// --- OLDBOOK 95: ОКНА, ДИАЛОГИ, МЕНЮ, ПАНЕЛЬ ЗАДАЧ ---
// Всё нарисовано HTML и CSS (css/win95.css). Здесь только поведение.

OB.ui = (function () {
    const esc = OB.esc;

    // ---------- перетаскивание окна за заголовок ----------
    function makeDraggable(win, handle, canDrag) {
        handle.addEventListener('pointerdown', e => {
            if (e.button !== 0 || e.target.closest('.tb-btn')) return;
            if (canDrag && !canDrag()) return;
            const r = win.getBoundingClientRect();
            const dx = e.clientX - r.left, dy = e.clientY - r.top;
            try { handle.setPointerCapture(e.pointerId); } catch (err) {}
            const move = ev => {
                const maxX = window.innerWidth - 60, maxY = window.innerHeight - 70;
                win.style.left = Math.max(-r.width + 80, Math.min(maxX, ev.clientX - dx)) + 'px';
                win.style.top = Math.max(0, Math.min(maxY, ev.clientY - dy)) + 'px';
            };
            const up = () => {
                handle.removeEventListener('pointermove', move);
                handle.removeEventListener('pointerup', up);
                handle.removeEventListener('pointercancel', up);
            };
            handle.addEventListener('pointermove', move);
            handle.addEventListener('pointerup', up);
            handle.addEventListener('pointercancel', up);
        });
    }

    // ---------- диалоги ----------
    // dialog({ title, icon, text | html | node, buttons: [{ label, value, default, cancel }], width, onOpen })
    // → Promise со значением нажатой кнопки (Esc — кнопка с cancel: true)
    function dialog(opt) {
        return new Promise(resolve => {
            const layer = document.createElement('div');
            layer.className = 'modal-layer';
            const win = document.createElement('div');
            win.className = 'window dialog';
            win.setAttribute('role', 'dialog');
            win.setAttribute('aria-modal', 'true');
            win.setAttribute('aria-label', opt.title || 'Oldbook');
            if (opt.width) win.style.width = Math.min(opt.width, window.innerWidth - 12) + 'px';
            const buttons = opt.buttons && opt.buttons.length ? opt.buttons : [{ label: 'ОК', value: true, default: true, cancel: true }];
            win.innerHTML =
                `<div class="titlebar"><span class="tb-icon">${OB.icons.book}</span><span class="tb-title">${esc(opt.title || 'Oldbook')}</span>` +
                `<span class="tb-btns"><button type="button" class="tb-btn close" aria-label="Закрыть"></button></span></div>` +
                `<div class="window-body">` +
                `<div class="dlg-body">${opt.icon ? `<div class="dlg-icon">${OB.icons[opt.icon] || ''}</div>` : ''}` +
                `<div class="dlg-text">${opt.html != null ? opt.html : esc(opt.text || '')}</div></div>` +
                `<div class="dlg-extra"></div>` +
                `<div class="dlg-buttons">${buttons.map((b, i) => `<button type="button" class="btn${b.default ? ' default' : ''}" data-i="${i}">${esc(b.label)}</button>`).join('')}</div>` +
                `</div>`;
            layer.appendChild(win);
            document.body.appendChild(layer);
            if (opt.node) win.querySelector('.dlg-extra').appendChild(opt.node);

            // по центру
            const r = win.getBoundingClientRect();
            win.style.left = Math.max(4, (window.innerWidth - r.width) / 2) + 'px';
            win.style.top = Math.max(4, Math.min((window.innerHeight - r.height) / 2 - 20, window.innerHeight - r.height - 50)) + 'px';
            makeDraggable(win, win.querySelector('.titlebar'));

            const prevFocus = document.activeElement;
            let done = false;
            const finish = value => {
                if (done) return;
                done = true;
                document.removeEventListener('keydown', onKey, true);
                layer.remove();
                if (prevFocus && prevFocus.focus) { try { prevFocus.focus(); } catch (e) {} }
                resolve(value);
            };
            const cancelBtn = buttons.find(b => b.cancel);
            const onKey = e => {
                // работаем только если этот диалог — самый верхний
                const layers = document.querySelectorAll('.modal-layer');
                if (layers[layers.length - 1] !== layer) return;
                if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(cancelBtn ? cancelBtn.value : null); }
                else if (e.key === 'Enter' && !(e.target && e.target.tagName === 'TEXTAREA') && !(e.target && e.target.tagName === 'BUTTON')) {
                    const def = buttons.find(b => b.default);
                    if (def) { e.preventDefault(); finish(def.value); }
                }
            };
            document.addEventListener('keydown', onKey, true);
            win.querySelector('.dlg-buttons').addEventListener('click', e => {
                const b = e.target.closest('button[data-i]');
                if (b) finish(buttons[+b.dataset.i].value);
            });
            win.querySelector('.tb-btn.close').addEventListener('click', () => finish(cancelBtn ? cancelBtn.value : null));
            // клик мимо диалога — «звуковой сигнал» вместо закрытия, как в Windows: просто подсвечиваем заголовок
            layer.addEventListener('pointerdown', e => { if (e.target === layer) { win.classList.add('inactive'); setTimeout(() => win.classList.remove('inactive'), 120); } });

            if (opt.onOpen) opt.onOpen(win, finish);
            const focusEl = win.querySelector('.dlg-extra input, .dlg-extra textarea, .dlg-extra select') || win.querySelector('.btn.default') || win.querySelector('.btn');
            if (focusEl) setTimeout(() => { try { focusEl.focus(); if (focusEl.select && focusEl.tagName === 'INPUT') focusEl.select(); } catch (e) {} }, 0);
        });
    }

    const alert = (text, o) => dialog({ title: (o && o.title) || 'Oldbook', icon: (o && o.icon) || 'info', text, buttons: [{ label: 'ОК', value: true, default: true, cancel: true }] });

    // Да / Нет (по умолчанию «Нет», если danger)
    const confirm = (text, o) => {
        o = o || {};
        return dialog({
            title: o.title || 'Oldbook', icon: o.icon || 'question', text,
            buttons: [
                { label: o.yes || 'Да', value: true, default: !o.danger },
                { label: o.no || 'Нет', value: false, default: !!o.danger, cancel: true }
            ]
        });
    };

    // Строка ввода → строка или null
    const prompt = (text, value, o) => {
        o = o || {};
        const input = document.createElement('input');
        input.type = 'text';
        input.value = value || '';
        input.maxLength = o.maxlength || 60;
        if (o.placeholder) input.placeholder = o.placeholder;
        return dialog({
            title: o.title || 'Oldbook', icon: o.icon || 'question', text, node: input,
            buttons: [{ label: 'ОК', value: '__ok', default: true }, { label: 'Отмена', value: null, cancel: true }],
            onOpen: (win, finish) => {
                input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); finish('__ok'); } });
            }
        }).then(v => (v === '__ok' ? input.value : null));
    };

    // Выбор из нескольких кнопок → value
    const choose = (text, buttons, o) => dialog({ title: (o && o.title) || 'Oldbook', icon: (o && o.icon) || 'question', text, buttons, width: (o && o.width) || 380 });

    // ---------- меню ----------
    let openMenu = null;
    function closeMenus() {
        if (openMenu) {
            if (openMenu.drop) openMenu.drop.remove();
            if (openMenu.btn) openMenu.btn.classList.remove('open');
            openMenu = null;
        }
    }
    document.addEventListener('pointerdown', e => {
        if (openMenu && !e.target.closest('.menu-drop') && !(openMenu.btn && openMenu.btn.contains(e.target))) closeMenus();
    }, true);
    window.addEventListener('blur', closeMenus);

    // items: [{ label, icon, key, action, disabled, hidden }] или '-' — разделитель
    function buildMenu(menubar, menus) {
        menubar.innerHTML = '';
        menus.forEach(m => {
            const b = document.createElement('button');
            b.type = 'button';
            b.innerHTML = esc(m.label).replace(m.mnemonic ? m.mnemonic : '\u0000', c => `<u>${c}</u>`);
            b.setAttribute('aria-haspopup', 'true');
            const show = () => {
                closeMenus();
                const items = (typeof m.items === 'function' ? m.items() : m.items).filter(i => i === '-' || !i.hidden);
                const drop = document.createElement('div');
                drop.className = 'menu-drop';
                drop.setAttribute('role', 'menu');
                drop.innerHTML = items.map((i, n) => i === '-' ? '<hr>' :
                    `<button type="button" role="menuitem" data-n="${n}"${i.disabled ? ' disabled' : ''}>` +
                    `<span class="mi-icon">${i.icon ? OB.icons[i.icon] || '' : ''}</span><span>${esc(i.label)}</span>${i.key ? `<span class="mi-key">${esc(i.key)}</span>` : ''}</button>`).join('');
                document.body.appendChild(drop);
                const r = b.getBoundingClientRect();
                drop.style.left = Math.min(r.left, window.innerWidth - drop.offsetWidth - 2) + 'px';
                drop.style.top = r.bottom + 'px';
                b.classList.add('open');
                openMenu = { drop, btn: b };
                drop.addEventListener('click', e => {
                    const it = e.target.closest('button[data-n]');
                    if (!it || it.disabled) return;
                    const item = items[+it.dataset.n];
                    closeMenus();
                    if (item && item.action) item.action();
                });
            };
            b.addEventListener('click', () => { if (openMenu && openMenu.btn === b) closeMenus(); else show(); });
            b.addEventListener('pointerenter', () => { if (openMenu && openMenu.btn !== b) show(); });
            menubar.appendChild(b);
        });
    }

    // ---------- главное окно ----------
    // Заголовок, три кнопки, перетаскивание, «развернуть», «свернуть» и «закрыть» (значок остаётся на рабочем столе)
    function appWindow(win, hooks) {
        const state = { minimized: false, closed: false };
        const titlebar = win.querySelector('.titlebar');
        const setActive = on => { win.classList.toggle('inactive', !on); hooks.onActive && hooks.onActive(on); };

        function layout() {
            // стартовый размер и положение
            const vw = window.innerWidth, vh = window.innerHeight;
            const small = vw <= 720;
            win.classList.toggle('maximized', small || win.dataset.userMax === '1');
            if (!small && win.dataset.userMax !== '1' && !win.dataset.placed) {
                const w = Math.min(1000, vw - 40), h = Math.min(780, vh - parseInt(getComputedStyle(document.documentElement).getPropertyValue('--taskbar-h')) - 60);
                win.style.width = w + 'px'; win.style.height = h + 'px';
                win.style.left = Math.max(0, Math.round((vw - w) / 2) + 30) + 'px';
                win.style.top = '20px';
                win.dataset.placed = '1';
            }
        }
        function toggleMax() {
            if (window.innerWidth <= 720) return;
            win.dataset.userMax = win.classList.contains('maximized') ? '0' : '1';
            win.classList.toggle('maximized');
            hooks.onResize && hooks.onResize();
        }
        function minimize() {
            state.minimized = true;
            win.classList.add('minimized');
            hooks.onState && hooks.onState(state);
        }
        function restore() {
            state.minimized = false; state.closed = false;
            win.hidden = false;
            win.classList.remove('minimized');
            setActive(true);
            hooks.onState && hooks.onState(state);
            hooks.onResize && hooks.onResize();
        }
        function close() {
            state.closed = true; state.minimized = false;
            win.hidden = true;
            hooks.onState && hooks.onState(state);
        }
        titlebar.querySelector('.tb-btn.min').addEventListener('click', minimize);
        titlebar.querySelector('.tb-btn.max').addEventListener('click', toggleMax);
        titlebar.querySelector('.tb-btn.close').addEventListener('click', close);
        titlebar.addEventListener('dblclick', e => { if (!e.target.closest('.tb-btn')) toggleMax(); });
        makeDraggable(win, titlebar, () => !win.classList.contains('maximized'));
        win.addEventListener('pointerdown', () => setActive(true), true);
        window.addEventListener('resize', () => { layout(); hooks.onResize && hooks.onResize(); });
        layout();
        return { state, minimize, restore, close, toggleMax, layout, setActive };
    }

    // ---------- Пуск и часы ----------
    function startMenu(btn, items) {
        let menu = null;
        function close() { if (menu) { menu.remove(); menu = null; btn.classList.remove('open'); } }
        function open() {
            closeMenus();
            menu = document.createElement('div');
            menu.className = 'start-menu';
            menu.innerHTML = `<div class="start-banner"><span><b>Oldbook</b> <i>95</i></span></div><div class="start-items">` +
                items().map((i, n) => i === '-' ? '<hr>' :
                    `<button type="button" data-n="${n}"${i.disabled ? ' disabled' : ''}><span class="mi-icon">${OB.icons[i.icon] || ''}</span><span>${esc(i.label)}</span></button>`).join('') + `</div>`;
            document.body.appendChild(menu);
            menu.style.bottom = (btn.parentElement.getBoundingClientRect().height) + 'px';
            btn.classList.add('open');
            const list = items();
            menu.addEventListener('click', e => {
                const it = e.target.closest('button[data-n]');
                if (!it || it.disabled) return;
                const item = list[+it.dataset.n];
                close();
                if (item && item.action) item.action();
            });
        }
        btn.addEventListener('click', e => { e.stopPropagation(); if (menu) close(); else open(); });
        document.addEventListener('pointerdown', e => { if (menu && !menu.contains(e.target) && !btn.contains(e.target)) close(); }, true);
        document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
        window.addEventListener('blur', close);
    }

    function clock(el) {
        const tick = () => {
            el.textContent = OB.clockText();
            el.title = OB.fmtDate(OB.nowIso()) + ' (Алматы)';
        };
        tick();
        setInterval(tick, 15000);
    }

    return { dialog, alert, confirm, prompt, choose, buildMenu, closeMenus, appWindow, startMenu, clock, makeDraggable };
})();
