// --- OLDBOOK 95: ОБЩИЕ ПОМОЩНИКИ ---
// Всё приложение живёт в одном объекте window.OB. Скрипты обычные (не модули), чтобы index.html открывался
// двойным щелчком из папки, без сервера.

window.OB = window.OB || {};

OB.VERSION = '1.0.0';
OB.CURRENCY = '₸';
OB.COMMENT_MAX = 100;
OB.ALMATY_UTC_OFFSET_HOURS = 5; // Казахстан живёт по UTC+5 без перехода на летнее время

OB.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
};

OB.money = function (v) {
    return Number(v || 0).toLocaleString('ru-RU', { maximumFractionDigits: 2 });
};

// «2026-11-03T13:15» по времени Алматы; shiftDays сдвигает на сутки
OB.nowIso = function (shiftDays) {
    return new Date(Date.now() + OB.ALMATY_UTC_OFFSET_HOURS * 3600000 + (shiftDays || 0) * 86400000).toISOString().slice(0, 16);
};

OB.clockText = function () {
    return OB.nowIso().slice(11, 16);
};

OB.fmtDate = function (iso) {
    const d = String(iso || '').slice(0, 10).split('-');
    return d.length === 3 ? `${d[2]}.${d[1]}.${d[0]}` : String(iso || '');
};

OB.fmtDateTime = function (iso) {
    const s = String(iso || '');
    return OB.fmtDate(s) + (s.length >= 16 ? ' ' + s.slice(11, 16) : '');
};

// Латиница для имён файлов: «Катя» → «Katya» (кириллица в имени файла не везде сохраняется одинаково)
OB.translit = function (s) {
    const m = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya', ә: 'a', ғ: 'g', қ: 'k', ң: 'n', ө: 'o', ұ: 'u', ү: 'u', һ: 'h', і: 'i' };
    return String(s || '').toLowerCase().split('').map(c => (c in m ? m[c] : c)).join('').replace(/^./, c => c.toUpperCase());
};

OB.uid = function (prefix) {
    return (prefix || 'ob') + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
};

OB.$ = function (sel, root) { return (root || document).querySelector(sel); };
OB.$$ = function (sel, root) { return Array.from((root || document).querySelectorAll(sel)); };

// Простая шина событий: OB.on('change', fn) / OB.emit('change')
OB._handlers = {};
OB.on = function (name, fn) { (OB._handlers[name] = OB._handlers[name] || []).push(fn); };
OB.emit = function (name, arg) {
    (OB._handlers[name] || []).slice().forEach(fn => { try { fn(arg); } catch (e) { console.error('OB.emit ' + name, e); } });
};

// Короткие SVG-значки 16×16 / 32×32 в духе Windows 95 (рисунок «пикселями», без картинок)
OB.icons = {
    book: '<svg viewBox="0 0 32 32" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="3" width="22" height="26" fill="#000080"/><rect x="6" y="3" width="20" height="24" fill="#1084d0"/><rect x="8" y="5" width="16" height="6" fill="#ffffff"/><rect x="10" y="7" width="12" height="2" fill="#000080"/><rect x="8" y="13" width="16" height="2" fill="#c0c0c0"/><rect x="8" y="17" width="16" height="2" fill="#c0c0c0"/><rect x="8" y="21" width="10" height="2" fill="#c0c0c0"/><rect x="4" y="3" width="2" height="26" fill="#000040"/><rect x="26" y="5" width="2" height="24" fill="#ffffff"/><rect x="6" y="27" width="22" height="2" fill="#ffffff"/></svg>',
    info: '<svg viewBox="0 0 32 32" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><circle cx="16" cy="16" r="14" fill="#0000ff" stroke="#000080" stroke-width="2"/><rect x="14" y="7" width="4" height="4" fill="#fff"/><rect x="14" y="13" width="4" height="12" fill="#fff"/></svg>',
    warn: '<svg viewBox="0 0 32 32" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><path d="M16 2 L30 29 H2 Z" fill="#ffff00" stroke="#000" stroke-width="2" stroke-linejoin="miter"/><rect x="14" y="10" width="4" height="10" fill="#000"/><rect x="14" y="22" width="4" height="4" fill="#000"/></svg>',
    error: '<svg viewBox="0 0 32 32" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><circle cx="16" cy="16" r="14" fill="#ff0000" stroke="#800000" stroke-width="2"/><path d="M10 10 L22 22 M22 10 L10 22" stroke="#fff" stroke-width="4"/></svg>',
    question: '<svg viewBox="0 0 32 32" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><circle cx="16" cy="16" r="14" fill="#ffffff" stroke="#000080" stroke-width="2"/><path d="M11 12 q0 -6 6 -6 q6 0 6 5 q0 3 -4 5 q-2 1 -2 4" fill="none" stroke="#000080" stroke-width="3"/><rect x="14" y="24" width="4" height="4" fill="#000080"/></svg>',
    floppy: '<svg viewBox="0 0 16 16" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect x="1" y="1" width="14" height="14" fill="#000080"/><rect x="4" y="1" width="8" height="5" fill="#c0c0c0"/><rect x="9" y="2" width="2" height="3" fill="#000080"/><rect x="3" y="9" width="10" height="6" fill="#ffffff"/></svg>',
    folder: '<svg viewBox="0 0 16 16" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect x="1" y="3" width="6" height="2" fill="#808000"/><rect x="1" y="5" width="14" height="9" fill="#ffff00" stroke="#808000"/></svg>',
    plus: '<svg viewBox="0 0 16 16" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect x="7" y="3" width="2" height="10" fill="#008000"/><rect x="3" y="7" width="10" height="2" fill="#008000"/></svg>',
    chart: '<svg viewBox="0 0 16 16" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="9" width="3" height="5" fill="#000080"/><rect x="6" y="4" width="3" height="10" fill="#800000"/><rect x="10" y="7" width="3" height="7" fill="#008000"/><rect x="1" y="14" width="14" height="1" fill="#000"/></svg>',
    list: '<svg viewBox="0 0 16 16" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="2" width="12" height="12" fill="#fff" stroke="#000"/><rect x="4" y="5" width="8" height="1" fill="#000"/><rect x="4" y="8" width="8" height="1" fill="#000"/><rect x="4" y="11" width="8" height="1" fill="#000"/></svg>',
    people: '<svg viewBox="0 0 16 16" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="2" width="4" height="4" fill="#ffcc99" stroke="#000"/><rect x="2" y="7" width="6" height="6" fill="#000080"/><rect x="9" y="4" width="4" height="4" fill="#ffcc99" stroke="#000"/><rect x="8" y="9" width="6" height="5" fill="#800000"/></svg>',
    flag: '<svg viewBox="0 0 16 16" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><path d="M2 3 h5 v4 h-5 z" fill="#f00"/><path d="M8 3 h6 v4 h-6 z" fill="#0a0"/><path d="M2 8 h5 v4 h-5 z" fill="#00f"/><path d="M8 8 h6 v4 h-6 z" fill="#fc0"/></svg>',
    help: '<svg viewBox="0 0 16 16" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="1" width="12" height="14" fill="#ffffcc" stroke="#000"/><path d="M6 6 q0 -2 2 -2 q2 0 2 2 q0 1 -2 2 v1" fill="none" stroke="#000" stroke-width="1.5"/><rect x="7" y="11" width="2" height="2"/></svg>',
    power: '<svg viewBox="0 0 16 16" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="3" width="12" height="8" fill="#808080" stroke="#000"/><rect x="3" y="4" width="10" height="6" fill="#008080"/><rect x="5" y="12" width="6" height="2" fill="#c0c0c0" stroke="#000"/></svg>'
};
