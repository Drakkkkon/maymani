// --- OLDBOOK 95: ДИАГРАММЫ ---
// Рисуются прямо на canvas, без библиотек и без интернета: чёрные рамки, цвета как в палитре VGA.
// Подписи значений — в легенде, поэтому всплывающие подсказки не нужны.

OB.charts = (function () {
    const FONT = '12px Tahoma, "MS Sans Serif", "Segoe UI", "Liberation Sans", Arial, sans-serif';
    const PERSON_COLORS = { 'Катя': '#800080', 'Папа': '#000080', 'Саша': '#008080', 'Вы': '#404040' };
    const EXTRA_COLORS = ['#806000', '#800000', '#006000', '#4b0082', '#8b4513', '#2f4f4f'];
    const INCOME = '#008000', EXPENSE = '#d00000';

    function personColor(label, labels) {
        if (PERSON_COLORS[label]) return PERSON_COLORS[label];
        const i = Math.max(0, (labels || []).indexOf(label));
        return EXTRA_COLORS[i % EXTRA_COLORS.length];
    }

    // Холст под размер блока и плотность экрана; возвращает контекст в «обычных» пикселях
    function prepare(canvas) {
        const dpr = window.devicePixelRatio || 1;
        const w = Math.max(160, Math.round(canvas.clientWidth || 300));
        const h = Math.max(120, Math.round(canvas.clientHeight || 240));
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
        const ctx = canvas.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, w, h);
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, w, h);
        ctx.font = FONT;
        ctx.textBaseline = 'middle';
        return { ctx, w, h };
    }

    function fit(ctx, text, maxW) {
        if (ctx.measureText(text).width <= maxW) return text;
        let t = text;
        while (t.length > 1 && ctx.measureText(t + '…').width > maxW) t = t.slice(0, -1);
        return t + '…';
    }

    // Легенда внизу: квадратик + подпись, переносится на новые строки. Возвращает высоту
    function legend(ctx, w, y0, items) {
        let x = 8, y = y0;
        const rowH = 16;
        items.forEach(it => {
            const label = it.text;
            const tw = ctx.measureText(label).width;
            if (x + 14 + tw > w - 6 && x > 8) { x = 8; y += rowH; }
            ctx.fillStyle = it.color; ctx.fillRect(x, y - 5, 10, 10);
            ctx.strokeStyle = '#000'; ctx.lineWidth = 1; ctx.strokeRect(x + 0.5, y - 4.5, 9, 9);
            ctx.fillStyle = '#000'; ctx.textAlign = 'left';
            ctx.fillText(label, x + 14, y);
            x += 14 + tw + 12;
        });
        return y + rowH - y0;
    }

    function legendHeight(ctx, w, items) {
        let x = 8, rows = 1;
        items.forEach(it => {
            const tw = ctx.measureText(it.text).width;
            if (x + 14 + tw > w - 6 && x > 8) { x = 8; rows++; }
            x += 14 + tw + 12;
        });
        return rows * 16 + 4;
    }

    function noData(ctx, w, h, text) {
        ctx.fillStyle = '#808080'; ctx.textAlign = 'center';
        ctx.fillText(text || 'Нет данных', w / 2, h / 2);
    }

    // 1) Кружок: кто сколько потратил. items: [{ label, value, color }]
    function doughnut(canvas, items) {
        const { ctx, w, h } = prepare(canvas);
        const total = items.reduce((s, i) => s + i.value, 0);
        const leg = items.map(i => ({ color: i.color, text: `${i.label} — ${OB.money(i.value)} ${OB.CURRENCY}` }));
        const lh = total > 0 ? legendHeight(ctx, w, leg) : 0;
        const cx = w / 2, cy = (h - lh) / 2 + 2;
        const R = Math.max(30, Math.min(w / 2 - 12, (h - lh) / 2 - 8));
        if (total <= 0) {
            ctx.beginPath(); ctx.arc(cx, h / 2, Math.min(R, h / 2 - 12), 0, Math.PI * 2);
            ctx.arc(cx, h / 2, Math.min(R, h / 2 - 12) * 0.55, 0, Math.PI * 2, true);
            ctx.fillStyle = '#c0c0c0'; ctx.fill('evenodd'); ctx.strokeStyle = '#000'; ctx.stroke();
            noData(ctx, w, h);
            return;
        }
        let a = -Math.PI / 2;
        items.forEach(it => {
            if (it.value <= 0) return;
            const da = it.value / total * Math.PI * 2;
            ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, R, a, a + da); ctx.closePath();
            ctx.fillStyle = it.color; ctx.fill(); ctx.strokeStyle = '#000'; ctx.lineWidth = 1; ctx.stroke();
            a += da;
        });
        // «дырка» кружка
        ctx.beginPath(); ctx.arc(cx, cy, R * 0.55, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = '#000'; ctx.stroke();
        ctx.fillStyle = '#000'; ctx.textAlign = 'center';
        ctx.font = 'bold ' + FONT; ctx.fillText(OB.money(total), cx, cy - 6);
        ctx.font = FONT; ctx.fillText(OB.CURRENCY, cx, cy + 9);
        legend(ctx, w, h - lh + 10, leg);
    }

    // «Красивые» деления оси: шаг 1, 2, 2,5 или 5 × 10^k, около четырёх делений
    function niceScale(v) {
        if (!(v > 0)) return { max: 4, step: 1, n: 4 };
        const raw = v / 4;
        const p = Math.pow(10, Math.floor(Math.log10(raw)));
        const f = raw / p;
        const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p;
        const n = Math.max(1, Math.ceil(v / step - 1e-9));
        return { max: step * n, step, n };
    }
    function shortMoney(v) {
        if (v >= 1e6) return (v / 1e6).toLocaleString('ru-RU', { maximumFractionDigits: 1 }) + ' млн';
        if (v >= 1e3) return (v / 1e3).toLocaleString('ru-RU', { maximumFractionDigits: 1 }) + ' тыс';
        return String(v);
    }

    // 2) Горизонтальные столбики по категориям, сложенные по людям. series: [{ name, color, data[] }]
    function stackedBars(canvas, cats, series) {
        const { ctx, w, h } = prepare(canvas);
        const leg = series.map(s => ({ color: s.color, text: s.name }));
        if (!cats.length) { noData(ctx, w, h); return; }
        const lh = legendHeight(ctx, w, leg);
        const labelW = Math.min(110, Math.max(60, w * 0.3));
        const totals = cats.map((_, i) => series.reduce((s, x) => s + (x.data[i] || 0), 0));
        const sc = niceScale(Math.max.apply(null, totals)), max = sc.max;
        const lastLabelW = ctx.measureText(shortMoney(max)).width;
        const left = labelW + 8, right = Math.ceil(lastLabelW / 2) + 6, top = 8, bottom = lh + 22;
        const plotW = w - left - right, plotH = h - top - bottom;
        // сетка и подписи оси X
        ctx.textAlign = 'center'; ctx.fillStyle = '#000';
        for (let t = 0; t <= sc.n; t++) {
            const x = left + plotW * t / sc.n;
            ctx.strokeStyle = t === 0 ? '#000' : '#c0c0c0'; ctx.setLineDash(t === 0 ? [] : [2, 2]);
            ctx.beginPath(); ctx.moveTo(Math.round(x) + 0.5, top); ctx.lineTo(Math.round(x) + 0.5, top + plotH); ctx.stroke();
            ctx.fillText(shortMoney(sc.step * t), x, top + plotH + 10);
        }
        ctx.setLineDash([]);
        const rowH = plotH / cats.length, barH = Math.min(26, rowH * 0.7);
        cats.forEach((c, i) => {
            const y = top + rowH * i + (rowH - barH) / 2;
            ctx.fillStyle = '#000'; ctx.textAlign = 'right';
            ctx.fillText(fit(ctx, c, labelW), left - 6, y + barH / 2);
            let x = left;
            series.forEach(s => {
                const v = s.data[i] || 0;
                if (v <= 0) return;
                const bw = v / max * plotW;
                ctx.fillStyle = s.color; ctx.fillRect(x, y, bw, barH);
                ctx.strokeStyle = '#000'; ctx.lineWidth = 1; ctx.strokeRect(Math.round(x) + 0.5, Math.round(y) + 0.5, Math.max(0, bw - 1), barH - 1);
                x += bw;
            });
        });
        ctx.textAlign = 'left';
        legend(ctx, w, h - lh + 10, leg);
    }

    // 3) Вертикальные столбики: у каждого человека — доход и расход. groups: [label], series: [{ name, color, data[] }]
    function groupedBars(canvas, groups, series) {
        const { ctx, w, h } = prepare(canvas);
        const leg = series.map(s => ({ color: s.color, text: s.name }));
        if (!groups.length) { noData(ctx, w, h); return; }
        const lh = legendHeight(ctx, w, leg);
        const sc = niceScale(Math.max.apply(null, series.reduce((a, s) => a.concat(s.data), [0]))), max = sc.max;
        const axisW = Math.max.apply(null, Array.from({ length: sc.n + 1 }, (_, t) => ctx.measureText(shortMoney(sc.step * t)).width));
        const left = Math.ceil(axisW) + 12, right = 10, top = 10, bottom = lh + 30;
        const plotW = w - left - right, plotH = h - top - bottom;
        ctx.textAlign = 'right'; ctx.fillStyle = '#000';
        for (let t = 0; t <= sc.n; t++) {
            const y = top + plotH - plotH * t / sc.n;
            ctx.strokeStyle = t === 0 ? '#000' : '#c0c0c0'; ctx.setLineDash(t === 0 ? [] : [2, 2]);
            ctx.beginPath(); ctx.moveTo(left, Math.round(y) + 0.5); ctx.lineTo(left + plotW, Math.round(y) + 0.5); ctx.stroke();
            ctx.fillText(shortMoney(sc.step * t), left - 5, y);
        }
        ctx.setLineDash([]);
        ctx.strokeStyle = '#000'; ctx.beginPath(); ctx.moveTo(left + 0.5, top); ctx.lineTo(left + 0.5, top + plotH); ctx.stroke();
        const gw = plotW / groups.length, bw = Math.min(34, gw * 0.8 / series.length);
        groups.forEach((g, gi) => {
            const x0 = left + gw * gi + (gw - bw * series.length) / 2;
            series.forEach((s, si) => {
                const v = s.data[gi] || 0;
                if (v <= 0) return;
                const bh = v / max * plotH;
                ctx.fillStyle = s.color; ctx.fillRect(x0 + bw * si, top + plotH - bh, bw, bh);
                ctx.strokeStyle = '#000'; ctx.strokeRect(Math.round(x0 + bw * si) + 0.5, Math.round(top + plotH - bh) + 0.5, bw - 1, Math.max(0, bh - 1));
            });
            ctx.fillStyle = '#000'; ctx.textAlign = 'center';
            ctx.fillText(fit(ctx, g, gw - 4), left + gw * gi + gw / 2, top + plotH + 12);
        });
        ctx.textAlign = 'left';
        legend(ctx, w, h - lh + 10, leg);
    }

    return { doughnut, stackedBars, groupedBars, personColor, INCOME, EXPENSE };
})();
