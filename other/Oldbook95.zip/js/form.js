// --- OLDBOOK 95: ВКЛАДКА «ЗАПИСЬ» ---
// Сумма набирается на цифровой клавиатуре (на телефоне не вылезает системная), категория — со списком подсказок,
// комментарий до 100 символов. Доход или расход — две кнопки внизу.

OB.form = (function () {
    let digits = '';       // набранная сумма
    let editId = '';       // id редактируемой записи («Изменить» в истории)
    const $ = OB.$;

    function render() {
        const root = $('#page-entry');
        root.innerHTML = `
        <div class="entry-grid">
            <fieldset class="gb">
                <legend>Сумма</legend>
                <div class="amount-display is-empty" id="amount-display" aria-live="polite">0 ${OB.CURRENCY}</div>
                <div class="keypad" role="group" aria-label="Цифровая клавиатура">
                    ${['1', '2', '3', 'back', '4', '5', '6', 'clear', '7', '8', '9', '000'].map(k =>
                        `<button type="button" class="btn" data-key="${k}"${k === 'back' ? ' aria-label="Стереть"' : k === 'clear' ? ' aria-label="Очистить"' : ''}>${k === 'back' ? '⌫' : k === 'clear' ? 'C' : k}</button>`).join('')}
                    <button type="button" class="btn wide" data-key="0">0</button>
                    <button type="button" class="btn wide" data-key="00">00</button>
                </div>
            </fieldset>
            <fieldset class="gb entry-form">
                <legend>Запись</legend>
                <div class="edit-banner" id="edit-banner" hidden>Правка записи. Нажмите «Сохранить» или «Отмена».</div>
                <label class="field"><span class="lbl">Дата и время</span><input type="datetime-local" id="f-date"></label>
                <label class="field"><span class="lbl">На что</span>
                    <span class="cat-row">
                        <input type="text" id="f-cat" list="cat-list" maxlength="60" autocomplete="off" placeholder="Продукты, кружок, проезд…">
                        <button type="button" class="btn square" id="f-cat-add" title="Добавить в мои категории" aria-label="Добавить в мои категории"><span class="btn-ico" style="margin:0;vertical-align:middle">${OB.icons.plus}</span></button>
                    </span>
                    <datalist id="cat-list"></datalist>
                </label>
                <label class="field"><span class="lbl">Комментарий <span style="color:var(--muted)">(необязательно)</span></span>
                    <textarea id="f-comment" rows="3" maxlength="${OB.COMMENT_MAX}" placeholder="Например: подарок маме на день рождения"></textarea>
                    <div class="cmt-counter"><span id="f-comment-count">0</span> / ${OB.COMMENT_MAX}</div>
                </label>
                <div class="entry-actions" id="add-btns">
                    <button type="button" class="btn btn-inc" id="btn-income">＋ Доход</button>
                    <button type="button" class="btn btn-exp" id="btn-expense">－ Расход</button>
                </div>
                <div class="entry-actions" id="edit-btns" hidden>
                    <button type="button" class="btn default" id="btn-save">Сохранить</button>
                    <button type="button" class="btn" id="btn-cancel">Отмена</button>
                </div>
            </fieldset>
        </div>
        <p class="hint-small" style="text-align:center">Сумма в тенге. С клавиатуры компьютера можно набирать цифры, Backspace стирает.</p>`;

        root.addEventListener('click', e => {
            const k = e.target.closest('[data-key]');
            if (k) key(k.dataset.key);
        });
        $('#btn-income').addEventListener('click', () => save('income'));
        $('#btn-expense').addEventListener('click', () => save('expense'));
        $('#btn-save').addEventListener('click', saveEdit);
        $('#btn-cancel').addEventListener('click', reset);
        $('#f-cat-add').addEventListener('click', addCategory);
        $('#f-comment').addEventListener('input', e => {
            if (e.target.value.length > OB.COMMENT_MAX) e.target.value = e.target.value.slice(0, OB.COMMENT_MAX);
            $('#f-comment-count').textContent = e.target.value.length;
        });
        // цифры с клавиатуры компьютера — пока курсор не в поле ввода
        document.addEventListener('keydown', e => {
            if (!root.classList.contains('active') || e.ctrlKey || e.metaKey || e.altKey) return;
            if (document.querySelector('.modal-layer')) return;
            const t = e.target;
            if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT')) return;
            if (/^\d$/.test(e.key)) { key(e.key); e.preventDefault(); }
            else if (e.key === 'Backspace') { key('back'); e.preventDefault(); }
            else if (e.key === 'Delete') { key('clear'); e.preventDefault(); }
        });
        OB.on('change', refreshCategories);
        reset();
        refreshCategories();
    }

    function key(k) {
        if (k === 'back') digits = digits.slice(0, -1);
        else if (k === 'clear') digits = '';
        else if (/^\d+$/.test(k)) {
            if (digits === '' && /^0+$/.test(k)) return;   // без ведущих нулей
            digits = (digits + k).slice(0, 10);
        }
        showAmount();
    }

    function showAmount() {
        const el = $('#amount-display');
        if (!el) return;
        el.textContent = Number(digits || 0).toLocaleString('ru-RU') + ' ' + OB.CURRENCY;
        el.classList.toggle('is-empty', !digits);
    }

    function refreshCategories() {
        const dl = $('#cat-list');
        if (dl) dl.innerHTML = OB.data.allCategories().map(c => `<option value="${OB.esc(c)}"></option>`).join('');
    }

    function reset() {
        digits = '';
        editId = '';
        showAmount();
        $('#f-cat').value = '';
        $('#f-date').value = OB.nowIso();
        $('#f-comment').value = '';
        $('#f-comment-count').textContent = '0';
        $('#add-btns').hidden = false;
        $('#edit-btns').hidden = true;
        $('#edit-banner').hidden = true;
    }

    // → { amount, category, date, comment } или null (с сообщением)
    async function read() {
        const amount = Number(digits || 0);
        const category = $('#f-cat').value.replace(/\s+/g, ' ').trim();
        const date = $('#f-date').value;
        if (!amount) { await OB.ui.alert('Наберите сумму на цифровой клавиатуре.', { icon: 'warn' }); return null; }
        if (!category) { await OB.ui.alert('Укажите категорию (на что).', { icon: 'warn' }); $('#f-cat').focus(); return null; }
        if (!date) { await OB.ui.alert('Укажите дату и время.', { icon: 'warn' }); $('#f-date').focus(); return null; }
        return { amount, category: category.slice(0, 60), date, comment: $('#f-comment').value.slice(0, OB.COMMENT_MAX) };
    }

    async function save(type) {
        const d = await read();
        if (!d) return;
        const e = OB.data.addEntry(type, d);
        if (!e) { await OB.ui.alert('Не удалось сохранить запись.', { icon: 'error' }); return; }
        reset();
        OB.status(`${type === 'income' ? 'Доход' : 'Расход'} записан: ${e.category}, ${OB.money(e.amount)} ${OB.CURRENCY}`);
    }

    function startEdit(id) {
        const e = OB.data.getEntry(id);
        if (!e) return;
        editId = id;
        digits = String(Math.round(e.amount));
        showAmount();
        $('#f-cat').value = e.category || '';
        $('#f-date').value = e.date || OB.nowIso();
        $('#f-comment').value = e.comment || '';
        $('#f-comment-count').textContent = (e.comment || '').length;
        $('#add-btns').hidden = true;
        $('#edit-btns').hidden = false;
        $('#edit-banner').hidden = false;
    }

    async function saveEdit() {
        const d = await read();
        if (!d || !editId) return;
        // тип записи (доход/расход) при правке не меняется
        if (!OB.data.updateEntry(editId, d)) { await OB.ui.alert('Запись не найдена.', { icon: 'error' }); return; }
        reset();
        OB.status('Запись изменена');
        OB.showTab('history');
    }

    function addCategory() {
        const r = OB.data.addCategory($('#f-cat').value);
        if (r === 'empty') OB.ui.alert('Введите название категории.', { icon: 'warn' });
        else if (r === 'exists') OB.status(`Категория «${$('#f-cat').value.trim()}» уже есть`);
        else OB.status(`Категория «${$('#f-cat').value.trim()}» добавлена`);
    }

    return { render, startEdit, reset };
})();
