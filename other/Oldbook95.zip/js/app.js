// --- OLDBOOK 95: ЗАПУСК ---
// Собирает окно: меню, вкладки, строку состояния, панель задач с «Пуском» и часами Алматы.

(function () {
    const $ = OB.$, $$ = OB.$$;
    const TABS = [
        { id: 'entry', label: 'Запись', icon: 'plus' },
        { id: 'history', label: 'История', icon: 'list' },
        { id: 'stats', label: 'Статистика', icon: 'chart' },
        { id: 'share', label: 'Доступ', icon: 'people' }
    ];
    let currentTab = 'entry';
    let statusTimer = null;
    let win;   // управление главным окном

    // ---------- строка состояния ----------
    OB.status = function (text, ms) {
        const el = $('#sb-status');
        if (!el) return;
        el.textContent = text;
        clearTimeout(statusTimer);
        statusTimer = setTimeout(() => { el.textContent = 'Готово'; }, ms || 6000);
    };

    function refreshStatusbar() {
        const own = OB.data.ownEntries();
        const bal = own.reduce((s, e) => s + (e.type === 'income' ? e.amount : -e.amount), 0);
        $('#sb-count').textContent = `Записей: ${own.length}`;
        $('#sb-balance').innerHTML = `Баланс: <b class="${bal < 0 ? 'exp' : 'inc'}">${bal < 0 ? '−' : ''}${OB.money(Math.abs(bal))} ${OB.CURRENCY}</b>`;
    }

    // ---------- вкладки ----------
    OB.showTab = function (id) {
        if (!TABS.some(t => t.id === id)) return;
        currentTab = id;
        $$('.tabs button').forEach(b => {
            const on = b.dataset.tab === id;
            b.setAttribute('aria-selected', on ? 'true' : 'false');
            b.tabIndex = on ? 0 : -1;
        });
        $$('.page').forEach(p => p.classList.toggle('active', p.id === 'page-' + id));
        const panel = $('.tabpanel');
        panel.scrollTop = 0;
        if (id === 'stats') requestAnimationFrame(() => OB.stats.refresh());
        if (id === 'history') OB.history.refresh();
        OB.emit('tab', id);
    };

    function openApp() {
        win.restore();
        syncTaskbar();
    }

    // ---------- панель задач ----------
    function syncTaskbar() {
        const tasks = $('#tasks');
        const closed = win.state.closed;
        tasks.innerHTML = closed ? '' :
            `<button type="button" class="task-btn${win.state.minimized || $('#app-window').classList.contains('inactive') ? '' : ' active'}" id="task-app">` +
            `<span class="t-ico">${OB.icons.book}</span><span class="t-text">Oldbook — семейная книга</span></button>`;
        $('#desk-icon').hidden = !closed && window.innerWidth <= 720;
        const t = $('#task-app');
        if (t) t.addEventListener('click', () => {
            if (win.state.minimized) { win.restore(); }
            else if ($('#app-window').classList.contains('inactive')) { win.setActive(true); }
            else win.minimize();
            syncTaskbar();
        });
    }

    // ---------- диалоги меню ----------
    async function askName() {
        const cur = OB.data.getProfile().name;
        const name = await OB.ui.prompt('Как подписывать вашу книгу? Это имя увидят получатели файла вашей книги. Ваши записи в самой книге подписаны словом «Вы».', cur, { title: 'Моё имя', maxlength: 30, placeholder: 'Например: Катя' });
        if (name === null) return;
        OB.data.setName(name);
        OB.status(name.trim() ? `Имя: ${name.trim()}` : 'Имя очищено');
    }

    function manageCategories() {
        const wrap = document.createElement('div');
        wrap.innerHTML = `<div class="cat-list-box" id="cl" role="listbox" aria-label="Мои категории"></div>
            <div class="dlg-field"><input type="text" id="cl-in" maxlength="40" placeholder="Новая категория"><button type="button" class="btn" id="cl-add">Добавить</button></div>
            <div class="dlg-field"><button type="button" class="btn" id="cl-del" disabled>Удалить выбранную</button></div>
            <p class="hint-small">Стандартные категории (${OB.DEFAULT_CATEGORIES.length}) удалить нельзя. Сделанные записи при удалении категории не меняются.</p>`;
        let selected = '';
        const list = $('#cl', wrap);
        const draw = () => {
            const items = OB.data.customCategories();
            list.innerHTML = items.length ? items.map(c => `<button type="button" class="item${c === selected ? ' selected' : ''}" role="option" data-c="${OB.esc(c)}">${OB.esc(c)}</button>`).join('') :
                '<span class="item" style="color:var(--muted)">Своих категорий пока нет</span>';
            $('#cl-del', wrap).disabled = !selected;
        };
        list.addEventListener('click', e => { const b = e.target.closest('[data-c]'); if (b) { selected = b.dataset.c; draw(); } });
        $('#cl-add', wrap).addEventListener('click', () => {
            const input = $('#cl-in', wrap);
            const r = OB.data.addCategory(input.value);
            if (r === 'added') { input.value = ''; draw(); }
            else if (r === 'exists') OB.ui.alert('Такая категория уже есть.', { icon: 'info' });
            else OB.ui.alert('Введите название категории.', { icon: 'warn' });
        });
        $('#cl-in', wrap).addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#cl-add', wrap).click(); } });
        $('#cl-del', wrap).addEventListener('click', () => { OB.data.removeCategory(selected); selected = ''; draw(); });
        draw();
        OB.ui.dialog({ title: 'Мои категории', icon: null, html: 'Свои категории появляются в подсказках поля «На что».', node: wrap, width: 380, buttons: [{ label: 'Закрыть', value: true, default: true, cancel: true }] });
    }

    async function clearBook() {
        const n = OB.data.ownCount();
        if (!n) { await OB.ui.alert('Ваша книга и так пуста.', { icon: 'info' }); return; }
        const ok = await OB.ui.confirm(`Удалить все ваши записи (${n})?\n\nЭто нельзя отменить. Чужие подключённые книги не затрагиваются. Перед очисткой можно сохранить книгу в файл («Файл → Сохранить мою книгу в файл»).`, { title: 'Очистить книгу', icon: 'warn', yes: 'Удалить всё', no: 'Отмена', danger: true });
        if (!ok) return;
        OB.data.clearOwn();
        OB.form.reset();
        OB.status('Книга очищена');
    }

    function about() {
        OB.ui.dialog({
            title: 'О программе Oldbook 95', icon: 'book', width: 400,
            html: `<b>Oldbook 95</b>, версия ${OB.VERSION}\nСемейная книга доходов и расходов.\n\nДанные хранятся только на этом устройстве. Книгами обмениваются файлами: «Доступ → Сохранить мою книгу в файл».\n\nВремя — Алматы (UTC+5), валюта — тенге.`,
            buttons: [{ label: 'ОК', value: true, default: true, cancel: true }]
        });
    }

    // ---------- меню ----------
    function menus() {
        return [
            { label: 'Файл', mnemonic: 'Ф', items: () => [
                { label: 'Новая запись', icon: 'plus', key: 'Ctrl+N', action: () => { OB.showTab('entry'); OB.form.reset(); } },
                '-',
                { label: 'Сохранить мою книгу в файл…', icon: 'floppy', key: 'Ctrl+S', action: () => OB.share.exportBook(false) },
                { label: 'Импорт и открыть файл книги…', icon: 'folder', key: 'Ctrl+O', action: () => OB.share.pickFile() },
                { label: 'Взять из My Money…', icon: 'folder', hidden: !OB.data.detectMyMoney(), action: () => OB.share.importFromMyMoney() },
                '-',
                { label: 'Выход', action: () => { win.close(); syncTaskbar(); } }
            ] },
            { label: 'Правка', mnemonic: 'П', items: [
                { label: 'Моё имя…', icon: 'people', action: askName },
                { label: 'Мои категории…', action: manageCategories },
                '-',
                { label: 'Очистить мою книгу…', icon: 'warn', action: clearBook }
            ] },
            { label: 'Вид', mnemonic: 'В', items: [
                ...TABS.map((t, i) => ({ label: t.label, icon: t.icon, key: 'Ctrl+' + (i + 1), action: () => OB.showTab(t.id) })),
                '-',
                { label: 'Развернуть окно', action: () => win.toggleMax() }
            ] },
            { label: 'Справка', mnemonic: 'С', items: [
                { label: 'О программе Oldbook 95…', icon: 'help', action: about }
            ] }
        ];
    }

    function startItems() {
        return [
            { label: 'Oldbook', icon: 'book', action: openApp },
            '-',
            { label: 'Новая запись', icon: 'plus', action: () => { openApp(); OB.showTab('entry'); } },
            { label: 'История', icon: 'list', action: () => { openApp(); OB.showTab('history'); } },
            { label: 'Статистика', icon: 'chart', action: () => { openApp(); OB.showTab('stats'); } },
            { label: 'Общий доступ', icon: 'people', action: () => { openApp(); OB.showTab('share'); } },
            '-',
            { label: 'Сохранить книгу в файл…', icon: 'floppy', action: () => { openApp(); OB.share.exportBook(false); } },
            { label: 'О программе…', icon: 'help', action: () => { openApp(); about(); } },
            '-',
            { label: 'Завершение работы…', icon: 'power', action: async () => { if (await OB.ui.confirm('Закрыть Oldbook?', { title: 'Завершение работы' })) { win.close(); syncTaskbar(); } } }
        ];
    }

    // ---------- старт ----------
    function init() {
        // вкладки
        const tabs = $('.tabs');
        tabs.innerHTML = TABS.map(t => `<button type="button" role="tab" data-tab="${t.id}" aria-selected="false"><span class="tab-icon">${OB.icons[t.icon]}</span>${t.label}</button>`).join('');
        tabs.addEventListener('click', e => { const b = e.target.closest('[data-tab]'); if (b) OB.showTab(b.dataset.tab); });
        tabs.addEventListener('keydown', e => {
            const i = TABS.findIndex(t => t.id === currentTab);
            if (e.key === 'ArrowRight') { OB.showTab(TABS[(i + 1) % TABS.length].id); $(`.tabs [data-tab="${currentTab}"]`).focus(); e.preventDefault(); }
            else if (e.key === 'ArrowLeft') { OB.showTab(TABS[(i + TABS.length - 1) % TABS.length].id); $(`.tabs [data-tab="${currentTab}"]`).focus(); e.preventDefault(); }
        });

        // значки: заголовок окна и рабочий стол
        $('#app-window .tb-icon').innerHTML = OB.icons.book;
        $('#desk-icon .dicon-img').innerHTML = OB.icons.book;
        $('.start-btn .sb-flag').innerHTML = OB.icons.flag;
        $('.tray .tray-ico').innerHTML = OB.icons.book;

        // вкладки-страницы
        OB.form.render();
        OB.history.render();
        OB.stats.render();
        OB.share.render();

        // окно
        win = OB.ui.appWindow($('#app-window'), {
            onActive: () => syncTaskbar(),
            onState: () => syncTaskbar(),
            onResize: () => { OB.emit('resize'); }
        });
        OB.ui.buildMenu($('#menubar'), menus());
        OB.ui.startMenu($('.start-btn'), startItems);
        OB.ui.clock($('#clock'));
        syncTaskbar();

        // значок на рабочем столе: двойной щелчок (на сенсорных экранах — одно касание)
        const icon = $('#desk-icon');
        icon.addEventListener('dblclick', openApp);
        icon.addEventListener('click', () => { icon.classList.add('selected'); if (matchMedia('(pointer: coarse)').matches) openApp(); });
        icon.addEventListener('keydown', e => { if (e.key === 'Enter') openApp(); });
        document.addEventListener('pointerdown', e => { if (!e.target.closest('#desk-icon')) icon.classList.remove('selected'); });

        // сочетания клавиш
        document.addEventListener('keydown', e => {
            if (!(e.ctrlKey || e.metaKey) || e.altKey || document.querySelector('.modal-layer') || win.state.closed) return;
            const k = e.key.toLowerCase();
            if (k === 'n') { OB.showTab('entry'); OB.form.reset(); e.preventDefault(); }
            else if (k === 's') { OB.share.exportBook(false); e.preventDefault(); }
            else if (k === 'o') { OB.share.pickFile(); e.preventDefault(); }
            else if (/^[1-4]$/.test(k)) { OB.showTab(TABS[+k - 1].id); e.preventDefault(); }
        });
        document.addEventListener('keydown', e => { if (e.key === 'Escape') OB.ui.closeMenus(); });

        // диаграммы перерисовываются при смене размера окна
        let rz;
        if (window.ResizeObserver) new ResizeObserver(() => { clearTimeout(rz); rz = setTimeout(() => OB.emit('resize'), 80); }).observe($('.tabpanel'));

        OB.on('change', refreshStatusbar);
        OB.on('storage-failed', () => OB.ui.alert('Браузер не разрешает сохранять данные на этом устройстве (возможно, включён приватный режим). Записи будут жить только до закрытия страницы. Сохраните книгу в файл: «Файл → Сохранить мою книгу в файл».', { icon: 'warn', title: 'Хранилище недоступно' }));
        refreshStatusbar();
        OB.showTab('entry');
        OB.status('Готово', 1);

        // прежняя книга из My Money рядом — предложить забрать
        setTimeout(() => OB.share.offerMyMoney(), 400);

        // работа без интернета
        if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
