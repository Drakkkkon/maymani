// --- OLDBOOK 95: ВКЛАДКА «ИСТОРИЯ» ---
// Таблица в духе проводника Windows 95: щелчок по заголовку сортирует, двойной щелчок по строке — правка.
// Свои записи можно изменить и удалить; записи чужих книг только читаются.

OB.history = (function () {
    const $ = OB.$;
    let sortKey = 'date', sortDir = -1;   // по дате, новые сверху
    let selectedId = '';
    let rows = [];                        // что сейчас показано

    function render() {
        const root = $('#page-history');
        root.innerHTML = `
        <div class="hist-toolbar">
            <label>Чьи записи: <select id="h-filter" aria-label="Чьи записи показать"></select></label>
            <div class="hist-totals" id="h-totals"></div>
        </div>
        <div class="lv" id="h-lv" tabindex="0" role="grid" aria-label="Расходы и доходы">
            <table>
                <thead><tr>
                    <th data-sort="date">Дата</th><th data-sort="who">Кто</th><th data-sort="category">Категория</th>
                    <th class="cmt" data-sort="comment">Комментарий</th><th class="num" data-sort="amount">Сумма</th>
                </tr></thead>
                <tbody id="h-body"></tbody>
            </table>
        </div>
        <div class="hist-buttons">
            <button type="button" class="btn" id="h-edit" disabled>Изменить…</button>
            <button type="button" class="btn" id="h-del" disabled>Удалить</button>
        </div>`;
        $('#h-filter').addEventListener('change', refresh);
        $('#h-edit').addEventListener('click', editSelected);
        $('#h-del').addEventListener('click', deleteSelected);
        root.querySelector('thead').addEventListener('click', e => {
            const th = e.target.closest('th[data-sort]');
            if (!th) return;
            if (sortKey === th.dataset.sort) sortDir = -sortDir; else { sortKey = th.dataset.sort; sortDir = sortKey === 'date' || sortKey === 'amount' ? -1 : 1; }
            refresh();
        });
        $('#h-body').addEventListener('click', e => {
            const tr = e.target.closest('tr[data-id]');
            if (tr) select(tr.dataset.id);
        });
        $('#h-body').addEventListener('dblclick', e => {
            const tr = e.target.closest('tr[data-id]');
            if (tr) { select(tr.dataset.id); editSelected(); }
        });
        $('#h-lv').addEventListener('keydown', e => {
            if (!rows.length) return;
            const i = rows.findIndex(r => r.id === selectedId);
            if (e.key === 'ArrowDown') { select(rows[Math.min(rows.length - 1, i + 1)].id, true); e.preventDefault(); }
            else if (e.key === 'ArrowUp') { select(rows[Math.max(0, i < 0 ? 0 : i - 1)].id, true); e.preventDefault(); }
            else if (e.key === 'Enter') { editSelected(); e.preventDefault(); }
            else if (e.key === 'Delete') { deleteSelected(); e.preventDefault(); }
        });
        OB.on('change', refresh);
        refresh();
    }

    function sortValue(e, key) {
        if (key === 'who') return OB.data.who(e).toLowerCase();
        if (key === 'amount') return e.amount;
        return String(e[key] || '').toLowerCase();
    }

    function refresh() {
        const body = $('#h-body');
        if (!body) return;
        const all = OB.data.allEntries();
        const labels = [...new Set(all.map(OB.data.who))];
        const sel = $('#h-filter');
        const keep = labels.includes(sel.value) ? sel.value : '';
        sel.innerHTML = '<option value="">Все</option>' + labels.map(l => `<option value="${OB.esc(l)}">${OB.esc(l)}</option>`).join('');
        sel.value = keep;

        rows = all.filter(e => !keep || OB.data.who(e) === keep).sort((a, b) => {
            const x = sortValue(a, sortKey), y = sortValue(b, sortKey);
            const c = x < y ? -1 : x > y ? 1 : 0;
            return (c || String(b.date).localeCompare(String(a.date))) * (c ? sortDir : 1);
        });

        const inc = rows.filter(e => e.type === 'income').reduce((s, e) => s + e.amount, 0);
        const exp = rows.filter(e => e.type !== 'income').reduce((s, e) => s + e.amount, 0);
        $('#h-totals').innerHTML = `<span class="inc">+${OB.money(inc)} ${OB.CURRENCY}</span><span class="exp">−${OB.money(exp)} ${OB.CURRENCY}</span><span>Итог: ${OB.money(inc - exp)} ${OB.CURRENCY}</span>`;

        $$('#page-history th[data-sort]').forEach(th => {
            const on = th.dataset.sort === sortKey;
            th.innerHTML = th.textContent.replace(/[▲▼]/g, '').trim() + (on ? `<span class="lv-sort">${sortDir > 0 ? '▲' : '▼'}</span>` : '');
        });

        if (!rows.length) {
            body.innerHTML = '<tr class="empty"><td colspan="5">Записей пока нет. Добавьте первую на вкладке «Запись».</td></tr>';
            selectedId = '';
        } else {
            if (!rows.some(r => r.id === selectedId)) selectedId = '';
            body.innerHTML = rows.map(e => {
                const who = OB.data.who(e);
                const inc = e.type === 'income';
                return `<tr data-id="${OB.esc(e.id)}" class="${e.id === selectedId ? 'selected' : ''}">` +
                    `<td>${OB.esc(OB.fmtDateTime(e.date))}</td>` +
                    `<td><span class="badge" style="background:${OB.charts.personColor(who, labels)}">${OB.esc(who)}</span></td>` +
                    `<td>${OB.esc(e.category || 'Без категории')}${e.comment ? `<span class="cmt-inline">${OB.esc(e.comment)}</span>` : ''}</td>` +
                    `<td class="cmt" title="${OB.esc(e.comment || '')}">${OB.esc(e.comment || '')}</td>` +
                    `<td class="num ${inc ? 'inc' : 'exp'}"><b>${inc ? '+' : '−'}${OB.money(e.amount)} ${OB.CURRENCY}</b></td></tr>`;
            }).join('');
        }
        syncButtons();
    }

    function $$(sel) { return OB.$$(sel); }

    function selectedEntry() { return rows.find(r => r.id === selectedId) || null; }

    function select(id, scroll) {
        selectedId = id;
        $$('#h-body tr').forEach(tr => {
            const on = tr.dataset.id === id;
            tr.classList.toggle('selected', on);
            if (on && scroll) tr.scrollIntoView({ block: 'nearest' });
        });
        syncButtons();
    }

    function syncButtons() {
        const e = selectedEntry();
        const own = !!(e && e.own);
        $('#h-edit').disabled = !own;
        $('#h-del').disabled = !own;
        $('#h-edit').title = e && !e.own ? 'Записи чужих книг только для чтения' : '';
        $('#h-del').title = $('#h-edit').title;
    }

    function editSelected() {
        const e = selectedEntry();
        if (!e) { OB.ui.alert('Выберите запись в списке.', { icon: 'info' }); return; }
        if (!e.own) { OB.ui.alert('Это запись чужой книги — её можно только читать.', { icon: 'info' }); return; }
        OB.form.startEdit(e.id);
        OB.showTab('entry');
    }

    async function deleteSelected() {
        const e = selectedEntry();
        if (!e || !e.own) return;
        const ok = await OB.ui.confirm(`Удалить запись «${e.category || 'Без категории'}» на ${OB.money(e.amount)} ${OB.CURRENCY}?\n\nОтменить удаление будет нельзя.`, { title: 'Удаление записи', icon: 'warn', yes: 'Удалить', no: 'Отмена', danger: true });
        if (!ok) return;
        OB.data.deleteEntry(e.id);
        OB.status('Запись удалена');
    }

    return { render, refresh };
})();
