// --- OLDBOOK 95: ДАННЫЕ ---
// Всё хранится только на этом устройстве (localStorage, ключи oldbook95.*). Ничего не уходит в сеть.
// Запись: { id, type: 'income'|'expense', amount, category, date: 'ГГГГ-ММ-ДДTЧЧ:ММ', comment?, person?, updatedAt }
//   person — подпись у старых записей (Катя, Папа, Саша); у новых её нет, запись подписана владельцем книги.
// Чужая книга (получена файлом): { id, name, owner, savedAt, entries: [...] } — только для чтения.

OB.DEFAULT_CATEGORIES = ['Продукты', 'Еда вне дома', 'Проезд', 'Одежда', 'Учёба', 'Кружки и секции',
    'Развлечения', 'Подарки', 'Здоровье', 'Карманные деньги', 'Зарплата', 'Другое'];

OB.KEYS = {
    entries: 'oldbook95.entries',
    links: 'oldbook95.links',
    cats: 'oldbook95.cats',
    profile: 'oldbook95.profile',
    mmAsked: 'oldbook95.mm_asked'
};

OB.store = (function () {
    let memory = {};              // запасной вариант, если localStorage недоступен (приватный режим и т. п.)
    let persistent = true;

    function read(key, fallback) {
        try {
            const raw = persistent ? localStorage.getItem(key) : memory[key];
            return raw ? JSON.parse(raw) : fallback;
        } catch (e) { return fallback; }
    }
    function write(key, value) {
        const raw = JSON.stringify(value);
        try { if (persistent) localStorage.setItem(key, raw); else memory[key] = raw; return true; }
        catch (e) { persistent = false; memory[key] = raw; OB.emit('storage-failed'); return false; }
    }
    function probe() {
        try { localStorage.setItem('oldbook95.probe', '1'); localStorage.removeItem('oldbook95.probe'); }
        catch (e) { persistent = false; }
    }
    return { read, write, probe, isPersistent: () => persistent };
})();

OB.data = (function () {
    const S = OB.store;
    S.probe();

    let entries = [];
    let links = [];
    let cats = [];
    let profile = { id: '', name: '' };

    // ---------- нормализация чужих данных ----------
    function normEntry(e) {
        if (!e || typeof e !== 'object') return null;
        const amount = Number(e.amount);
        const date = String(e.date || '');
        if (!(amount > 0) || !isFinite(amount) || !/^\d{4}-\d{2}-\d{2}/.test(date)) return null;
        const out = {
            id: String(e.id || OB.uid('ob')).slice(0, 60),
            type: e.type === 'income' ? 'income' : 'expense',
            amount: Math.round(amount * 100) / 100,
            category: String(e.category || '').replace(/\s+/g, ' ').trim().slice(0, 60),
            date: date.length >= 16 ? date.slice(0, 16) : date.slice(0, 10) + 'T00:00',
            updatedAt: Number(e.updatedAt) || 0
        };
        const comment = String(e.comment || '').replace(/\s+/g, ' ').trim().slice(0, OB.COMMENT_MAX);
        if (comment) out.comment = comment;
        const person = String(e.person || '').trim().slice(0, 30);
        if (person) out.person = person;
        return out;
    }

    function normList(list) {
        const out = [];
        let skipped = 0;
        (Array.isArray(list) ? list : []).forEach(e => { const n = normEntry(e); if (n) out.push(n); else skipped++; });
        return { list: out, skipped };
    }

    // ---------- загрузка / сохранение ----------
    function load() {
        entries = normList(S.read(OB.KEYS.entries, [])).list;
        links = (Array.isArray(S.read(OB.KEYS.links, [])) ? S.read(OB.KEYS.links, []) : []).map(l => ({
            id: String(l.id || ''), name: String(l.name || 'Другой пользователь').slice(0, 40), owner: String(l.owner || '').slice(0, 80),
            savedAt: Number(l.savedAt) || 0, addedAt: Number(l.addedAt) || 0, entries: normList(l.entries).list
        })).filter(l => l.id);
        cats = (S.read(OB.KEYS.cats, []) || []).map(c => String(c).slice(0, 40)).filter(Boolean);
        const p = S.read(OB.KEYS.profile, null) || {};
        profile = { id: String(p.id || ''), name: String(p.name || '').slice(0, 30) };
        if (!profile.id) { profile.id = OB.uid('u'); S.write(OB.KEYS.profile, profile); }
    }

    function save() {
        S.write(OB.KEYS.entries, entries);
        S.write(OB.KEYS.links, links);
        S.write(OB.KEYS.cats, cats);
        S.write(OB.KEYS.profile, profile);
    }

    function changed() { save(); OB.emit('change'); }

    // ---------- свои записи ----------
    function addEntry(type, data) {
        const e = normEntry({ id: OB.uid('ob'), type, ...data, updatedAt: Date.now() });
        if (!e) return null;
        entries.push(e);
        changed();
        return e;
    }

    function updateEntry(id, data) {
        const e = entries.find(x => x.id === id);
        if (!e) return null;
        const n = normEntry({ ...e, ...data, id, updatedAt: Date.now() });
        if (!n) return null;
        Object.keys(e).forEach(k => delete e[k]);
        Object.assign(e, n);
        changed();
        return e;
    }

    function deleteEntry(id) {
        const before = entries.length;
        entries = entries.filter(x => x.id !== id);
        if (entries.length !== before) changed();
    }

    function clearOwn() { entries = []; changed(); }

    function getEntry(id) { return entries.find(x => x.id === id) || null; }
    function ownEntries() { return entries.slice(); }
    function ownCount() { return entries.length; }

    // Свои + чужие книги: у каждой записи own и ownerName (у своих — «Вы»)
    function allEntries() {
        const list = entries.map(e => ({ ...e, own: true, ownerName: 'Вы' }));
        links.forEach(l => l.entries.forEach(e => list.push({ ...e, own: false, ownerName: l.name })));
        return list;
    }

    function who(e) { return e.person || e.ownerName || '—'; }

    // ---------- категории ----------
    function allCategories() {
        const seen = new Set();
        return cats.concat(OB.DEFAULT_CATEGORIES).filter(n => {
            const k = n.toLowerCase();
            if (seen.has(k)) return false;
            seen.add(k);
            return true;
        });
    }
    function customCategories() { return cats.slice(); }
    // → 'added' | 'exists' | 'empty'
    function addCategory(raw) {
        const name = String(raw || '').replace(/\s+/g, ' ').trim().slice(0, 40);
        if (!name) return 'empty';
        if (allCategories().some(c => c.toLowerCase() === name.toLowerCase())) return 'exists';
        cats.push(name);
        changed();
        return 'added';
    }
    function removeCategory(name) {
        const before = cats.length;
        cats = cats.filter(c => c !== name);
        if (cats.length !== before) changed();
    }

    // ---------- профиль ----------
    function getProfile() { return { ...profile }; }
    function setName(name) { profile.name = String(name || '').replace(/\s+/g, ' ').trim().slice(0, 30); changed(); }

    // ---------- обмен книгами ----------
    // Файл, который получатель открывает у себя. Формат совместим с файлом my_money_oldbook.json из My Money.
    function exportBook() {
        return {
            app: 'oldbook95', format: 1, savedAt: Date.now(),
            owner: { id: profile.id, name: profile.name || 'Без имени' },
            entries: entries.map(e => ({ ...e }))
        };
    }

    // Что это за файл → { kind, owner, entries, skipped, note }
    //  own-book      — файл с моим id (резервная копия моей книги)
    //  foreign-book  — книга другого пользователя (Oldbook 95)
    //  legacy-book   — книга из My Money (my_money_oldbook.json): чья она, решает человек
    //  mymoney-data  — общий файл данных My Money: берутся только записи Oldbook, остальное не читается
    //  entries       — просто список записей
    //  unknown
    function parseFile(obj) {
        if (Array.isArray(obj)) {
            const n = normList(obj);
            return n.list.length ? { kind: 'entries', entries: n.list, skipped: n.skipped, owner: {} } : { kind: 'unknown' };
        }
        if (!obj || typeof obj !== 'object') return { kind: 'unknown' };
        if (obj.app === 'oldbook95' && Array.isArray(obj.entries)) {
            const n = normList(obj.entries);
            const owner = { id: String((obj.owner && obj.owner.id) || ''), name: String((obj.owner && obj.owner.name) || 'Другой пользователь').slice(0, 40) };
            return { kind: owner.id && owner.id === profile.id ? 'own-book' : 'foreign-book', owner, entries: n.list, skipped: n.skipped, savedAt: Number(obj.savedAt) || 0 };
        }
        if (obj.app === 'my-money-oldbook' && Array.isArray(obj.entries)) {
            const n = normList(obj.entries);
            const o = obj.owner || {};
            const owner = { id: o.email ? 'mail:' + String(o.email).toLowerCase() : '', name: String(o.name || o.email || 'Другой пользователь').slice(0, 40), email: String(o.email || '') };
            return { kind: 'legacy-book', owner, entries: n.list, skipped: n.skipped, savedAt: Number(obj.savedAt) || 0 };
        }
        if (obj.app === 'my-money' && Array.isArray(obj.ob)) {
            const n = normList(obj.ob);
            return { kind: 'mymoney-data', entries: n.list, skipped: n.skipped, owner: {}, hadLinks: Array.isArray(obj.links) && obj.links.length > 0 };
        }
        return { kind: 'unknown' };
    }

    // Добавить в свои записи → { added, same, skipped }. Одинаковый id — запись уже есть; побеждает более свежая правка.
    function mergeOwn(list, skipped) {
        let added = 0, same = 0;
        const index = new Map(entries.map(e => [e.id, e]));
        list.forEach(e => {
            const cur = index.get(e.id);
            if (!cur) { entries.push(e); index.set(e.id, e); added++; }
            else if ((e.updatedAt || 0) > (cur.updatedAt || 0)) { Object.keys(cur).forEach(k => delete cur[k]); Object.assign(cur, e); added++; }
            else same++;
        });
        if (added) changed();
        return { added, same, skipped: skipped || 0 };
    }

    // Подключить книгу другого пользователя (повторный файл от того же владельца обновляет книгу) → 'added' | 'updated'
    function linkBook(owner, list, savedAt) {
        const id = owner.id || 'name:' + owner.name.toLowerCase();
        const cur = links.find(l => l.id === id);
        if (cur) {
            cur.name = owner.name; cur.entries = list; cur.savedAt = savedAt || Date.now();
            changed();
            return 'updated';
        }
        links.push({ id, name: owner.name, owner: owner.email || '', savedAt: savedAt || Date.now(), addedAt: Date.now(), entries: list });
        changed();
        return 'added';
    }

    function linkedBooks() { return links.map(l => ({ id: l.id, name: l.name, owner: l.owner, savedAt: l.savedAt, count: l.entries.length })); }
    function unlinkBook(id) { const n = links.length; links = links.filter(l => l.id !== id); if (links.length !== n) changed(); }

    // ---------- прежняя книга из My Money (если открыто на том же сайте, где лежал My Money) ----------
    // Читается ТОЛЬКО ключ finance_oldbook, больше ничего из My Money не трогается.
    function detectMyMoney() {
        try {
            const raw = localStorage.getItem('finance_oldbook');
            if (!raw) return null;
            const n = normList(JSON.parse(raw));
            return n.list.length ? n : null;
        } catch (e) { return null; }
    }

    load();

    return {
        load, addEntry, updateEntry, deleteEntry, clearOwn, getEntry, ownEntries, ownCount, allEntries, who,
        allCategories, customCategories, addCategory, removeCategory,
        getProfile, setName, exportBook, parseFile, mergeOwn, linkBook, linkedBooks, unlinkBook, detectMyMoney, normList
    };
})();
