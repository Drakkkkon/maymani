// --- OLDBOOK 95: ВКЛАДКА «ДОСТУП», ЭКСПОРТ, ИМПОРТ, ПЕРЕНОС ИЗ MY MONEY ---
// Обмен между людьми — файлами: владелец сохраняет свою книгу в файл и отправляет (мессенджер, почта),
// получатель открывает файл у себя. Оба действия добровольные; делятся только записи Oldbook.
// Чужие книги подключаются только для чтения и обновляются новым файлом от того же человека.
//
// Формат файла (совместим с my_money_oldbook.json из My Money):
//   { app: 'oldbook95', format: 1, savedAt, owner: { id, name }, entries: [ … ] }

OB.share = (function () {
    const $ = OB.$;
    const MAX_FILE = 8 * 1024 * 1024;

    function render() {
        const canShare = typeof navigator.canShare === 'function' && typeof File === 'function' && (() => {
            try { return navigator.canShare({ files: [new File(['{}'], 'a.json', { type: 'application/json' })] }); } catch (e) { return false; }
        })();
        const root = $('#page-share');
        root.innerHTML = `
        <div class="share-wrap">
            <p class="hint" style="margin:0">Записи других членов семьи попадают к вам только по согласию обеих сторон: владелец передаёт файл своей книги,
            а получатель сам открывает его у себя. Делятся только записи Oldbook — ничего больше.</p>

            <fieldset class="gb">
                <legend>1. Поделиться своей книгой</legend>
                <p>Сохраните свою книгу в файл и отправьте его человеку (в мессенджере, по почте). Когда добавятся новые записи — отправьте новый файл, он обновит вашу книгу у получателя.</p>
                <div class="btn-row">
                    <button type="button" class="btn" id="sh-save">Сохранить мою книгу в файл…</button>
                    ${canShare ? '<button type="button" class="btn" id="sh-send">Отправить…</button>' : ''}
                </div>
                <p class="hint-small" id="sh-own-info"></p>
            </fieldset>

            <fieldset class="gb">
                <legend>2. Принять книгу другого человека</legend>
                <p>Когда вам прислали файл книги, откройте его здесь — это и есть ваше согласие. Записи появятся в истории и статистике; чужие записи изменить нельзя.</p>
                <button type="button" class="btn" id="sh-open">Открыть файл книги…</button>
                <div class="books" id="sh-books"></div>
            </fieldset>

            <fieldset class="gb">
                <legend>Перенос из My Money</legend>
                <p>Если Oldbook раньше был разделом My Money: откройте файл <b>my_money_data.json</b> (папка «My Money» на Google Диске) или <b>my_money_oldbook.json</b> — будут взяты только записи Oldbook.</p>
                <div class="btn-row">
                    <button type="button" class="btn" id="sh-import">Импорт из файла…</button>
                    <button type="button" class="btn" id="sh-mm" hidden></button>
                </div>
            </fieldset>
        </div>
        <input type="file" id="sh-file" accept=".json,application/json,text/plain" hidden>`;

        $('#sh-save').addEventListener('click', () => exportBook(false));
        if (canShare) $('#sh-send').addEventListener('click', () => exportBook(true));
        $('#sh-open').addEventListener('click', pickFile);
        $('#sh-import').addEventListener('click', pickFile);
        $('#sh-mm').addEventListener('click', importFromMyMoney);
        $('#sh-file').addEventListener('change', onFilePicked);
        $('#sh-books').addEventListener('click', e => {
            const b = e.target.closest('button[data-act]');
            if (!b) return;
            if (b.dataset.act === 'update') pickFile();
            else if (b.dataset.act === 'unlink') unlink(b.dataset.id);
        });
        OB.on('change', refresh);
        refresh();
    }

    function refresh() {
        if (!$('#sh-books')) return;
        const own = OB.data.ownCount();
        const prof = OB.data.getProfile();
        $('#sh-own-info').textContent = `В вашей книге ${own} ${plural(own, 'запись', 'записи', 'записей')}. Подпись в файле: «${prof.name || 'Без имени'}» (меняется в меню «Правка → Моё имя»).`;
        const books = OB.data.linkedBooks();
        $('#sh-books').innerHTML = books.length ? books.map(b => `
            <div class="book-row">
                <span class="book-ico">${OB.icons.people}</span>
                <span class="book-info"><b>${OB.esc(b.name)}</b><small>${b.count} ${plural(b.count, 'запись', 'записи', 'записей')}${b.savedAt ? ' · файл от ' + OB.fmtDate(new Date(b.savedAt + OB.ALMATY_UTC_OFFSET_HOURS * 3600000).toISOString()) : ''}</small></span>
                <button type="button" class="btn" data-act="update" title="Открыть новый файл этого человека">Обновить…</button>
                <button type="button" class="btn" data-act="unlink" data-id="${OB.esc(b.id)}">Отключить</button>
            </div>`).join('') : '<div class="books-empty">Вы пока не подключили книги других людей.</div>';
        const mm = OB.data.detectMyMoney();
        const btn = $('#sh-mm');
        btn.hidden = !mm;
        if (mm) btn.textContent = `Взять из My Money (${mm.list.length})…`;
    }

    function plural(n, a, b, c) {
        const m = Math.abs(n) % 100, d = m % 10;
        return m > 10 && m < 20 ? c : d > 1 && d < 5 ? b : d === 1 ? a : c;
    }

    // ---------- экспорт ----------
    async function exportBook(viaShare) {
        let prof = OB.data.getProfile();
        if (!prof.name) {
            const name = await OB.ui.prompt('Как подписать вашу книгу? Это имя увидят получатели файла.', '', { title: 'Моё имя', maxlength: 30, placeholder: 'Например: Катя' });
            if (name === null) return;
            if (!name.trim()) { await OB.ui.alert('Имя не указано — книга не сохранена.', { icon: 'warn' }); return; }
            OB.data.setName(name);
            prof = OB.data.getProfile();
        }
        const json = JSON.stringify(OB.data.exportBook(), null, 1);
        const safe = OB.translit(prof.name).replace(/[^A-Za-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '') || 'book';
        const fileName = `oldbook_${safe}_${OB.nowIso().slice(0, 10)}.json`;
        if (viaShare && typeof File === 'function') {
            try {
                const file = new File([json], fileName, { type: 'application/json' });
                await navigator.share({ files: [file], title: 'Книга Oldbook', text: 'Моя книга Oldbook. Откройте файл в Oldbook 95: вкладка «Доступ» → «Открыть файл книги».' });
                OB.status('Книга отправлена');
                return;
            } catch (e) {
                if (e && e.name === 'AbortError') return;   // человек передумал
            }
        }
        const url = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
        const a = document.createElement('a');
        a.href = url; a.download = fileName;
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 4000);
        OB.status(`Книга сохранена в файл ${fileName}`);
    }

    // ---------- импорт ----------
    function pickFile() { const f = $('#sh-file'); f.value = ''; f.click(); }
    OB.pickFile = pickFile;

    async function onFilePicked(e) {
        const file = e.target.files && e.target.files[0];
        e.target.value = '';   // чтобы тот же файл можно было открыть ещё раз
        if (!file) return;
        if (file.size > MAX_FILE) { await OB.ui.alert('Файл слишком большой для книги Oldbook.', { icon: 'error' }); return; }
        let obj;
        try { obj = JSON.parse(await file.text()); }
        catch (err) { await OB.ui.alert('Не удалось прочитать файл: это не JSON.', { icon: 'error' }); return; }
        await handleParsed(OB.data.parseFile(obj));
    }

    function report(r, extra) {
        const parts = [];
        if (r.added) parts.push(`Добавлено записей: ${r.added}.`);
        if (r.same) parts.push(`Уже были: ${r.same}.`);
        if (r.skipped) parts.push(`Пропущено повреждённых: ${r.skipped}.`);
        if (!r.added && !r.same) parts.push('Новых записей нет.');
        if (extra) parts.push(extra);
        return OB.ui.alert(parts.join('\n'), { icon: 'info', title: 'Импорт' });
    }

    async function handleParsed(p) {
        if (p.kind === 'unknown') {
            await OB.ui.alert('Этот файл не похож на книгу Oldbook.\n\nПодходят: файл книги из Oldbook 95, my_money_oldbook.json и my_money_data.json из My Money.', { icon: 'error', title: 'Импорт' });
            return;
        }
        const n = p.entries.length;
        const recs = `${n} ${plural(n, 'запись', 'записи', 'записей')}`;
        if (p.kind === 'own-book') {
            if (!(await OB.ui.confirm(`Это копия вашей книги (${recs}).\nДобавить недостающие записи?`, { title: 'Импорт' }))) return;
            await report(OB.data.mergeOwn(p.entries, p.skipped));
        } else if (p.kind === 'foreign-book') {
            await linkForeign(p, recs);
        } else if (p.kind === 'legacy-book') {
            const who = p.owner.name;
            const v = await OB.ui.choose(`Книга из My Money: «${who}», ${recs}.\n\nЧья это книга?`, [
                { label: 'Моя', value: 'own' },
                { label: 'Чужая', value: 'foreign' },
                { label: 'Отмена', value: null, cancel: true, default: true }
            ], { title: 'Импорт', width: 400 });
            if (v === 'own') await report(OB.data.mergeOwn(p.entries, p.skipped));
            else if (v === 'foreign') await linkForeign(p, recs);
        } else if (p.kind === 'mymoney-data' || p.kind === 'entries') {
            const text = p.kind === 'mymoney-data'
                ? `В файле данных My Money найдено записей Oldbook: ${n}.\nБудут взяты только они — остальное (записи, настройки, темы) не читается.\n\nДобавить в вашу книгу?`
                : `В файле найдено записей: ${n}.\nДобавить в вашу книгу?`;
            if (!(await OB.ui.confirm(text, { title: 'Импорт' }))) return;
            await report(OB.data.mergeOwn(p.entries, p.skipped),
                p.hadLinks ? 'Книги других людей, которые были подключены в My Money, сюда не переносятся: попросите их прислать файл книги и откройте его на вкладке «Доступ».' : '');
        }
    }

    async function linkForeign(p, recs) {
        const ok = await OB.ui.confirm(`Книга пользователя «${p.owner.name}» (${recs}).\n\nПодключить для чтения? Ваши записи не изменятся, чужие записи изменить нельзя.`, { title: 'Принять книгу', yes: 'Подключить', no: 'Отмена' });
        if (!ok) return;
        const r = OB.data.linkBook(p.owner, p.entries, p.savedAt);
        OB.status(r === 'updated' ? `Книга «${p.owner.name}» обновлена` : `Книга «${p.owner.name}» подключена`);
        if (p.skipped) await OB.ui.alert(`Пропущено повреждённых записей: ${p.skipped}.`, { icon: 'warn' });
    }

    async function unlink(id) {
        const b = OB.data.linkedBooks().find(x => x.id === id);
        if (!b) return;
        const ok = await OB.ui.confirm(`Отключить книгу «${b.name}»?\n\nЕё записи перестанут показываться у вас (у владельца ничего не удалится).`, { title: 'Отключить книгу', yes: 'Отключить', no: 'Отмена', danger: true });
        if (ok) { OB.data.unlinkBook(id); OB.status('Книга отключена'); }
    }

    // ---------- перенос из My Money (тот же сайт — общий localStorage; читается только finance_oldbook) ----------
    async function importFromMyMoney() {
        const mm = OB.data.detectMyMoney();
        if (!mm) { await OB.ui.alert('Прежних записей Oldbook из My Money здесь не найдено.\n\nЕсли My Money стоит на другом адресе, откройте файл my_money_data.json через «Файл → Импорт».', { icon: 'info', title: 'My Money' }); return; }
        const ok = await OB.ui.confirm(`Найдена прежняя книга Oldbook из My Money: ${mm.list.length} ${plural(mm.list.length, 'запись', 'записи', 'записей')}.\n\nДобавить их сюда? Данные My Money не изменятся.`, { title: 'My Money' });
        if (!ok) return;
        OB.store.write(OB.KEYS.mmAsked, 1);
        await report(OB.data.mergeOwn(mm.list, mm.skipped));
    }

    // При первом запуске: если рядом лежит прежняя книга из My Money — предложить забрать
    async function offerMyMoney() {
        if (OB.store.read(OB.KEYS.mmAsked, 0)) return;
        const mm = OB.data.detectMyMoney();
        if (!mm) return;
        const n = mm.list.length;
        const v = await OB.ui.choose(`Найдена прежняя книга Oldbook из My Money: ${n} ${plural(n, 'запись', 'записи', 'записей')}.\n\nДобавить их в Oldbook 95? Данные My Money не изменятся.`, [
            { label: 'Добавить', value: 'yes', default: true },
            { label: 'Не сейчас', value: 'later', cancel: true },
            { label: 'Не спрашивать', value: 'never' }
        ], { title: 'My Money', width: 420 });
        if (v === 'yes') { OB.store.write(OB.KEYS.mmAsked, 1); await report(OB.data.mergeOwn(mm.list, mm.skipped)); }
        else if (v === 'never') OB.store.write(OB.KEYS.mmAsked, 1);
    }

    return { render, exportBook, pickFile, importFromMyMoney, offerMyMoney, refresh };
})();
