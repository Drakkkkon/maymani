// --- OLDBOOK 95: ВКЛАДКА «СТАТИСТИКА» («Кто, на что и зачем») ---
// Три диаграммы за выбранный период: кто сколько потратил, на что тратил каждый, доходы и расходы по людям;
// ниже — «зачем»: самые крупные траты с комментариями. Считаются свои записи и подключённые чужие книги.

OB.stats = (function () {
    const $ = OB.$;

    function render() {
        const root = $('#page-stats');
        root.innerHTML = `
        <div class="stats-toolbar">
            <label>Период: <select id="s-period" aria-label="Период статистики">
                <option value="7">Последние 7 дней</option>
                <option value="30">Последние 30 дней</option>
                <option value="month" selected>Этот месяц</option>
                <option value="year">Этот год</option>
                <option value="all">Всё время</option>
            </select></label>
        </div>
        <div class="charts">
            <fieldset class="gb"><legend>Кто сколько потратил</legend><div class="chart-box"><canvas id="c-person"></canvas></div></fieldset>
            <fieldset class="gb"><legend>На что тратил каждый</legend><div class="chart-box"><canvas id="c-cat"></canvas></div></fieldset>
            <fieldset class="gb"><legend>Доходы и расходы по людям</legend><div class="chart-box"><canvas id="c-bal"></canvas></div></fieldset>
        </div>
        <fieldset class="gb" style="margin-top:12px"><legend>Зачем: самые крупные траты</legend><div class="why-list" id="s-why"></div></fieldset>`;
        $('#s-period').addEventListener('change', refresh);
        OB.on('change', () => { if (isVisible()) refresh(); });
        OB.on('resize', () => { if (isVisible()) refresh(); });
    }

    function isVisible() { return $('#page-stats').classList.contains('active') && !$('#app-window').hidden && !$('#app-window').classList.contains('minimized'); }

    function periodStart(today) {
        const p = $('#s-period').value;
        if (p === '7') return OB.nowIso(-6).slice(0, 10);
        if (p === '30') return OB.nowIso(-29).slice(0, 10);
        if (p === 'month') return today.slice(0, 8) + '01';
        if (p === 'year') return today.slice(0, 5) + '01-01';
        return '';
    }

    const sum = arr => arr.reduce((s, e) => s + e.amount, 0);

    function refresh() {
        if (!$('#s-period')) return;
        const today = OB.nowIso().slice(0, 10);
        const start = periodStart(today);
        const list = OB.data.allEntries().filter(e => { const d = String(e.date).slice(0, 10); return d >= start && d <= today; });
        const expenses = list.filter(e => e.type !== 'income');
        const incomes = list.filter(e => e.type === 'income');
        const persons = [...new Set(list.map(OB.data.who))];
        const color = p => OB.charts.personColor(p, persons);

        // 1) кто сколько потратил
        OB.charts.doughnut($('#c-person'), persons
            .map(p => ({ label: p, value: sum(expenses.filter(e => OB.data.who(e) === p)), color: color(p) }))
            .filter(i => i.value > 0));

        // 2) на что тратил каждый: 7 самых затратных категорий, столбики сложены по людям
        const byCat = {};
        expenses.forEach(e => { const k = e.category || 'Без категории'; byCat[k] = (byCat[k] || 0) + e.amount; });
        const cats = Object.entries(byCat).sort((a, b) => b[1] - a[1]).slice(0, 7).map(c => c[0]);
        OB.charts.stackedBars($('#c-cat'), cats, persons.map(p => ({
            name: p, color: color(p),
            data: cats.map(c => sum(expenses.filter(e => OB.data.who(e) === p && (e.category || 'Без категории') === c)))
        })).filter(s => s.data.some(v => v > 0)));

        // 3) доходы и расходы по людям
        OB.charts.groupedBars($('#c-bal'), persons, [
            { name: 'Доход', color: OB.charts.INCOME, data: persons.map(p => sum(incomes.filter(e => OB.data.who(e) === p))) },
            { name: 'Расход', color: OB.charts.EXPENSE, data: persons.map(p => sum(expenses.filter(e => OB.data.who(e) === p))) }
        ]);

        // «зачем»
        const top = expenses.slice().sort((a, b) => b.amount - a.amount).slice(0, 6);
        $('#s-why').innerHTML = top.length ? top.map(e => `
            <div class="why-row">
                <span class="badge" style="background:${color(OB.data.who(e))}">${OB.esc(OB.data.who(e))}</span>
                <span class="why-text"><b>${OB.esc(e.category || '')}</b>${e.comment ? ` — <i>${OB.esc(e.comment)}</i>` : ''}</span>
                <span class="why-sum">${OB.money(e.amount)} ${OB.CURRENCY}</span>
            </div>`).join('') : '<div class="why-empty">Нет расходов за период</div>';
    }

    return { render, refresh };
})();
