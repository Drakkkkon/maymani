// Приложение только на русском (4.22.0). Здесь то немногое, на что опирается остальной код.
const appLang = 'ru';
window.APP_LOCALE = 'ru-RU';
document.documentElement.lang = 'ru';
window.t = s => s;
try { localStorage.removeItem('finance_lang'); } catch (e) {}
