// --- ВИД ПРИЛОЖЕНИЯ: настройки вида, кнопки окон у блоков ---
// uiPrefs синхронизируется через Google Диск (cloud.js, вместе с копилкой, лимитом и т. п.):
//   quotes  — пара котировок на заставке, скрытые стандартные котировки (js/quotes.js);
//   catIcons / catColors / iconMode — картинки категорий, их цвета и вид в «Новой записи» и в истории (js/emoji.js).
// Свёрнутые блоки запоминаются только на этом устройстве (finance_collapsed).

const UI_PREFS_KEY = 'finance_ui';
const COLLAPSED_KEY = 'finance_collapsed';

const UI_DEFAULTS = {
    quotes: { splash: ['AAPL', 'KSPI'], hidden: [] },
    catIcons: { form: {}, history: {} },
    catColors: { form: {}, history: {} },
    iconMode: { form: 'both', history: 'both' }
};

function normalizeUiPrefs(p) {
    const src = (p && typeof p === 'object') ? p : {};
    const obj = (v, d) => (v && typeof v === 'object' && !Array.isArray(v)) ? v : d;
    const q = obj(src.quotes, {});
    const ci = obj(src.catIcons, {});
    const im = obj(src.iconMode, {});
    const cc = obj(src.catColors, {});
    const colorMap = m => Object.fromEntries(Object.entries(obj(m, {})).filter(([k, v]) => k.length < 80 && typeof v === 'string' && /^[a-z]{3,8}$/.test(v)).slice(0, 400));
    const mode = v => ['icon', 'text', 'both'].includes(v) ? v : 'both';
    return {
        quotes: {
            splash: Array.isArray(q.splash) ? q.splash.filter(x => typeof x === 'string').slice(0, 4) : UI_DEFAULTS.quotes.splash.slice(),
            hidden: Array.isArray(q.hidden) ? q.hidden.filter(x => typeof x === 'string') : []
        },
        catIcons: { form: obj(ci.form, {}), history: obj(ci.history, {}) },
        catColors: { form: colorMap(cc.form), history: colorMap(cc.history) },
        iconMode: { form: mode(im.form), history: mode(im.history) },
        notify: normalizeNotifyPrefs(obj(src.notify, {})),
        bank: normalizeBankPrefs(obj(src.bank, {})),
        fonts: obj(src.fonts, {}),
        // Размеры блоков (js/sizes.js): { id блока: 's' | 'm' | 'l' }
        sizes: Object.fromEntries(Object.entries(obj(src.sizes, {})).filter(([k, v]) => typeof k === 'string' && k.length < 80 && ['s', 'm', 'l'].includes(v)).slice(0, 200)),
        // Ширина страниц на ПК (js/sizes.js → «Масштаб» страницы): { id блока: 'm' | 'l' }, компактная ('s') — по умолчанию
        pageSizes: Object.fromEntries(Object.entries(obj(src.pageSizes, {})).filter(([k, v]) => typeof k === 'string' && k.length < 80 && ['m', 'l'].includes(v)).slice(0, 200)),
        layout: normalizeLayoutPrefs(obj(src.layout, {})),
        // 4.14.0: прежние рабочие категории администратора уже добавлены (js/script.js → seedAdminCategories)
        catsSeeded: src.catsSeeded === true,
        // 4.14.0: экран приветствия (js/welcome.js)
        welcome: normalizeWelcomePrefs(obj(src.welcome, {}))
    };
}

// Разметка (js/layout.js ниже): ширина и колонки на ПК, плотность, вид меню, заставка на ПК
function normalizeLayoutPrefs(l) {
    const pick = (v, list, d) => list.includes(v) ? v : d;
    const pct = Number(l.widthPct);
    return {
        pcWidth: pick(l.pcWidth, ['auto', 'full', 'narrow', 'custom'], 'auto'),
        widthPct: Number.isFinite(pct) && pct >= 50 && pct <= 100 ? pct : 80,
        pcCols: pick(String(l.pcCols || 'auto'), ['auto', '1', '2', '3'], 'auto'),
        density: pick(l.density, ['compact', 'normal', 'roomy'], 'normal'),
        pcMenu: pick(l.pcMenu, ['left', 'burger'], 'left'),
        mobileMenu: pick(l.mobileMenu, ['bottom', 'top', 'left', 'burger'], 'bottom'),
        pcSplash: l.pcSplash !== false,
        // 4.9.0: «страницы вместо блоков» — каждый блок раздела отдельной страницей на весь экран (js/pages.js)
        noBlocks: l.noBlocks === true
    };
}

// Экран приветствия (js/welcome.js): mode — standard (как было: погода, часы, котировки), simple (только приветствие на своей
// картинке или анимации), off (без экрана). bg — anim | image; anim — вид анимации; text — своё приветствие ('' — по времени суток)
function normalizeWelcomePrefs(w) {
    const pick = (v, list, d) => list.includes(v) ? v : d;
    return {
        mode: pick(w.mode, ['standard', 'simple', 'off'], 'standard'),
        bg: pick(w.bg, ['anim', 'image'], 'anim'),
        anim: pick(w.anim, ['aurora', 'stars', 'bubbles', 'waves'], 'aurora'),
        text: typeof w.text === 'string' ? w.text.slice(0, 60) : ''
    };
}

// Уведомления (js/notify.js): утро 9:00 с целями, выгрузка за день в 23:00, напоминания подписок по умолчанию
function normalizeNotifyPrefs(n) {
    const offsets = ['1w', '3d', '1d', '3h', '1h', '0'];
    return {
        morning: n.morning !== false,
        daily: n.daily !== false,
        subDefault: Array.isArray(n.subDefault) ? n.subDefault.filter(o => offsets.includes(o)) : ['1d'],
        bank: n.bank !== false
    };
}

// Банк (js/bank.js): выбранный банк, остаток из выписки или уведомления и пороги предупреждений
function normalizeBankPrefs(b) {
    const num = v => { const n = Number(v); return Number.isFinite(n) ? n : null; };
    return {
        name: typeof b.name === 'string' ? b.name.slice(0, 30) : 'kaspi',
        balance: num(b.balance),
        balanceAt: typeof b.balanceAt === 'string' ? b.balanceAt.slice(0, 16) : '',
        source: typeof b.source === 'string' ? b.source.slice(0, 20) : '',
        low: Math.max(0, num(b.low) || 0),
        big: Math.max(0, num(b.big) || 0),
        summary: (b.summary && typeof b.summary === 'object') ? b.summary : null
    };
}

let uiPrefs = normalizeUiPrefs(null);
try { uiPrefs = normalizeUiPrefs(JSON.parse(localStorage.getItem(UI_PREFS_KEY) || 'null')); } catch (e) {}

function saveUiPrefsLocal() {
    try { localStorage.setItem(UI_PREFS_KEY, JSON.stringify(uiPrefs)); } catch (e) {}
}

// Настройки пришли с другого устройства
function setUiPrefs(p) {
    uiPrefs = normalizeUiPrefs(p);
    saveUiPrefsLocal();
    if (typeof renderNotifySettings === 'function') renderNotifySettings();
    applyLayoutPrefs();
    renderLayoutSettings();
    if (typeof applyCardSizes === 'function') applyCardSizes();
    if (typeof applyTheme === 'function' && typeof currentThemeId !== 'undefined') applyTheme(currentThemeId, { save: false }); // шрифты с другого устройства
}

// Изменение настроек на этом устройстве: сохранить и отправить в облако
function commitUiPrefs() {
    saveUiPrefsLocal();
    if (typeof updateUI === 'function') updateUI(true);
}

// ---------- Кнопки окна у блоков: «_» сворачивает, «□» разворачивает на весь экран с прокруткой ----------
function readCollapsed() {
    try { return JSON.parse(localStorage.getItem(COLLAPSED_KEY) || '{}') || {}; } catch (e) { return {}; }
}

function cardKey(card) {
    if (card.id) return card.id;
    const tab = card.closest('.tab');
    const h = card.querySelector(':scope > h3');
    return (tab ? tab.id : 'x') + ':' + (h ? h.textContent.trim().slice(0, 40) : '');
}

// Постоянные id блоков без id: «card-<раздел>-<номер>» по порядку в разметке (нужны для «Стены» и свёрнутых блоков)
let cardIdsAssigned = false;
function assignCardIds() {
    if (cardIdsAssigned) return;
    cardIdsAssigned = true;
    document.querySelectorAll('main > .tab').forEach(tab => {
        let i = 0;
        tab.querySelectorAll('.card').forEach(card => {
            if (!card.id) card.id = `card-${tab.id}-${i}`;
            i++;
        });
    });
}

function enhanceCards(root = document) {
    assignCardIds();
    const collapsed = readCollapsed();
    root.querySelectorAll('main .card').forEach(card => {
        const h = card.querySelector(':scope > h3');
        if (!h) return;
        if (!h.querySelector('.w95-ctls')) {
            h.classList.add('has-controls');
            const ctls = document.createElement('span');
            ctls.className = 'w95-ctls';
            ctls.innerHTML =
                (card.id && !card.classList.contains('wall-info') ? '<button type="button" class="w95-ctl w95-ctl-size" onclick="openCardSizeMenu(this)" title="Размер блока" aria-label="Размер блока" aria-haspopup="menu"></button>' : '') +
                '<button type="button" class="w95-ctl w95-ctl-min" onclick="toggleCardCollapse(this)" title="Свернуть" aria-label="Свернуть блок"></button>' +
                '<button type="button" class="w95-ctl w95-ctl-max" onclick="toggleMaximize(this)" title="Развернуть" aria-label="Развернуть на весь экран"></button>' +
                '<span class="w95-ctl w95-ctl-close" aria-hidden="true"></span>';
            h.appendChild(ctls);
        } else {
            // готовая панель кнопок в разметке: «_» тоже становится настоящей кнопкой, и появляется булавка «На стену»
            const ctlsBox = h.querySelector('.w95-ctls');
            if (card.id && !card.classList.contains('wall-info') && !ctlsBox.querySelector('.w95-ctl-size')) {
                const before = ctlsBox.querySelector('.w95-ctl-min');
                (before || ctlsBox).insertAdjacentHTML(before ? 'beforebegin' : 'afterbegin', '<button type="button" class="w95-ctl w95-ctl-size" onclick="openCardSizeMenu(this)" title="Размер блока" aria-label="Размер блока" aria-haspopup="menu"></button>');
            }
            const min = h.querySelector('.w95-ctl-min');
            if (min && min.tagName !== 'BUTTON') {
                const b = document.createElement('button');
                b.type = 'button';
                b.className = min.className;
                b.title = 'Свернуть';
                b.setAttribute('aria-label', 'Свернуть блок');
                b.setAttribute('onclick', 'toggleCardCollapse(this)');
                min.replaceWith(b);
            }
        }
        // 4.11.0: «Масштаб» и «На стену» — отдельные кнопки внизу блока (а не в шапке). У «Windows 95_Пуск» и «Экстра» они остаются в шапке окна, внизу блока их скрывает css/pages.css
        ensureCardFoot(card);
        // двойное нажатие по заголовку тоже сворачивает (как в Windows)
        if (!h._dbl) {
            h._dbl = true;
            h.addEventListener('dblclick', (e) => {
                if (e.target.closest('button, a, input, select')) return;
                const min = h.querySelector('.w95-ctl-min');
                if (min) toggleCardCollapse(min);
            });
        }
        // 4.9.0: в режиме «страницы вместо блоков» и в меню Настроек свёрнутость игнорируется (js/pages.js), сохранённое значение остаётся
        const pagesOn = typeof pagesIgnoreLayout === 'function' && pagesIgnoreLayout(card);
        card.classList.toggle('is-collapsed', !pagesOn && !!collapsed[cardKey(card)] && !card.classList.contains('is-maximized'));
        syncCollapseButton(card);
    });
}

function ensureCardFoot(card) {
    if (card.parentElement && card.parentElement.closest('.card')) return; // вложенный блок — без своих кнопок
    const canSize = !!card.id && !card.classList.contains('wall-info');
    let foot = card.querySelector(':scope > .card-foot');
    if (!canSize) { if (foot) foot.remove(); return; }
    if (!foot) {
        foot = document.createElement('div');
        foot.className = 'card-foot';
        foot.innerHTML =
            '<button type="button" class="btn-secondary foot-btn foot-size" onclick="openCardSizeMenu(this)" aria-haspopup="menu"><span class="material-icons" aria-hidden="true">aspect_ratio</span><span>Масштаб</span></button>';
    }
    if (foot !== card.lastElementChild) card.appendChild(foot); // всегда самый нижний
    if (typeof syncFootSize === 'function') syncFootSize(card);
}

function syncCollapseButton(card) {
    const min = card.querySelector(':scope > h3 .w95-ctl-min');
    if (!min) return;
    const c = card.classList.contains('is-collapsed');
    min.title = c ? 'Развернуть блок' : 'Свернуть';
    min.setAttribute('aria-label', c ? 'Развернуть блок' : 'Свернуть блок');
    min.setAttribute('aria-expanded', String(!c));
}

function toggleCardCollapse(btn) {
    const card = btn.closest('.card');
    if (!card) return;
    if (card.classList.contains('is-maximized')) {
        const max = card.querySelector('.w95-ctl-max');
        if (max) toggleMaximize(max);
    }
    const collapsed = !card.classList.contains('is-collapsed');
    card.classList.toggle('is-collapsed', collapsed);
    syncCollapseButton(card);
    const state = readCollapsed();
    if (collapsed) state[cardKey(card)] = 1; else delete state[cardKey(card)];
    try { localStorage.setItem(COLLAPSED_KEY, JSON.stringify(state)); } catch (e) {}
    if (typeof playSound === 'function') playSound(collapsed ? 'close' : 'open');
    // диаграммы в развёрнутом блоке пересчитывают размер
    if (!collapsed) setTimeout(() => window.dispatchEvent(new Event('resize')), 30);
}

// ---------- Разметка: ПК по центру, колонки, плотность; вид меню (внизу / слева / гамбургер) ----------
// Всё задаётся атрибутами на <html>, оформление — css/layout.css.
function isDesktopView() {
    return window.innerWidth >= 769;
}

function applyLayoutPrefs() {
    const l = uiPrefs.layout;
    const root = document.documentElement;
    const desktop = isDesktopView();
    root.setAttribute('data-pc-width', l.pcWidth);
    root.style.setProperty('--pc-width-pct', l.widthPct + 'vw');
    root.setAttribute('data-pc-cols', l.pcCols);
    root.setAttribute('data-density', l.density);
    const menu = desktop ? l.pcMenu : l.mobileMenu;
    root.setAttribute('data-menu', menu);
    root.toggleAttribute('data-pc-splash', l.pcSplash);
    if (menu !== 'burger') toggleBurgerMenu(false);
    if (typeof updateMobileNavHeight === 'function') updateMobileNavHeight();
    window.dispatchEvent(new Event('app-layout'));
}

function setLayoutPref(key, value) {
    if (key === 'widthPct') value = Math.round(Number(value));
    if (key === 'pcSplash' || key === 'noBlocks') value = !!value;
    uiPrefs.layout = normalizeLayoutPrefs({ ...uiPrefs.layout, [key]: value });
    applyLayoutPrefs();
    if (key !== 'widthPct') renderLayoutSettings();
    else { const v = document.getElementById('lay-width-val'); if (v) v.textContent = uiPrefs.layout.widthPct + '%'; }
    commitUiPrefs();
}

function toggleBurgerMenu(open) {
    const root = document.documentElement;
    const next = typeof open === 'boolean' ? open : !root.classList.contains('menu-open');
    root.classList.toggle('menu-open', next);
    const btn = document.getElementById('burger-btn');
    if (btn) btn.setAttribute('aria-expanded', String(next));
    if (typeof open !== 'boolean' && typeof playSound === 'function') playSound(next ? 'open' : 'close');
}

function renderLayoutSettings() {
    const box = document.getElementById('layout-settings');
    if (!box) return;
    const l = uiPrefs.layout;
    const seg = (key, opts) => `<div class="seg-buttons" role="radiogroup">${opts.map(([v, label]) =>
        `<button type="button" role="radio" aria-checked="${String(l[key]) === v}" class="seg-btn${String(l[key]) === v ? ' is-on' : ''}" onclick="setLayoutPref('${key}', '${v}')">${label}</button>`).join('')}</div>`;
    box.innerHTML = `
        <h4 class="font-sub">Страницы вместо блоков</h4>
        <label class="sw-row sw-big"><span class="sw-text"><b>Каждый блок — отдельная страница</b><small>Включено — один блок на весь экран, без сетки блоков</small></span>
            <input type="checkbox" class="ios-switch is-lg" ${l.noBlocks ? 'checked' : ''} onchange="setLayoutPref('noBlocks', this.checked)" aria-label="Каждый блок — отдельная страница"></label>
        <p class="hint">Вместо сетки блоков в каждом разделе — один блок на весь экран. Если блоков немного, они переключаются вкладками сверху, если много — списком. Кнопки размера, «На стену», «свернуть» и «развернуть» убираются. «Стена» остаётся как есть. Не действует в темах «Windows 95_Пуск» и «Windows 95_Экстра» (у них свои окна).</p>
        <p class="hint">В меню остаются «Записи» и «Настройки». Нужный блок можно добавить в меню отдельной страницей: Настройки → «Пункты меню» → «Блоки как страницы меню». Кнопка «На стену» на странице спрашивает, каким сделать блок на стене: компактным или оригинальным.</p>
        <h4 class="font-sub">Меню на телефоне</h4>
        ${seg('mobileMenu', [['bottom', 'Внизу'], ['top', 'Сверху'], ['left', 'Слева'], ['burger', 'Гамбургер ☰']])}
        <div class="layout-pc-only">
            <h4 class="font-sub">Меню на ПК</h4>
            ${seg('pcMenu', [['left', 'Слева'], ['burger', 'Гамбургер ☰']])}
            <h4 class="font-sub">Ширина приложения на ПК</h4>
            ${seg('pcWidth', [['auto', 'По центру 16:9'], ['narrow', 'Узко'], ['custom', 'Своя'], ['full', 'Во весь экран']])}
            ${l.pcWidth === 'custom' ? `<label class="hdr-slider"><span>Ширина: <b id="lay-width-val">${l.widthPct}%</b> экрана</span>
                <input type="range" min="50" max="100" step="5" value="${l.widthPct}" oninput="setLayoutPref('widthPct', this.value)"></label>` : ''}
            <p class="hint">«По центру 16:9»: на очень широких экранах приложение не растягивается, а стоит посередине.</p>
            <h4 class="font-sub">Блоки в строке</h4>
            ${seg('pcCols', [['auto', 'Авто'], ['1', '1'], ['2', '2'], ['3', '3']])}
            <h4 class="font-sub">Плотность</h4>
            ${seg('density', [['compact', 'Компактно'], ['normal', 'Обычно'], ['roomy', 'Просторно']])}
        </div>`;
}

// ---------- Экран приветствия: баланс, траты за сегодня, главная цель ----------
function renderSplashExtra() {
    const el = document.getElementById('splash-extra');
    if (!el || typeof transactions === 'undefined') return;
    const balance = transactions.reduce((a, tx) => tx.type === 'income' ? a + tx.amount : a - tx.amount, 0);
    const today = almatyIsoNow().slice(0, 10);
    const spent = transactions.filter(tx => tx.type === 'expense' && !tx.isSystem && getTxDateStr(tx.date) === today).reduce((s, tx) => s + tx.amount, 0);
    const fmt = n => Math.round(n).toLocaleString('ru-RU') + ' ₸';
    el.innerHTML = `<div class="splash-stat"><span>Баланс</span><b>${fmt(balance)}</b></div>
        <div class="splash-stat"><span>Потрачено сегодня</span><b>${fmt(spent)}</b></div>`;
}

window.addEventListener('DOMContentLoaded', () => {
    enhanceCards();
    applyLayoutPrefs();
    renderLayoutSettings();
    // гамбургер: выбор пункта закрывает меню
    const nav = document.getElementById('sidebar-nav');
    if (nav) nav.addEventListener('click', e => { if (e.target.closest('button')) toggleBurgerMenu(false); });
    // заставка на ПК открывается и клавишей Enter / пробелом
    document.addEventListener('keydown', e => {
        const splash = document.getElementById('splash-screen');
        if ((e.key === 'Enter' || e.key === ' ') && splash && !splash.classList.contains('is-gone') && getComputedStyle(splash).display !== 'none' && typeof proceedFromSplash === 'function') {
            e.preventDefault();
            proceedFromSplash();
        }
        if (e.key === 'Escape' && document.documentElement.classList.contains('menu-open')) toggleBurgerMenu(false);
    });
});
window.addEventListener('load', renderSplashExtra);
let layoutWasDesktop = null;
window.addEventListener('resize', () => {
    const d = isDesktopView();
    if (d !== layoutWasDesktop) { layoutWasDesktop = d; applyLayoutPrefs(); }
});
