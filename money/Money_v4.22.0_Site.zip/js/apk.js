// --- 4.20.0: ПРИЛОЖЕНИЕ ANDROID (APK, исходники — папка android-app) ---
// Внутри приложения есть window.MMApp: системные уведомления по расписанию (приходят и при закрытом приложении),
// сохранение файлов в «Загрузки», обновление APK из облака (GitHub). В браузере — только ссылка на скачивание APK.
(function () {
    const app = window.MMApp || null;
    const INFO_URL = 'https://drakkkkon.github.io/maymani/updates/money.json';
    const HUB_URL = 'https://drakkkkon.github.io/maymani/money.html';
    const tr = s => (typeof window.t === 'function' ? window.t(s) : s);
    const box = () => document.getElementById('apk-settings');

    function renderBrowser() {
        const el = box();
        if (!el) return;
        el.innerHTML = `
            <p class="hint">Приложение для Android 10 и новее: уведомления приходят, даже когда оно закрыто, обновления ставятся прямо из приложения.</p>
            <a class="btn-primary btn-block" id="apk-download" href="${HUB_URL}" target="_blank" rel="noopener" style="text-decoration:none;text-align:center;display:block;"><span class="material-icons">download</span> Скачать приложение (APK)</a>
            <p class="hint">Данные из браузера в приложение сами не переходят: войдите в обоих в «Аккаунт My Money» или перенесите резервную копию.</p>`;
        fetch(INFO_URL, { cache: 'no-store' }).then(r => r.json()).then(i => {
            const a = document.getElementById('apk-download');
            if (a && /^https:\/\/raw\.githubusercontent\.com\/Drakkkkon\/maymani\//.test(i.url)) a.href = i.url;
        }).catch(() => {});
    }

    if (!app) {
        window.addEventListener('DOMContentLoaded', renderBrowser);
        return;
    }

    // ---------- Вход через Google: в браузере, токен возвращается в приложение ----------
    window.mmGoogleStart = () => {
        const state = [...crypto.getRandomValues(new Uint8Array(16))].map(b => b.toString(16).padStart(2, '0')).join('');
        localStorage.setItem('finance_g_state', JSON.stringify({ state, at: Date.now() }));
        app.openLogin(state, cloudUser ? cloudUser.email : '');
    };
    window.mmGoogleToken = (token, expires, state) => {
        let want = null;
        try { want = JSON.parse(localStorage.getItem('finance_g_state') || 'null'); } catch (e) {}
        // принимаем только ответ на вход, который сами начали не больше 10 минут назад
        if (!want || !token || want.state !== state || Date.now() - want.at > 600000) return;
        localStorage.removeItem('finance_g_state');
        storeToken(token, expires);
        fetchGoogleProfile()
            .then(() => { renderCloudUi(); return runCloudSync({ manual: true }); })
            .catch(e => { console.warn(e); alert(describeAuthError(e)); });
    };

    // ---------- Отпечаток ----------
    let bioDone = null;
    window.mmBioAsk = title => new Promise(resolve => {
        if (bioDone) bioDone(false);
        bioDone = resolve;
        app.bioAuth(title);
    });
    window.mmBio = ok => { const f = bioDone; bioDone = null; if (f) f(!!ok); };

    // ---------- Голос «средствами браузера»: распознавание Android под тем же интерфейсом ----------
    let rec = null;
    class AppRecognition {
        constructor() { this.lang = 'ru-RU'; }
        start() { rec = this; app.speechStart(this.lang); }
        stop() { app.speechStop(); }
        abort() { app.speechCancel(); if (rec === this) { rec = null; this.onerror && this.onerror({ error: 'aborted' }); this.onend && this.onend(); } }
    }
    if (app.speechAvailable()) window.SpeechRecognition = AppRecognition;
    window.mmSpeech = (type, text) => {
        const r = rec;
        if (!r) return;
        if (type === 'partial' || type === 'final') {
            const result = [{ transcript: text }];
            result.isFinal = type === 'final';
            r.onresult && r.onresult({ resultIndex: 0, results: [result] });
        }
        if (type === 'error') r.onerror && r.onerror({ error: text });
        if (type === 'final' || type === 'error') { rec = null; r.onend && r.onend(); }
    };

    // ---------- Виджет на рабочем столе ----------
    let lastWidget = '';
    function syncWidget() {
        if (typeof window.mmSpentToday !== 'function') return;
        const hide = localStorage.getItem('finance_widget_sums') ? localStorage.getItem('finance_widget_sums') === '0' : !!localStorage.getItem('finance_pin');
        const json = JSON.stringify({ day: almatyIsoNow().slice(0, 10), limit: manualLimit > 0 ? manualLimit : 0, spent: window.mmSpentToday(), hide });
        if (json !== lastWidget) { app.widget(json); lastWidget = json; }
    }

    // ---------- Действия из ярлыков, виджета и уведомлений ----------
    const locked = () => {
        const pin = document.getElementById('pin-screen');
        return !!localStorage.getItem('finance_pin') && (!pinUnlocked || (pin && pin.style.display !== 'none'));
    };
    const splashShown = () => {
        const s = document.getElementById('splash-screen');
        return !!s && getComputedStyle(s).display !== 'none';
    };
    let waiting = '', waitTimer = null, splashSkipped = false;
    window.mmAction = name => {
        waiting = name || app.takeAction();
        if (!waiting || waitTimer) return;
        splashSkipped = false;
        waitTimer = setInterval(() => {
            if (splashShown()) { if (!splashSkipped) { splashSkipped = true; proceedFromSplash(); } return; }
            if (locked()) return; // сначала ПИН-код или отпечаток
            clearInterval(waitTimer); waitTimer = null;
            const what = waiting; waiting = '';
            showTab('transactions');
            if (what !== 'receipt') window.mmOpenEntry(what);
        }, 700);
    };

    // ---------- Файлы: ссылки «скачать» (blob:, data:) внутри приложения сохраняются в «Загрузки» ----------
    const nativeClick = HTMLAnchorElement.prototype.click;
    function saveAnchor(a) {
        if (!a.hasAttribute('download') || !/^(blob|data):/.test(a.href)) return false;
        const name = a.download || 'my_money_file';
        fetch(a.href).then(r => r.blob()).then(async b => {
            if (!window.MoneyNative.saveFile(await blobToBase64(b), name, b.type)) alert('Не удалось сохранить файл.');
        }).catch(() => alert('Не удалось сохранить файл.'));
        return true;
    }
    HTMLAnchorElement.prototype.click = function () { if (!saveAnchor(this)) nativeClick.call(this); };
    document.addEventListener('click', e => {
        const a = e.target.closest && e.target.closest('a[download]');
        if (a && saveAnchor(a)) e.preventDefault();
    }, true);

    // ---------- Расписание уведомлений ----------
    // Что уже показал будильник, пока приложение было закрыто, повторно не показываем
    function takeDelivered() {
        try {
            const done = JSON.parse(app.delivered() || '{}');
            const fired = readFired();
            Object.keys(done).forEach(k => { if (!k.startsWith('remind-export:') && !fired[k]) markFired(k); });
        } catch (e) { console.warn('Уведомления приложения', e); }
    }

    function buildPlan(now = Date.now()) {
        const plan = [];
        const fired = readFired();
        const add = (at, key, tag, title, body) => {
            if (at > now && !fired[key]) plan.push({ at, key, tag: 'mymoney-' + tag, title, body });
        };
        // подписки: ближайшие два списания
        subscriptions.forEach(sub => {
            if (!sub || !sub.id) return;
            let charge = nextSubCharge(sub, now);
            for (let n = 0; n < 2 && charge; n++) {
                const ms = almatyMs(charge);
                if (!subPaidRecently(sub, charge)) {
                    const date = `${charge.slice(8, 10)}.${charge.slice(5, 7)}`;
                    NOTIFY_OFFSETS.filter(o => subReminders(sub).includes(o.id)).forEach(o => {
                        add(ms - o.ms, `sub:${sub.id}:${charge}:${o.id}`, 'sub-' + sub.id, `Подписка «${sub.name}»`,
                            `Списание ${date} в ${subTime(sub)}: ${fmtTenge(sub.amount)}. Не забудьте пополнить счёт.`);
                    });
                }
                charge = nextSubCharge(sub, ms + 7 * 3600000);
            }
        });
        // доброе утро — на месяц вперёд (текст берётся на момент последнего открытия приложения)
        if (uiPrefs.notify.morning) {
            const title = 'Доброе утро' + (profileName ? ', ' + profileName : '') + '!';
            const body = morningText();
            for (let i = 0; i < 31; i++) {
                const day = almatyIsoNow(i).slice(0, 10);
                add(almatyMs(`${day}T0${MORNING_HOUR}:00`), 'morning:' + day, 'morning', title, body);
            }
        }
        // 23:00: файлы создаёт сам сайт, поэтому напоминаем открыть приложение
        const today = almatyIsoNow().slice(0, 10);
        if (uiPrefs.notify.daily && !fired['export:' + today] && transactions.some(t => getTxDateStr(t.date) === today)) {
            add(almatyMs(`${today}T${DAILY_EXPORT_HOUR}:00`), 'remind-export:' + today, 'export',
                'Выгрузка за день', 'Нажмите: приложение откроется и сохранит Excel и PDF в «Загрузки».');
        }
        return plan.sort((a, b) => a.at - b.at).slice(0, 100);
    }

    let lastPlan = '';
    function syncPlan() {
        try {
            const json = JSON.stringify(buildPlan());
            if (json !== lastPlan) { app.plan(json); lastPlan = json; }
        } catch (e) { console.warn('Расписание уведомлений', e); }
    }
    window.mmBuildPlan = buildPlan;

    // ---------- Цвет строки состояния под тему ----------
    let lastColor = '';
    function syncBars() {
        const m = getComputedStyle(document.body).backgroundColor.match(/\d+(\.\d+)?/g);
        if (!m || (m.length > 3 && Number(m[3]) === 0)) return;
        const hex = '#' + m.slice(0, 3).map(x => Math.round(Number(x)).toString(16).padStart(2, '0')).join('');
        if (hex !== lastColor) { lastColor = hex; app.bars(hex); }
    }

    // ---------- Настройки → «Приложение Android» ----------
    function renderApp() {
        const el = box();
        if (!el) return;
        let st = {};
        try { st = JSON.parse(app.updateStatus()); } catch (e) {}
        const allowed = app.notifyAllowed();
        el.innerHTML = `
            <p>Версия приложения: <b>${escapeHtml(st.installed || '—')}</b></p>
            ${st.text ? `<p class="hint">${escapeHtml(tr(st.text))}</p>` : ''}
            ${st.available ? `<button type="button" class="btn-primary btn-block" id="apk-install"><span class="material-icons">system_update</span> Установить обновление ${escapeHtml(st.available)}</button>` : ''}
            <button type="button" class="btn-secondary btn-block" id="apk-check"><span class="material-icons">cloud_download</span> Проверить обновление</button>
            <p class="notify-perm is-${allowed ? 'granted' : 'default'}"><span class="material-icons">${allowed ? 'notifications_active' : 'notifications_off'}</span> ${allowed ? 'Уведомления разрешены' : 'Уведомления ещё не разрешены'}</p>
            <button type="button" class="btn-secondary btn-block" id="apk-notify"><span class="material-icons">settings</span> Настройки уведомлений телефона</button>
            <label class="sw-row"><span>Показывать суммы на виджете рабочего стола</span><input type="checkbox" class="ios-switch" id="apk-widget-sums" ${(localStorage.getItem('finance_widget_sums') ? localStorage.getItem('finance_widget_sums') === '1' : !localStorage.getItem('finance_pin')) ? 'checked' : ''}></label>`;
        const sums = document.getElementById('apk-widget-sums');
        if (sums) sums.onchange = () => { localStorage.setItem('finance_widget_sums', sums.checked ? '1' : '0'); syncWidget(); };
        const on = (id, fn) => { const b = document.getElementById(id); if (b) b.onclick = fn; };
        on('apk-install', () => app.updateInstall());
        on('apk-check', () => { showToast('Проверяю обновление…'); app.updateCheck(); });
        on('apk-notify', () => app.notifySettings());
    }

    // ---------- Вызовы из Android ----------
    window.mmUpdate = renderApp;
    window.mmPermission = () => { renderApp(); renderNotifySettings(); lastPlan = ''; syncPlan(); };
    window.mmResume = () => { takeDelivered(); renderApp(); renderNotifySettings(); };
    window.mmPause = () => { syncPlan(); syncWidget(); };
    // кнопка «Назад»: сначала закрываем открытое окно
    window.mmBack = () => {
        const all = [...document.querySelectorAll('.export-sheet-overlay')].filter(o => o.offsetParent !== null || getComputedStyle(o).display !== 'none');
        const top = all[all.length - 1];
        if (!top) return !!(window.mmCloseEntry && window.mmCloseEntry());
        const close = top.querySelector('.export-sheet-close, [data-act="close"]');
        if (close) close.click(); else top.remove();
        return true;
    };

    takeDelivered();
    window.addEventListener('DOMContentLoaded', () => {
        renderApp();
        setTimeout(() => window.mmAction(), 1200);
        setInterval(syncWidget, 3000);
        setTimeout(() => { syncPlan(); syncBars(); }, 4000);
        setInterval(syncPlan, 20000);
        setInterval(syncBars, 2000);
    });
})();
