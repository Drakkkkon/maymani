
let transactions = [];
let priorityGoal = { name: '', amount: 0, icon: '🎯' };
let manualLimit = 0;
let savings = 0;
let currentReportType = 'days';

function init() {
    loadData();
    checkDailyRollover();
    
    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('tx-datetime').value = now.toISOString().slice(0,16);
    
    document.querySelectorAll('.icon-btn').forEach(btn => {
        btn.onclick = (e) => {
            document.querySelectorAll('.icon-btn').forEach(b => b.classList.remove('selected'));
            e.target.classList.add('selected');
        }
    });

    updateUI();
}

function loadData() {
    const dTx = localStorage.getItem('finance_tx');
    const dGoal = localStorage.getItem('finance_goal');
    const dLimit = localStorage.getItem('finance_limit');
    const dSavings = localStorage.getItem('finance_savings');
    const dTheme = localStorage.getItem('finance_theme');
    const dBg = localStorage.getItem('finance_bg');
    
    const dSyncUrl = localStorage.getItem('finance_sync_url');
    const dSyncId = localStorage.getItem('finance_sync_id');

    if (dTx) transactions = JSON.parse(dTx);
    if (dGoal) priorityGoal = JSON.parse(dGoal);
    if (dLimit) manualLimit = parseFloat(dLimit);
    if (dSavings) savings = parseFloat(dSavings);
    
    if (dTheme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
        document.getElementById('theme-icon').innerText = 'light_mode';
    }
    
    if (dBg) setHeaderBg(dBg);
    if (dSyncUrl) document.getElementById('sync-url').value = dSyncUrl;
    if (dSyncId) document.getElementById('sync-id').value = dSyncId;

    document.getElementById('manual-limit').value = manualLimit > 0 ? manualLimit : '';
}

function toggleTheme() {
    const root = document.documentElement;
    const isDark = root.getAttribute('data-theme') === 'dark';
    root.setAttribute('data-theme', isDark ? 'light' : 'dark');
    document.getElementById('theme-icon').innerText = isDark ? 'dark_mode' : 'light_mode';
    localStorage.setItem('finance_theme', isDark ? 'light' : 'dark');
}

function setHeaderBg(bgClass) {
    document.getElementById('main-header').className = bgClass;
    localStorage.setItem('finance_bg', bgClass);
}

function getTxDateStr(datetimeStr) {
    return datetimeStr.includes('T') ? datetimeStr.split('T')[0] : datetimeStr;
}

function checkDailyRollover() {
    let nowStr = new Date().toISOString();
    const today = nowStr.split('T')[0];
    let lastDate = localStorage.getItem('finance_lastDate');
    
    if (!lastDate) {
        localStorage.setItem('finance_lastDate', today);
        return;
    }
    
    if (lastDate !== today && manualLimit > 0) {
        let dayExpenses = transactions
            .filter(t => getTxDateStr(t.date) === lastDate && t.type === 'expense' && !t.isSystem)
            .reduce((sum, t) => sum + t.amount, 0);
            
        let saved = manualLimit - dayExpenses;
        
        if (saved > 0 && priorityGoal.amount > 0) {
            savings += saved;
            transactions.push({
                id: Date.now().toString(),
                type: 'expense',
                amount: saved,
                category: 'Автоперенос в копилку (остаток лимита)',
                date: lastDate + 'T23:59',
                isSystem: true
            });
            sendNotification("Перевод в копилку", `Вчера вы сэкономили ${saved} ₸, они отправлены на цель!`);
        }
        localStorage.setItem('finance_lastDate', today);
    }
}

function updateUI() {
    saveDataLocally();

    let balance = transactions.reduce((acc, tx) => tx.type === 'income' ? acc + tx.amount : acc - tx.amount, 0);
    document.getElementById('balance').innerText = `${balance.toFixed(0)} ₸`;
    document.getElementById('savings').innerText = `${savings.toFixed(0)} ₸`;
    document.getElementById('daily-limit-display').innerText = manualLimit > 0 ? `${manualLimit} ₸` : 'Не установлен';

    renderTransactions();
    renderGoal();
    generateReport(); 
}

function renderTransactions() {
    const txList = document.getElementById('tx-list');
    txList.innerHTML = '';
    
    if (transactions.length === 0) {
        txList.innerHTML = '<p class="hint" style="text-align:center; padding: 20px;">Записей пока нет</p>';
        return;
    }

    let sortedAsc = [...transactions].sort((a,b) => new Date(a.date.replace('T', ' ')) - new Date(b.date.replace('T', ' ')));
    let groups = {};
    let runBalance = 0;
    
    sortedAsc.forEach(tx => {
        runBalance += (tx.type === 'income' ? tx.amount : -tx.amount);
        let dDate = getTxDateStr(tx.date);
        
        if(!groups[dDate]) groups[dDate] = { income: 0, expense: 0, endBalance: 0, items: [] };
        
        if(!tx.isSystem) {
            if(tx.type === 'income') groups[dDate].income += tx.amount;
            else groups[dDate].expense += tx.amount;
        }
        groups[dDate].endBalance = runBalance;
        groups[dDate].items.push(tx);
    });

    let datesDesc = Object.keys(groups).sort((a,b) => new Date(b) - new Date(a));
    
    datesDesc.forEach(date => {
        let g = groups[date];
        let [y, m, d] = date.split('-');
        let fDate = `${d}.${m}.${y}`;
        
        let header = document.createElement('div');
        header.className = 'date-group-header';
        header.innerHTML = `
            <h4>${fDate}</h4>
            <p>
                <span style="color:var(--income)">+${g.income}</span> 
                <span style="color:var(--expense)">-${g.expense}</span> 
                <span>Итог: <strong>${g.endBalance} ₸</strong></span>
            </p>
        `;
        txList.appendChild(header);
        
        let itemsDesc = g.items.reverse();
        itemsDesc.forEach(tx => {
            let sign = tx.type === 'income' ? '+' : '-';
            let timeStr = tx.date.includes('T') ? ` <span style="font-size:12px;color:#aaa;">${tx.date.split('T')[1]}</span>` : '';
            let div = document.createElement('div');
            div.className = `tx-item ${tx.type}`;
            div.innerHTML = `
                <div class="tx-info">
                    <strong>${tx.category}</strong><br>${timeStr}
                </div>
                <strong style="font-size: 16px;">${sign}${tx.amount} ₸</strong>
                ${tx.isSystem ? '' : `
                <div class="tx-actions">
                    <button onclick="editTx('${tx.id}')"><span class="material-icons" style="font-size:18px;">edit</span></button>
                    <button onclick="deleteTx('${tx.id}')"><span class="material-icons" style="font-size:18px; color:#f44336;">delete</span></button>
                </div>
                `}
            `;
            txList.appendChild(div);
        });
    });
}

function saveTx(type) {
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;
    const datetime = document.getElementById('tx-datetime').value; 
    
    if (!amount || !category || !datetime) {
        alert('Заполните все поля!');
        return;
    }
    
    transactions.push({ id: Date.now().toString(), type, amount, category, date: datetime });
    
    let dDate = getTxDateStr(datetime);
    if (type === 'expense' && manualLimit > 0) {
        let todayExp = transactions
            .filter(t => getTxDateStr(t.date) === dDate && t.type === 'expense' && !t.isSystem)
            .reduce((sum, t) => sum + t.amount, 0);
            
        if (todayExp > manualLimit) {
            sendNotification("Превышен лимит!", `Потрачено ${todayExp} ₸, лимит: ${manualLimit} ₸.`);
        }
    }

    clearForm();
    updateUI();
}

function deleteTx(id) {
    if(confirm("Удалить запись?")) {
        transactions = transactions.filter(t => t.id !== id);
        updateUI();
    }
}

function editTx(id) {
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        document.getElementById('edit-id').value = tx.id;
        document.getElementById('tx-datetime').value = tx.date.includes('T') ? tx.date : tx.date + 'T00:00';
        document.getElementById('amount').value = tx.amount;
        document.getElementById('category').value = tx.category;
        
        document.getElementById('add-btns').style.display = 'none';
        document.getElementById('save-edit-btn').style.display = 'flex';
        
        // Для мобилок, если мы не на вкладке транзакций - перекидываем туда
        if(window.innerWidth <= 768) {
             showTab('transactions', document.querySelector('.mobile-nav button'));
        }
        
        document.querySelector('.main-wrapper').scrollTo(0, 0);
    }
}

function saveEdit() {
    const id = document.getElementById('edit-id').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;
    const datetime = document.getElementById('tx-datetime').value;
    
    if (!amount || !category || !datetime) return;
    
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        tx.amount = amount;
        tx.category = category;
        tx.date = datetime;
    }
    
    clearForm();
    updateUI();
}

function clearForm() {
    document.getElementById('amount').value = '';
    document.getElementById('category').value = '';
    document.getElementById('edit-id').value = '';
    document.getElementById('add-btns').style.display = 'flex';
    document.getElementById('save-edit-btn').style.display = 'none';
    
    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('tx-datetime').value = now.toISOString().slice(0,16);
}

// ОТЧЕТЫ 
function generateReport() {
    let type = document.getElementById('report-type').value;
    currentReportType = type;
    const tbody = document.getElementById('report-tbody');
    tbody.innerHTML = '';
    
    let groups = {};
    
    transactions.forEach(tx => {
        if(tx.isSystem) return; 
        let dt = tx.date;
        if(!dt.includes('T')) dt += 'T00:00';
        
        let dateObj = new Date(dt);
        let key = '';
        
        if (type === 'days') {
            key = dt.split('T')[0];
        } else if (type === 'hours') {
            let hour = dt.split('T')[1].split(':')[0];
            key = `${dt.split('T')[0]} ${hour}:00`;
        } else if (type === 'weeks') {
            let d = new Date(Date.UTC(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate()));
            let dayNum = d.getUTCDay() || 7;
            d.setUTCDate(d.getUTCDate() + 4 - dayNum);
            let yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
            let weekNo = Math.ceil((((d - yearStart) / 86400000) + 1)/7);
            key = `Нед. ${weekNo} (${d.getUTCFullYear()})`;
        }
        
        if(!groups[key]) groups[key] = { inc: 0, exp: 0 };
        if(tx.type === 'income') groups[key].inc += tx.amount;
        else groups[key].exp += tx.amount;
    });
    
    let sortedKeys = Object.keys(groups).sort((a,b) => b.localeCompare(a));
    
    if (sortedKeys.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">Нет данных</td></tr>';
        return;
    }
    
    sortedKeys.forEach(k => {
        let g = groups[k];
        let total = g.inc - g.exp;
        let totalColor = total > 0 ? 'var(--income)' : (total < 0 ? 'var(--expense)' : 'inherit');
        let sign = total > 0 ? '+' : '';
        
        let displayKey = k;
        if(type === 'days') {
            let [y, m, d] = k.split('-');
            displayKey = `${d}.${m}.${y}`;
        } else if(type === 'hours') {
            let parts = k.split(' ');
            let [y, m, d] = parts[0].split('-');
            displayKey = `${d}.${m} ${parts[1]}`;
        }

        tbody.innerHTML += `<tr>
            <td>${displayKey}</td>
            <td style="color:var(--income)">${g.inc}</td>
            <td style="color:var(--expense)">${g.exp}</td>
            <td style="color:${totalColor}; font-weight:bold;">${sign}${total}</td>
        </tr>`;
    });
}

function exportReportCSV() {
    let typeName = { 'days': 'По_дням', 'weeks': 'По_неделям', 'hours': 'По_часам' }[currentReportType];
    let csv = '\uFEFFПериод,Доход,Расход,Итог\n'; 
    
    const rows = document.querySelectorAll('#report-tbody tr');
    if(rows.length === 0 || rows[0].innerText.includes('Нет данных')) return;
    
    rows.forEach(tr => {
        let cols = tr.querySelectorAll('td');
        csv += `"${cols[0].innerText}",${cols[1].innerText},${cols[2].innerText},${cols[3].innerText}\n`;
    });
    
    downloadFile(csv, `Отчет_${typeName}.csv`);
}

function exportTransactionsCSV() {
    let csv = '\uFEFFДата,Время,Тип,Категория,Сумма\n'; 
    transactions.forEach(tx => {
        let dt = tx.date;
        if(!dt.includes('T')) dt += 'T00:00';
        let datePart = dt.split('T')[0];
        let timePart = dt.split('T')[1];
        let typeStr = tx.type === 'income' ? 'Доход' : 'Расход';
        csv += `${datePart},${timePart},${typeStr},"${tx.category}",${tx.amount}\n`;
    });
    downloadFile(csv, `Все_записи_${new Date().toISOString().split('T')[0]}.csv`);
}

function downloadFile(content, filename) {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();
}

// ЦЕЛИ
function setPriorityGoal() {
    const name = document.getElementById('goal-name').value;
    const amount = parseFloat(document.getElementById('goal-amount').value);
    const icon = document.querySelector('.icon-btn.selected').getAttribute('data-icon');
    
    if (!name || !amount) return;
    priorityGoal = { name, amount, icon };
    updateUI();
}

function renderGoal() {
    const gd = document.getElementById('current-goal-display');
    if (priorityGoal.name && priorityGoal.amount > 0) {
        let percent = Math.min(100, (savings / priorityGoal.amount) * 100);
        gd.innerHTML = `
            <h4>${priorityGoal.icon} ${priorityGoal.name}</h4>
            <p>Собрано: ${savings.toFixed(0)} ₸ из ${priorityGoal.amount} ₸ (${percent.toFixed(1)}%)</p>
            <div class="goal-progress">
                <div class="goal-bar" style="width: ${percent}%"></div>
            </div>
        `;
    }
}

// НАСТРОЙКИ И ДАННЫЕ
function saveSettings() {
    const l = parseFloat(document.getElementById('manual-limit').value);
    manualLimit = isNaN(l) ? 0 : l;
    
    const url = document.getElementById('sync-url').value.trim();
    const id = document.getElementById('sync-id').value.trim();
    localStorage.setItem('finance_sync_url', url);
    localStorage.setItem('finance_sync_id', id);
    
    updateUI();
    alert('Настройки сохранены!');
}

function saveDataLocally() {
    localStorage.setItem('finance_tx', JSON.stringify(transactions));
    localStorage.setItem('finance_savings', savings.toString());
    localStorage.setItem('finance_limit', manualLimit.toString());
    localStorage.setItem('finance_goal', JSON.stringify(priorityGoal));
}

function exportBackup() {
    const data = {
        tx: transactions,
        savings: savings,
        limit: manualLimit,
        goal: priorityGoal,
        lastDate: localStorage.getItem('finance_lastDate')
    };
    const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `money1.3_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
}

function importBackup(event) {
    const file = event.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            if(data.tx) transactions = data.tx;
            if(data.savings !== undefined) savings = data.savings;
            if(data.limit !== undefined) manualLimit = data.limit;
            if(data.goal) priorityGoal = data.goal;
            if(data.lastDate) localStorage.setItem('finance_lastDate', data.lastDate);
            updateUI();
            alert("Данные успешно восстановлены!");
        } catch (err) {
            alert("Ошибка чтения файла!");
        }
    };
    reader.readAsText(file);
}

function clearAllData() {
    if(confirm("ВНИМАНИЕ! Это удалит все ваши записи локально. Продолжить?")) {
        localStorage.removeItem('finance_tx');
        localStorage.removeItem('finance_savings');
        localStorage.removeItem('finance_limit');
        localStorage.removeItem('finance_goal');
        localStorage.removeItem('finance_lastDate');
        
        transactions = [];
        savings = 0;
        manualLimit = 0;
        priorityGoal = { name: '', amount: 0, icon: '🎯' };
        updateUI();
    }
}

// ОБЛАЧНАЯ СИНХРОНИЗАЦИЯ (REST API FIREBASE)
function getSyncConfig() {
    let url = document.getElementById('sync-url').value.trim();
    let id = document.getElementById('sync-id').value.trim();
    if(url && url.endsWith('/')) url = url.slice(0, -1);
    return { url, id };
}

async function pushToCloud() {
    const { url, id } = getSyncConfig();
    const status = document.getElementById('sync-status');
    if(!url || !id) {
        status.innerText = '❌ Заполните URL и ID!';
        status.style.color = '#f44336';
        return;
    }
    
    saveSettings(); // сохраняем url/id локально
    status.innerText = '⏳ Отправка...';
    status.style.color = '#607d8b';
    
    const data = {
        tx: transactions,
        savings: savings,
        limit: manualLimit,
        goal: priorityGoal,
        lastDate: localStorage.getItem('finance_lastDate')
    };
    
    try {
        const response = await fetch(`${url}/${id}.json`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if(response.ok) {
            status.innerText = '✅ Данные успешно отправлены в облако!';
            status.style.color = '#4CAF50';
        } else {
            throw new Error('Server error');
        }
    } catch(err) {
        status.innerText = '❌ Ошибка сети или неверный URL';
        status.style.color = '#f44336';
    }
}

async function pullFromCloud() {
    const { url, id } = getSyncConfig();
    const status = document.getElementById('sync-status');
    if(!url || !id) {
        status.innerText = '❌ Заполните URL и ID!';
        status.style.color = '#f44336';
        return;
    }
    
    saveSettings(); 
    status.innerText = '⏳ Скачивание...';
    status.style.color = '#607d8b';
    
    try {
        const response = await fetch(`${url}/${id}.json`);
        if(response.ok) {
            const data = await response.json();
            if(data) {
                if(data.tx) transactions = data.tx;
                if(data.savings !== undefined) savings = data.savings;
                if(data.limit !== undefined) manualLimit = data.limit;
                if(data.goal) priorityGoal = data.goal;
                if(data.lastDate) localStorage.setItem('finance_lastDate', data.lastDate);
                updateUI();
                status.innerText = '✅ Данные загружены из облака!';
                status.style.color = '#4CAF50';
            } else {
                status.innerText = '⚠️ В облаке пока нет данных для этого ID.';
                status.style.color = '#ff9800';
            }
        } else {
            throw new Error('Server error');
        }
    } catch(err) {
        status.innerText = '❌ Ошибка сети или неверный URL';
        status.style.color = '#f44336';
    }
}

function showTab(tabId, btn) {
    document.querySelectorAll('.tab').forEach(t => t.style.display = 'none');
    
    // Подсветка кнопок и в мобильном, и в десктопном меню
    document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
    
    let btnIndex = Array.from(btn.parentNode.children).indexOf(btn);
    if(document.querySelector('.sidebar-nav').children[btnIndex]) {
        document.querySelector('.sidebar-nav').children[btnIndex].classList.add('active');
    }
    if(document.querySelector('.mobile-nav').children[btnIndex]) {
        document.querySelector('.mobile-nav').children[btnIndex].classList.add('active');
    }
    
    document.getElementById(tabId).style.display = 'block';
}

function sendNotification(title, body) {
    if(window.Notification && Notification.permission === "granted") {
        new Notification(title, {body: body});
    } else if (window.Notification && Notification.permission !== "denied") {
        Notification.requestPermission().then(perm => {
            if(perm === "granted") new Notification(title, {body: body});
        });
    }
}

window.onload = init;
