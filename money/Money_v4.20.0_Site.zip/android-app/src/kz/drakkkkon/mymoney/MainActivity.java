package kz.drakkkkon.mymoney;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.OutputStream;
import org.json.JSONObject;

/** Приложение My Money: сайт плюс то, чего нет у сайта, — уведомления, «Загрузки», камера, обновление APK. */
public class MainActivity extends Activity {
    private static final String HOME = "https://drakkkkon.github.io/my-money/";
    private static final int PICK = 1, ASK_NOTIFY = 2, ASK_MIC = 3;

    private WebView web;
    private FrameLayout root;
    private ValueCallback<Uri[]> picker;
    private Uri photo;
    private PermissionRequest micRequest;
    private volatile Updater.Release update;
    private volatile String updateText = "";
    private long lastUpdateCheck;
    private boolean checking, waitingPermission;
    private int offered;
    private AlertDialog offer;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        root = new FrameLayout(this);
        root.addView(web);
        // не залезаем под строку состояния, кнопки навигации и клавиатуру
        root.setOnApplyWindowInsetsListener((View v, WindowInsets in) -> {
            v.setPadding(in.getSystemWindowInsetLeft(), in.getSystemWindowInsetTop(),
                    in.getSystemWindowInsetRight(), in.getSystemWindowInsetBottom());
            return in.consumeSystemWindowInsets();
        });
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        Bridge bridge = new Bridge();
        web.addJavascriptInterface(bridge, "MMApp");
        web.addJavascriptInterface(bridge, "MoneyNative"); // это имя уже ищет script.js для сохранения файлов

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                if (request.getUrl().toString().startsWith(HOME)) return false;
                // всё чужое открываем в браузере: мост доступен только нашему сайту
                String scheme = request.getUrl().getScheme();
                if ("https".equals(scheme) || "http".equals(scheme) || "mailto".equals(scheme) || "tel".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl()));
                    } catch (ActivityNotFoundException e) {
                        say("Нечем открыть ссылку");
                    }
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (!request.isForMainFrame()) return;
                view.loadDataWithBaseURL(null, "<meta charset=utf-8><meta name=viewport content='width=device-width'>"
                        + "<body style='font:18px sans-serif;text-align:center;padding:40px'>Нет связи. Для первого запуска нужен интернет."
                        + "<p><a href='" + HOME + "'>Повторить</a></p>", "text/html", "utf-8", null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                return chooseFile(callback, params);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> microphone(request));
            }
        });

        Notify.channels(this);
        Notify.run(getApplicationContext());
        UpdateJob.schedule(getApplicationContext());
        if (state == null || web.restoreState(state) == null) web.loadUrl(HOME);

        // один раз при первом запуске спрашиваем разрешение на уведомления
        if (!getPreferences(MODE_PRIVATE).getBoolean("asked", false)) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("asked", true).apply();
            askNotifications();
        }
    }

    private boolean chooseFile(ValueCallback<Uri[]> callback, WebChromeClient.FileChooserParams params) {
        if (picker != null) picker.onReceiveValue(null);
        picker = callback;
        photo = null;
        boolean images = false;
        for (String type : params.getAcceptTypes()) if (type.startsWith("image/")) images = true;
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType(images ? "image/*" : "*/*")
                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);
        Intent chooser = Intent.createChooser(pick, images ? "Фото" : "Файл");
        if (images) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, "mymoney_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/My Money");
            photo = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (photo != null) {
                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, photo)
                        .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                camera.setClipData(ClipData.newRawUri("", photo));
                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
            }
        }
        try {
            startActivityForResult(chooser, PICK);
        } catch (ActivityNotFoundException e) {
            picker = null;
            return false;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        if (request != PICK || picker == null) return;
        Uri[] uris = null;
        boolean usedPhoto = false;
        if (result == RESULT_OK) {
            if (data != null && data.getClipData() != null && data.getData() == null) {
                ClipData clip = data.getClipData();
                uris = new Uri[clip.getItemCount()];
                for (int i = 0; i < uris.length; i++) uris[i] = clip.getItemAt(i).getUri();
            } else if (data != null && data.getData() != null) {
                uris = new Uri[]{data.getData()};
            } else if (photo != null) {
                uris = new Uri[]{photo};
                usedPhoto = true;
            }
        }
        // камеру не использовали — убираем пустую заготовку
        if (photo != null && !usedPhoto) getContentResolver().delete(photo, null, null);
        photo = null;
        picker.onReceiveValue(uris);
        picker = null;
    }

    private void microphone(PermissionRequest request) {
        boolean ours = HOME.startsWith(request.getOrigin().toString());
        boolean audioOnly = request.getResources().length == 1
                && PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(request.getResources()[0]);
        if (!ours || !audioOnly) {
            request.deny();
        } else if (checkSelfPermission("android.permission.RECORD_AUDIO") == PackageManager.PERMISSION_GRANTED) {
            request.grant(request.getResources());
        } else {
            micRequest = request;
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, ASK_MIC);
        }
    }

    private void askNotifications() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, ASK_NOTIFY);
        }
    }

    @Override
    public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (request == ASK_NOTIFY) js("window.mmPermission&&mmPermission(" + Notify.allowed(this) + ")");
        if (request == ASK_MIC && micRequest != null) {
            if (ok) micRequest.grant(micRequest.getResources());
            else micRequest.deny();
            micRequest = null;
        }
    }

    private void js(String code) {
        web.evaluateJavascript(code, null);
    }

    private void say(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    /** Методы, которые вызывает сайт (js/apk.js и script.js). */
    private class Bridge {
        @JavascriptInterface
        public boolean saveFile(String base64, String fileName, String mime) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                String name = fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
                String type = mime == null || mime.isEmpty() ? "application/octet-stream" : mime.split(";")[0];
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                values.put(MediaStore.MediaColumns.MIME_TYPE, type);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return false;
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(bytes);
                }
                runOnUiThread(() -> say("Сохранено в «Загрузки»: " + name));
                Notify.saved(getApplicationContext(), name, uri, type);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean notifyAllowed() {
            return Notify.allowed(MainActivity.this);
        }

        @JavascriptInterface
        public void notifyAsk() {
            runOnUiThread(() -> {
                boolean mayAsk = Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
                        && shouldShowRequestPermissionRationale("android.permission.POST_NOTIFICATIONS");
                if (mayAsk) askNotifications();
                else if (!Notify.allowed(MainActivity.this)) notifySettings();
                else js("window.mmPermission&&mmPermission(true)");
            });
        }

        @JavascriptInterface
        public void notifySettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())));
        }

        @JavascriptInterface
        public void notify(String tag, String title, String body) {
            Notify.show(getApplicationContext(), tag, title, body);
        }

        @JavascriptInterface
        public void plan(String json) {
            Notify.plan(getApplicationContext(), json);
        }

        @JavascriptInterface
        public String delivered() {
            return Notify.delivered(getApplicationContext());
        }

        /** Цвет строки состояния под тему сайта. */
        @JavascriptInterface
        public void bars(String hex) {
            runOnUiThread(() -> {
                try {
                    int color = Color.parseColor(hex);
                    boolean light = Color.luminance(color) > 0.4f;
                    root.setBackgroundColor(color);
                    getWindow().setStatusBarColor(color);
                    getWindow().setNavigationBarColor(color);
                    View decor = getWindow().getDecorView();
                    int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    int now = decor.getSystemUiVisibility();
                    decor.setSystemUiVisibility(light ? now | flags : now & ~flags);
                } catch (IllegalArgumentException ignored) {
                }
            });
        }

        @JavascriptInterface
        public String updateStatus() {
            try {
                Updater.Release r = update;
                return new JSONObject().put("installed", Updater.installedName(MainActivity.this))
                        .put("available", r == null ? "" : r.version).put("text", updateText).toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void updateCheck() {
            runOnUiThread(() -> checkUpdate(true));
        }

        @JavascriptInterface
        public void updateInstall() {
            runOnUiThread(MainActivity.this::installUpdate);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (waitingPermission) {
            // вернулись из настроек, где разрешают установку
            waitingPermission = false;
            if (getPackageManager().canRequestPackageInstalls()) installUpdate();
        } else if (System.currentTimeMillis() - lastUpdateCheck > 3 * 3600_000L) {
            checkUpdate(false);
        }
        js("window.mmResume&&mmResume()");
    }

    private void checkUpdate(boolean asked) {
        if (checking) return;
        checking = true;
        lastUpdateCheck = System.currentTimeMillis();
        new Thread(() -> {
            Updater.Release found = null;
            String text;
            try {
                found = Updater.fetch(getApplicationContext());
                text = found == null ? "Установлена последняя версия." : "Версия " + found.version + " скачана.";
            } catch (Exception e) {
                text = "Не получилось проверить обновление. Проверьте интернет и попробуйте ещё раз.";
                lastUpdateCheck = 0;
            }
            final Updater.Release result = found;
            final String message = text;
            runOnUiThread(() -> {
                checking = false;
                if (isDestroyed()) return;
                update = result;
                updateText = message;
                js("window.mmUpdate&&mmUpdate()");
                if (result != null && !isFinishing() && (asked || offered != result.code)) offerUpdate(result);
            });
        }).start();
    }

    private void offerUpdate(Updater.Release r) {
        if (offer != null && offer.isShowing()) return;
        offered = r.code;
        offer = new AlertDialog.Builder(this)
                .setTitle("Доступна версия " + r.version)
                .setMessage(r.notes)
                .setPositiveButton("Обновить", (d, w) -> installUpdate())
                .setNegativeButton("Позже", null)
                .show();
    }

    private void installUpdate() {
        Updater.Release r = update;
        if (r == null) {
            checkUpdate(true);
            return;
        }
        if (!getPackageManager().canRequestPackageInstalls()) {
            say("Разрешите установку для «My Money» и вернитесь назад");
            waitingPermission = true;
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException e) {
                waitingPermission = false;
                say("Откройте настройки телефона и разрешите установку из этого приложения");
            }
            return;
        }
        new Thread(() -> {
            try {
                Updater.install(getApplicationContext(), r.file);
            } catch (Exception e) {
                // файл мог пропасть из кэша: при следующей попытке скачаем заново
                runOnUiThread(() -> {
                    update = null;
                    say("Не получилось начать установку. Нажмите «Проверить обновление».");
                });
            }
        }).start();
    }

    @Override
    public void onBackPressed() {
        // сначала даём сайту закрыть открытое окно или страницу настроек
        web.evaluateJavascript("window.mmBack?mmBack():false", handled -> {
            if ("true".equals(handled)) return;
            if (web.canGoBack()) web.goBack();
            else moveTaskToBack(true);
        });
    }

    @Override
    protected void onPause() {
        js("window.mmPause&&mmPause()");
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
