package kz.drakkkkon.mymoney;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Системные уведомления. Сайт присылает расписание (план), будильник Android показывает записи плана,
 * даже когда приложение закрыто. Показанные ключи запоминаются, чтобы не повторяться.
 */
final class Notify {
    private static final String REMINDERS = "reminders", FILES = "files", UPDATES = "updates";
    /** Если телефон был выключен дольше, напоминание уже неуместно: сайт сам покажет пропущенное. */
    private static final long STALE = 12 * 3600_000L;

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("notify", Context.MODE_PRIVATE);
    }

    static boolean allowed(Context c) {
        return c.getSystemService(NotificationManager.class).areNotificationsEnabled();
    }

    static void channels(Context c) {
        NotificationManager m = c.getSystemService(NotificationManager.class);
        m.createNotificationChannel(new NotificationChannel(REMINDERS, "Напоминания", NotificationManager.IMPORTANCE_HIGH));
        m.createNotificationChannel(new NotificationChannel(FILES, "Сохранённые файлы", NotificationManager.IMPORTANCE_DEFAULT));
        m.createNotificationChannel(new NotificationChannel(UPDATES, "Обновления приложения", NotificationManager.IMPORTANCE_DEFAULT));
    }

    private static PendingIntent openApp(Context c) {
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void post(Context c, String channel, String tag, String title, String body, PendingIntent open) {
        if (!allowed(c)) return;
        channels(c);
        c.getSystemService(NotificationManager.class).notify(tag, 1, new Notification.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_notify)
                .setColor(0xFF2E7D32)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(open)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .build());
    }

    static void show(Context c, String tag, String title, String body) {
        post(c, REMINDERS, tag, title, body, openApp(c));
    }

    static void update(Context c, String version) {
        post(c, UPDATES, "app-update", "Доступна новая версия My Money " + version, "Нажмите, чтобы обновить приложение.", openApp(c));
    }

    static void saved(Context c, String name, Uri uri, String mime) {
        Intent view = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent chooser = Intent.createChooser(view, name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        post(c, FILES, "file:" + name, "Файл сохранён в «Загрузки»", name,
                PendingIntent.getActivity(c, name.hashCode(), chooser, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
    }

    /** Новый план целиком: [{at, key, tag, title, body}]. */
    static synchronized void plan(Context c, String json) {
        try {
            JSONArray in = new JSONArray(json);
            prefs(c).edit().putString("plan", in.toString()).apply();
            run(c);
        } catch (Exception ignored) {
            // испорченное расписание не должно ронять приложение
        }
    }

    /** Ключи уже показанных по расписанию напоминаний: сайт не повторит их при открытии. */
    static synchronized String delivered(Context c) {
        return prefs(c).getString("delivered", "{}");
    }

    /** Показывает всё, чему пришло время, и ставит будильник на следующее. */
    static synchronized void run(Context c) {
        try {
            SharedPreferences p = prefs(c);
            JSONArray plan = new JSONArray(p.getString("plan", "[]"));
            JSONObject done = new JSONObject(p.getString("delivered", "{}"));
            JSONArray rest = new JSONArray();
            long now = System.currentTimeMillis(), next = Long.MAX_VALUE;
            for (int i = 0; i < plan.length(); i++) {
                JSONObject n = plan.getJSONObject(i);
                long at = n.getLong("at");
                String key = n.getString("key");
                if (done.has(key)) continue;
                if (at > now + 15_000) {
                    rest.put(n);
                    next = Math.min(next, at);
                } else if (now - at < STALE && allowed(c)) {
                    show(c, n.getString("tag"), n.getString("title"), n.getString("body"));
                    done.put(key, now);
                }
            }
            for (Iterator<String> it = done.keys(); it.hasNext(); )
                if (now - done.optLong(it.next()) > 60L * 86400_000L) it.remove();
            p.edit().putString("plan", rest.toString()).putString("delivered", done.toString()).apply();
            alarm(c, next);
        } catch (Exception ignored) {
        }
    }

    private static void alarm(Context c, long at) {
        AlarmManager alarms = c.getSystemService(AlarmManager.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, 1, new Intent(c, AlarmReceiver.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        alarms.cancel(pi);
        if (at == Long.MAX_VALUE) return;
        if (Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms())
            alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        else
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
    }
}
