// Service worker My Money: свежие файлы сайта из сети (автообновление), без интернета — из кэша.
// Внешние запросы (Google, курсы, погода, библиотеки) не перехватываются.
//
// Важно: запрос самой страницы (navigate) нельзя пересоздавать с параметрами — браузер выдаёт ошибку,
// и раньше из-за этого всегда открывалась старая копия index.html из кэша (в установленном приложении
// старая страница + новые скрипты ломали запуск). Теперь страница запрашивается по адресу.
const CACHE = 'my-money-v43';
const CORE = [
    './',
    'index.html',
    'css/style.css',
    'css/win95.css',
    'css/features.css',
    'css/v38.css',
    'css/layout.css',
    'css/v4.css',
    'css/v41.css',
    'css/v43.css',
    'css/desk95.css',
    'css/v46.css',
    'css/android.css',
    'css/pages.css',
    'css/experimental.css',
    'js/android.js',
    'js/pages.js',
    'js/experimental.js',
    'js/desk95-walls.js',
    'js/desk95-icons.js',
    'js/desk95.js',
    'js/desk95-tools.js',
    'js/desk95-menu.js',
    'js/desk95-desktop.js',
    'js/admin.js',
    'js/voice.js',
    'js/voiceengines.js',
    'js/fonts.js',
    'js/icon.js',
    'css/custom.css',
    'js/extras.js',
    'js/importer.js',
    'js/layout.js',
    'js/emoji.js',
    'js/currency.js',
    'js/notify.js',
    'js/apk.js',
    'js/config.js',
    'js/sound.js',
    'js/soundpicker.js',
    'js/themes.js',
    'js/scrollbars.js',
    'js/cloud.js',
    'js/account.js',
    'js/help.js',
    'js/switch.js',
    'js/exportdlg.js',
    'js/dialogs.js',
    'js/script.js',
    'manifest.webmanifest',
    'images/icon-192.png',
    'images/logo.png',
    'vendor/fonts.css',
    'vendor/chart.umd.min.js',
    'vendor/exceljs.min.js',
    'vendor/pdfmake.min.js',
    'vendor/vfs_fonts.min.js',
    'vendor/pdf.min.js',
    'vendor/pdf.worker.min.js',
    'vendor/jszip.min.js',
    'vendor/firebase-app-compat.js',
    'vendor/firebase-auth-compat.js',
    'vendor/firebase-database-compat.js',
    'vendor/fonts/google-sans-flex-latin-400-normal.woff2',
    'vendor/fonts/google-sans-flex-latin-500-normal.woff2',
    'vendor/fonts/google-sans-flex-latin-700-normal.woff2',
    'vendor/fonts/google-sans-flex-latin-ext-400-normal.woff2',
    'vendor/fonts/google-sans-flex-latin-ext-500-normal.woff2',
    'vendor/fonts/google-sans-flex-latin-ext-700-normal.woff2',
    'vendor/fonts/material-icons.woff2',
    'vendor/fonts/open-sans-cyrillic-300-normal.woff2',
    'vendor/fonts/open-sans-cyrillic-400-normal.woff2',
    'vendor/fonts/open-sans-cyrillic-600-normal.woff2',
    'vendor/fonts/open-sans-cyrillic-ext-300-normal.woff2',
    'vendor/fonts/open-sans-cyrillic-ext-400-normal.woff2',
    'vendor/fonts/open-sans-cyrillic-ext-600-normal.woff2',
    'vendor/fonts/open-sans-latin-300-normal.woff2',
    'vendor/fonts/open-sans-latin-400-normal.woff2',
    'vendor/fonts/open-sans-latin-600-normal.woff2',
    'vendor/fonts/open-sans-latin-ext-300-normal.woff2',
    'vendor/fonts/open-sans-latin-ext-400-normal.woff2',
    'vendor/fonts/open-sans-latin-ext-600-normal.woff2',
    'vendor/fonts/pixelify-sans-cyrillic-400-normal.woff2',
    'vendor/fonts/pixelify-sans-cyrillic-500-normal.woff2',
    'vendor/fonts/pixelify-sans-cyrillic-600-normal.woff2',
    'vendor/fonts/pixelify-sans-cyrillic-700-normal.woff2',
    'vendor/fonts/pixelify-sans-latin-400-normal.woff2',
    'vendor/fonts/pixelify-sans-latin-500-normal.woff2',
    'vendor/fonts/pixelify-sans-latin-600-normal.woff2',
    'vendor/fonts/pixelify-sans-latin-700-normal.woff2',
    'vendor/fonts/pixelify-sans-latin-ext-400-normal.woff2',
    'vendor/fonts/pixelify-sans-latin-ext-500-normal.woff2',
    'vendor/fonts/pixelify-sans-latin-ext-600-normal.woff2',
    'vendor/fonts/pixelify-sans-latin-ext-700-normal.woff2',
    'images/help/account.webp',
    'images/help/backup.webp',
    'images/help/categories.webp',
    'images/help/export.webp',
    'images/help/exportdlg.webp',
    'images/help/history.webp',
    'images/help/import.webp',
    'css/home.css',
    'css/entry.css',
    'js/entry.js',
    'js/ru.js',
    'js/home.js',
    
    'images/icon-512.png'
];

self.addEventListener('install', (event) => {
    // Каждый файл кэшируется отдельно: отсутствие одного (например, config.js) не ломает установку
    event.waitUntil(
        caches.open(CACHE)
            .then(cache => Promise.all(CORE.map(url => cache.add(new Request(url, { cache: 'reload' })).catch(() => null))))
            .then(() => self.skipWaiting())
    );
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys()
            .then(keys => Promise.all(keys.filter(k => k !== CACHE && k !== 'my-money-fonts').map(k => caches.delete(k))))
            .then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', (event) => {
    const req = event.request;
    // Дополнительные шрифты из настроек (Google Fonts): один раз скачанные берутся из кэша и без интернета
    if (req.method === 'GET' && /^https:\/\/fonts\.(googleapis|gstatic)\.com\//.test(req.url)) {
        event.respondWith(caches.open('my-money-fonts').then(c => c.match(req).then(hit => hit ||
            fetch(req).then(res => { if (res.ok || res.type === 'opaque') c.put(req, res.clone()); return res; }))));
        return;
    }
    if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;

    const isPage = req.mode === 'navigate';
    const network = isPage
        ? fetch(req.url, { cache: 'no-cache', credentials: 'same-origin' })
        : fetch(req, { cache: 'no-cache' });

    // Сначала сеть (с проверкой свежести у сервера), при ошибке — кэш
    event.respondWith(
        network
            .then(res => {
                if (res && res.ok) {
                    const copy = res.clone();
                    caches.open(CACHE).then(cache => cache.put(isPage ? req.url : req, copy)).catch(() => {});
                }
                return res;
            })
            .catch(() => caches.match(isPage ? req.url : req, { ignoreSearch: true })
                .then(hit => hit || (isPage ? caches.match('index.html') : null))
                .then(hit => hit || Response.error()))
    );
});

// Нажатие на уведомление (js/notify.js): открыть уже запущенное приложение или запустить его
self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    event.waitUntil(
        self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
            const win = list.find(c => c.url.startsWith(self.registration.scope));
            return win ? win.focus() : self.clients.openWindow('./');
        })
    );
});
