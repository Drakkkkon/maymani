package kz.drakkkkon.mymoney;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;

/** Раз в сутки проверяет в облаке (GitHub), нет ли новой версии, и сообщает уведомлением. */
public class UpdateJob extends JobService {
    private static final int JOB = 1;

    static void schedule(Context c) {
        JobScheduler jobs = c.getSystemService(JobScheduler.class);
        if (jobs.getPendingJob(JOB) != null) return;
        jobs.schedule(new JobInfo.Builder(JOB, new ComponentName(c, UpdateJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED)
                .setPeriodic(24 * 3600_000L)
                .setPersisted(true)
                .build());
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try {
                Updater.Release r = Updater.fetch(getApplicationContext());
                if (r != null) Notify.update(getApplicationContext(), r.version);
            } catch (Exception ignored) {
                // нет связи: попробуем в следующий раз
            }
            jobFinished(params, false);
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }
}
