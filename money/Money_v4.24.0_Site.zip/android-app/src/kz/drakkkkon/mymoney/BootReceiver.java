package kz.drakkkkon.mymoney;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** После перезагрузки, обновления приложения или перевода часов будильник нужно поставить заново. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Notify.run(context.getApplicationContext());
        UpdateJob.schedule(context.getApplicationContext());
    }
}
