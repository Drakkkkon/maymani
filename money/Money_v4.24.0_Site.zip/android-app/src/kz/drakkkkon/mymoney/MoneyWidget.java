package kz.drakkkkon.mymoney;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import org.json.JSONObject;

/** Виджет: остаток дневного лимита (или потрачено сегодня) и кнопка «+». Данные присылает сайт. */
public class MoneyWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        manager.updateAppWidget(ids, views(context));
    }

    static void save(Context c, String json) {
        c.getSharedPreferences("widget", Context.MODE_PRIVATE).edit().putString("data", json).apply();
        AppWidgetManager manager = AppWidgetManager.getInstance(c);
        int[] ids = manager.getAppWidgetIds(new ComponentName(c, MoneyWidget.class));
        if (ids.length > 0) manager.updateAppWidget(ids, views(c));
    }

    private static PendingIntent open(Context c, String action, int request) {
        Intent i = new Intent(c, MainActivity.class).setAction(action)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, request, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static RemoteViews views(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setOnClickPendingIntent(R.id.widget_root, open(c, Intent.ACTION_MAIN, 20));
        v.setOnClickPendingIntent(R.id.widget_add, open(c, MainActivity.EXPENSE, 21));
        try {
            JSONObject d = new JSONObject(c.getSharedPreferences("widget", Context.MODE_PRIVATE).getString("data", ""));
            SimpleDateFormat day = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            day.setTimeZone(TimeZone.getTimeZone("GMT+05:00")); // как и всё приложение — время Алматы
            // наступил новый день — вчерашние траты уже не считаются
            double spent = day.format(new Date()).equals(d.getString("day")) ? d.getDouble("spent") : 0;
            double limit = d.optDouble("limit", 0);
            double value = limit > 0 ? limit - spent : spent;
            v.setTextViewText(R.id.widget_title, limit <= 0 ? "Потрачено сегодня" : value < 0 ? "Лимит превышен на" : "Осталось на сегодня");
            v.setTextViewText(R.id.widget_sum, d.optBoolean("hide") ? "•••"
                    : NumberFormat.getIntegerInstance(new Locale("ru", "RU")).format(Math.abs(Math.round(value))) + " ₸");
        } catch (Exception e) {
            v.setTextViewText(R.id.widget_title, "My Money");
            v.setTextViewText(R.id.widget_sum, "Откройте приложение");
        }
        return v;
    }
}
