#!/bin/sh
# Сборка APK без Gradle. Нужны: JDK, Android SDK (build-tools 35, platform android-35) и ключ подписи.
# SDK_BT=…/build-tools/35.0.0 SDK_JAR=…/android.jar KEYSTORE=…/mymoney.p12 KEYPASS=… sh build.sh out.apk
# Ключ подписи в репозиторий НЕ класть (репозиторий публичный). Без того же ключа обновление не установится.
set -e
OUT=$(realpath -m "$1")
cd "$(dirname "$0")"
T=$(mktemp -d)
"$SDK_BT/aapt2" compile --dir res -o "$T/res.zip"
"$SDK_BT/aapt2" link -o "$T/base.apk" -I "$SDK_JAR" --manifest AndroidManifest.xml --java "$T/gen" "$T/res.zip"
mkdir "$T/classes" "$T/dex"
javac -encoding utf-8 --release 11 -classpath "$SDK_JAR" -d "$T/classes" src/kz/drakkkkon/mymoney/*.java "$T/gen/kz/drakkkkon/mymoney/R.java"
"$SDK_BT/d8" --release --min-api 29 --lib "$SDK_JAR" --output "$T/dex" $(find "$T/classes" -name '*.class')
(cd "$T/dex" && zip -q "$T/base.apk" classes.dex)
"$SDK_BT/zipalign" -f -p 4 "$T/base.apk" "$T/aligned.apk"
"$SDK_BT/apksigner" sign --ks "$KEYSTORE" --ks-pass env:KEYPASS --out "$OUT" "$T/aligned.apk"
"$SDK_BT/apksigner" verify "$OUT"
rm -rf "$T" "$OUT.idsig"
