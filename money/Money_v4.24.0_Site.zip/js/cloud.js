// --- ОБЛАКО: слияние данных и синхронизация с аккаунтом My Money (js/account.js) ---
// С 4.23.0 синхронизация только через аккаунт (почта и пароль, Firebase). Google Диск отключён.
// Записи и подписки объединяются поштучно (по id и времени изменения), удаления передаются «надгробиями».

const CLOUD_KEYS = { meta: 'finance_sync_meta' };
const TOMBSTONE_TTL_MS = 180 * 86400000;
let syncBaseline = null;        // снимок данных после последней загрузки/синхронизации

function readJsonKey(key, fallback) {
    try { const v = JSON.parse(localStorage.getItem(key) || 'null'); return v === null ? fallback : v; } catch (e) { return fallback; }
}

function isCloudConnected() { return typeof acctUser !== 'undefined' && !!acctUser; }

// --- Снимки данных, отметки изменений и слияние ---
// Списки, которые сливаются поштучно: записи, подписки и прочее.
// ob и links — прежние данные Oldbook: раздел вынесен в отдельное приложение (Oldbook95), здесь они только
// сохраняются как есть, чтобы синхронизация не стёрла их из облачной копии.
const SYNC_LISTS = [
    { key: 'tx', get: () => transactions, set: v => { transactions = v; } },
    { key: 'subs', get: () => subscriptions, set: v => { subscriptions = v; } },
    { key: 'ob', get: () => legacyObEntries, set: v => { legacyObEntries = v; } },
    { key: 'links', get: () => legacyObLinks, set: v => { legacyObLinks = v; } },
    { key: 'cats', get: () => customCategories, set: v => { customCategories = v; } },
    // свои темы оформления (js/themes.js)
    { key: 'themes', get: () => customThemes, set: v => { customThemes = v; if (typeof onCustomThemesChanged === 'function') onCustomThemesChanged(); } },
    // «Мои звуки»: библиотека своих звуков (файлы — отдельно на Диске, js/soundpicker.js)
    { key: 'soundlib', get: () => soundLibrary, set: v => { soundLibrary = v; } },
    // приоритетные цели (js/goals.js) и свои котировки (js/quotes.js)
    { key: 'goals', get: () => goalsList, set: v => { goalsList = v; } },
    { key: 'quotes', get: () => userQuotes, set: v => { userQuotes = v; } },
    // список покупок и цены товаров (js/shopping.js)
    { key: 'shop', get: () => shopList, set: v => { shopList = v; } },
    { key: 'prices', get: () => priceRecords, set: v => { priceRecords = v; } }
];

function getSyncMeta() {
    const m = readJsonKey(CLOUD_KEYS.meta, {});
    const deleted = {};
    SYNC_LISTS.forEach(l => { deleted[l.key] = { ...(m.deleted && m.deleted[l.key]) }; });
    return { scalarsAt: Number(m.scalarsAt) || 0, deleted };
}

function saveSyncMeta(meta) {
    try { localStorage.setItem(CLOUD_KEYS.meta, JSON.stringify(meta)); } catch (e) {}
}

function scalarsJson() {
    return JSON.stringify({ savings, limit: manualLimit, goal: priorityGoal, name: profileName, sounds: customSoundMeta, themeSounds: themeSoundMeta, ui: uiPrefs });
}

function itemJson(item) {
    const { updatedAt, ...rest } = item;
    return JSON.stringify(rest);
}

// Запоминает текущее состояние как «синхронизированное»: следующие отличия будут считаться новыми правками.
function initSyncBaseline() {
    const map = list => new Map(list.filter(i => i && i.id).map(i => [String(i.id), itemJson(i)]));
    syncBaseline = { scalars: scalarsJson() };
    SYNC_LISTS.forEach(l => { syncBaseline[l.key] = map(l.get()); });
}

// Вызывается при каждом сохранении: ставит время изменения новым/изменённым записям и «надгробия» удалённым.
function stampLocalChanges() {
    if (!syncBaseline) return;
    const meta = getSyncMeta();
    const now = Date.now();
    let changed = false;

    const stamp = (list, key) => {
        const prev = syncBaseline[key];
        const next = new Map();
        list.forEach(item => {
            if (!item) return;
            if (!item.id) item.id = now.toString(36) + Math.random().toString(36).slice(2, 7);
            const id = String(item.id);
            const json = itemJson(item);
            if (prev.get(id) !== json) { item.updatedAt = now; changed = true; delete meta.deleted[key][id]; }
            next.set(id, json);
        });
        prev.forEach((_, id) => { if (!next.has(id)) { meta.deleted[key][id] = now; changed = true; } });
        syncBaseline[key] = next;
    };
    SYNC_LISTS.forEach(l => stamp(l.get(), l.key));

    const scalars = scalarsJson();
    if (scalars !== syncBaseline.scalars) { meta.scalarsAt = now; syncBaseline.scalars = scalars; changed = true; }

    if (changed) {
        saveSyncMeta(meta);
        try { localStorage.setItem(CLOUD_KEYS.dirty, '1'); } catch (e) {}
    }
}

function localSnapshot() {
    const meta = getSyncMeta();
    return {
        app: 'my-money', format: 2, savedAt: Date.now(),
        profile: { name: profileName },
        tx: transactions, subs: subscriptions,
        ob: legacyObEntries, links: legacyObLinks, cats: customCategories, themes: customThemes,
        soundlib: soundLibrary, goals: goalsList, quotes: userQuotes, shop: shopList, prices: priceRecords,
        savings, limit: manualLimit, goal: priorityGoal,
        sounds: customSoundMeta, themeSounds: themeSoundMeta, ui: uiPrefs,
        scalarsAt: meta.scalarsAt, deleted: meta.deleted
    };
}

function asList(v) {
    if (Array.isArray(v)) return v.filter(Boolean);
    if (v && typeof v === 'object') return Object.values(v).filter(Boolean); // старые данные из Firebase могли прийти объектом
    return [];
}

function mergeLists(a, b, delA, delB) {
    const deleted = {};
    const cutoff = Date.now() - TOMBSTONE_TTL_MS;
    [delA || {}, delB || {}].forEach(d => Object.entries(d).forEach(([id, ts]) => {
        if (ts > cutoff) deleted[id] = Math.max(deleted[id] || 0, Number(ts) || 0);
    }));
    const map = new Map();
    [...asList(a), ...asList(b)].forEach(item => {
        if (!item.id) return;
        const id = String(item.id);
        const cur = map.get(id);
        if (!cur || (Number(item.updatedAt) || 0) > (Number(cur.updatedAt) || 0)) map.set(id, item);
    });
    const list = [...map.values()].filter(item => !(deleted[String(item.id)] && deleted[String(item.id)] >= (Number(item.updatedAt) || 0)));
    return { list, deleted };
}

function mergeSnapshots(local, remote) {
    const r = remote || {};
    const merged = {};
    const deleted = {};
    SYNC_LISTS.forEach(l => {
        const m = mergeLists(local[l.key], r[l.key], local.deleted && local.deleted[l.key], r.deleted && r.deleted[l.key]);
        merged[l.key] = m.list;
        deleted[l.key] = m.deleted;
    });
    const remoteNewer = (Number(r.scalarsAt) || 0) > (Number(local.scalarsAt) || 0);
    const src = remoteNewer ? r : local;
    return {
        app: 'my-money', format: 2, savedAt: Date.now(),
        profile: { name: (src.profile && src.profile.name) || '' },
        ...merged,
        savings: Number(src.savings) || 0,
        limit: Number(src.limit) || 0,
        goal: src.goal || { name: '', amount: 0, icon: '🎯' },
        sounds: (src.sounds && typeof src.sounds === 'object') ? src.sounds : {},
        themeSounds: (src.themeSounds && typeof src.themeSounds === 'object') ? src.themeSounds : ((remoteNewer ? local.themeSounds : r.themeSounds) || {}),
        // настройки вида (шапка, котировки, картинки категорий): если их ещё нет в более новом снимке — берём из другого
        ui: (src.ui && typeof src.ui === 'object') ? src.ui : ((remoteNewer ? local.ui : r.ui) || {}),
        scalarsAt: Math.max(Number(local.scalarsAt) || 0, Number(r.scalarsAt) || 0),
        deleted
    };
}

// Сравнение без учёта времени сохранения и порядка записей
function snapshotKey(s) {
    const byId = list => asList(list).map(i => JSON.stringify(i)).sort();
    return JSON.stringify([...SYNC_LISTS.map(l => byId(s[l.key])), s.savings, s.limit, s.goal, s.profile && s.profile.name,
        JSON.stringify(s.sounds || {}), JSON.stringify(s.themeSounds || {}), JSON.stringify(s.ui || {}), s.scalarsAt, s.deleted]);
}

function applySnapshot(s) {
    SYNC_LISTS.forEach(l => l.set(asList(s[l.key])));
    savings = Number(s.savings) || 0;
    manualLimit = Number(s.limit) || 0;
    priorityGoal = s.goal || { name: '', amount: 0, icon: '🎯' };
    profileName = (s.profile && s.profile.name) || '';
    customSoundMeta = (s.sounds && typeof s.sounds === 'object') ? s.sounds : {};
    themeSoundMeta = (s.themeSounds && typeof s.themeSounds === 'object') ? s.themeSounds : {};
    if (s.ui && typeof s.ui === 'object') setUiPrefs(s.ui);
    if (typeof onCustomSoundsChanged === 'function') onCustomSoundsChanged();
    saveSyncMeta({ scalarsAt: Number(s.scalarsAt) || 0, deleted: s.deleted || { tx: {}, subs: {} } });
    initSyncBaseline();
    updateUI(false);
    fillProfileInput();
    const mLimit = document.getElementById('manual-limit');
    if (mLimit) mLimit.value = manualLimit > 0 ? manualLimit : '';
}

function scheduleCloudSync(delay = 1500) {
    if (typeof scheduleAccountSync === 'function') scheduleAccountSync(delay);
}

// Кнопка синхронизации (круглая внизу справа)
async function syncNowButton() {
    if (isCloudConnected()) {
        const ok = await runAccountSync({ manual: true });
        showToast(ok ? 'Синхронизировано с аккаунтом' : 'Синхронизация не удалась');
        return;
    }
    openSettingsCard('account-section');
    showToast('Войдите в аккаунт, чтобы данные сохранялись в облаке');
}

function showToast(text) {
    let el = document.getElementById('app-toast');
    if (!el) {
        el = document.createElement('div');
        el.id = 'app-toast';
        el.className = 'app-toast';
        el.setAttribute('role', 'status');
        document.body.appendChild(el);
    }
    el.textContent = text;
    el.classList.add('is-visible');
    clearTimeout(el._hideTimer);
    el._hideTimer = setTimeout(() => el.classList.remove('is-visible'), 2600);
}

function initCloud() {
    // прежний вход через Google больше не нужен
    ['finance_google_token', 'finance_google_user', 'finance_drive_file_id', 'finance_drive_modified', 'finance_sync_dirty', 'finance_g_state']
        .forEach(k => { try { localStorage.removeItem(k); } catch (e) {} });
}

// Настройки Firebase для аккаунта (проект money99774)
const LEGACY_FIREBASE_CONFIG = {
    apiKey: 'AIzaSyB27Rqisiz2OyavjImphW-M0PBg5hbIdiE',
    authDomain: 'money99774.firebaseapp.com',
    databaseURL: 'https://money99774-default-rtdb.firebaseio.com',
    projectId: 'money99774',
    storageBucket: 'money99774.firebasestorage.app',
    messagingSenderId: '711455509046',
    appId: '1:711455509046:web:dbedd1a788759ccaa22697'
};
const LEGACY_FIREBASE_SCRIPTS = [
    'vendor/firebase-app-compat.js',
    'vendor/firebase-auth-compat.js',
    'vendor/firebase-database-compat.js'
];
