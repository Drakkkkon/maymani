// --- ПЕРЕЛИСТЫВАНИЕ СВАЙПОМ ---

// ---------- Перелистывание разделов свайпом влево / вправо ----------
function visibleMenuIds() {
    if (typeof getMenuState !== 'function') return [];
    // 4.10.0: тот же список, что в меню (в режиме «страницы» — Записи, Стена, блоки-страницы, Настройки)
    if (typeof menuNavItems === 'function') return menuNavItems().map(i => i.id);
    const state = getMenuState();
    return state.order.filter(id => !state.hidden.includes(id));
}

function swipeToTab(dir) {
    const ids = visibleMenuIds();
    const idx = ids.indexOf(typeof currentNavId === 'string' ? currentNavId : (typeof currentTabId === 'string' ? currentTabId : ''));
    const next = ids[idx + dir];
    if (idx < 0 || !next) return false;
    if (typeof openMenuItem === 'function') openMenuItem(next, null); else showTab(next, null);
    const tab = document.getElementById(next);
    if (tab) {
        tab.classList.remove('tab-enter', 'tab-swipe-next', 'tab-swipe-prev');
        void tab.offsetWidth;
        tab.classList.add(dir > 0 ? 'tab-swipe-next' : 'tab-swipe-prev');
        clearTimeout(tab._swipeTimer);
        tab._swipeTimer = setTimeout(() => tab.classList.remove('tab-swipe-next', 'tab-swipe-prev'), 400);
    }
    // Активный пункт нижнего меню — в поле зрения
    const btn = document.querySelector(`.mobile-nav button[data-tab="${next}"]`);
    if (btn && btn.scrollIntoView) btn.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    if (typeof playSound === 'function') playSound('menu');
    return true;
}

// Свайп не срабатывает в полях ввода, в окнах поверх страницы и там, где что-то само листается вбок
function swipeBlocked(target) {
    if (document.querySelector('.export-sheet-overlay, .card.is-maximized, #entry:not([hidden])')) return true;
    const pin = document.querySelector('.pin-screen');
    if (pin && pin.offsetParent !== null && getComputedStyle(pin).display !== 'none') return true;
    if (!target || !target.closest) return false;
    if (target.closest('input, textarea, select, .w95-sb, .slider-container, .custom-dropdown, .sidebar, .mobile-nav, [data-no-swipe]')) return true;
    for (let el = target; el && el !== document.body && !el.classList.contains('main-wrapper'); el = el.parentElement) {
        if (el.scrollWidth > el.clientWidth + 4) {
            const ox = getComputedStyle(el).overflowX;
            if (ox === 'auto' || ox === 'scroll') return true;
        }
    }
    return false;
}

(function initSwipeTabs() {
    let start = null;
    document.addEventListener('touchstart', (e) => {
        if (e.touches.length !== 1 || swipeBlocked(e.target)) { start = null; return; }
        const t = e.touches[0];
        start = { x: t.clientX, y: t.clientY, at: Date.now() };
    }, { passive: true });
    document.addEventListener('touchmove', (e) => {
        if (start && e.touches.length !== 1) start = null;
    }, { passive: true });
    document.addEventListener('touchend', (e) => {
        if (!start) return;
        const t = e.changedTouches[0];
        const dx = t.clientX - start.x;
        const dy = t.clientY - start.y;
        const dt = Date.now() - start.at;
        start = null;
        // Уверенный горизонтальный жест: не меньше 60 px, заметно больше вертикального сдвига, быстрее 0,7 с
        if (Math.abs(dx) >= 60 && Math.abs(dx) > Math.abs(dy) * 1.6 && dt < 700) swipeToTab(dx < 0 ? 1 : -1);
    }, { passive: true });
    document.addEventListener('touchcancel', () => { start = null; }, { passive: true });
})();

