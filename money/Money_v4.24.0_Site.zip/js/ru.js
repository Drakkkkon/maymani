// Приложение только на русском (4.22.0). Здесь то немногое, на что опирается остальной код.
const appLang = 'ru';
window.APP_LOCALE = 'ru-RU';
document.documentElement.lang = 'ru';
window.t = s => s;
try { localStorage.removeItem('finance_lang'); } catch (e) {}

// 4.23.0: один раз, до всех изменений, сохраняем копию записей и подписок на этом устройстве
try {
    if (!localStorage.getItem('finance_safety_4230') && localStorage.getItem('finance_tx')) {
        localStorage.setItem('finance_safety_4230', JSON.stringify({ at: Date.now(), tx: localStorage.getItem('finance_tx'), subs: localStorage.getItem('finance_subs'), cats: localStorage.getItem('finance_categories') }));
    }
} catch (e) {}
