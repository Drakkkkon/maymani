// --- 4.22.0: ОКНО ЗАПИСИ. Открывается кнопками «Расход» / «Доход», «+», виджетом, ярлыками и «Изменить» ---
(function () {
    const $ = id => document.getElementById(id);
    const box = $('entry');
    const typeButtons = [...box.querySelectorAll('[data-type]')];
    const touch = window.matchMedia('(pointer: coarse)').matches;
    let type = 'expense';

    function sync() {
        const editing = !!$('edit-id').value;
        const word = type === 'income' ? 'доход' : 'расход';
        box.dataset.type = type;
        typeButtons.forEach(b => { const on = b.dataset.type === type; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', String(on)); });
        $('entry-title').textContent = editing ? 'Изменить запись' : 'Новый ' + word;
        $('entry-save').textContent = editing ? 'Сохранить изменения' : 'Записать ' + word;
        const day = $('tx-datetime').value.slice(0, 10);
        box.querySelectorAll('[data-day]').forEach(b => b.classList.toggle('is-on', day === almatyIsoNow(-Number(b.dataset.day)).slice(0, 10)));
    }
    function setType(next) { type = next === 'income' ? 'income' : 'expense'; sync(); }

    function open(mode) {
        clearForm();
        box.hidden = false;
        document.documentElement.classList.add('entry-open');
        setType(mode || 'expense');
        box.querySelector('.entry-body').scrollTop = 0;
        if (!touch) $('amount').focus();
        return true;
    }
    function close() {
        if (box.hidden) return false;
        box.hidden = true;
        document.documentElement.classList.remove('entry-open');
        clearForm();
        return true;
    }
    function save() {
        const before = JSON.stringify(transactions);
        if ($('edit-id').value) saveEdit(); else saveTx(type);
        if (JSON.stringify(transactions) === before && !$('edit-id').value && $('amount').value) return; // не сохранилось
        if (JSON.stringify(transactions) === before) return;
        box.hidden = true;
        document.documentElement.classList.remove('entry-open');
        if (window.mmRenderGlance) window.mmRenderGlance();
        if (window.MMApp) window.MMApp.buzz(); else if (navigator.vibrate) navigator.vibrate(25);
    }
    function key(k) {
        const el = $('amount');
        let v = String(el.value || '');
        if (k === 'back') v = v.slice(0, -1);
        else if (k === '.') { if (!v.includes('.')) v = (v || '0') + '.'; }
        else v = (v === '0' ? '' : v) + k;
        el.value = v.slice(0, 12);
        el.dispatchEvent(new Event('input', { bubbles: true }));
    }

    window.mmOpenEntry = open;
    window.mmCloseEntry = close;
    window.mmEntryType = setType;
    window.mmEntrySync = () => { const on = $('edit-id').value && transactions.find(t => t.id === $('edit-id').value); if (on) type = on.type; sync(); };

    // на телефоне цифры набираются кнопками окна — системная клавиатура не закрывает их
    if (touch) $('amount').setAttribute('inputmode', 'none');
    $('amount').addEventListener('input', () => {
        const el = $('amount');
        const clean = el.value.replace(/,/g, '.').replace(/[^\d.]/g, '').replace(/^(\d*\.\d*).*$/, '$1');
        if (clean !== el.value) el.value = clean;
    });
    $('tx-datetime').addEventListener('change', sync);
    box.addEventListener('click', e => {
        if (e.target.classList.contains('entry-back') || e.target.closest('.entry-x')) { close(); return; }
        const b = e.target.closest('button');
        if (!b) return;
        if (b.dataset.type) setType(b.dataset.type);
        else if (b.dataset.k) key(b.dataset.k);
        else if (b.dataset.day) { $('tx-datetime').value = almatyIsoNow(-Number(b.dataset.day)); sync(); }
        else if (b.id === 'entry-save') save();
    });
    document.addEventListener('keydown', e => {
        if (box.hidden || document.querySelector('.export-sheet-overlay')) return;
        if (e.key === 'Escape') close();
        else if (e.key === 'Enter' && e.target.tagName === 'INPUT') save();
    });
    // уход в другой раздел закрывает окно
    const orig = window.showTab;
    window.showTab = function (id) { if (id !== 'transactions') close(); return orig.apply(this, arguments); };
})();
