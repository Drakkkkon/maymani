// --- ВИД ПРИЛОЖЕНИЯ: настройки вида, страницы, «Скрыть» ---

const UI_PREFS_KEY = 'finance_ui';

const UI_DEFAULTS = {
    catIcons: { form: {}, history: {} },
    catColors: { form: {}, history: {} },
    iconMode: { form: 'both', history: 'both' }
};

function normalizeUiPrefs(p) {
    const src = (p && typeof p === 'object') ? p : {};
    const obj = (v, d) => (v && typeof v === 'object' && !Array.isArray(v)) ? v : d;
    const ci = obj(src.catIcons, {});
    const im = obj(src.iconMode, {});
    const cc = obj(src.catColors, {});
    const colorMap = m => Object.fromEntries(Object.entries(obj(m, {})).filter(([k, v]) => k.length < 80 && typeof v === 'string' && /^[a-z]{3,8}$/.test(v)).slice(0, 400));
    const mode = v => ['icon', 'text', 'both'].includes(v) ? v : 'both';
    return {
        catIcons: { form: obj(ci.form, {}), history: obj(ci.history, {}) },
        catColors: { form: colorMap(cc.form), history: colorMap(cc.history) },
        iconMode: { form: mode(im.form), history: mode(im.history) },
        notify: normalizeNotifyPrefs(obj(src.notify, {})),
        bank: normalizeBankPrefs(obj(src.bank, {})),
        fonts: obj(src.fonts, {}),
        layout: normalizeLayoutPrefs(obj(src.layout, {})),
        // 4.14.0: прежние рабочие категории администратора уже добавлены (js/script.js → seedAdminCategories)
        catsSeeded: src.catsSeeded === true
    };
}

// Разметка (js/layout.js ниже): ширина и колонки на ПК, плотность, вид меню, заставка на ПК
function normalizeLayoutPrefs(l) {
    const pick = (v, list, d) => list.includes(v) ? v : d;
    const pct = Number(l.widthPct);
    return {
        pcWidth: pick(l.pcWidth, ['auto', 'full', 'narrow', 'custom'], 'auto'),
        widthPct: Number.isFinite(pct) && pct >= 50 && pct <= 100 ? pct : 80,
        density: pick(l.density, ['compact', 'normal', 'roomy'], 'normal'),
        pcMenu: pick(l.pcMenu, ['left', 'burger'], 'left'),
        mobileMenu: pick(l.mobileMenu, ['bottom', 'top', 'left', 'burger'], 'bottom'),
        // 4.23.0: только страницы
        noBlocks: true
    };
}

// Уведомления (js/notify.js): утро 9:00 с целями, выгрузка за день в 23:00, напоминания подписок по умолчанию
function normalizeNotifyPrefs(n) {
    const offsets = ['1w', '3d', '1d', '3h', '1h', '0'];
    return {
        morning: n.morning !== false,
        daily: n.daily !== false,
        subDefault: Array.isArray(n.subDefault) ? n.subDefault.filter(o => offsets.includes(o)) : ['1d'],
        bank: n.bank !== false
    };
}

// Банк (js/bank.js): выбранный банк, остаток из выписки или уведомления и пороги предупреждений
function normalizeBankPrefs(b) {
    const num = v => { const n = Number(v); return Number.isFinite(n) ? n : null; };
    return {
        name: typeof b.name === 'string' ? b.name.slice(0, 30) : 'kaspi',
        balance: num(b.balance),
        balanceAt: typeof b.balanceAt === 'string' ? b.balanceAt.slice(0, 16) : '',
        source: typeof b.source === 'string' ? b.source.slice(0, 20) : '',
        low: Math.max(0, num(b.low) || 0),
        big: Math.max(0, num(b.big) || 0),
        summary: (b.summary && typeof b.summary === 'object') ? b.summary : null
    };
}

let uiPrefs = normalizeUiPrefs(null);
try { uiPrefs = normalizeUiPrefs(JSON.parse(localStorage.getItem(UI_PREFS_KEY) || 'null')); } catch (e) {}

function saveUiPrefsLocal() {
    try { localStorage.setItem(UI_PREFS_KEY, JSON.stringify(uiPrefs)); } catch (e) {}
}

// Настройки пришли с другого устройства
function setUiPrefs(p) {
    uiPrefs = normalizeUiPrefs(p);
    saveUiPrefsLocal();
    if (typeof renderNotifySettings === 'function') renderNotifySettings();
    applyLayoutPrefs();
    renderLayoutSettings();
    if (typeof applyTheme === 'function' && typeof currentThemeId !== 'undefined') applyTheme(currentThemeId, { save: false }); // шрифты с другого устройства
}

// Изменение настроек на этом устройстве: сохранить и отправить в облако
function commitUiPrefs() {
    saveUiPrefsLocal();
    if (typeof updateUI === 'function') updateUI(true);
}

// ---------- Страницы: «Скрыть» — содержимое прячется под картинкой (запоминается только на этом устройстве) ----------
const HIDDEN_KEY = 'finance_hidden';
function readHidden() { try { return JSON.parse(localStorage.getItem(HIDDEN_KEY) || '{}') || {}; } catch (e) { return {}; } }

// Постоянные id карточек без id: «card-<раздел>-<номер>» по порядку в разметке
let cardIdsAssigned = false;
function assignCardIds() {
    if (cardIdsAssigned) return;
    cardIdsAssigned = true;
    document.querySelectorAll('main > .tab').forEach(tab => {
        let i = 0;
        tab.querySelectorAll('.card').forEach(card => { if (!card.id) card.id = `card-${tab.id}-${i}`; i++; });
    });
}

function applyHidden(card, hidden) {
    card.classList.toggle('is-private', hidden);
    const b = card.querySelector(':scope > .card-foot .foot-hide');
    if (b) {
        b.innerHTML = `<span class="material-icons" aria-hidden="true">${hidden ? 'visibility' : 'visibility_off'}</span><span>${hidden ? 'Показать' : 'Скрыть'}</span>`;
        b.setAttribute('aria-pressed', String(hidden));
    }
    const tab = card.closest('.tab');
    if (tab && tab.id === 'transactions') tab.classList.toggle('is-private', hidden); // сводка на главной тоже прячется
}

function toggleCardHidden(btn) {
    const card = btn.closest('.card');
    const state = readHidden();
    const hidden = !state[card.id];
    if (hidden) state[card.id] = 1; else delete state[card.id];
    try { localStorage.setItem(HIDDEN_KEY, JSON.stringify(state)); } catch (e) {}
    applyHidden(card, hidden);
    if (typeof playSound === 'function') playSound(hidden ? 'close' : 'open');
    if (!hidden) setTimeout(() => window.dispatchEvent(new Event('resize')), 30);
}

function enhanceCards(root = document) {
    assignCardIds();
    const hidden = readHidden();
    root.querySelectorAll('main > .tab:not(#settings):not(#experimental) .card').forEach(card => {
        if (card.parentElement.closest('.card') || !card.querySelector(':scope > h3')) return;
        let foot = card.querySelector(':scope > .card-foot');
        if (!foot) {
            foot = document.createElement('div');
            foot.className = 'card-foot';
            foot.innerHTML = '<div class="card-veil" aria-hidden="true"><span class="material-icons">visibility_off</span><b>Скрыто</b></div>' +
                '<button type="button" class="btn-secondary foot-btn foot-hide" onclick="toggleCardHidden(this)"></button>';
        }
        if (foot !== card.lastElementChild) card.appendChild(foot);
        applyHidden(card, !!hidden[card.id]);
    });
}

// ---------- Разметка: ПК по центру, колонки, плотность; вид меню (внизу / слева / гамбургер) ----------
// Всё задаётся атрибутами на <html>, оформление — css/layout.css.
function isDesktopView() {
    return window.innerWidth >= 769;
}

function applyLayoutPrefs() {
    const l = uiPrefs.layout;
    const root = document.documentElement;
    const desktop = isDesktopView();
    root.setAttribute('data-pc-width', l.pcWidth);
    root.style.setProperty('--pc-width-pct', l.widthPct + 'vw');
    root.setAttribute('data-density', l.density);
    const menu = desktop ? l.pcMenu : l.mobileMenu;
    root.setAttribute('data-menu', menu);
    if (menu !== 'burger') toggleBurgerMenu(false);
    if (typeof updateMobileNavHeight === 'function') updateMobileNavHeight();
    window.dispatchEvent(new Event('app-layout'));
}

function setLayoutPref(key, value) {
    if (key === 'widthPct') value = Math.round(Number(value));
    uiPrefs.layout = normalizeLayoutPrefs({ ...uiPrefs.layout, [key]: value });
    applyLayoutPrefs();
    if (key !== 'widthPct') renderLayoutSettings();
    else { const v = document.getElementById('lay-width-val'); if (v) v.textContent = uiPrefs.layout.widthPct + '%'; }
    commitUiPrefs();
}

function toggleBurgerMenu(open) {
    const root = document.documentElement;
    const next = typeof open === 'boolean' ? open : !root.classList.contains('menu-open');
    root.classList.toggle('menu-open', next);
    const btn = document.getElementById('burger-btn');
    if (btn) btn.setAttribute('aria-expanded', String(next));
    if (typeof open !== 'boolean' && typeof playSound === 'function') playSound(next ? 'open' : 'close');
}

function renderLayoutSettings() {
    const box = document.getElementById('layout-settings');
    if (!box) return;
    const l = uiPrefs.layout;
    const seg = (key, opts) => `<div class="seg-buttons" role="radiogroup">${opts.map(([v, label]) =>
        `<button type="button" role="radio" aria-checked="${String(l[key]) === v}" class="seg-btn${String(l[key]) === v ? ' is-on' : ''}" onclick="setLayoutPref('${key}', '${v}')">${label}</button>`).join('')}</div>`;
    box.innerHTML = `
        <h4 class="font-sub">Меню на телефоне</h4>
        ${seg('mobileMenu', [['bottom', 'Внизу'], ['top', 'Сверху'], ['left', 'Слева'], ['burger', 'Гамбургер ☰']])}
        <div class="layout-pc-only">
            <h4 class="font-sub">Меню на ПК</h4>
            ${seg('pcMenu', [['left', 'Слева'], ['burger', 'Гамбургер ☰']])}
            <h4 class="font-sub">Ширина приложения на ПК</h4>
            ${seg('pcWidth', [['auto', 'По центру 16:9'], ['narrow', 'Узко'], ['custom', 'Своя'], ['full', 'Во весь экран']])}
            ${l.pcWidth === 'custom' ? `<label class="hdr-slider"><span>Ширина: <b id="lay-width-val">${l.widthPct}%</b> экрана</span>
                <input type="range" min="50" max="100" step="5" value="${l.widthPct}" oninput="setLayoutPref('widthPct', this.value)"></label>` : ''}
            <p class="hint">«По центру 16:9»: на очень широких экранах приложение не растягивается, а стоит посередине.</p>
            <h4 class="font-sub">Плотность</h4>
            ${seg('density', [['compact', 'Компактно'], ['normal', 'Обычно'], ['roomy', 'Просторно']])}
        </div>`;
}

window.addEventListener('DOMContentLoaded', () => {
    enhanceCards();
    applyLayoutPrefs();
    renderLayoutSettings();
    // гамбургер: выбор пункта закрывает меню
    const nav = document.getElementById('sidebar-nav');
    if (nav) nav.addEventListener('click', e => { if (e.target.closest('button')) toggleBurgerMenu(false); });
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape' && document.documentElement.classList.contains('menu-open')) toggleBurgerMenu(false);
    });
});
window.addEventListener('load', () => enhanceCards());
let layoutWasDesktop = null;
window.addEventListener('resize', () => {
    const d = isDesktopView();
    if (d !== layoutWasDesktop) { layoutWasDesktop = d; applyLayoutPrefs(); }
});
