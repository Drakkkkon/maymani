// --- 4.21.0: СВОДКА НА ГЛАВНОЙ («кольцо» лимита и три последние записи) ---
(function () {
    const GLANCE = 'finance_glance';
    const on = k => { try { return localStorage.getItem(k) !== '0'; } catch (e) { return true; } };
    const $ = id => document.getElementById(id);
    const desk = () => document.documentElement.getAttribute('data-w95') === 'desk95';
    const money = v => fmtTenge(Math.round(v));

    function today() {
        const day = almatyIsoNow().slice(0, 10);
        return transactions.filter(t => t.type === 'expense' && getTxDateStr(t.date) === day).reduce((s, t) => s + (Number(t.amount) || 0), 0);
    }
    window.mmSpentToday = today;
    window.mmRenderGlance = () => renderGlance();

    // ---------- Сводка ----------
    let lastHtml = '';
    function renderGlance() {
        const tab = $('transactions');
        if (!tab) return;
        let box = $('mm-glance');
        if (!on(GLANCE)) { if (box) box.remove(); lastHtml = ''; return; }
        if (!box) { box = document.createElement('div'); box.id = 'mm-glance'; box.className = 'mm-glance'; tab.prepend(box); lastHtml = ''; }
        const spent = today(), limit = manualLimit > 0 ? manualLimit : 0;
        const part = limit ? Math.min(spent / limit, 1) : 0;
        const state = !limit ? '' : spent > limit ? ' is-over' : spent >= limit * 0.8 ? ' is-near' : '';
        const last = transactions.slice().sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 3);
        const html = `
            <div class="mm-ring${state}">
                <svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="52" class="mm-ring-bg"/>
                <circle cx="60" cy="60" r="52" class="mm-ring-val" style="stroke-dasharray:${(part * 326.7).toFixed(1)} 326.7"/></svg>
                <div class="mm-ring-text"><b>${escapeHtml(money(spent))}</b><small>${limit ? 'из ' + escapeHtml(money(limit)) : 'сегодня'}</small></div>
            </div>
            <div class="mm-glance-side">
                <p class="mm-glance-title">${limit ? (spent > limit ? 'Лимит превышен на ' + escapeHtml(money(spent - limit)) : 'Осталось ' + escapeHtml(money(limit - spent))) : 'Потрачено сегодня'}</p>
                ${last.map(t => `<div class="mm-last"><span data-i18n-skip>${escapeHtml(t.category || '—')}</span><b class="${t.type === 'income' ? 'in' : 'out'}">${t.type === 'income' ? '+' : '−'}${escapeHtml(money(t.amount))}</b></div>`).join('') || '<p class="hint">Записей пока нет.</p>'}
            </div>`;
        if (html !== lastHtml) { box.innerHTML = html; lastHtml = html; }
    }

    function renderSettings() {
        const box = $('home-settings');
        if (!box) return;
        box.innerHTML = `
            <label class="sw-row"><span>Сводка сверху в «Записях»: кольцо лимита и три последние записи</span><input type="checkbox" class="ios-switch" id="mm-glance-sw" ${on(GLANCE) ? 'checked' : ''}></label>`;
        $('mm-glance-sw').onchange = e => { localStorage.setItem(GLANCE, e.target.checked ? '1' : '0'); renderGlance(); };
    }

    window.addEventListener('DOMContentLoaded', () => {
        renderSettings();
        setTimeout(renderGlance, 300);
        setInterval(renderGlance, 2000);
    });
})();
