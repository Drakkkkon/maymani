// --- ТЕМА «WINDOWS 95_ЭКСТРА»: ЧАСЫ И ДАТА НА ПАНЕЛИ ЗАДАЧ ---

(function () {
    'use strict';
    const D = window.DESK95;
    if (!D) return;

    // ---------- часы ----------
    const TZ = 'Asia/Almaty';
    let tray = null, tTime = null, tDate = null, timer = 0;
    let fmt = null, lastLang = '';

    function locale() {
        try {
            const l = typeof appLang !== 'undefined' ? appLang : 'ru';
            return ({ ru: 'ru-RU', kk: 'kk-KZ', en: 'en-GB', de: 'de-DE', fr: 'fr-FR' })[l] || 'ru-RU';
        } catch (e) { return 'ru-RU'; }
    }

    function formatters() {
        const loc = locale();
        if (fmt && lastLang === loc) return fmt;
        lastLang = loc;
        const mk = (o) => { try { return new Intl.DateTimeFormat(loc, Object.assign({ timeZone: TZ }, o)); } catch (e) { return new Intl.DateTimeFormat('ru-RU', o); } };
        fmt = {
            time: mk({ hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }),
            sec: mk({ hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }),
            date: mk({ day: '2-digit', month: '2-digit', year: 'numeric' }),
            full: mk({ weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
        };
        return fmt;
    }

    function tick() {
        if (!tray || !tray.isConnected) return;
        const f = formatters(), now = new Date();
        const t = f.time.format(now), d = f.date.format(now);
        if (tTime.textContent !== t) tTime.textContent = t;
        if (tDate.textContent !== d) tDate.textContent = d;
        tray.dataset.tip = f.full.format(now) + ', ' + f.sec.format(now);
        tray.setAttribute('aria-label', 'Время ' + t + ', дата ' + d);
    }

    D.on('build', (ctx) => {
        tray = ctx.bar.querySelector('.tb-tray');
        if (!tray) return;
        tray.innerHTML = '<span class="tb-time"></span><span class="tb-date"></span>';
        tTime = tray.querySelector('.tb-time');
        tDate = tray.querySelector('.tb-date');
        tick();
        clearInterval(timer);
        timer = setInterval(tick, 1000);
    });
    D.on('leave', () => { clearInterval(timer); timer = 0; tray = tTime = tDate = null; });

})();
