// --- 4.21.0: СВОДКА НА ГЛАВНОЙ («кольцо» лимита и три последние записи) И ЗАПИСЬ НИЖНЕЙ ШТОРКОЙ ---
(function () {
    const GLANCE = 'finance_glance', SHEET = 'finance_sheet';
    const on = k => { try { return localStorage.getItem(k) !== '0'; } catch (e) { return true; } };
    const $ = id => document.getElementById(id);
    const form = () => document.querySelector('#transactions .forms');
    const desk = () => document.documentElement.getAttribute('data-w95') === 'desk95';
    const money = v => fmtTenge(Math.round(v));

    function today() {
        const day = almatyIsoNow().slice(0, 10);
        return transactions.filter(t => t.type === 'expense' && getTxDateStr(t.date) === day).reduce((s, t) => s + (Number(t.amount) || 0), 0);
    }
    window.mmSpentToday = today;

    // ---------- Сводка ----------
    let lastHtml = '';
    function renderGlance() {
        const tab = $('transactions');
        if (!tab) return;
        let box = $('mm-glance');
        if (!on(GLANCE)) { if (box) box.remove(); lastHtml = ''; return; }
        if (!box) { box = document.createElement('div'); box.id = 'mm-glance'; box.className = 'mm-glance'; tab.prepend(box); lastHtml = ''; }
        const spent = today(), limit = manualLimit > 0 ? manualLimit : 0;
        const part = limit ? Math.min(spent / limit, 1) : 0;
        const state = !limit ? '' : spent > limit ? ' is-over' : spent >= limit * 0.8 ? ' is-near' : '';
        const last = transactions.slice().sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 3);
        const html = `
            <div class="mm-ring${state}">
                <svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="52" class="mm-ring-bg"/>
                <circle cx="60" cy="60" r="52" class="mm-ring-val" style="stroke-dasharray:${(part * 326.7).toFixed(1)} 326.7"/></svg>
                <div class="mm-ring-text"><b>${escapeHtml(money(spent))}</b><small>${limit ? 'из ' + escapeHtml(money(limit)) : 'сегодня'}</small></div>
            </div>
            <div class="mm-glance-side">
                <p class="mm-glance-title">${limit ? (spent > limit ? 'Лимит превышен на ' + escapeHtml(money(spent - limit)) : 'Осталось ' + escapeHtml(money(limit - spent))) : 'Потрачено сегодня'}</p>
                ${last.map(t => `<div class="mm-last"><span data-i18n-skip>${escapeHtml(t.category || '—')}</span><b class="${t.type === 'income' ? 'in' : 'out'}">${t.type === 'income' ? '+' : '−'}${escapeHtml(money(t.amount))}</b></div>`).join('') || '<p class="hint">Записей пока нет.</p>'}
            </div>`;
        if (html !== lastHtml) { box.innerHTML = html; lastHtml = html; }
    }

    // ---------- Запись шторкой ----------
    function closeEntry() {
        const f = form();
        document.documentElement.classList.remove('mm-sheet-open');
        if (f) f.classList.remove('mm-sheet', 'mm-mode-expense', 'mm-mode-income');
        const b = $('mm-backdrop'); if (b) b.remove();
        const x = $('mm-sheet-head'); if (x) x.remove();
    }
    // true — шторка открыта; false — шторка выключена или не подходит (тогда обычный переход к форме)
    function openEntry(mode) {
        if (!on(SHEET) || desk() || window.innerWidth >= 769) return false;
        if (typeof showTab === 'function') showTab('transactions');
        const f = form();
        if (!f) return false;
        closeEntry();
        const back = document.createElement('div');
        back.id = 'mm-backdrop';
        back.onclick = closeEntry;
        f.parentNode.insertBefore(back, f);
        const head = document.createElement('div');
        head.id = 'mm-sheet-head';
        head.innerHTML = `<b>${mode === 'income' ? 'Новый доход' : mode === 'expense' ? 'Новый расход' : 'Новая запись'}</b><button type="button" aria-label="Закрыть"><span class="material-icons">close</span></button>`;
        head.querySelector('button').onclick = closeEntry;
        f.prepend(head);
        f.classList.add('mm-sheet');
        if (mode === 'income' || mode === 'expense') f.classList.add('mm-mode-' + mode);
        document.documentElement.classList.add('mm-sheet-open');
        f.scrollTop = 0;
        return true;
    }
    window.mmOpenEntry = openEntry;
    window.mmCloseEntry = () => { if (!document.documentElement.classList.contains('mm-sheet-open')) return false; closeEntry(); return true; };

    // после записи: вибрация, шторка закрывается
    function hook(name) {
        const orig = window[name];
        if (typeof orig !== 'function') return;
        window[name] = function () {
            const snapshot = JSON.stringify(transactions);
            const r = orig.apply(this, arguments);
            if (JSON.stringify(transactions) !== snapshot) {
                closeEntry();
                renderGlance();
                if (window.MMApp) window.MMApp.buzz(); else if (navigator.vibrate) navigator.vibrate(25);
            }
            return r;
        };
    }

    function renderSettings() {
        const box = $('home-settings');
        if (!box) return;
        box.innerHTML = `
            <label class="sw-row"><span>Сводка сверху в «Записях»: кольцо лимита и три последние записи</span><input type="checkbox" class="ios-switch" id="mm-glance-sw" ${on(GLANCE) ? 'checked' : ''}></label>
            <label class="sw-row"><span>Кнопка «+» открывает запись шторкой снизу (телефон)</span><input type="checkbox" class="ios-switch" id="mm-sheet-sw" ${on(SHEET) ? 'checked' : ''}></label>`;
        $('mm-glance-sw').onchange = e => { localStorage.setItem(GLANCE, e.target.checked ? '1' : '0'); renderGlance(); };
        $('mm-sheet-sw').onchange = e => { localStorage.setItem(SHEET, e.target.checked ? '1' : '0'); closeEntry(); };
    }

    window.addEventListener('DOMContentLoaded', () => {
        hook('saveTx'); hook('saveEdit');
        const origTab = window.showTab;
        window.showTab = function (id) { if (id !== 'transactions') closeEntry(); return origTab.apply(this, arguments); };
        renderSettings();
        setTimeout(renderGlance, 300);
        setInterval(renderGlance, 2000);
    });
})();
