# My Money — памятка для следующего ИИ-ассистента

Прочитайте этот файл первым. Файлы переписки (CHAT_DIALOG.md, CHAT_FULL.md) в этот публичный архив не входят — они в полном архиве на Google Диске (папка «МайМани»).
Исходники сайта — папка `site/`, инструменты перевода — `tools/`.

## Что это
Личное приложение учёта финансов «My Money» (в интерфейсе «Money Pro»). Статический сайт (PWA) без сборки и без
своего сервера: размещается на **GitHub Pages**, вход через **Google**, данные — файл `my_money_data.json`
в папке «My Money» на **Google Диске** пользователя (доступ `drive.file`). Валюта — тенге, время — Алматы (UTC+5).
Текущая версия — **4.0.0** (версии ведутся в `index.html` → блок «История версий» и в `README_FIX_RU.txt`).

## О пользователе и правилах работы
- Пишет по-русски, не программист. Отвечать по-русски, просто, без жаргона; в конце — что сделано, что не проверено.
- После каждой доработки: проверить в браузере, обновить «Историю версий» и `README_FIX_RU.txt`, поднять версию
  кэша в `sw.js` (`my-money-vNN`, добавить новые файлы в `CORE`) и собрать архив `Money_vX.Y.Z_Site.zip`
  (всё содержимое сайта, **без `js/config.js`**). Пользователь сам загружает архив на GitHub поверх старых файлов.
- **Никогда не включать `js/config.js` в архив и не перезаписывать его**: там ключи пользователя (Google Client ID,
  API key, App ID). Образец — `js/config.example.js`.
- Новые темы **не должны менять существующие**: стили новой темы только под `html[data-w95="<id>"]`.
- Без логотипов, фирменных шрифтов, иконок и звуков Apple/Microsoft — всё рисуется самим (CSS/SVG/Web Audio).
- Пользователь любит, когда идеи собираются в список и предлагаются при вопросе «что добавить».

## Устройство (папка site/)
- `index.html` — вся разметка: разделы-вкладки `main > .tab` (id: transactions, wall, subscriptions, salary,
  statistics, reports, wishlist, quotes, prices, oldbook, settings). Меню рисуется из `MENU_ITEMS` (`js/script.js`).
- CSS по порядку: `style.css` → `win95.css` (базовый стиль Windows 95 на переменных `--w95-*`) → `features.css`
  → темы `aqua.css`, `mono.css`, `vista.css` → `v38.css` → `metro.css` → `layout.css` → `v4.css` → `custom.css`.
- JS по порядку (classic scripts, общие глобальные функции): `config.js`, `i18n.js` (первым!), `sound.js`,
  `soundpicker.js`, `themes.js`, `scrollbars.js`, `cloud.js`, `oldbook.js`, `extras.js`, `importer.js`, `layout.js`,
  `emoji.js`, `quotes.js`, `goals.js`, `currency.js`, `shopping.js`, `receipt.js`, `notify.js`, `bank.js`,
  `fonts.js`, `icon.js`, `voice.js`, `obcatalog.js`, `wall.js`, `script.js` (последним: данные, updateUI, меню).
- Словари языков: `js/lang/en.js`, `kk.js`, `fr.js`, `de.js` (подгружаются `i18n.js` через document.write).

### Данные и синхронизация (`js/cloud.js`)
- Списки, сливаемые поштучно по id и `updatedAt` с «надгробиями» удалений — `SYNC_LISTS`: tx, subs, ob, links,
  cats, themes, soundlib, goals, quotes, shop, prices. Новые списки добавлять туда же и в `localSnapshot()`.
- Скаляры (последний по времени выигрывает): savings, limit, goal, profile.name, sounds, themeSounds, ui.
- `uiPrefs` (`js/layout.js`, ключ `ui`) — все настройки вида: header, quotes, catIcons, iconMode, notify, bank,
  fonts, layout, wall. Новые поля добавлять в `normalizeUiPrefs()`.
- Всё сохраняется в localStorage (`finance_*`) в `saveDataLocally()` и уходит на Диск через `updateUI(true)`.
- Файлы на Диске: свои звуки (soundpicker), фото чеков `My Money/Чеки/ГГГГ/ММ/ДД` (receipt.js), книга Oldbook для
  совместного доступа `my_money_oldbook.json`.

### Темы (`js/themes.js`)
- Группы-папки: Windows 95 (19 тем, включая Леопард и Неон), Windows Vista («Аэро»), Mac OS («Аква», «Классика 1-бит»),
  Windows 8 Метро (10 вариантов, `cssId: 'metro'`, особые `data-w95-variant`: light, neon, leopard).
- Тема = переменные на `body` + `html[data-w95=cssId]`. Свои темы пользователя — `customThemes` (редактор цветов).
- Звуки синтезируются Web Audio (`SOUND_PACKS` в `sound.js`), у каждой темы свой набор.

### Внешние сервисы (без ключей)
- Погода open-meteo, курсы currency-api / open.er-api, котировки Yahoo Finance и товары по ссылке, каталог
  oldbook.kz — через бесплатный посредник **r.jina.ai** (сайты не отдают CORS). Ozon и Wildberries блокируют любые
  запросы — даём ссылки на их поиск.
- OCR чеков и обложек: Tesseract.js 5 (rus+eng) с jsdelivr, на устройстве. PDF выписок банка: pdf.js 3.11.
- Распознавание речи: Web Speech API (ru-RU). Альтернативы обсуждались: Vosk/Whisper в браузере, Yandex SpeechKit.

## Языки (`js/i18n.js`)
- Русский — исходный текст в коде. Перевод накладывается на DOM (тексты, placeholder/title/aria-label/data-title,
  alert/confirm/prompt, подписи Chart.js) через MutationObserver. Ключ словаря — русская строка, `{0}` — значения.
- Данные пользователя не переводятся: список `I18N_SKIP` и атрибут `data-i18n-skip`.
- «Дореволюционный»: `toOldStyle()` (вычурные слова) + `toOldOrthography()` (ѣ, і, ъ). Замены не должны содержать
  сами себя (иначе бесконечный цикл).
- В коде не склеивать фразы из кусков (`'текст ' + x`): лучше два шаблона `` `… ${x}` `` — так их находит словарь.
- **Обновить переводы после изменений** (Python 3, нужен интернет):
  ```
  python -X utf8 tools/i18n_extract.py site tools/strings.json
  python -X utf8 tools/i18n_translate.py tools en,kk,fr,de
  python -X utf8 tools/i18n_fix_cyr.py tools
  python -X utf8 tools/i18n_build.py tools site
  ```
  (скрипты ждут, что `strings.json`, `cache_*.json` лежат в папке tools). Ручные переводы ключевых слов —
  словарь `O` в `i18n_build.py`; остальное — машинный черновик Google Translate (кэш в `cache_<язык>.json`).

## Проверка
- Локально: любой статический сервер в папке сайта (например `python -m http.server 8781`). Google-вход работает
  только с адресом, внесённым в Google Cloud (сайт пользователя на GitHub Pages).
- Не проверялось на реальном телефоне: живой микрофон, системные уведомления, загрузка фото чеков на Диск.
- Ограничения, о которых пользователь знает: уведомления приходят, пока приложение открыто/свёрнуто (нет push-сервера);
  банки Казахстана не дают доступа к счёту (только выписка PDF / текст уведомления).

## История версий (кратко)
2.8–2.12: APK-обёртка WebIntoApp, выгрузки Excel/PDF. 3.0: сайт + Google Диск. 3.1–3.3: дизайн Windows 95, 19 тем.
3.4: свои категории и звуки. 3.5–3.7: темы Аква, 1-бит, Аэро, папки тем, редактор тем, свайпы, импорт таблиц,
калькулятор. 3.8: котировки, цели по ссылке, чек по фото, картинки категорий, кнопки окон, «Мои звуки».
3.9: уведомления, список покупок, «Цены», валюта записи, банк. 3.10: ползунки прокрутки, тема «Метро» (10 вариантов).
3.11: шрифты, 6 языков, разметка ПК, гамбургер-меню, приветствие на ПК, своя иконка.
4.0: «Стена», каталог OldBook.kz (номер/фото обложки), голосовой ввод, фото чеков на Диске, «старый слог».
