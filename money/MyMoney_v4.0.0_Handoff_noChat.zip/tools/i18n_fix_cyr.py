"""Переводы en/fr/de, где остались русские слова: перевести заново по частям (предложениями), иначе пометить."""
import json, re, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
SP = Path(sys.argv[1])
CYR = re.compile(r'[А-Яа-яЁё]{3,}')
QUOTED = re.compile(r'«[^»]*»')
strings = json.loads((SP / 'strings.json').read_text(encoding='utf-8'))

import importlib.util
spec = importlib.util.spec_from_file_location('tr', SP / 'i18n_translate.py')
# берём только функцию call, не запуская основной цикл
src = (SP / 'i18n_translate.py').read_text(encoding='utf-8')
ns = {}
exec(src.split('for lang in LANGS:')[0].replace("SP = Path(sys.argv[1])", "SP = Path(r'%s')" % SP).replace("LANGS = sys.argv[2].split(',')", "LANGS = []"), ns)
call = ns['call']

for lang in ['en', 'fr', 'de']:
    cf = SP / f'cache_{lang}.json'
    cache = json.loads(cf.read_text(encoding='utf-8'))
    bad = [k for k, v in cache.items() if k in strings and v and CYR.search(QUOTED.sub('', v)) and not CYR.search(QUOTED.sub('', k)) is None]
    bad = [k for k in bad if CYR.search(QUOTED.sub('', cache[k]))]
    fixed = 0
    for k in bad:
        # предложения по отдельности, плейсхолдеры защищаем числами-маркерами
        parts = re.split(r'(?<=[.!?])\s+', k)
        out = []
        ok = True
        for p in parts:
            prot = re.sub(r'\{(\d+)\}', lambda m: f'[{m.group(1)}]', p)
            try:
                r = call(lang, [prot])[0] or ''
            except Exception:
                ok = False
                break
            r = re.sub(r'\[(\d+)\]', lambda m: '{' + m.group(1) + '}', r)
            out.append(r)
            time.sleep(0.25)
        res = ' '.join(out)
        if ok and not CYR.search(QUOTED.sub('', res)) and sorted(re.findall(r'\{\d+\}', res)) == sorted(re.findall(r'\{\d+\}', k)):
            cache[k] = res
            fixed += 1
        else:
            print(lang, 'NOT FIXED:', k[:70], '=>', res[:70])
    cf.write_text(json.dumps(cache, ensure_ascii=False, indent=0), encoding='utf-8')
    print(lang, 'bad', len(bad), 'fixed', fixed)
