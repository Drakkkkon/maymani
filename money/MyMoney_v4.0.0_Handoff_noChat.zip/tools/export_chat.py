"""Transcript .jsonl -> CHAT_DIALOG.md (только переписка) и CHAT_FULL.md (переписка + шаги работы с инструментами)."""
import json, re, sys
from pathlib import Path

SRC, OUT = Path(sys.argv[1]), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)

SECRET = [
    (re.compile(r'\d{6,}-[a-z0-9_-]+\.apps\.googleusercontent\.com', re.I), '[GOOGLE_CLIENT_ID]'),
    (re.compile(r'AIza[0-9A-Za-z_-]{20,}'), '[GOOGLE_API_KEY]'),
    (re.compile(r'[A-Za-z0-9._%+-]+@gmail\.com'), '[email]'),
    (re.compile(r'(Bearer\s+)[A-Za-z0-9._-]{20,}'), r'\1[TOKEN]'),
    (re.compile(r'ya29\.[A-Za-z0-9._-]+'), '[TOKEN]'),
]


def clean(s):
    s = re.sub(r'<system-reminder>[\s\S]*?</system-reminder>', '', s)
    for re_, rep in SECRET:
        s = re_.sub(rep, s)
    return s.strip()


def brief_input(name, inp):
    if not isinstance(inp, dict):
        return ''
    for k in ('file_path', 'path', 'url', 'pattern', 'description', 'name', 'skill', 'query'):
        if k in inp and isinstance(inp[k], str):
            v = inp[k]
            if k == 'description' and 'command' in inp:
                return v
            return v
    if 'command' in inp:
        return str(inp['command'])[:160]
    if 'text' in inp:
        return str(inp['text'])[:160]
    return json.dumps(inp, ensure_ascii=False)[:160]


dialog, full = [], []
last_user = None
for line in SRC.open(encoding='utf-8'):
    try:
        o = json.loads(line)
    except Exception:
        continue
    if o.get('isSidechain'):
        continue
    t = o.get('type')
    ts = (o.get('timestamp') or '')[:16].replace('T', ' ')
    if t == 'user':
        content = o['message'].get('content')
        if isinstance(content, str):
            txt = clean(content)
            if txt and not txt.startswith('<') and txt != last_user:
                last_user = txt
                block = f'\n\n---\n\n## 👤 Пользователь ({ts})\n\n{txt}\n'
                dialog.append(block)
                full.append(block)
        elif isinstance(content, list):
            for b in content:
                if b.get('type') == 'text':
                    txt = clean(b.get('text', ''))
                    if txt and not txt.startswith('<') and 'This session is being continued' not in txt and txt != last_user:
                        last_user = txt
                        block = f'\n\n---\n\n## 👤 Пользователь ({ts})\n\n{txt}\n'
                        dialog.append(block)
                        full.append(block)
                elif b.get('type') == 'tool_result':
                    c = b.get('content')
                    if isinstance(c, list):
                        c = ' '.join(x.get('text', '') for x in c if x.get('type') == 'text')
                    c = clean(str(c or ''))
                    if c:
                        full.append(f'   ↳ результат: {c[:300].replace(chr(10), " ")}{"…" if len(c) > 300 else ""}\n')
    elif t == 'assistant':
        for b in o['message'].get('content', []) or []:
            if b.get('type') == 'text':
                txt = clean(b.get('text', ''))
                if txt:
                    block = f'\n**🤖 Ассистент ({ts}):**\n\n{txt}\n'
                    dialog.append(block)
                    full.append(block)
            elif b.get('type') == 'tool_use':
                name = b.get('name', '')
                if name.startswith('mcp__ccd_turn__'):
                    continue
                full.append(f'- 🔧 `{name}` — {clean(brief_input(name, b.get("input")))[:200]}\n')

head = ('# My Money — переписка с ИИ-ассистентом (Claude Code)\n\n'
        'Полная история разработки сайта-приложения My Money (личные финансы, GitHub Pages + Google Диск).\n'
        'Секреты (ключи Google, токены, email) заменены на [GOOGLE_CLIENT_ID], [GOOGLE_API_KEY], [TOKEN], [email].\n'
        'Начало разговора было сжато системой, поэтому первые версии (до 3.4) описаны кратко в HANDOFF.md.\n')
(OUT / 'CHAT_DIALOG.md').write_text(head + '\nТолько сообщения пользователя и ответы ассистента.\n' + ''.join(dialog), encoding='utf-8')
(OUT / 'CHAT_FULL.md').write_text(head + '\nСообщения + каждый шаг работы (инструмент и кратко что сделано/получено).\n' + ''.join(full), encoding='utf-8')
print('dialog', len(dialog), 'full', len(full))
