"""strings.json -> cache_<lang>.json (machine draft; hand overrides are applied later in build step)"""
import json, re, sys, time, urllib.request, urllib.parse
from pathlib import Path

SP = Path(sys.argv[1])
LANGS = sys.argv[2].split(',')
strings = json.loads((SP / 'strings.json').read_text(encoding='utf-8'))
PH = re.compile(r'\{\d+\}')


def call(lang, texts):
    body = urllib.parse.urlencode([('q', t) for t in texts]).encode()
    req = urllib.request.Request(
        f'https://translate.googleapis.com/translate_a/t?client=gtx&sl=ru&tl={lang}',
        data=body, headers={'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8', 'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=40) as r:
        res = json.loads(r.read().decode('utf-8'))
    if len(texts) == 1 and isinstance(res, str):
        res = [res]
    out = []
    for x in res:
        out.append(x[0] if isinstance(x, list) else x)
    return out


for lang in LANGS:
    cf = SP / f'cache_{lang}.json'
    cache = json.loads(cf.read_text(encoding='utf-8')) if cf.exists() else {}
    # новые строки и те, что в прошлый раз пришли пустыми (повтор маленькими пачками)
    retry = [k for k in strings if k in cache and not cache[k] and len(k) >= 2]
    todo = [k for k in strings if k not in cache and len(k) >= 2]
    for k in retry:
        try:
            res = call(lang, [k])
            if res and res[0] and sorted(PH.findall(k)) == sorted(PH.findall(res[0])):
                cache[k] = res[0]
        except Exception as e:
            print('retry fail', k[:30], e)
        time.sleep(0.3)
    cf.write_text(json.dumps(cache, ensure_ascii=False, indent=0), encoding='utf-8')
    print(lang, 'todo', len(todo), flush=True)
    batch, size = [], 0
    def flush():
        global batch, size
        if not batch:
            return
        for attempt in range(5):
            try:
                res = call(lang, batch)
                break
            except Exception as e:
                print('retry', attempt, e, flush=True)
                time.sleep(3 + attempt * 5)
        else:
            raise SystemExit('failed')
        for src, tr in zip(batch, res):
            # плейсхолдеры должны сохраниться
            if sorted(PH.findall(src)) != sorted(PH.findall(tr or '')):
                tr = None
            cache[src] = tr
        cf.write_text(json.dumps(cache, ensure_ascii=False, indent=0), encoding='utf-8')
        batch, size = [], 0
        time.sleep(0.6)
    for k in todo:
        batch.append(k)
        size += len(k)
        if size > 1800 or len(batch) >= 40:
            flush()
    flush()
    bad = [k for k in strings if cache.get(k) is None and len(k) >= 2]
    print(lang, 'done; placeholder mismatches:', len(bad), flush=True)
