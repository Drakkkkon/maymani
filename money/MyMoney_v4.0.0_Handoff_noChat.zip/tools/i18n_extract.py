"""Collect user-visible Russian strings from index.html and js/*.js -> strings.json"""
import json, re, sys, html
from html.parser import HTMLParser
from pathlib import Path

APP = Path(sys.argv[1])
OUT = Path(sys.argv[2])
CYR = re.compile(r'[А-Яа-яЁё]')
SKIP_JS = {'config.js', 'config.example.js'}
keys = {}


def norm(s):
    s = html.unescape(s)
    s = s.replace(' ', ' ')
    s = re.sub(r'\s+', ' ', s).strip()
    return s


def add(s, src):
    s = norm(s)
    if not s or not CYR.search(s) or len(s) > 600:
        return
    # голый плейсхолдер вокруг: «{0} ₸» не нужен
    keys.setdefault(s, src)


# ---------- HTML ----------
class P(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style'):
            self.skip += 1
        for k, v in attrs:
            if k in ('placeholder', 'title', 'aria-label', 'data-title', 'alt', 'content') and v:
                add(v, 'html@' + k)

    def handle_endtag(self, tag):
        if tag in ('script', 'style'):
            self.skip -= 1

    def handle_data(self, data):
        if not self.skip:
            add(data, 'html')


P().feed((APP / 'index.html').read_text(encoding='utf-8'))


# ---------- JS: лексер строковых литералов ----------
def split_segments(text):
    """Шаблон с {n} -> текстовые сегменты между тегами, плейсхолдеры перенумерованы"""
    # подписи внутри тегов: title="…", aria-label="…", placeholder="…"
    attrs = [m.group(1) for m in re.finditer(r'(?:title|aria-label|placeholder|data-title)="([^"]*)"', text)]
    # плейсхолдеры внутри тегов исчезают вместе с тегами
    parts = attrs + re.split(r'<[^<>]*>', text)
    for seg in parts:
        for line in seg.split('\n'):
            n = [0]
            def renum(m):
                r = '{%d}' % n[0]
                n[0] += 1
                return r
            line2 = re.sub(r'\{\d+\}', renum, line)
            yield line2


def lex(src, name):
    i, n = 0, len(src)
    prev = ''  # последний значимый символ / слово для отличия regex от деления

    def read_quoted(i, q):
        out = []
        i += 1
        while i < n:
            c = src[i]
            if c == '\\':
                nx = src[i + 1]
                out.append({'n': '\n', 't': '\t'}.get(nx, nx) if nx not in 'u' else chr(int(src[i + 2:i + 6], 16)))
                i += 6 if nx == 'u' else 2
                continue
            if c == q:
                return ''.join(out), i + 1
            out.append(c)
            i += 1
        return ''.join(out), i

    def read_template(i):
        """возвращает (текст с {n}, новая позиция)"""
        out, k = [], 0
        i += 1
        while i < n:
            c = src[i]
            if c == '\\':
                nx = src[i + 1]
                out.append({'n': '\n', 't': '\t'}.get(nx, nx))
                i += 2
                continue
            if c == '`':
                return ''.join(out), i + 1
            if c == '$' and i + 1 < n and src[i + 1] == '{':
                j = read_expr(i + 2)
                out.append('{%d}' % k)
                k += 1
                i = j
                continue
            out.append(c)
            i += 1
        return ''.join(out), i

    def read_expr(i):
        """выражение внутри ${...}: вложенные строки тоже собираются"""
        depth = 0
        while i < n:
            c = src[i]
            if c in '\'"':
                s, i = read_quoted(i, c)
                emit(s)
                continue
            if c == '`':
                s, i = read_template(i)
                emit(s)
                continue
            if c == '{':
                depth += 1
            elif c == '}':
                if depth == 0:
                    return i + 1
                depth -= 1
            i += 1
        return i

    def emit(s):
        if CYR.search(s):
            for seg in split_segments(s):
                add(seg, name)

    while i < n:
        c = src[i]
        if c == '/' and src[i + 1:i + 2] == '/':
            j = src.find('\n', i)
            i = n if j < 0 else j
            continue
        if c == '/' and src[i + 1:i + 2] == '*':
            j = src.find('*/', i + 2)
            i = n if j < 0 else j + 2
            continue
        if c == '/' and (prev in '(,=:[!&|?{};+-*%<>~^' or prev in ('return', 'typeof', '')):
            # литерал регулярного выражения
            i += 1
            in_cls = False
            while i < n:
                ch = src[i]
                if ch == '\\':
                    i += 2
                    continue
                if ch == '[':
                    in_cls = True
                elif ch == ']':
                    in_cls = False
                elif ch == '/' and not in_cls:
                    break
                elif ch == '\n':
                    break
                i += 1
            i += 1
            while i < n and src[i].isalpha():
                i += 1
            prev = 'x'
            continue
        if c in '\'"':
            line_start = src.rfind('\n', 0, i)
            before = src[line_start:i]
            s, i = read_quoted(i, c)
            if 'console.' not in before:
                emit(s)
            prev = 'x'
            continue
        if c == '`':
            line_start = src.rfind('\n', 0, i)
            before = src[line_start:i]
            s, i = read_template(i)
            if 'console.' not in before:
                emit(s)
            prev = 'x'
            continue
        if c.isalnum() or c in '_$':
            j = i
            while j < n and (src[j].isalnum() or src[j] in '_$'):
                j += 1
            prev = src[i:j]
            i = j
            continue
        if not c.isspace():
            prev = c
        i += 1


for f in sorted((APP / 'js').glob('*.js')):
    if f.name in SKIP_JS:
        continue
    lex(f.read_text(encoding='utf-8'), f.name)

# CSS content: '...'
for f in sorted((APP / 'css').glob('*.css')):
    for m in re.finditer(r"content:\s*'([^']*)'", f.read_text(encoding='utf-8')):
        add(m.group(1), f.name)

data = sorted(keys.items(), key=lambda kv: kv[0])
OUT.write_text(json.dumps(dict(data), ensure_ascii=False, indent=0), encoding='utf-8')
print(len(data), 'strings', sum(len(k) for k, _ in data), 'chars')
