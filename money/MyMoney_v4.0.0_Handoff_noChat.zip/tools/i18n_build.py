"""cache_<lang>.json + ручные переводы ключевых слов -> app/js/lang/<lang>.js"""
import json, sys, re
from pathlib import Path

SP = Path(sys.argv[1])
APP = Path(sys.argv[2])
LANGS = ['en', 'kk', 'fr', 'de']
strings = json.loads((SP / 'strings.json').read_text(encoding='utf-8'))

# Ручные переводы: меню, заголовки, кнопки — машинный перевод здесь часто ошибается («Записи» → «Posts»)
O = {
 # меню
 'Записи': ('Records', 'Жазбалар', 'Opérations', 'Buchungen'),
 'Подписки': ('Subscriptions', 'Жазылымдар', 'Abonnements', 'Abos'),
 'Зарплата': ('Salary', 'Жалақы', 'Salaire', 'Gehalt'),
 'Статистика': ('Statistics', 'Статистика', 'Statistiques', 'Statistik'),
 'Отчёты': ('Reports', 'Есептер', 'Rapports', 'Berichte'),
 'Цели': ('Goals', 'Мақсаттар', 'Objectifs', 'Ziele'),
 'Котировки': ('Stocks', 'Акциялар', 'Bourse', 'Aktien'),
 'Цены': ('Prices', 'Бағалар', 'Prix', 'Preise'),
 'Настройки': ('Settings', 'Баптаулар', 'Paramètres', 'Einstellungen'),
 # главная
 'Текущий баланс': ('Current balance', 'Ағымдағы баланс', 'Solde actuel', 'Aktueller Kontostand'),
 'Дневной лимит:': ('Daily limit:', 'Күндік лимит:', 'Limite journalière :', 'Tageslimit:'),
 'Дневной лимит': ('Daily limit', 'Күндік лимит', 'Limite journalière', 'Tageslimit'),
 'Копилка:': ('Savings:', 'Жинақ:', 'Tirelire :', 'Sparschwein:'),
 'Копилка': ('Savings', 'Жинақ', 'Tirelire', 'Sparschwein'),
 'Не установлен': ('Not set', 'Орнатылмаған', 'Non défini', 'Nicht festgelegt'),
 'Новая запись': ('New record', 'Жаңа жазба', 'Nouvelle opération', 'Neue Buchung'),
 'История операций': ('Transaction history', 'Операциялар тарихы', 'Historique des opérations', 'Buchungsverlauf'),
 'Доход': ('Income', 'Кіріс', 'Revenu', 'Einnahme'),
 'Расход': ('Expense', 'Шығыс', 'Dépense', 'Ausgabe'),
 'Доходы': ('Income', 'Кірістер', 'Revenus', 'Einnahmen'),
 'Расходы': ('Expenses', 'Шығыстар', 'Dépenses', 'Ausgaben'),
 'Итог': ('Total', 'Қорытынды', 'Total', 'Summe'),
 'Итог:': ('Total:', 'Қорытынды:', 'Total :', 'Summe:'),
 'Сумма': ('Amount', 'Сома', 'Montant', 'Betrag'),
 'Сумма (₸)': ('Amount (₸)', 'Сома (₸)', 'Montant (₸)', 'Betrag (₸)'),
 'Категория': ('Category', 'Санат', 'Catégorie', 'Kategorie'),
 'Комментарий': ('Comment', 'Түсініктеме', 'Commentaire', 'Kommentar'),
 'Сохранить изменения': ('Save changes', 'Өзгерістерді сақтау', 'Enregistrer', 'Änderungen speichern'),
 'Записей пока нет': ('No records yet', 'Әзірге жазба жоқ', 'Aucune opération', 'Noch keine Buchungen'),
 'Чек по фото': ('Receipt photo', 'Фото чек', 'Ticket en photo', 'Kassenbon-Foto'),
 'Сфотографируйте чек': ('Take a photo of a receipt', 'Чекті суретке түсіріңіз', 'Photographiez le ticket', 'Kassenbon fotografieren'),
 'Сумма и покупки запишутся сами': ('Amount and items are filled in automatically', 'Сома мен сатып алулар өзі жазылады', 'Montant et achats saisis automatiquement', 'Betrag und Artikel werden automatisch erfasst'),
 'Сумма с цифровой клавиатуры': ('Amount from the keypad', 'Сандық пернетақтадан сома', 'Montant au pavé numérique', 'Betrag per Ziffernblock'),
 # подписки, зарплата
 'Новая подписка': ('New subscription', 'Жаңа жазылым', 'Nouvel abonnement', 'Neues Abo'),
 'Активные подписки': ('Active subscriptions', 'Белсенді жазылымдар', 'Abonnements actifs', 'Aktive Abos'),
 'Добавить подписку': ('Add subscription', 'Жазылым қосу', 'Ajouter un abonnement', 'Abo hinzufügen'),
 'Списать': ('Pay', 'Төлеу', 'Payer', 'Bezahlen'),
 'Внести зарплату': ('Add salary', 'Жалақы енгізу', 'Saisir le salaire', 'Gehalt eintragen'),
 'Зачислить': ('Add', 'Есепке алу', 'Créditer', 'Gutschreiben'),
 'История выплат': ('Payment history', 'Төлемдер тарихы', 'Historique des versements', 'Auszahlungsverlauf'),
 # статистика
 'Потрачено сегодня': ('Spent today', 'Бүгін жұмсалды', 'Dépensé aujourd’hui', 'Heute ausgegeben'),
 'Сводка за период': ('Period summary', 'Кезең қорытындысы', 'Résumé de la période', 'Zeitraum-Übersicht'),
 'Калькулятор': ('Calculator', 'Калькулятор', 'Calculatrice', 'Rechner'),
 'Лента калькулятора': ('Calculator tape', 'Калькулятор таспасы', 'Ruban de calcul', 'Rechenstreifen'),
 'Мой банк': ('My bank', 'Менің банкім', 'Ma banque', 'Meine Bank'),
 'Последние 7 дней': ('Last 7 days', 'Соңғы 7 күн', '7 derniers jours', 'Letzte 7 Tage'),
 'Последние 30 дней': ('Last 30 days', 'Соңғы 30 күн', '30 derniers jours', 'Letzte 30 Tage'),
 'Этот месяц': ('This month', 'Осы ай', 'Ce mois-ci', 'Dieser Monat'),
 'Этот год': ('This year', 'Осы жыл', 'Cette année', 'Dieses Jahr'),
 'Всё время': ('All time', 'Барлық уақыт', 'Toute la période', 'Gesamter Zeitraum'),
 # отчёты
 'Сводка по периодам': ('Summary by period', 'Кезеңдер бойынша қорытынды', 'Résumé par période', 'Übersicht nach Zeitraum'),
 'По дням': ('By day', 'Күндер бойынша', 'Par jour', 'Nach Tagen'),
 'По неделям': ('By week', 'Апталар бойынша', 'Par semaine', 'Nach Wochen'),
 'По часам': ('By hour', 'Сағаттар бойынша', 'Par heure', 'Nach Stunden'),
 'Период': ('Period', 'Кезең', 'Période', 'Zeitraum'),
 'Выгрузка': ('Export', 'Экспорт', 'Export', 'Export'),
 'Скачать Excel (.xlsx)': ('Download Excel (.xlsx)', 'Excel жүктеу (.xlsx)', 'Télécharger Excel (.xlsx)', 'Excel herunterladen (.xlsx)'),
 'Скачать PDF (A4)': ('Download PDF (A4)', 'PDF жүктеу (A4)', 'Télécharger PDF (A4)', 'PDF herunterladen (A4)'),
 'Загрузить свою таблицу': ('Import your spreadsheet', 'Өз кестеңізді жүктеу', 'Importer votre tableau', 'Eigene Tabelle importieren'),
 # цели, покупки, цены, котировки
 'Новая приоритетная цель': ('New priority goal', 'Жаңа басым мақсат', 'Nouvel objectif prioritaire', 'Neues Prioritätsziel'),
 'Приоритетные цели': ('Priority goals', 'Басым мақсаттар', 'Objectifs prioritaires', 'Prioritätsziele'),
 'Список покупок': ('Shopping list', 'Сатып алу тізімі', 'Liste de courses', 'Einkaufsliste'),
 'Котировки акций': ('Stock prices', 'Акция бағалары', 'Cours des actions', 'Aktienkurse'),
 'Мои котировки': ('My stocks', 'Менің акцияларым', 'Mes actions', 'Meine Aktien'),
 'Добавить компанию': ('Add company', 'Компания қосу', 'Ajouter une société', 'Unternehmen hinzufügen'),
 'Обновить': ('Refresh', 'Жаңарту', 'Actualiser', 'Aktualisieren'),
 'Как менялась цена': ('Price history', 'Баға қалай өзгерді', 'Évolution du prix', 'Preisverlauf'),
 'Добавить цену': ('Add price', 'Баға қосу', 'Ajouter un prix', 'Preis hinzufügen'),
 'Цены по магазинам': ('Prices by store', 'Дүкендер бойынша бағалар', 'Prix par magasin', 'Preise nach Geschäft'),
 'Все цены': ('All prices', 'Барлық бағалар', 'Tous les prix', 'Alle Preise'),
 'Сохранить цену': ('Save price', 'Бағаны сақтау', 'Enregistrer le prix', 'Preis speichern'),
 # настройки
 'Темы оформления': ('Themes', 'Безендіру тақырыптары', 'Thèmes', 'Designs'),
 'Звуки': ('Sounds', 'Дыбыстар', 'Sons', 'Töne'),
 'Шрифты': ('Fonts', 'Қаріптер', 'Polices', 'Schriftarten'),
 'Разметка и меню': ('Layout and menu', 'Орналасу және мәзір', 'Disposition et menu', 'Layout und Menü'),
 'Иконка приложения': ('App icon', 'Қолданба белгішесі', 'Icône de l’application', 'App-Symbol'),
 'Уведомления': ('Notifications', 'Хабарландырулар', 'Notifications', 'Benachrichtigungen'),
 'Безопасность': ('Security', 'Қауіпсіздік', 'Sécurité', 'Sicherheit'),
 'Профиль': ('Profile', 'Профиль', 'Profil', 'Profil'),
 'Мои категории': ('My categories', 'Менің санаттарым', 'Mes catégories', 'Meine Kategorien'),
 'Пункты меню': ('Menu items', 'Мәзір тармақтары', 'Éléments du menu', 'Menüpunkte'),
 'История версий': ('Version history', 'Нұсқалар тарихы', 'Historique des versions', 'Versionsverlauf'),
 'Локальные данные': ('Local data', 'Жергілікті деректер', 'Données locales', 'Lokale Daten'),
 'Сбросить всё': ('Reset everything', 'Барлығын тазалау', 'Tout réinitialiser', 'Alles zurücksetzen'),
 'Мои звуки': ('My sounds', 'Менің дыбыстарым', 'Mes sons', 'Meine Töne'),
 'Выбрать звуки': ('Choose sounds', 'Дыбыстарды таңдау', 'Choisir les sons', 'Töne auswählen'),
 'Картинки категорий': ('Category pictures', 'Санат суреттері', 'Images des catégories', 'Kategoriebilder'),
 'Картинки в истории операций': ('Pictures in transaction history', 'Операциялар тарихындағы суреттер', 'Images dans l’historique', 'Bilder im Buchungsverlauf'),
 'Блок «Текущий баланс»': ('“Current balance” block', '«Ағымдағы баланс» блогы', 'Bloc « Solde actuel »', 'Block „Aktueller Kontostand“'),
 'Аккаунт Google (Google Диск)': ('Google account (Google Drive)', 'Google аккаунты (Google Drive)', 'Compte Google (Google Drive)', 'Google-Konto (Google Drive)'),
 'Как в теме': ('As in theme', 'Тақырыптағыдай', 'Comme le thème', 'Wie im Design'),
 'Заголовки, кнопки и меню': ('Headings, buttons and menu', 'Тақырыптар, түймелер және мәзір', 'Titres, boutons et menu', 'Überschriften, Tasten und Menü'),
 'Текст, суммы и даты': ('Text, amounts and dates', 'Мәтін, сомалар және күндер', 'Texte, montants et dates', 'Text, Beträge und Daten'),
 'Меню на телефоне': ('Menu on phone', 'Телефондағы мәзір', 'Menu sur téléphone', 'Menü auf dem Telefon'),
 'Меню на ПК': ('Menu on PC', 'ДК-дағы мәзір', 'Menu sur PC', 'Menü auf dem PC'),
 'Внизу': ('Bottom', 'Төменде', 'En bas', 'Unten'),
 'Слева': ('Left', 'Сол жақта', 'À gauche', 'Links'),
 'Гамбургер ☰': ('Hamburger ☰', 'Гамбургер ☰', 'Hamburger ☰', 'Hamburger ☰'),
 'Ширина приложения на ПК': ('App width on PC', 'ДК-дағы қолданба ені', 'Largeur sur PC', 'App-Breite auf dem PC'),
 'По центру 16:9': ('Centered 16:9', 'Ортада 16:9', 'Centré 16:9', 'Zentriert 16:9'),
 'Узко': ('Narrow', 'Тар', 'Étroit', 'Schmal'),
 'Своя': ('Custom', 'Өзіндік', 'Personnalisé', 'Eigene'),
 'Во весь экран': ('Full screen', 'Толық экран', 'Plein écran', 'Vollbild'),
 'Блоки в строке': ('Blocks per row', 'Жолдағы блоктар', 'Blocs par ligne', 'Blöcke pro Zeile'),
 'Авто': ('Auto', 'Авто', 'Auto', 'Auto'),
 'Плотность': ('Density', 'Тығыздық', 'Densité', 'Dichte'),
 'Компактно': ('Compact', 'Ықшам', 'Compact', 'Kompakt'),
 'Обычно': ('Normal', 'Қалыпты', 'Normal', 'Normal'),
 'Просторно': ('Spacious', 'Кең', 'Aéré', 'Großzügig'),
 # общие
 'Добро пожаловать': ('Welcome', 'Қош келдіңіз', 'Bienvenue', 'Willkommen'),
 'разблокируйте': ('slide to unlock', 'құлпын ашыңыз', 'glissez pour déverrouiller', 'zum Entsperren schieben'),
 'Доброе утро!': ('Good morning!', 'Қайырлы таң!', 'Bonjour !', 'Guten Morgen!'),
 'Добрый день!': ('Good afternoon!', 'Қайырлы күн!', 'Bon après-midi !', 'Guten Tag!'),
 'Добрый вечер!': ('Good evening!', 'Қайырлы кеш!', 'Bonsoir !', 'Guten Abend!'),
 'Доброй ночи!': ('Good night!', 'Қайырлы түн!', 'Bonne nuit !', 'Gute Nacht!'),
 'Баланс': ('Balance', 'Баланс', 'Solde', 'Kontostand'),
 'Цель': ('Goal', 'Мақсат', 'Objectif', 'Ziel'),
 'Свернуть': ('Minimize', 'Жию', 'Réduire', 'Minimieren'),
 'Развернуть': ('Maximize', 'Жаю', 'Agrandir', 'Maximieren'),
 'Готово': ('Done', 'Дайын', 'Terminé', 'Fertig'),
 'Отмена': ('Cancel', 'Болдырмау', 'Annuler', 'Abbrechen'),
 'Удалить': ('Delete', 'Жою', 'Supprimer', 'Löschen'),
 'Сохранить': ('Save', 'Сақтау', 'Enregistrer', 'Speichern'),
 'Закрыть': ('Close', 'Жабу', 'Fermer', 'Schließen'),
 'Синхронизировать': ('Sync', 'Синхрондау', 'Synchroniser', 'Synchronisieren'),
 'Войти через Google': ('Sign in with Google', 'Google арқылы кіру', 'Se connecter avec Google', 'Mit Google anmelden'),
 'Выйти': ('Sign out', 'Шығу', 'Se déconnecter', 'Abmelden'),
 'текущая': ('current', 'ағымдағы', 'actuelle', 'aktuell'),
 'общий': ('shared', 'ортақ', 'commune', 'allgemein'),
 'кг': ('kg', 'кг', 'kg', 'kg'), 'г': ('g', 'г', 'g', 'g'), 'л': ('l', 'л', 'l', 'l'), 'мл': ('ml', 'мл', 'ml', 'ml'),
 'шт': ('pcs', 'дана', 'pcs', 'Stk.'), 'уп': ('pack', 'қап', 'paq.', 'Pck.'),
 'В наличии: {0} шт.': ('In stock: {0} pcs', 'Қоймада: {0} дана', 'En stock : {0} ex.', 'Vorrätig: {0} Stk.'),
 'Нет в наличии': ('Out of stock', 'Қоймада жоқ', 'Épuisé', 'Nicht vorrätig'),
 'Стена': ('Wall', 'Қабырға', 'Mur', 'Pinnwand'),
 'На стену': ('Pin to wall', 'Қабырғаға', 'Épingler au mur', 'An die Pinnwand'),
 'Убрать со стены': ('Remove from wall', 'Қабырғадан алу', 'Retirer du mur', 'Von der Pinnwand nehmen'),
 'Вернуть': ('Put back', 'Қайтару', 'Remettre', 'Zurücklegen'),
 'Каталог OldBook.kz': ('OldBook.kz catalog', 'OldBook.kz каталогы', 'Catalogue OldBook.kz', 'OldBook.kz-Katalog'),
 'Книга не найдена': ('Book not found', 'Кітап табылмады', 'Livre introuvable', 'Buch nicht gefunden'),
 'Сказать голосом': ('Say it', 'Дауыспен айту', 'Dicter', 'Diktieren'),
 'Фото чека': ('Receipt photo', 'Чек суреті', 'Photo du ticket', 'Kassenbon-Foto'),
 'курс на {0}': ('rate on {0}', '{0} бағамы', 'taux du {0}', 'Kurs vom {0}'),
 'курс на {0} (нет сети)': ('rate on {0} (offline)', '{0} бағамы (желі жоқ)', 'taux du {0} (hors ligne)', 'Kurs vom {0} (offline)'),
 'Мои шрифты': ('My fonts', 'Менің қаріптерім', 'Mes polices', 'Meine Schriftarten'),
 'Общие шрифты': ('Shared fonts', 'Ортақ қаріптер', 'Polices communes', 'Allgemeine Schriftarten'),
}
IDX = {l: i for i, l in enumerate(LANGS)}

for lang in LANGS:
    cache = json.loads((SP / f'cache_{lang}.json').read_text(encoding='utf-8'))
    out = {}
    for k in strings:
        v = cache.get(k)
        if v:
            out[k] = v
    for k, vals in O.items():
        out[k] = vals[IDX[lang]]
    (APP / 'js' / 'lang').mkdir(parents=True, exist_ok=True)
    body = json.dumps(out, ensure_ascii=False, separators=(',', ':'))
    (APP / 'js' / 'lang' / f'{lang}.js').write_text(
        f'// Словарь «{lang}» для js/i18n.js: русская строка → перевод. Ключевые слова переведены вручную,\n'
        f'// остальное — машинный черновик, проверенный по смыслу. {len(out)} строк.\nwindow.I18N_DICT = {body};\n', encoding='utf-8')
    print(lang, len(out))
