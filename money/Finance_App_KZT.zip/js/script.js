
let balance = 0;
let savings = 0;
let transactions = [];
let priorityGoal = { name: '', amount: 0 };
let chartInstance = null;

function init() {
    const storedTx = localStorage.getItem('finance_tx');
    const storedSavings = localStorage.getItem('finance_savings');
    const storedGoal = localStorage.getItem('finance_goal');
    const storedLastDate = localStorage.getItem('finance_lastDate');
    
    if (storedTx) transactions = JSON.parse(storedTx);
    if (storedSavings) savings = parseFloat(storedSavings);
    if (storedGoal) priorityGoal = JSON.parse(storedGoal);
    
    checkDailyRollover(storedLastDate);
    updateUI();
}

function checkDailyRollover(storedLastDate) {
    const today = new Date().toLocaleDateString();
    
    if (storedLastDate && storedLastDate !== today) {
        // Перенос неиспользованного дневного лимита в копилку
        let currentBalance = transactions.reduce((acc, tx) => tx.type === 'income' ? acc + tx.amount : acc - tx.amount, 0);
        
        // Пересчет лимита, который был на вчерашний день
        let daysInMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate();
        let daysLeftYesterday = daysInMonth - new Date(storedLastDate.split('.')[2], storedLastDate.split('.')[1]-1, storedLastDate.split('.')[0]).getDate() + 1;
        
        let yesterdayLimit = currentBalance > 0 ? currentBalance / daysLeftYesterday : 0;
        
        // Симуляция: если мы не потратили весь лимит, добавим часть в копилку.
        // Для упрощения, переносим 10% от текущего остатка при смене дня (в реальном приложении нужна более точная логика расхода за день)
        let transferAmount = yesterdayLimit * 0.2; 
        
        if (transferAmount > 0 && priorityGoal.amount > 0) {
            savings += transferAmount;
            transactions.push({ 
                type: 'expense', 
                amount: transferAmount, 
                category: 'Автоперенос в копилку', 
                date: today 
            });
            alert(`Новый день! В копилку автоматически переведено: ${transferAmount.toFixed(0)} ₸`);
        }
    }
    localStorage.setItem('finance_lastDate', today);
}

function updateUI() {
    balance = transactions.reduce((acc, tx) => tx.type === 'income' ? acc + tx.amount : acc - tx.amount, 0);
    
    const now = new Date();
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    const daysLeft = daysInMonth - now.getDate() + 1;
    const dailyLimit = balance > 0 ? (balance / daysLeft).toFixed(0) : 0;

    document.getElementById('balance').innerText = `${balance.toFixed(0)} ₸`;
    document.getElementById('daily-limit').innerText = `${dailyLimit} ₸`;
    document.getElementById('savings').innerText = `${savings.toFixed(0)} ₸`;
    
    // Рендер истории
    const txList = document.getElementById('tx-list');
    txList.innerHTML = '';
    
    const sortedTx = [...transactions].reverse();
    sortedTx.forEach(tx => {
        const sign = tx.type === 'income' ? '+' : '-';
        txList.innerHTML += `<li class="${tx.type}">
            <div>
                <strong>${tx.category}</strong><br>
                <small style="color:#888">${tx.date}</small>
            </div>
            <strong>${sign}${tx.amount.toFixed(0)} ₸</strong>
        </li>`;
    });
    
    // Рендер цели
    const goalDisplay = document.getElementById('current-goal-display');
    if (priorityGoal.name) {
        let percent = priorityGoal.amount > 0 ? Math.min(100, (savings / priorityGoal.amount) * 100) : 0;
        goalDisplay.innerHTML = `
            <h4>${priorityGoal.name}</h4>
            <p>Собрано: ${savings.toFixed(0)} ₸ из ${priorityGoal.amount} ₸</p>
            <div class="goal-progress">
                <div class="goal-bar" style="width: ${percent}%"></div>
            </div>
        `;
    }
    
    localStorage.setItem('finance_tx', JSON.stringify(transactions));
    localStorage.setItem('finance_savings', savings.toString());
    localStorage.setItem('finance_goal', JSON.stringify(priorityGoal));
    
    updateChart();
}

function addTx(type) {
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;
    if (!amount || !category) {
        alert('Заполните сумму и категорию');
        return;
    }
    transactions.push({ type, amount, category, date: new Date().toLocaleDateString() });
    document.getElementById('amount').value = '';
    document.getElementById('category').value = '';
    updateUI();
    
    if(window.Notification && Notification.permission === "granted") {
        new Notification("Запись добавлена", {body: `${category}: ${amount} ₸`});
    } else if (window.Notification && Notification.permission !== "denied") {
        Notification.requestPermission().then(perm => {
            if(perm === "granted") new Notification("Уведомления включены!");
        });
    }
}

function setPriorityGoal() {
    const name = document.getElementById('goal-name').value;
    const amount = parseFloat(document.getElementById('goal-amount').value);
    if (!name || !amount) return;
    priorityGoal = { name, amount };
    document.getElementById('goal-name').value = '';
    document.getElementById('goal-amount').value = '';
    updateUI();
}

function showTab(tabId, btn) {
    document.querySelectorAll('.tab').forEach(t => t.style.display = 'none');
    document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
    document.getElementById(tabId).style.display = 'block';
    btn.classList.add('active');
}

function exportCSV() {
    let csv = '\uFEFFДата,Тип,Категория,Сумма\n'; // BOM для Excel
    transactions.forEach(tx => {
        csv += `${tx.date},${tx.type === 'income' ? 'Доход' : 'Расход'},${tx.category},${tx.amount}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'finance_export.csv';
    link.click();
}

function updateChart() {
    const ctx = document.getElementById('chart');
    if (!ctx) return;
    
    const expenses = transactions.filter(t => t.type === 'expense' && t.category !== 'Автоперенос в копилку');
    const categories = [...new Set(expenses.map(t => t.category))];
    const data = categories.map(c => expenses.filter(t => t.category === c).reduce((sum, t) => sum + t.amount, 0));
    
    if (chartInstance) chartInstance.destroy();
    
    if(data.length === 0) return;

    chartInstance = new Chart(ctx.getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: categories,
            datasets: [{ 
                data: data, 
                backgroundColor: ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4'] 
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });
}

// Инициализация при загрузке
window.onload = init;
