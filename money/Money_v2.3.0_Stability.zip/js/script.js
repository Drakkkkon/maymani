
// --- НАСТРОЙКИ FIREBASE (ЗАПОЛНИТЬ СВОИМИ ДАННЫМИ ИЗ КОНСОЛИ) ---
const firebaseConfig = {
  apiKey: "AIzaSyB27Rqisiz2OyavjImphW-M0PBg5hbIdiE",
  authDomain: "money99774.firebaseapp.com",
  databaseURL: "https://money99774-default-rtdb.firebaseio.com",
  projectId: "money99774",
  storageBucket: "money99774.firebasestorage.app",
  messagingSenderId: "711455509046",
  appId: "1:711455509046:web:dbedd1a788759ccaa22697",
  measurementId: "G-EHXW3LVGFF"
};

// Инициализация Firebase
let auth, db;
try {
    if (typeof firebase !== 'undefined') {
        firebase.initializeApp(firebaseConfig);
        auth = firebase.auth();
        db = firebase.database();
    }
} catch(e) {
    console.warn("Firebase не загружен", e);
}
let currentUser = null;

let transactions = [];
let subscriptions = [];
let priorityGoal = { name: '', amount: 0, icon: '🎯' };
let manualLimit = 0;
let savings = 0;
let myChart = null; 

window.onload = function() {
    loadData();
    checkDailyRollover();
    
    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    let dtInput = document.getElementById('tx-datetime');
    if (dtInput) dtInput.value = now.toISOString().slice(0,16);

    if (typeof Chart !== 'undefined') { Chart.defaults.color = '#888'; Chart.defaults.font.family = "'Inter', sans-serif"; }

    updateUI(false);
    initSlider();
    
    // Слушатель авторизации
    if (auth) auth.onAuthStateChanged(user => {
        let loggedOutDiv = document.getElementById('auth-logged-out');
        let loggedInDiv = document.getElementById('auth-logged-in');
        let emailDisp = document.getElementById('user-email-display');
        
        if (user) {
            currentUser = user;
            if(loggedOutDiv) loggedOutDiv.style.display = 'none';
            if(loggedInDiv) loggedInDiv.style.display = 'block';
            if(emailDisp) emailDisp.innerText = user.email;
            
            // При входе в аккаунт автоматически подтягиваем данные из облака
            autoSyncPull(); 
        } else {
            currentUser = null;
            if(loggedOutDiv) loggedOutDiv.style.display = 'block';
            if(loggedInDiv) loggedInDiv.style.display = 'none';
            if(emailDisp) emailDisp.innerText = '';
        }
    });
};

// --- ФУНКЦИИ АВТОРИЗАЦИИ ---
async function loginFirebase() {
    if (!auth) { alert('Облако недоступно'); return; }
    const email = document.getElementById('auth-email').value.trim();
    const pass = document.getElementById('auth-password').value;
    const errEl = document.getElementById('auth-error');
    errEl.innerText = '';
    
    if(!email || !pass) { errEl.innerText = 'Введите email и пароль'; return; }
    try {
        await auth.signInWithEmailAndPassword(email, pass);
        // Не нужно вызывать alert, onAuthStateChanged обновит UI
        document.getElementById('auth-password').value = '';
    } catch(e) {
        errEl.innerText = "Ошибка входа. Проверьте данные.";
        console.error(e);
    }
}

async function registerFirebase() {
    if (!auth) { alert('Облако недоступно'); return; }
    const email = document.getElementById('auth-email').value.trim();
    const pass = document.getElementById('auth-password').value;
    const errEl = document.getElementById('auth-error');
    errEl.innerText = '';
    
    if(!email || !pass) { errEl.innerText = 'Введите email и пароль'; return; }
    if(pass.length < 6) { errEl.innerText = 'Пароль должен быть минимум 6 символов'; return; }
    
    try {
        await auth.createUserWithEmailAndPassword(email, pass);
        alert("Регистрация успешна! Вы вошли в аккаунт.");
        document.getElementById('auth-password').value = '';
        
        // Отправляем текущие локальные данные в новое облако
        autoSyncPush();
    } catch(e) {
        errEl.innerText = "Ошибка регистрации: " + e.message;
        console.error(e);
    }
}

async function logoutFirebase() {
    if(confirm("Вы точно хотите выйти из аккаунта?")) {
        try {
            await auth.signOut();
        } catch(e) {
            console.error(e);
        }
    }
}

// --- ФУНКЦИИ СИНХРОНИЗАЦИИ ---
async function autoSyncPull() {
    if (!db) return;
    if (!currentUser) return;
    try {
        const snapshot = await db.ref('users/' + currentUser.uid).once('value');
        const data = snapshot.val();
        if(data) {
            if(data.tx) transactions = data.tx;
            if(data.subs) subscriptions = data.subs;
            if(data.savings !== undefined) savings = data.savings;
            if(data.limit !== undefined) manualLimit = data.limit;
            if(data.goal) priorityGoal = data.goal;
            updateUI(false);
    initSlider(); // false чтобы не зациклить
        }
    } catch(e) {
        console.error("Ошибка скачивания из облака", e);
    }
}

async function autoSyncPush() {
    if (!db) return;
    if (!currentUser) return;
    let data = { tx: transactions, subs: subscriptions, savings, limit: manualLimit, goal: priorityGoal };
    try {
        await db.ref('users/' + currentUser.uid).set(data);
    } catch(e) {
        console.error("Ошибка сохранения в облако", e);
    }
}

async function pushToCloud() { 
    if(!currentUser) { alert("Войдите в аккаунт!"); return; }
    await autoSyncPush(); 
    alert("Данные принудительно отправлены в облако!"); 
}
async function pullFromCloud() { 
    if(!currentUser) { alert("Войдите в аккаунт!"); return; }
    await autoSyncPull(); 
    alert("Данные загружены из облака!"); 
}
async function forceSyncPull() { 
    if(!currentUser) { 
        alert("Войдите в аккаунт для облачной синхронизации."); 
        return; 
    }
    await autoSyncPull(); 
    alert("Синхронизировано с облаком!"); 
}


// --- ОСТАЛЬНАЯ ЛОГИКА ---
function loadData() {
    try {
        if (localStorage.getItem('finance_tx')) transactions = JSON.parse(localStorage.getItem('finance_tx'));
        if (localStorage.getItem('finance_subs')) subscriptions = JSON.parse(localStorage.getItem('finance_subs'));
        if (localStorage.getItem('finance_goal')) priorityGoal = JSON.parse(localStorage.getItem('finance_goal'));
        if (localStorage.getItem('finance_limit')) manualLimit = parseFloat(localStorage.getItem('finance_limit')) || 0;
        if (localStorage.getItem('finance_savings')) savings = parseFloat(localStorage.getItem('finance_savings')) || 0;
    } catch(e) {
        console.error("Error loading local storage:", e);
    }
    
    if (localStorage.getItem('finance_theme') === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
        let icon = document.getElementById('theme-icon');
        if (icon) icon.innerText = 'light_mode';
    }
    
    if (localStorage.getItem('finance_bg')) setHeaderBg(localStorage.getItem('finance_bg'));
    
    let mLimit = document.getElementById('manual-limit');
    if (mLimit) mLimit.value = manualLimit > 0 ? manualLimit : '';
}

function toggleTheme() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
    let icon = document.getElementById('theme-icon');
    if (icon) icon.innerText = isDark ? 'dark_mode' : 'light_mode';
    localStorage.setItem('finance_theme', isDark ? 'light' : 'dark');
    
    if(myChart) {
        myChart.update();
    }
}

function setHeaderBg(bgClass) {
    let header = document.getElementById('main-header');
    if (header) header.className = bgClass;
    localStorage.setItem('finance_bg', bgClass);
}

function getTxDateStr(datetimeStr) {
    if (!datetimeStr) return '';
    return datetimeStr.includes('T') ? datetimeStr.split('T')[0] : datetimeStr;
}

function checkDailyRollover() {
    let nowStr = new Date().toISOString();
    const today = nowStr.split('T')[0];
    let lastDate = localStorage.getItem('finance_lastDate');
    
    if (!lastDate) {
        localStorage.setItem('finance_lastDate', today);
        return;
    }
    
    if (lastDate !== today && manualLimit > 0) {
        let dayExpenses = transactions
            .filter(t => getTxDateStr(t.date) === lastDate && t.type === 'expense' && !t.isSystem)
            .reduce((sum, t) => sum + t.amount, 0);
            
        let saved = manualLimit - dayExpenses;
        
        if (saved > 0 && priorityGoal.amount > 0) {
            savings += saved;
            transactions.push({
                id: Date.now().toString(),
                type: 'expense',
                amount: saved,
                category: 'Автоперенос в копилку (остаток лимита)',
                date: lastDate + 'T23:59',
                isSystem: true
            });
            updateUI(true);
        }
        localStorage.setItem('finance_lastDate', today);
    }
}

function updateUI(pushToCloud = false) {
    saveDataLocally();

    let balance = transactions.reduce((acc, tx) => tx.type === 'income' ? acc + tx.amount : acc - tx.amount, 0);
    
    let elBalance = document.getElementById('balance');
    let elSavings = document.getElementById('savings');
    let elLimitDisp = document.getElementById('daily-limit-display');

    if (elBalance) elBalance.innerText = `${balance.toFixed(0)} ₸`;
    if (elSavings) elSavings.innerText = `${savings.toFixed(0)} ₸`;
    if (elLimitDisp) elLimitDisp.innerText = manualLimit > 0 ? `${manualLimit} ₸` : 'Не установлен';

    renderTransactions();
    renderSubscriptions();
    if(typeof renderSalaryList === "function") renderSalaryList();
    renderGoal();
    generateReport(); 
    renderStatistics();
    
    // Если флаг pushToCloud true, то пушим в Firebase автоматически
    if (pushToCloud) autoSyncPush();
}

function renderStatistics() {
    let today = new Date();
    today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
    let todayStr = today.toISOString().split('T')[0];
    
    let spentToday = transactions
        .filter(t => getTxDateStr(t.date) === todayStr && t.type === 'expense' && !t.isSystem)
        .reduce((sum, t) => sum + t.amount, 0);
        
    let elTodaySpent = document.getElementById('today-spent');
    if (elTodaySpent) elTodaySpent.innerText = `${spentToday} ₸`;
    
    if (typeof Chart === 'undefined') return;
    
    let dates = [];
    for(let i=6; i>=0; i--) {
        let d = new Date();
        d.setDate(d.getDate() - i);
        d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
        dates.push(d.toISOString().split('T')[0]);
    }
    
    let incomeData = dates.map(d => {
        return transactions.filter(t => getTxDateStr(t.date) === d && t.type === 'income' && !t.isSystem)
                           .reduce((sum, t) => sum + t.amount, 0);
    });
    let expenseData = dates.map(d => {
        return transactions.filter(t => getTxDateStr(t.date) === d && t.type === 'expense' && !t.isSystem)
                           .reduce((sum, t) => sum + t.amount, 0);
    });
    
    let displayDates = dates.map(d => {
        let parts = d.split('-');
        return `${parts[2]}.${parts[1]}`;
    });

    const ctx = document.getElementById('mainChart');
    if (!ctx) return;
    
    if (myChart) {
        myChart.data.labels = displayDates;
        myChart.data.datasets[0].data = incomeData;
        myChart.data.datasets[1].data = expenseData;
        myChart.update();
    } else {
        myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: displayDates,
                datasets: [
                    {
                        label: 'Доход',
                        data: incomeData,
                        backgroundColor: '#4caf50',
                        borderRadius: 4
                    },
                    {
                        label: 'Расход',
                        data: expenseData,
                        backgroundColor: '#ef5350',
                        borderRadius: 4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                },
                scales: {
                    y: { beginAtZero: true },
                    x: { grid: { display: false } }
                }
            }
        });
    }
}

function renderTransactions() {
    const txList = document.getElementById('tx-list');
    if (!txList) return;
    txList.innerHTML = '';
    
    if (transactions.length === 0) {
        txList.innerHTML = '<p class="hint" style="text-align:center; padding: 25px;">Записей пока нет</p>';
        return;
    }

    let sortedAsc = [...transactions].sort((a,b) => new Date((a.date||'').replace('T', ' ')) - new Date((b.date||'').replace('T', ' ')));
    let groups = {};
    let runBalance = 0;
    
    sortedAsc.forEach(tx => {
        runBalance += (tx.type === 'income' ? tx.amount : -tx.amount);
        let dDate = getTxDateStr(tx.date);
        if (!dDate) return;
        
        if(!groups[dDate]) groups[dDate] = { income: 0, expense: 0, endBalance: 0, items: [] };
        
        if(!tx.isSystem) {
            if(tx.type === 'income') groups[dDate].income += tx.amount;
            else groups[dDate].expense += tx.amount;
        }
        groups[dDate].endBalance = runBalance;
        groups[dDate].items.push(tx);
    });

    Object.keys(groups).sort((a,b) => new Date(b) - new Date(a)).forEach(date => {
        let g = groups[date];
        let parts = date.split('-');
        let fDate = parts.length === 3 ? `${parts[2]}.${parts[1]}.${parts[0]}` : date;
        
        let header = document.createElement('div');
        header.className = 'date-group-header';
        header.innerHTML = `
            <h4>${fDate}</h4>
            <p>
                <span style="color:var(--income)">+${g.income}</span> 
                <span style="color:var(--expense)">-${g.expense}</span> 
                <span>Итог: <strong>${g.endBalance} ₸</strong></span>
            </p>
        `;
        txList.appendChild(header);
        
        g.items.reverse().forEach(tx => {
            let sign = tx.type === 'income' ? '+' : '-';
            let timeStr = (tx.date && tx.date.includes('T')) ? ` <span style="font-size:12px;color:var(--text-muted);">${tx.date.split('T')[1]}</span>` : '';
            let div = document.createElement('div');
            div.className = `tx-item ${tx.type}`;
            div.innerHTML = `
                <div class="tx-info">
                    <strong>${tx.category || 'Без категории'}</strong><br>${timeStr}
                </div>
                <strong style="font-size: 15px;">${sign}${tx.amount} ₸</strong>
                ${tx.isSystem ? '' : `
                <div class="tx-actions">
                    <button type="button" onclick="editTx('${tx.id}')"><span class="material-icons" style="font-size:18px;">edit</span></button>
                    <button type="button" onclick="deleteTx('${tx.id}')"><span class="material-icons" style="font-size:18px; color:#d32f2f;">delete</span></button>
                </div>
                `}
            `;
            txList.appendChild(div);
        });
    });
}

function addSub() {
    let nameEl = document.getElementById('sub-name');
    let amountEl = document.getElementById('sub-amount');
    let dayEl = document.getElementById('sub-day');

    if (!nameEl || !amountEl || !dayEl) return;

    const name = nameEl.value.trim();
    const amount = parseFloat(amountEl.value);
    const day = parseInt(dayEl.value);

    if(!name || !amount || isNaN(day) || day < 1 || day > 31) {
        alert("Заполните название, сумму и день месяца (1-31)!");
        return;
    }

    subscriptions.push({ id: Date.now().toString(), name, amount, day });

    nameEl.value = '';
    amountEl.value = '';
    dayEl.value = '1';

    updateUI(true);
}

function deleteSub(id) {
    if(confirm("Удалить подписку?")) {
        subscriptions = subscriptions.filter(s => s.id !== id);
        updateUI(true);
    }
}

function paySub(id) {
    let sub = subscriptions.find(s => s.id === id);
    if(!sub) return;

    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    let datetimeNow = now.toISOString().slice(0,16);

    transactions.push({
        id: Date.now().toString(),
        type: 'expense',
        amount: sub.amount,
        category: `Подписка: ${sub.name}`,
        date: datetimeNow
    });

    updateUI(true);
    alert(`Подписка «${sub.name}» успешно списана (${sub.amount} ₸)!`);
}

function renderSubscriptions() {
    const subsList = document.getElementById('subs-list');
    if (!subsList) return;
    subsList.innerHTML = '';

    if(subscriptions.length === 0) {
        subsList.innerHTML = '<p class="hint" style="text-align:center; padding: 20px;">Нет активных подписок</p>';
        return;
    }

    subscriptions.forEach(sub => {
        let div = document.createElement('div');
        div.className = 'sub-item';
        div.innerHTML = `
            <div class="sub-info">
                <strong>${sub.name}</strong><br>
                <span style="font-size: 12px; color: var(--text-muted);">Списание: ${sub.day}-го числа каждого месяца</span>
            </div>
            <strong style="font-size: 16px; color: var(--expense);">-${sub.amount} ₸</strong>
            <div class="sub-actions">
                <button type="button" class="pay-btn" onclick="paySub('${sub.id}')"><span class="material-icons" style="font-size:16px;">check</span> Списать</button>
                <button type="button" onclick="deleteSub('${sub.id}')"><span class="material-icons" style="font-size:18px; color:#d32f2f;">delete</span></button>
            </div>
        `;
        subsList.appendChild(div);
    });
}

function saveTx(type) {
    let amountEl = document.getElementById('amount');
    let categoryEl = document.getElementById('category');
    let datetimeEl = document.getElementById('tx-datetime');

    if (!amountEl || !categoryEl || !datetimeEl) return;

    const amount = parseFloat(amountEl.value);
    const category = categoryEl.value.trim();
    const datetime = datetimeEl.value; 
    
    if (!amount || !category || !datetime) {
        alert('Заполните все поля!');
        return;
    }
    
    transactions.push({ id: Date.now().toString(), type, amount, category, date: datetime });
    clearForm();
    updateUI(true);
}

function deleteTx(id) {
    if(confirm("Удалить запись?")) {
        transactions = transactions.filter(t => t.id !== id);
        updateUI(true);
    }
}

function editTx(id) {
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        let editIdEl = document.getElementById('edit-id');
        let dtEl = document.getElementById('tx-datetime');
        let amountEl = document.getElementById('amount');
        let catEl = document.getElementById('category');
        let addBtns = document.getElementById('add-btns');
        let saveEditBtn = document.getElementById('save-edit-btn');

        if (editIdEl) editIdEl.value = tx.id;
        if (dtEl) dtEl.value = (tx.date && tx.date.includes('T')) ? tx.date : (tx.date + 'T00:00');
        if (amountEl) amountEl.value = tx.amount;
        if (catEl) catEl.value = tx.category;
        
        if (addBtns) addBtns.style.display = 'none';
        if (saveEditBtn) saveEditBtn.style.display = 'flex';
        
        let mainWrap = document.querySelector('.main-wrapper');
        if (mainWrap) mainWrap.scrollTo(0, 0);
    }
}

function saveEdit() {
    let editIdEl = document.getElementById('edit-id');
    let amountEl = document.getElementById('amount');
    let categoryEl = document.getElementById('category');
    let datetimeEl = document.getElementById('tx-datetime');

    if (!editIdEl || !amountEl || !categoryEl || !datetimeEl) return;

    const id = editIdEl.value;
    const amount = parseFloat(amountEl.value);
    const category = categoryEl.value.trim();
    const datetime = datetimeEl.value;
    
    if (!amount || !category || !datetime) return;
    
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        tx.amount = amount;
        tx.category = category;
        tx.date = datetime;
    }
    
    clearForm();
    updateUI(true);
}

function clearForm() {
    let amountEl = document.getElementById('amount');
    let categoryEl = document.getElementById('category');
    let editIdEl = document.getElementById('edit-id');
    let addBtns = document.getElementById('add-btns');
    let saveEditBtn = document.getElementById('save-edit-btn');
    let dtEl = document.getElementById('tx-datetime');

    if (amountEl) amountEl.value = '';
    if (categoryEl) categoryEl.value = '';
    if (editIdEl) editIdEl.value = '';
    if (addBtns) addBtns.style.display = 'flex';
    if (saveEditBtn) saveEditBtn.style.display = 'none';
    
    if (dtEl) {
        let now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        dtEl.value = now.toISOString().slice(0,16);
    }
}

function generateReport() {
    let reportSelect = document.getElementById('report-type');
    const tbody = document.getElementById('report-tbody');
    if (!reportSelect || !tbody) return;

    let type = reportSelect.value;
    tbody.innerHTML = '';
    
    let groups = {};
    
    transactions.forEach(tx => {
        if(tx.isSystem) return; 
        let dt = (tx.date && tx.date.includes('T')) ? tx.date : ((tx.date || '') + 'T00:00');
        let key = '';
        
        if (type === 'days') {
            key = dt.split('T')[0];
        } else if (type === 'hours') {
            let parts = dt.split('T');
            let hour = (parts[1] || '00:00').split(':')[0];
            key = `${parts[0]} ${hour}:00`;
        } else if (type === 'weeks') {
            let dateObj = new Date(dt);
            if (isNaN(dateObj)) return;
            let d = new Date(Date.UTC(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate()));
            let dayNum = d.getUTCDay() || 7;
            d.setUTCDate(d.getUTCDate() + 4 - dayNum);
            let yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
            let weekNo = Math.ceil((((d - yearStart) / 86400000) + 1)/7);
            key = `Нед. ${weekNo} (${d.getUTCFullYear()})`;
        }
        
        if(!groups[key]) groups[key] = { inc: 0, exp: 0 };
        if(tx.type === 'income') groups[key].inc += tx.amount;
        else groups[key].exp += tx.amount;
    });
    
    let sortedKeys = Object.keys(groups).sort((a,b) => b.localeCompare(a));
    
    if (sortedKeys.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">Нет данных</td></tr>';
        return;
    }
    
    sortedKeys.forEach(k => {
        let g = groups[k];
        let total = g.inc - g.exp;
        let sign = total > 0 ? '+' : '';
        
        tbody.innerHTML += `<tr>
            <td>${k}</td>
            <td style="color:var(--income)">${g.inc}</td>
            <td style="color:var(--expense)">${g.exp}</td>
            <td style="font-weight:bold;">${sign}${total}</td>
        </tr>`;
    });
}

async function exportExcel() {
    if (typeof ExcelJS === 'undefined') {
        alert('Библиотека выгрузки загружается... Пожалуйста, нажмите еще раз через секунду.');
        let s = document.createElement('script');
        s.src = "https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js";
        document.head.appendChild(s);
        return;
    }
    
    try {
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Записи');
        
        worksheet.columns = [
            { header: 'Дата', key: 'date', width: 15 },
            { header: 'Время', key: 'time', width: 10 },
            { header: 'Тип', key: 'type', width: 15 },
            { header: 'Категория', key: 'category', width: 25 },
            { header: 'Сумма', key: 'amount', width: 15 }
        ];
        
        worksheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
        worksheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF424242' } };
        
        let sortedTx = [...transactions].sort((a,b) => new Date((a.date||'').replace('T', ' ')) - new Date((b.date||'').replace('T', ' ')));
        
        let currentDate = null;
        let dailyTotal = 0;
        
        
        function addTotalRow(total) {
            let totalRow = worksheet.addRow({ date: 'ИТОГО ЗА ДЕНЬ', time: '', type: '', category: '', amount: total });
            totalRow.eachCell((cell) => {
                cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFF00' } };
                cell.font = { color: { argb: 'FF000000' }, bold: true }; // СТРОГО ЧЕРНЫЙ ЦВЕТ
            });
        }
;
                cell.font = { color: { argb: 'FF000000' }, bold: true };
            });
        }

        sortedTx.forEach(t => {
            let dt = (t.date && t.date.includes('T')) ? t.date : ((t.date || '') + 'T00:00');
            let parts = dt.split('T');
            let txDate = parts[0];
            
            if (currentDate !== null && txDate !== currentDate) {
                addTotalRow(dailyTotal);
                dailyTotal = 0;
            }
            
            currentDate = txDate;
            let amount = parseFloat(t.amount) || 0;
            let isIncome = t.type === 'income';
            
            if (isIncome) dailyTotal += amount;
            else dailyTotal -= amount;
            
            let row = worksheet.addRow({
                date: txDate,
                time: parts[1] || '',
                type: isIncome ? 'Доход' : 'Расход',
                category: t.category,
                amount: amount
            });
            
            let rowColor = isIncome ? 'FF2E7D32' : 'FFD32F2F';
            row.eachCell((cell) => {
                cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: rowColor } };
                cell.font = { color: { argb: 'FFFFFFFF' } };
            });
        });
        
        if (currentDate !== null) {
            addTotalRow(dailyTotal);
        }
        
        const buffer = await workbook.xlsx.writeBuffer();
        const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = window.URL.createObjectURL(blob);
        
        // Мобильный фикс: добавляем ссылку прямо в документ перед кликом
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = 'Money_Export.xlsx';
        anchor.style.display = 'none';
        document.body.appendChild(anchor);
        anchor.click();
        
        setTimeout(() => {
            document.body.removeChild(anchor);
            window.URL.revokeObjectURL(url);
        }, 500);
        
    } catch(e) {
        console.error(e);
        alert("Ошибка при выгрузке. Если вы на iPhone, попробуйте 'Скачать для Apple Pages'.");
    }
}

async function exportForPages() { 
    if (typeof ExcelJS === 'undefined') {
        alert('Библиотека выгрузки не загружена. Проверьте интернет или обновите страницу.');
        return;
    }
    await exportExcel(); 
}


function selectGoalIcon(btn) {
    document.querySelectorAll('.icon-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
}

function setPriorityGoal() {
    let nameEl = document.getElementById('goal-name');
    let amountEl = document.getElementById('goal-amount');
    let selBtn = document.querySelector('.icon-btn.selected');

    if (!nameEl || !amountEl) return;

    const name = nameEl.value.trim();
    const amount = parseFloat(amountEl.value);
    const icon = selBtn ? selBtn.getAttribute('data-icon') : '🎯';
    
    if (!name || !amount) {
        alert('Заполните название и сумму цели!');
        return;
    }
    priorityGoal = { name, amount, icon };
    updateUI(true);
    alert('Цель установлена!');
}

function renderGoal() {
    const gd = document.getElementById('current-goal-display');
    if (!gd) return;
    if (priorityGoal.name && priorityGoal.amount > 0) {
        let percent = Math.min(100, (savings / priorityGoal.amount) * 100);
        gd.innerHTML = `
            <h4>${priorityGoal.icon} ${priorityGoal.name}</h4>
            <p>Собрано: ${savings.toFixed(0)} ₸ из ${priorityGoal.amount} ₸ (${percent.toFixed(1)}%)</p>
            <div class="goal-progress">
                <div class="goal-bar" style="width: ${percent}%"></div>
            </div>
        `;
    } else {
        gd.innerHTML = '';
    }
}

function saveSettings() {
    let mLimitEl = document.getElementById('manual-limit');
    manualLimit = mLimitEl ? (parseFloat(mLimitEl.value) || 0) : 0;
    updateUI(true);
    alert('Настройки сохранены!');
}

function saveDataLocally() {
    try {
        localStorage.setItem('finance_tx', JSON.stringify(transactions));
        localStorage.setItem('finance_subs', JSON.stringify(subscriptions));
        localStorage.setItem('finance_savings', savings.toString());
        localStorage.setItem('finance_limit', manualLimit.toString());
        localStorage.setItem('finance_goal', JSON.stringify(priorityGoal));
    } catch(e) {}
}

function exportBackup() {
    const data = { tx: transactions, subs: subscriptions, savings, limit: manualLimit, goal: priorityGoal };
    const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `money_backup.json`;
    link.click();
}

function importBackup(e) {
    const file = e.target.files ? e.target.files[0] : null;
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const data = JSON.parse(event.target.result);
            if(data.tx) transactions = data.tx;
            if(data.subs) subscriptions = data.subs;
            if(data.savings !== undefined) savings = data.savings;
            if(data.limit !== undefined) manualLimit = data.limit;
            if(data.goal) priorityGoal = data.goal;
            updateUI(true); // Автоматически загрузит в облако, если юзер вошел
            alert("Данные успешно загружены!");
        } catch (err) {
            alert("Ошибка чтения файла!");
        }
    };
    reader.readAsText(file);
}

function clearAllData() {
    if(confirm("ВНИМАНИЕ! Это удалит все ваши локальные данные. Продолжить?")) {
        localStorage.clear();
        transactions = [];
        subscriptions = [];
        savings = 0;
        manualLimit = 0;
        priorityGoal = { name: '', amount: 0, icon: '🎯' };
        updateUI(true);
    }
}

function showTab(tabId, btn) {
    document.querySelectorAll('.tab').forEach(t => t.style.display = 'none');
    document.querySelectorAll('.sidebar-nav button, .mobile-nav button').forEach(b => {
        if(b.classList.contains('active')) b.classList.remove('active');
    });
    
    let tabEl = document.getElementById(tabId);
    if (tabEl) tabEl.style.display = 'block';
    
    if (btn) {
        btn.classList.add('active');
    } else {
        document.querySelectorAll(`.sidebar-nav button, .mobile-nav button`).forEach(b => {
            let onclickAttr = b.getAttribute('onclick') || '';
            if (onclickAttr.includes(tabId)) {
                b.classList.add('active');
            }
        });
    }
}

// Отключение pull-to-refresh на мобильных
document.body.addEventListener('touchmove', function(e) {
    if (document.documentElement.scrollTop === 0) {
        // e.preventDefault(); // Не всегда работает надежно, CSS надежнее, но на всякий случай
    }
}, { passive: false });

// ЗАРПЛАТА
function addSalary() {
    let amountEl = document.getElementById('salary-amount');
    let commentEl = document.getElementById('salary-comment');
    if (!amountEl) return;
    
    let amount = parseFloat(amountEl.value);
    let comment = commentEl ? commentEl.value.trim() : '';
    
    if (!amount || amount <= 0) {
        alert('Введите корректную сумму!');
        return;
    }
    
    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    let datetimeNow = now.toISOString().slice(0,16);
    
    let categoryName = comment ? `Зарплата: ${comment}` : 'Зарплата';
    
    transactions.push({
        id: Date.now().toString(),
        type: 'income',
        amount: amount,
        category: categoryName,
        date: datetimeNow,
        isSalary: true // Флаг для сортировки в меню зарплаты
    });
    
    if(amountEl) amountEl.value = '';
    if(commentEl) commentEl.value = '';
    
    updateUI(true);
    alert('Зарплата успешно зачислена!');
}

function renderSalaryList() {
    const sList = document.getElementById('salary-list');
    if (!sList) return;
    sList.innerHTML = '';
    
    let salaryTxs = transactions.filter(t => t.isSalary || t.category.toLowerCase().includes('зарплата'));
    
    if (salaryTxs.length === 0) {
        sList.innerHTML = '<p class="hint" style="text-align:center; padding: 20px;">Зачислений пока нет</p>';
        return;
    }
    
    let sortedTxs = [...salaryTxs].sort((a,b) => new Date((b.date||'').replace('T', ' ')) - new Date((a.date||'').replace('T', ' ')));
    
    let totalSalary = 0;
    
    sortedTxs.forEach(tx => {
        totalSalary += tx.amount;
        let dStr = (tx.date && tx.date.includes('T')) ? tx.date.split('T') : [tx.date, ''];
        
        let div = document.createElement('div');
        div.className = 'sub-item'; // Используем стиль как у подписок для красоты
        div.innerHTML = `
            <div class="sub-info">
                <strong>${tx.category}</strong><br>
                <span style="font-size: 12px; color: var(--text-muted);">${dStr[0]} ${dStr[1]}</span>
            </div>
            <strong style="font-size: 16px; color: var(--income);">+${tx.amount} ₸</strong>
            <div class="sub-actions">
                <button type="button" onclick="deleteTx('${tx.id}')"><span class="material-icons" style="font-size:18px; color:#d32f2f;">delete</span></button>
            </div>
        `;
        sList.appendChild(div);
    });
    
    // Добавляем итог
    let totalDiv = document.createElement('div');
    totalDiv.style.marginTop = '15px';
    totalDiv.style.paddingTop = '10px';
    totalDiv.style.borderTop = '1px dashed #ccc';
    totalDiv.style.textAlign = 'right';
    totalDiv.innerHTML = `<strong>Всего получено: <span style="color:var(--income)">${totalSalary} ₸</span></strong>`;
    sList.appendChild(totalDiv);
}

// Авто-выгрузка статистики каждый день в 23:00
setInterval(() => {
    let now = new Date();
    if (now.getHours() === 23 && now.getMinutes() === 0) {
        let lastAuto = localStorage.getItem('finance_lastAutoExport');
        let today = now.toISOString().split('T')[0];
        
        if (lastAuto !== today) {
            localStorage.setItem('finance_lastAutoExport', today);
            if (transactions.length > 0) {
                exportExcel(); // Триггерим выгрузку Excel
                if (currentUser) autoSyncPush(); // Заодно делаем бекап в облако
            }
        }
    }
}, 30000); // Проверяем каждые 30 секунд

// --- СИСТЕМА ЗАСТАВКИ И ПОГОДЫ ---
function updateSplashClock() {
    let now = new Date();
    let hh = String(now.getHours()).padStart(2, '0');
    let mm = String(now.getMinutes()).padStart(2, '0');
    let timeEl = document.getElementById('splash-time');
    if(timeEl) timeEl.innerText = `${hh}:${mm}`;
    
    const options = { weekday: 'long', month: 'long', day: 'numeric' };
    let dateStr = now.toLocaleDateString('ru-RU', options);
    dateStr = dateStr.charAt(0).toUpperCase() + dateStr.slice(1);
    let dateEl = document.getElementById('splash-date');
    if(dateEl) dateEl.innerText = dateStr;

    let greeting = 'Здравствуйте!';
    let hr = now.getHours();
    if (hr >= 5 && hr < 12) greeting = 'Доброе утро!';
    else if (hr >= 12 && hr < 18) greeting = 'Добрый день!';
    else if (hr >= 18 && hr < 23) greeting = 'Добрый вечер!';
    else greeting = 'Доброй ночи!';
    let greetEl = document.getElementById('splash-greeting');
    if(greetEl) greetEl.innerText = greeting;
}

async function fetchWeather() {
    try {
        let res = await fetch('https://api.open-meteo.com/v1/forecast?latitude=43.2567&longitude=76.9286&current_weather=true', { cache: "no-store" });
        if (!res.ok) throw new Error('API Error');
        let data = await res.json();
        let temp = Math.round(data.current_weather.temperature);
        let weatherEl = document.getElementById('splash-weather');
        if(weatherEl) weatherEl.innerHTML = `<span class="material-icons" style="vertical-align:middle; font-size:18px;">thermostat</span> Алматы: ${temp}°C`;
    } catch(e) {
        let weatherEl = document.getElementById('splash-weather');
        if(weatherEl) weatherEl.innerHTML = `<span class="material-icons" style="vertical-align:middle; font-size:18px;">thermostat</span> Алматы: Погода недоступна (оффлайн)`;
        console.error("Weather error:", e);
    }
}

// Запускаем часы и погоду
setInterval(updateSplashClock, 1000);
updateSplashClock();
setTimeout(fetchWeather, 500);

// --- СИСТЕМА ПИН-КОДА И БИОМЕТРИИ ---
let currentPinInput = "";
let savedPin = localStorage.getItem('finance_pin');
let bioEnabled = localStorage.getItem('finance_bio') === 'true';

function proceedFromSplash() {
    document.getElementById('splash-screen').style.opacity = '0';
    setTimeout(() => {
        document.getElementById('splash-screen').style.display = 'none';
        
        // Если установлен ПИН, показываем экран блокировки
        if (savedPin) {
            document.getElementById('pin-screen').style.display = 'flex';
            if (bioEnabled) {
                document.getElementById('bio-login-btn').style.visibility = 'visible';
                loginWithBiometrics();
            }
        }
    }, 500);
}

function addPinDigit(d) {
    if(currentPinInput.length < 4) {
        currentPinInput += d;
        updatePinDots();
        if(currentPinInput.length === 4) setTimeout(checkPin, 100);
    }
}

function deletePinDigit() {
    currentPinInput = currentPinInput.slice(0, -1);
    updatePinDots();
}

function updatePinDots() {
    let dots = document.querySelectorAll('#pin-dots .dot');
    dots.forEach((dot, i) => {
        dot.classList.toggle('filled', i < currentPinInput.length);
    });
}

function checkPin() {
    if (currentPinInput === savedPin) {
        document.getElementById('pin-screen').style.opacity = '0';
        setTimeout(() => { document.getElementById('pin-screen').style.display = 'none'; }, 400);
    } else {
        alert('Неверный ПИН-код!');
        currentPinInput = "";
        updatePinDots();
    }
}

function savePin() {
    let p = document.getElementById('new-pin').value;
    if(p.length === 4 && /^\d+$/.test(p)) {
        localStorage.setItem('finance_pin', p);
        savedPin = p;
        alert('ПИН-код успешно установлен!');
        document.getElementById('remove-pin-btn').style.display = 'inline-flex';
        document.getElementById('new-pin').value = '';
    } else {
        alert('ПИН-код должен состоять ровно из 4 цифр!');
    }
}

function removePin() {
    if(confirm('Вы уверены, что хотите удалить ПИН-код и защиту входа?')) {
        localStorage.removeItem('finance_pin');
        localStorage.removeItem('finance_bio');
        savedPin = null;
        bioEnabled = false;
        alert('Защита удалена!');
        document.getElementById('remove-pin-btn').style.display = 'none';
    }
}

// Биометрия (Отпечаток пальца / FaceID) через WebAuthn API
async function registerBiometrics() {
    if (!window.PublicKeyCredential) {
        alert('Ваше устройство или браузер не поддерживает вход по отпечатку.');
        return;
    }
    if (!savedPin) {
        alert('Сначала установите цифровой ПИН-код!');
        return;
    }
    try {
        const challenge = new Uint8Array(32);
        window.crypto.getRandomValues(challenge);
        const userId = new Uint8Array(16);
        window.crypto.getRandomValues(userId);
        
        const publicKey = {
            challenge: challenge,
            rp: { name: "Money Pro App" },
            user: { id: userId, name: "user@moneypro", displayName: "User" },
            pubKeyCredParams: [{ type: "public-key", alg: -7 }, { type: "public-key", alg: -257 }],
            authenticatorSelection: { authenticatorAttachment: "platform", userVerification: "required" },
            timeout: 60000
        };
        
        const credential = await navigator.credentials.create({ publicKey });
        if (credential) {
            localStorage.setItem('finance_bio', 'true');
            bioEnabled = true;
            alert('Биометрия успешно привязана!');
        }
    } catch (e) {
        console.error(e);
        alert('Ошибка настройки отпечатка. Возможно устройство не поддерживает данную функцию или запрос был отменен.');
    }
}

async function loginWithBiometrics() {
    try {
        const challenge = new Uint8Array(32);
        window.crypto.getRandomValues(challenge);
        
        const publicKey = {
            challenge: challenge,
            timeout: 60000,
            userVerification: "required"
        };
        
        const credential = await navigator.credentials.get({ publicKey });
        if (credential) {
            // Успешный вход
            document.getElementById('pin-screen').style.opacity = '0';
            setTimeout(() => { document.getElementById('pin-screen').style.display = 'none'; }, 400);
        }
    } catch(e) {
        console.log("Биометрия отменена или не удалась", e);
    }
}

// --- СИСТЕМА ОФОРМЛЕНИЯ И ТЕМ ---
function setFullTheme(themeName) {
    document.body.className = ''; 
    if (themeName !== 'light') {
        document.body.classList.add(`theme-${themeName}`);
    }
    localStorage.setItem('finance_full_theme', themeName);
}

function setFont(fontStr) {
    document.documentElement.style.setProperty('--font-family', fontStr);
    localStorage.setItem('finance_font', fontStr);
}

function setTextColor(colorHex) {
    document.documentElement.style.setProperty('--text-main', colorHex);
    localStorage.setItem('finance_text_color', colorHex);
}

// Подгрузка настроек темы и ПИНа при запуске
window.addEventListener('DOMContentLoaded', () => {
    if(localStorage.getItem('finance_pin')) {
        let btn = document.getElementById('remove-pin-btn');
        if(btn) btn.style.display = 'inline-flex';
    }
    
    let savedFull = localStorage.getItem('finance_full_theme');
    if(savedFull) setFullTheme(savedFull);
    
    let savedFont = localStorage.getItem('finance_font');
    if(savedFont) { 
        document.documentElement.style.setProperty('--font-family', savedFont);
        let appF = document.getElementById('app-font');
        if(appF) appF.value = savedFont;
    }
    
    let savedColor = localStorage.getItem('finance_text_color');
    if(savedColor) {
        document.documentElement.style.setProperty('--text-main', savedColor);
        let cPick = document.getElementById('app-text-color');
        if(cPick) cPick.value = savedColor;
    }

    // Авто-пропуск заставки на ПК
    if (window.innerWidth >= 769) {
        let splash = document.getElementById('splash-screen');
        if (splash) splash.style.display = 'none';
        
        if (savedPin) {
            let pinScreen = document.getElementById('pin-screen');
            if (pinScreen) pinScreen.style.display = 'flex';
            if (bioEnabled) {
                let bioBtn = document.getElementById('bio-login-btn');
                if (bioBtn) bioBtn.style.visibility = 'visible';
                if (typeof loginWithBiometrics === 'function') loginWithBiometrics();
            }
        }
    }
});

// SLIDE TO UNLOCK LOGIC
function initSlider() {
    const thumb = document.getElementById('slider-thumb');
    const container = document.getElementById('slider-container');
    if(!thumb || !container) return;

    let isDragging = false;
    let startX = 0;
    let currentX = 0;
    let maxDrag = 0;

    function updateMaxDrag() {
        maxDrag = container.offsetWidth - thumb.offsetWidth - 8;
    }

    function onStart(e) {
        isDragging = true;
        startX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
        thumb.style.transition = 'none';
        updateMaxDrag();
    }

    function onMove(e) {
        if (!isDragging) return;
        if (e.type.includes('touch')) {
            // Prevent vertical scrolling while swiping
            if(e.cancelable) e.preventDefault();
        }
        let clientX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
        let dx = clientX - startX;
        currentX = Math.max(0, Math.min(dx, maxDrag));
        thumb.style.transform = `translateX(${currentX}px)`;
    }

    
    function onEnd(e) {
        if (!isDragging) return;
        isDragging = false;
        if (currentX >= maxDrag * 0.90) {
            thumb.style.transform = `translateX(${maxDrag}px)`;
            setTimeout(() => {
                proceedFromSplash();
                // Reset slider after unlocking
                setTimeout(() => {
                    thumb.style.transition = 'none';
                    thumb.style.transform = 'translateX(0px)';
                    currentX = 0;
                }, 1000);
            }, 150);
        } else {
            thumb.style.transition = 'transform 0.3s ease';
            thumb.style.transform = `translateX(0px)`;
            currentX = 0;
        }
    }

    

    thumb.addEventListener('mousedown', onStart);

    document.addEventListener('mousemove', onMove, {passive: false});
    document.addEventListener('mouseup', onEnd);

    thumb.addEventListener('touchstart', onStart, {passive: true});
    document.addEventListener('touchmove', onMove, {passive: false});
    document.addEventListener('touchend', onEnd);
    window.addEventListener('resize', updateMaxDrag);
}

// --- СИСТЕМА АВТОЗАПОЛНЕНИЯ КАТЕГОРИЙ ---
const categoryOptions = [
    "Паковка Вб",
    "Паковка Озон",
    "Паковка Каспи",
    "Доставка",
    "Смена",
    "Инвентаризация",
    "Еда",
    "Магазин",
    "Тэму",
    "Подписка",
    "Другое"
];

function showCategories() {
    filterCategories(); 
    let drop = document.getElementById('category-dropdown');
    if(drop) drop.style.display = 'block';
}

function hideCategories() {
    setTimeout(() => {
        let drop = document.getElementById('category-dropdown');
        if (drop) drop.style.display = 'none';
    }, 200); 
}

function filterCategories() {
    let catInput = document.getElementById('category');
    let drop = document.getElementById('category-dropdown');
    if (!catInput || !drop) return;
    
    let input = catInput.value.toLowerCase();
    drop.innerHTML = '';
    
    let filtered = categoryOptions.filter(c => c.toLowerCase().includes(input));
    
    if (filtered.length === 0) {
        drop.style.display = 'none';
        return;
    }
    
    filtered.forEach(c => {
        let div = document.createElement('div');
        div.className = 'dropdown-item';
        div.innerText = c;
        div.onclick = function() {
            catInput.value = c;
            drop.style.display = 'none';
        };
        drop.appendChild(div);
    });
    drop.style.display = 'block';
}
