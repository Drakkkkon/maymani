// --- МЕНЮ НАСТРОЕК И СТРАНИЦЫ ---
// С 4.23.0 в приложении только страницы: в каждом разделе на экране одна страница (вкладки сверху, а если их много — список).
// «Настройки» — список пунктов. Темы «Windows 95_Экстра» показывают разделы в своих окнах (js/desk95*.js).

(function () {
    'use strict';

    const root = document.documentElement;
    const isDesk = () => root.getAttribute('data-w95') === 'desk95';
    const tt = (s) => (typeof tr === 'function' ? tr(s) : s);
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const sound = (n) => { try { if (typeof playSound === 'function') playSound(n); } catch (e) {} };

    // Режимы. smActive — меню Настроек, pagesActive — «страницы вместо блоков» (обе — только вне «Windows 95_Пуск»)
    const smActive = () => !isDesk();
    window.pagesActive = () => !isDesk();
    const MAX_CHIPS = 5; // до этого числа блоков — вкладки, больше — список-меню

    // Группы пунктов меню Настроек. Карточка попадает в группу по своему id или по названию значка в заголовке (он не переводится)
    const SM_GROUPS = [
        // 4.15.0: «Помощь» — самый верхний пункт (js/help.js)
        { name: 'Помощь', keys: ['help-card'] },
        { name: 'Аккаунт и данные', keys: ['account-section', 'profile-section', 'lock', 'speed', 'save'] },
        // 4.14.0: «Категории» — одно меню вместо «Картинки категорий», «Картинки в истории операций» и «Мои категории»;
        // «Шрифты» и «Иконка приложения» — внутри «Тем оформления»; «Блок „Текущий баланс“» убран; новый «Экран приветствия»
        { name: 'Записи', keys: ['categories-card'] },
        { name: 'Оформление и вид', keys: ['palette', 'theme-card', 'home-card', 'desk-wall-card', 'layout-settings-card', 'menu_open'] },
        { name: 'Ввод, звук и уведомления', keys: ['voice-card', 'volume_up', 'notify-card'] },
        { name: 'Приложение', keys: ['apk-card', 'history'] }
    ];

    const sel = {};      // раздел → id выбранной вкладки (для вкладок) — запоминается, пока открыта программа
    let pushedKey = null; // «раздел:карточка» — для кнопки «Назад» телефона

    // ---------- вспомогательное ----------
    function tabById(id) { return document.getElementById(id); }
    function contentTabs() { return [...document.querySelectorAll('main > .tab')].filter(t => t.id !== 'wall'); }

    function cardInfo(card) {
        const h = card.querySelector(':scope > h3');
        let icon = '', title = '';
        if (h) {
            const c = h.cloneNode(true);
            c.querySelectorAll('.w95-ctls, .wall-tools').forEach(n => n.remove());
            const ic = c.querySelector('.material-icons');
            if (ic) { icon = ic.textContent.trim(); ic.remove(); }
            title = c.textContent.replace(/\s+/g, ' ').trim();
        }
        return { id: card.id, icon: icon || 'chevron_right', title: title || card.id };
    }

    // Карточки раздела, которые сейчас вообще показываются (скрытые админские, обои вне рабочего стола и т. п. — нет).
    // Меряем при снятом data-pg: иначе наши же правила скрыли бы все карточки.
    function availableCards(tab) {
        const had = tab.getAttribute('data-pg');
        if (had !== null) tab.removeAttribute('data-pg');
        const list = [...tab.querySelectorAll('.card')].filter(c =>
            !c.parentElement.closest('.card') && !c.classList.contains('on-wall') && !c.classList.contains('wall-info') &&
            getComputedStyle(c).display !== 'none');
        if (had !== null) tab.setAttribute('data-pg', had);
        return list;
    }

    function kindOf(tab, count) {
        if (tab.id === 'settings') return smActive() ? 'menu' : null;
        if (!window.pagesActive() || count < 2) return null;
        // «Статистика» с главным графиком — одна страница (js/experimental.js)
        if (tab.id === 'statistics' && root.classList.contains('exp-stats')) return null;
        return count > MAX_CHIPS ? 'menu' : 'chips';
    }

    function groupIndex(card, info) {
        const i = SM_GROUPS.findIndex(g => g.keys.includes(card.id) || g.keys.includes(info.icon));
        return i < 0 ? SM_GROUPS.length : i;
    }

    // Пояснение под названием пункта (текущее значение) — только там, где оно есть и коротко
    function subtitleFor(tab, card, info) {
        if (tab.id !== 'settings') return '';
        const val = (id) => { const el = document.getElementById(id); return el ? (el.value || el.textContent || '').trim() : ''; };
        try {
            if (card.id === 'account-section') {
                const inn = document.getElementById('acct-logged-in');
                return inn && inn.style.display !== 'none' ? val('acct-who') : tt('Вход не выполнен');
            }
            if (card.id === 'profile-section') return val('profile-name');
            if (info.icon === 'palette' && typeof resolveTheme === 'function') return resolveTheme(currentThemeId).name || '';
            if (card.id === 'categories-card' && typeof customCategories !== 'undefined') {
                const tops = typeof catTops === 'function' ? catTops().length : 0;
                const subs = customCategories.length - tops;
                return tops ? `${tops} ${tt('разд.')}${subs > 0 ? ` · ${subs} ${tt('подкат.')}` : ''}` : tt('Пока нет');
            }
            if (info.icon === 'speed') { const v = Number(val('manual-limit')); return v > 0 ? Math.round(v).toLocaleString('ru-RU') + ' ₸' : tt('Не установлен'); }
        } catch (e) {}
        return '';
    }

    // ---------- построение ----------
    function buildMenu(tab, cards) {
        const infos = cards.map(c => ({ card: c, info: cardInfo(c) }));
        let groups;
        if (tab.id === 'settings') {
            groups = SM_GROUPS.map(g => ({ name: g.name, items: [] })).concat([{ name: 'Другое', items: [] }]);
            infos.forEach(x => groups[groupIndex(x.card, x.info)].items.push(x));
            groups = groups.filter(g => g.items.length);
            if (groups.length === 1) groups[0].name = '';
        } else {
            groups = [{ name: '', items: infos }];
        }
        const rows = groups.map(g => `<section class="pg-group">${g.name ? `<h4 class="pg-group-title">${esc(tt(g.name))}</h4>` : ''}<ul class="pg-rows">` +
            g.items.map(({ card, info }) => {
                const sub = subtitleFor(tab, card, info);
                return `<li><div role="button" tabindex="0" class="pg-row" data-card="${esc(card.id)}">` +
                    `<span class="pg-ico"><span class="material-icons">${esc(info.icon)}</span></span>` +
                    `<span class="pg-txt"><b>${esc(info.title)}</b>${sub ? `<small data-i18n-skip>${esc(sub)}</small>` : ''}</span>` +
                    `<span class="pg-chev material-icons" aria-hidden="true">chevron_right</span></div></li>`;
            }).join('') + '</ul></section>').join('');
        const label = (typeof MENU_ITEMS !== 'undefined' && (MENU_ITEMS.find(i => i.id === tab.id) || {}).label) || '';
        return `<div class="pg-list">${rows}</div>` +
            `<div class="pg-bar"><div role="button" tabindex="0" class="pg-back" aria-label="${esc(tt('Назад'))}"><span class="material-icons" aria-hidden="true">arrow_back</span><span class="pg-back-text">${esc(label)}</span></div>` +
            `<span class="pg-bar-title"><span class="pg-bar-ico material-icons" aria-hidden="true"></span><b></b></span></div>`;
    }

    function buildChips(cards, current) {
        return '<div class="pg-bar pg-chips" role="tablist" data-no-swipe>' + cards.map(c => {
            const i = cardInfo(c);
            return `<div role="tab" tabindex="0" class="pg-chip" data-card="${esc(c.id)}" aria-selected="${c.id === current}">` +
                `<span class="material-icons" aria-hidden="true">${esc(i.icon)}</span><span class="pg-chip-text">${esc(i.title)}</span></div>`;
        }).join('') + '</div>';
    }

    function teardown(tab) {
        tab.removeAttribute('data-pg');
        tab.removeAttribute('data-pg-view');
        tab.classList.remove('pg-on');
        tab._pgSig = null;
        tab.style.removeProperty('--pg-w');
        const r = tab.querySelector(':scope > .pg-root');
        if (r) r.remove();
        tab.querySelectorAll('.card.pg-active').forEach(c => c.classList.remove('pg-active'));
    }

    // Показать нужное: список / страница; у нужной карточки — pg-active, в панели — её название
    function syncView(tab) {
        const kind = tab.getAttribute('data-pg');
        if (!kind) return;
        const open = tab._pgOpen && tabById(tab._pgOpen) ? tab._pgOpen : null;
        const showId = kind === 'chips' ? (sel[tab.id] || null) : open;
        tab.querySelectorAll('.card').forEach(c => c.classList.toggle('pg-active', !!showId && c.id === showId));
        tab.setAttribute('data-pg-view', kind === 'menu' && !showId ? 'list' : 'page');
        const r = tab.querySelector(':scope > .pg-root');
        if (!r) return;
        if (kind === 'chips') {
            r.querySelectorAll('.pg-chip').forEach(b => b.setAttribute('aria-selected', String(b.dataset.card === showId)));
        } else if (showId && tabById(showId)) {
            const i = cardInfo(tabById(showId));
            const t = r.querySelector('.pg-bar-title');
            if (t) { t.querySelector('b').textContent = i.title; t.querySelector('.pg-bar-ico').textContent = i.icon; }
        }
    }

    function render(tab, { resetView = false } = {}) {
        if (!tab) return;
        const cards = (smActive() || window.pagesActive()) ? availableCards(tab) : [];
        const kind = kindOf(tab, cards.length);
        if (!kind) { if (tab.hasAttribute('data-pg') || tab.querySelector(':scope > .pg-root')) teardown(tab); return; }
        const sig = kind + '|' + cards.map(c => { const i = cardInfo(c); return c.id + ':' + i.title + ':' + (kind === 'menu' ? subtitleFor(tab, c, i) : ''); }).join(',');
        if (tab._pgSig !== sig || !tab.querySelector(':scope > .pg-root')) {
            const old = tab.querySelector(':scope > .pg-root');
            if (old) old.remove();
            if (kind === 'chips' && !cards.some(c => c.id === sel[tab.id])) {
                const forms = cards.find(c => c.classList.contains('forms'));
                sel[tab.id] = (forms || cards[0]).id;
            }
            const box = document.createElement('div');
            box.className = 'pg-root';
            box.dataset.kind = kind;
            box.innerHTML = kind === 'menu' ? buildMenu(tab, cards) : buildChips(cards, sel[tab.id]);
            tab.insertBefore(box, tab.firstChild);
            tab._pgSig = sig;
        }
        tab.setAttribute('data-pg', kind);
        tab.classList.add('pg-on');
        if (resetView && kind === 'menu') closePage(tab, { silent: true });
        if (kind === 'menu' && tab._pgOpen && !cards.some(c => c.id === tab._pgOpen)) tab._pgOpen = null;
        syncView(tab);
    }

    function renderAll(opts) {
        const tabs = [...document.querySelectorAll('main > .tab')];
        tabs.forEach(t => { if (t.id !== 'wall') render(t, opts); });
    }

    // ---------- переходы ----------
    function openPage(tab, cardId, { fromHistory = false } = {}) {
        const kind = tab.getAttribute('data-pg');
        if (!kind) return;
        if (kind === 'chips') {
            if (sel[tab.id] === cardId) return;
            sel[tab.id] = cardId;
            sound('click');
        } else {
            tab._pgOpen = cardId;
            sound('open');
            if (!fromHistory) {
                try { history.pushState({ pg: tab.id + ':' + cardId }, ''); pushedKey = tab.id + ':' + cardId; } catch (e) { pushedKey = null; }
            }
        }
        syncView(tab);
        const mw = document.querySelector('.main-wrapper');
        if (mw) mw.scrollTop = 0;
        // диаграммам и спискам нужен видимый холст
        setTimeout(() => { try { window.dispatchEvent(new Event('resize')); } catch (e) {} }, 30);
    }

    function closePage(tab, { silent = false, viaHistory = false } = {}) {
        if (!tab || !tab._pgOpen) return;
        tab._pgOpen = null;
        if (!silent) sound('close');
        if (pushedKey && pushedKey.indexOf(tab.id + ':') === 0) {
            const k = pushedKey;
            pushedKey = null;
            if (!viaHistory) { try { history.back(); } catch (e) {} }
            void k;
        }
        syncView(tab);
        if (!viaHistory) render(tab); // обновить пояснения в списке (например, выбранный язык)
        const mw = document.querySelector('.main-wrapper');
        if (mw) mw.scrollTop = 0;
    }

    // Ссылка из подсказки блока на страницу настройки («Настройки → Распознавание фото»)
    window.openSettingsCard = function (cardId) {
        // 4.15.0: переход с одного пункта Настроек на другой (например, из «Помощи» в «Категории») — сразу, без «Назад»:
        // раньше showTab закрывал открытую страницу через history.back(), и запоздавшее событие «Назад» закрывало новую
        const cur = tabById('settings');
        if (cur && cur._pgOpen && cur.style.display !== 'none' && cur.getAttribute('data-pg') === 'menu' && document.getElementById(cardId)) {
            if (cur._pgOpen === cardId) return;
            cur._pgOpen = cardId;
            try { if (pushedKey) { history.replaceState({ pg: 'settings:' + cardId }, ''); pushedKey = 'settings:' + cardId; } } catch (e) {}
            sound('open');
            syncView(cur);
            const mw = document.querySelector('.main-wrapper');
            if (mw) mw.scrollTop = 0;
            try { window.scrollTo(0, 0); } catch (e) {}
            return;
        }
        showTab('settings');
        const tab = tabById('settings');
        const card = document.getElementById(cardId);
        if (tab && card && tab.getAttribute('data-pg') === 'menu') { openPage(tab, cardId); return; }
        if (card) {
            setTimeout(() => { try { card.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) {} }, 60);
        }
    };


    // нажатия в списке, на вкладках и «Назад»
    document.addEventListener('click', (e) => {
        const root0 = e.target.closest && e.target.closest('.pg-root');
        if (!root0) return;
        const tab = root0.closest('.tab');
        if (!tab) return;
        const back = e.target.closest('.pg-back');
        if (back) { closePage(tab); return; }
        const b = e.target.closest('.pg-row, .pg-chip');
        if (b && b.dataset.card) openPage(tab, b.dataset.card);
    });

    // с клавиатуры: Enter и пробел нажимают строку, вкладку и «Назад»; стрелки ←/→ переключают вкладки
    document.addEventListener('keydown', (e) => {
        const el = e.target && e.target.closest && e.target.closest('.pg-row, .pg-chip, .pg-back');
        if (!el) return;
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); return; }
        if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && el.classList.contains('pg-chip')) {
            const all = [...el.parentElement.querySelectorAll('.pg-chip')];
            const n = all[all.indexOf(el) + (e.key === 'ArrowRight' ? 1 : -1)];
            if (n) { e.preventDefault(); n.click(); n.focus(); }
        }
    });

    // кнопка «Назад» телефона и браузера
    window.addEventListener('popstate', () => {
        pushedKey = null;
        document.querySelectorAll('main > .tab[data-pg="menu"]').forEach(t => { if (t._pgOpen) closePage(t, { silent: false, viaHistory: true }); });
    });

    // ---------- режимы и атрибуты ----------
    function syncModes() {
        root.setAttribute('data-sm', smActive() ? 'on' : 'off');
        root.setAttribute('data-pages', window.pagesActive() ? 'on' : 'off');
    }

    let lastSm = null;
    function onModesChanged() {
        syncModes();
        if (lastSm !== smActive()) {
            try { if (typeof enhanceCards === 'function') enhanceCards(); } catch (e) {}
            try { if (typeof renderMenus === 'function') renderMenus(); } catch (e) {}
        }
        lastSm = smActive();
        renderAll();
    }

    // Из showTab (js/script.js): показывается раздел — отметка на <html> и свежий список страниц
    window.pagesOnTabShown = function (tabId) {
        root.setAttribute('data-tab', tabId);
        // из раздела ушли, не закрыв страницу: закрываем сразу (и убираем лишнюю запись истории для кнопки «Назад»)
        document.querySelectorAll('main > .tab[data-pg="menu"]').forEach(t => { if (t.id !== tabId && t._pgOpen) closePage(t, { silent: true }); });
        const tab = tabById(tabId);
        if (tab && tabId !== 'wall') render(tab, { resetView: true });
    };

    // Следим за разделами: карточки добавляются и убираются (котировки, админские блоки в Настройках)
    let watchTimer = null;
    const watcher = new MutationObserver(() => {
        clearTimeout(watchTimer);
        watchTimer = setTimeout(() => renderAll(), 90);
    });
    function watch() {
        document.querySelectorAll('main > .tab').forEach(t => {
            if (t.id === 'wall' || t._pgWatched) return;
            t._pgWatched = true;
            watcher.observe(t, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden'] });
        });
    }

    window.addEventListener('w95-theme', () => setTimeout(onModesChanged, 0));
    window.addEventListener('app-layout', () => setTimeout(onModesChanged, 0));
    window.addEventListener('app-lang', () => setTimeout(() => { try { if (typeof renderMenus === 'function') renderMenus(); } catch (e) {} renderAll(); }, 60));
    window.addEventListener('DOMContentLoaded', () => {
        root.setAttribute('data-tab', (typeof currentTabId !== 'undefined' && currentTabId) || 'transactions');
        watch();
        setTimeout(onModesChanged, 0);
    });
    window.addEventListener('load', () => { watch(); onModesChanged(); });
})();
