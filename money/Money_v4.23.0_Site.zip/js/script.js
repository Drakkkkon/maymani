// Облако (вход через Google, данные на Google Диске, перенос из старого Firebase-аккаунта) — js/cloud.js.

// Заглушки на случай, если какой-то из файлов js/*.js не загрузился (нет сети, старая копия страницы):
// приложение должно запуститься в любом случае, просто без этой части.
['playSound', 'playStartupChime', 'renderSoundSettings', 'applySavedTheme',
    'openSoundPicker', 'initW95Scrollbars', 'renderAllQuotes',
    'renderAllIconSettings', 'renderCategoryTiles', 'enhanceCards', 'renderSoundLibrary',
    'renderBank', 'renderNotifySettings', 'openSubReminders', ]
    .forEach(name => { if (typeof window[name] !== 'function') window[name] = function () {}; });
if (typeof window.historyCategoryHtml !== 'function') window.historyCategoryHtml = name => `<strong>${escapeHtml(name || 'Без категории')}</strong>`;
if (typeof window.getFormComment !== 'function') window.getFormComment = function () { return ''; };
if (typeof window.setFormComment !== 'function') window.setFormComment = function () {};

// Выполняет шаг запуска; ошибка в одном шаге не останавливает остальные (слайдер, вход, меню)
function safeStep(name, fn) {
    try {
        fn();
    } catch (e) {
        console.error('Ошибка при запуске (' + name + '):', e);
    }
}

let transactions = [];
let subscriptions = [];
let priorityGoal = { name: '', amount: 0, icon: '🎯' };
let manualLimit = 0;
let savings = 0;
let profileName = '';
// Прежние данные Oldbook: раздел вынесен в отдельное приложение (Oldbook95). Здесь они только хранятся как есть
// (браузер + файл на Google Диске), чтобы ничего не пропало; ни в одном разделе не показываются.
let legacyObEntries = [];  // finance_oldbook
let legacyObLinks = [];    // finance_ob_links
let customCategories = []; // свои категории пользователя: [{ id, name }]
let myChart = null;
// Прежние цели (раздел убран в 4.22.0): только хранятся и синхронизируются, чтобы ничего не пропало
let goalsList = [];
try { goalsList = JSON.parse(localStorage.getItem('finance_goals') || '[]') || []; } catch (e) {}
if (!Array.isArray(goalsList)) goalsList = [];
function saveGoalsLocal() { try { localStorage.setItem('finance_goals', JSON.stringify(goalsList)); } catch (e) {} }

window.onload = function() {
    // Слайдер разблокировки — первым: заставка не должна «зависнуть», даже если что-то ниже сломается
    safeStep('данные', loadData);
    safeStep('перенос лимита', checkDailyRollover);

    let dtInput = document.getElementById('tx-datetime');
    if (dtInput) dtInput.value = almatyIsoNow();

    safeStep('диаграммы', () => {
        if (typeof Chart === 'undefined') return;
        // Диаграммы в стиле Windows 95: без скруглений; цвета текста и сетки задаёт тема (js/themes.js)
        Chart.defaults.font.family = "Tahoma, 'MS Sans Serif', 'Segoe UI', sans-serif";
        Chart.defaults.animation.duration = 400; // все анимации приложения не дольше 0.5 с
    });
    safeStep('тема', applySavedTheme);
    safeStep('интерфейс', () => updateUI(false));
    safeStep('полосы прокрутки', initW95Scrollbars);
    safeStep('облако', initCloud);
    safeStep('аккаунт', initAccount);
    safeStep('помощь', initHelp); // 4.15.0: «Помощь», подсказки при первом нажатии, окно «Что нового»
    safeStep('офлайн-режим', registerServiceWorker);
};

// --- ПРОФИЛЬ ---
function fillProfileInput() {
    const input = document.getElementById('profile-name');
    if (input && document.activeElement !== input) input.value = profileName;
}

function saveProfileName() {
    const input = document.getElementById('profile-name');
    const value = input ? input.value.replace(/\s+/g, ' ').trim().slice(0, 40) : '';
    profileName = value;
    updateUI(true);
    fillProfileInput();
    alert(value
        ? `Имя «${value}» сохранено.` + (isCloudConnected() ? ' Оно сохранится и в вашем аккаунте My Money.' : ' Войдите в аккаунт My Money, чтобы оно сохранилось в аккаунте.')
        : 'Имя удалено.');
}

// Имя файла выгрузки: дата_время_имя (время Алматы), например 2026-11-01_14-30_Айдар.xlsx
function exportFileName(ext, suffix = '') {
    const [date, time] = almatyIsoNow().split('T');
    const name = String(profileName || 'MyMoney').replace(/[\\/:*?"<>|]+/g, '').trim().replace(/\s+/g, '_').replace(/[._]+$/, '') || 'MyMoney';
    return `${date}_${time.replace(':', '-')}_${name}${suffix}.${ext}`;
}

// --- ОФЛАЙН-РЕЖИМ И АВТООБНОВЛЕНИЕ САЙТА ---
// sw.js отдаёт свежие файлы сайта из сети, а без интернета — из кэша. Новая версия подхватывается при открытии.
function registerServiceWorker() {
    if (!('serviceWorker' in navigator) || !window.isSecureContext || location.protocol === 'file:') return;
    // Когда новая версия сайта взяла управление — один раз перезагружаем страницу, чтобы не смешивать версии
    const hadController = !!navigator.serviceWorker.controller;
    let reloaded = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (!hadController || reloaded) return;
        reloaded = true;
        location.reload();
    });
    navigator.serviceWorker.register('sw.js', { updateViaCache: 'none' })
        .then(reg => {
            document.addEventListener('visibilitychange', () => {
                if (document.visibilityState === 'visible') reg.update().catch(() => {});
            });
        })
        .catch(e => console.warn('Service worker не зарегистрирован', e));
}

// Кнопка «Обновить сайт сейчас» (Настройки → История версий): убирает старую копию сайта (service worker и кэш)
// и заново скачивает файлы. Записи, настройки и ключи (localStorage) не трогаются.
async function forceSiteUpdate() {
    const btn = document.querySelector('.app-version-row button');
    if (btn) btn.disabled = true;
    try {
        if ('serviceWorker' in navigator) {
            const regs = await navigator.serviceWorker.getRegistrations();
            await Promise.all(regs.map(r => r.unregister()));
        }
    } catch (e) {}
    try {
        if (window.caches) {
            const keys = await caches.keys();
            await Promise.all(keys.map(k => caches.delete(k)));
        }
    } catch (e) {}
    try {
        // обновляем и обычный кэш браузера: без этого телефон мог бы снова взять старые файлы
        const urls = ['index.html'].concat([...document.querySelectorAll('script[src], link[rel="stylesheet"][href]')]
            .map(e => e.getAttribute('src') || e.getAttribute('href'))
            .filter(u => u && !/^(https?:)?\/\//.test(u)));
        await Promise.all(urls.map(u => fetch(u, { cache: 'reload' }).catch(() => null)));
    } catch (e) {}
    location.href = location.pathname + '?v=' + Date.now();
}

// --- ОСТАЛЬНАЯ ЛОГИКА ---
function loadData() {
    try {
        if (localStorage.getItem('finance_tx')) transactions = JSON.parse(localStorage.getItem('finance_tx'));
        if (localStorage.getItem('finance_subs')) subscriptions = JSON.parse(localStorage.getItem('finance_subs'));
        if (localStorage.getItem('finance_goal')) priorityGoal = JSON.parse(localStorage.getItem('finance_goal'));
        if (localStorage.getItem('finance_limit')) manualLimit = parseFloat(localStorage.getItem('finance_limit')) || 0;
        if (localStorage.getItem('finance_savings')) savings = parseFloat(localStorage.getItem('finance_savings')) || 0;
        profileName = localStorage.getItem('finance_profile_name') || '';
        if (localStorage.getItem('finance_oldbook')) legacyObEntries = JSON.parse(localStorage.getItem('finance_oldbook')) || [];
        if (localStorage.getItem('finance_ob_links')) legacyObLinks = JSON.parse(localStorage.getItem('finance_ob_links')) || [];
        if (localStorage.getItem('finance_categories')) customCategories = JSON.parse(localStorage.getItem('finance_categories')) || [];
    } catch(e) {
        console.error("Error loading local storage:", e);
    }
    initSyncBaseline();
    fillProfileInput();

    // Оформление одно (Windows 95, css/win95.css): прежние темы, фон шапки, шрифт и цвет текста больше не применяются
    ['finance_theme', 'finance_bg', 'finance_full_theme', 'finance_font', 'finance_text_color'].forEach(k => localStorage.removeItem(k));

    let mLimit = document.getElementById('manual-limit');
    if (mLimit) mLimit.value = manualLimit > 0 ? manualLimit : '';
}

function getTxDateStr(datetimeStr) {
    if (!datetimeStr) return '';
    return datetimeStr.includes('T') ? datetimeStr.split('T')[0] : datetimeStr;
}

function checkDailyRollover() {
    const today = almatyIsoNow().split('T')[0];
    let lastDate = localStorage.getItem('finance_lastDate');
    
    if (!lastDate) {
        localStorage.setItem('finance_lastDate', today);
        return;
    }
    
    if (lastDate !== today) {
        localStorage.setItem('finance_lastDate', today);
    }
}

function updateUI(pushToCloud = false) {
    saveDataLocally();

    renderTransactions();
    renderSubscriptions();
        generateReport();
    renderStatistics();
    renderCategorySettings();
    renderAllIconSettings();
    renderSoundLibrary();

    // Если флаг pushToCloud true, изменения отправляются в аккаунт (с небольшой задержкой, пачкой)
    if (pushToCloud) scheduleCloudSync();
}

function renderStatistics() {
    let todayStr = almatyIsoNow().split('T')[0];
    
    let spentToday = transactions
        .filter(t => getTxDateStr(t.date) === todayStr && t.type === 'expense' && !t.isSystem)
        .reduce((sum, t) => sum + t.amount, 0);
        
    let elTodaySpent = document.getElementById('today-spent');
    if (elTodaySpent) elTodaySpent.innerText = `${spentToday} ₸`;
    
    renderStatsKpi(todayStr);
    if (typeof Chart === 'undefined') return;

    let dates = [];
    for(let i=6; i>=0; i--) {
        dates.push(almatyIsoNow(-i).split('T')[0]);
    }

    let incomeData = dates.map(d => {
        return transactions.filter(t => getTxDateStr(t.date) === d && t.type === 'income' && !t.isSystem)
                           .reduce((sum, t) => sum + t.amount, 0);
    });
    let expenseData = dates.map(d => {
        return transactions.filter(t => getTxDateStr(t.date) === d && t.type === 'expense' && !t.isSystem)
                           .reduce((sum, t) => sum + t.amount, 0);
    });

    let displayDates = dates.map(shortDate);

    const ctx = document.getElementById('mainChart');
    if (ctx) {
        if (myChart) {
            myChart.data.labels = displayDates;
            myChart.data.datasets[0].data = incomeData;
            myChart.data.datasets[1].data = expenseData;
            myChart.update();
        } else {
            myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: displayDates,
                    datasets: [
                        { label: 'Доход', data: incomeData, backgroundColor: STAT_COLORS.income, borderRadius: 0 },
                        { label: 'Расход', data: expenseData, backgroundColor: STAT_COLORS.expense, borderRadius: 0 }
                    ]
                },
                options: barOptions()
            });
        }
    }

    renderExtraCharts(todayStr);
}

// --- РАСШИРЕННАЯ СТАТИСТИКА ---
// Палитра в духе 16-цветной VGA: доход зелёный, расход красный
const STAT_COLORS = { income: '#008000', expense: '#d00000', balance: '#000080' };
const CATEGORY_PALETTE = ['#d00000', '#000080', '#008080', '#808000', '#800080', '#008000', '#ff8000', '#0000ff', '#ff00ff', '#800000', '#808080'];
const statCharts = {};

function shortDate(d) {
    const parts = d.split('-');
    return `${parts[2]}.${parts[1]}`;
}

function barOptions(extra = {}) {
    return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom' } },
        scales: { y: { beginAtZero: true }, x: { grid: { display: false } } },
        ...extra
    };
}

function upsertChart(key, canvasId, config) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || typeof Chart === 'undefined') return;
    if (statCharts[key]) {
        statCharts[key].data = config.data;
        statCharts[key].options = config.options;
        statCharts[key].update();
    } else {
        statCharts[key] = new Chart(canvas, config);
    }
}

// Начало выбранного периода в формате YYYY-MM-DD ('' = всё время)
function statsPeriodStart(todayStr) {
    const sel = document.getElementById('stats-period');
    const period = sel ? sel.value : 'month';
    if (period === '7') return almatyIsoNow(-6).slice(0, 10);
    if (period === '30') return almatyIsoNow(-29).slice(0, 10);
    if (period === 'month') return todayStr.slice(0, 8) + '01';
    if (period === 'year') return todayStr.slice(0, 5) + '01-01';
    return '';
}

function periodTx(todayStr) {
    const start = statsPeriodStart(todayStr);
    return transactions.filter(t => !t.isSystem && getTxDateStr(t.date) >= start && getTxDateStr(t.date) <= todayStr);
}

function categoryName(tx) {
    return String(tx.category || 'Без категории').split(':')[0].trim() || 'Без категории';
}

function groupByCategory(list) {
    const map = {};
    list.forEach(t => { const c = categoryName(t); map[c] = (map[c] || 0) + (parseFloat(t.amount) || 0); });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
}

function renderStatsKpi(todayStr) {
    const box = document.getElementById('stats-kpi');
    if (!box) return;
    const list = periodTx(todayStr);
    const income = list.filter(t => t.type === 'income').reduce((s, t) => s + (parseFloat(t.amount) || 0), 0);
    const expense = list.filter(t => t.type === 'expense').reduce((s, t) => s + (parseFloat(t.amount) || 0), 0);
    const start = statsPeriodStart(todayStr);
    const firstDate = start || list.reduce((m, t) => { const d = getTxDateStr(t.date); return !m || d < m ? d : m; }, '') || todayStr;
    const days = Math.max(1, Math.round((Date.parse(todayStr + 'T00:00:00Z') - Date.parse(firstDate + 'T00:00:00Z')) / 86400000) + 1);
    const savedPct = income > 0 ? Math.round((income - expense) / income * 100) : null;
    const maxExpense = list.filter(t => t.type === 'expense').reduce((m, t) => Math.max(m, parseFloat(t.amount) || 0), 0);
    const kpis = [
        ['Доходы', fmtMoney(income) + ' ₸', 'amount-income'],
        ['Расходы', fmtMoney(expense) + ' ₸', 'amount-expense'],
        ['Итог', (income - expense >= 0 ? '+' : '') + fmtMoney(income - expense) + ' ₸', income - expense >= 0 ? 'amount-income' : 'amount-expense'],
        ['Средний расход в день', fmtMoney(Math.round(expense / days)) + ' ₸', ''],
        ['Сохранено от дохода', savedPct === null ? '—' : savedPct + '%', savedPct !== null && savedPct < 0 ? 'amount-expense' : ''],
        ['Самая крупная трата', fmtMoney(maxExpense) + ' ₸', ''],
        ['Операций', String(list.length), ''],
        ['Дней в периоде', String(days), '']
    ];
    box.innerHTML = kpis.map(([label, value, cls]) => `<div class="kpi"><span class="kpi-label">${label}</span><span class="kpi-value ${cls}">${value}</span></div>`).join('');
}

function renderCategoryList(elId, entries, total) {
    const el = document.getElementById(elId);
    if (!el) return;
    if (!entries.length) {
        el.innerHTML = '<p class="hint" style="text-align:center;">Нет данных за период</p>';
        return;
    }
    el.innerHTML = entries.slice(0, 8).map(([name, sum], i) => {
        const pct = total > 0 ? Math.round(sum / total * 100) : 0;
        return `<div class="cat-row"><span class="cat-dot" style="background:${CATEGORY_PALETTE[i % CATEGORY_PALETTE.length]}"></span>` +
            `<span class="cat-name">${escapeHtml(name)}</span><span class="cat-sum">${fmtMoney(sum)} ₸</span><span class="cat-pct">${pct}%</span></div>`;
    }).join('');
}

function doughnutConfig(entries) {
    const top = entries.slice(0, 8);
    const rest = entries.slice(8).reduce((s, e) => s + e[1], 0);
    const labels = top.map(e => e[0]).concat(rest > 0 ? ['Прочее'] : []);
    const data = top.map(e => e[1]).concat(rest > 0 ? [rest] : []);
    return {
        type: 'doughnut',
        data: {
            labels: labels.length ? labels : ['Нет данных'],
            datasets: [{
                data: data.length ? data : [1],
                backgroundColor: data.length ? labels.map((_, i) => CATEGORY_PALETTE[i % CATEGORY_PALETTE.length]) : ['#c0c0c0'],
                borderWidth: 1,
                borderColor: '#000'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '62%',
            plugins: { legend: { display: false }, tooltip: { enabled: data.length > 0 } }
        }
    };
}

function renderExtraCharts(todayStr) {
    const list = periodTx(todayStr);

    // Категории расходов и источники доходов за выбранный период
    const expenseCats = groupByCategory(list.filter(t => t.type === 'expense'));
    const incomeCats = groupByCategory(list.filter(t => t.type === 'income'));
    upsertChart('expenseCat', 'expenseCatChart', doughnutConfig(expenseCats));
    upsertChart('incomeCat', 'incomeCatChart', doughnutConfig(incomeCats));
    renderCategoryList('expense-cat-list', expenseCats, expenseCats.reduce((s, e) => s + e[1], 0));
    renderCategoryList('income-cat-list', incomeCats, incomeCats.reduce((s, e) => s + e[1], 0));

    // Баланс на конец каждого из последних 30 дней (с учётом всех операций, включая копилку)
    const days30 = [];
    for (let i = 29; i >= 0; i--) days30.push(almatyIsoNow(-i).slice(0, 10));
    const sorted = [...transactions].sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let idx = 0, running = 0;
    const balanceData = days30.map(day => {
        while (idx < sorted.length && getTxDateStr(sorted[idx].date) <= day) {
            const t = sorted[idx++];
            running += (t.type === 'income' ? 1 : -1) * (parseFloat(t.amount) || 0);
        }
        return running;
    });
    upsertChart('balance', 'balanceChart', {
        type: 'line',
        data: {
            labels: days30.map(shortDate),
            datasets: [{ label: 'Баланс', data: balanceData, borderColor: STAT_COLORS.balance, backgroundColor: 'rgba(0,0,128,0.12)', fill: true, tension: 0, stepped: false, borderWidth: 2, pointRadius: 0, pointHitRadius: 8 }]
        },
        options: barOptions({ plugins: { legend: { display: false } }, scales: { y: { beginAtZero: false }, x: { grid: { display: false }, ticks: { maxTicksLimit: 8 } } } })
    });

    // Доходы и расходы по месяцам (последние 6 месяцев)
    const [y, m] = todayStr.split('-').map(Number);
    const months = [];
    for (let i = 5; i >= 0; i--) {
        const d = new Date(Date.UTC(y, m - 1 - i, 1));
        months.push(d.toISOString().slice(0, 7));
    }
    const monthNames = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
    const real = transactions.filter(t => !t.isSystem);
    const sumMonth = (key, type) => real.filter(t => t.type === type && String(t.date).slice(0, 7) === key).reduce((s, t) => s + (parseFloat(t.amount) || 0), 0);
    upsertChart('months', 'monthsChart', {
        type: 'bar',
        data: {
            labels: months.map(k => monthNames[Number(k.slice(5, 7)) - 1] + ' ' + k.slice(2, 4)),
            datasets: [
                { label: 'Доход', data: months.map(k => sumMonth(k, 'income')), backgroundColor: STAT_COLORS.income, borderRadius: 0 },
                { label: 'Расход', data: months.map(k => sumMonth(k, 'expense')), backgroundColor: STAT_COLORS.expense, borderRadius: 0 }
            ]
        },
        options: barOptions()
    });

    // Расходы по дням недели и по времени суток за выбранный период
    const expenses = list.filter(t => t.type === 'expense');
    const weekday = [0, 0, 0, 0, 0, 0, 0]; // Пн..Вс
    const dayparts = [0, 0, 0, 0];         // ночь, утро, день, вечер
    expenses.forEach(t => {
        const d = getTxDateStr(t.date);
        const wd = new Date(d + 'T00:00:00Z').getUTCDay();
        if (!Number.isNaN(wd)) weekday[(wd + 6) % 7] += parseFloat(t.amount) || 0;
        const hour = Number(String(t.date).split('T')[1]?.slice(0, 2));
        const part = Number.isFinite(hour) ? (hour < 6 ? 0 : hour < 12 ? 1 : hour < 18 ? 2 : 3) : 2;
        dayparts[part] += parseFloat(t.amount) || 0;
    });
    upsertChart('weekday', 'weekdayChart', {
        type: 'bar',
        data: {
            labels: ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'],
            datasets: [{ label: 'Расход', data: weekday, backgroundColor: STAT_COLORS.expense, borderRadius: 0 }]
        },
        options: barOptions({ plugins: { legend: { display: false } } })
    });
    const hasDayparts = dayparts.some(v => v > 0);
    upsertChart('daypart', 'daypartChart', {
        type: 'doughnut',
        data: {
            labels: ['Ночь (0–6)', 'Утро (6–12)', 'День (12–18)', 'Вечер (18–24)'],
            datasets: [{ data: hasDayparts ? dayparts : [1, 1, 1, 1], backgroundColor: hasDayparts ? ['#000080', '#808000', '#ff8000', '#800080'] : ['#c0c0c0', '#c0c0c0', '#c0c0c0', '#c0c0c0'], borderWidth: 1, borderColor: '#000' }]
        },
        options: { responsive: true, maintainAspectRatio: false, cutout: '55%', plugins: { legend: { position: 'bottom' }, tooltip: { enabled: hasDayparts } } }
    });
}

function renderTransactions() {
    const txList = document.getElementById('tx-list');
    if (!txList) return;
    txList.innerHTML = '';
    
    if (transactions.length === 0) {
        txList.innerHTML = '<p class="hint" style="text-align:center; padding: 25px;">Записей пока нет</p>';
        return;
    }

    let sortedAsc = [...transactions].sort((a,b) => new Date((a.date||'').replace('T', ' ')) - new Date((b.date||'').replace('T', ' ')));
    let groups = {};
    let runBalance = 0;
    
    sortedAsc.forEach(tx => {
        runBalance += (tx.type === 'income' ? tx.amount : -tx.amount);
        let dDate = getTxDateStr(tx.date);
        if (!dDate) return;
        
        if(!groups[dDate]) groups[dDate] = { income: 0, expense: 0, endBalance: 0, items: [] };
        
        if(!tx.isSystem) {
            if(tx.type === 'income') groups[dDate].income += tx.amount;
            else groups[dDate].expense += tx.amount;
        }
        groups[dDate].endBalance = runBalance;
        groups[dDate].items.push(tx);
    });

    Object.keys(groups).sort((a,b) => new Date(b) - new Date(a)).forEach(date => {
        let g = groups[date];
        let parts = date.split('-');
        let fDate = parts.length === 3 ? `${parts[2]}.${parts[1]}.${parts[0]}` : date;
        
        let header = document.createElement('div');
        header.className = 'date-group-header';
        header.innerHTML = `
            <h4>${fDate}</h4>
            <p>
                <span style="color:var(--income)">+${g.income}</span> 
                <span style="color:var(--expense)">-${g.expense}</span> 
                <span>Итог: <strong>${g.endBalance} ₸</strong></span>
            </p>
        `;
        txList.appendChild(header);
        
        g.items.reverse().forEach(tx => {
            let sign = tx.type === 'income' ? '+' : '-';
            let timeStr = (tx.date && tx.date.includes('T')) ? ` <span style="font-size:12px;color:var(--text-muted);">${tx.date.split('T')[1]}</span>` : '';
            let commentStr = (tx.comment ? `<span class="tx-comment">${escapeHtml(tx.comment)}</span>` : '');
            let div = document.createElement('div');
            div.className = `tx-item ${tx.type}`;
            div.innerHTML = `
                <div class="tx-info">
                    <span class="tx-cat">${historyCategoryHtml(tx.category)}</span><br>${timeStr}${commentStr}
                </div>
                <strong class="tx-amount ${tx.type === 'income' ? 'amount-income' : 'amount-expense'}" style="font-size: 15px;">${sign}${tx.amount} ₸${typeof txOrigAmountHtml === 'function' ? txOrigAmountHtml(tx) : ''}</strong>
                ${tx.isSystem ? '' : `
                <div class="tx-actions">
                    <button type="button" onclick="editTx('${tx.id}')"><span class="material-icons" style="font-size:18px;">edit</span></button>
                    <button type="button" onclick="deleteTx('${tx.id}')"><span class="material-icons" style="font-size:18px; color:#d32f2f;">delete</span></button>
                </div>
                `}
            `;
            txList.appendChild(div);
        });
    });
}

function addSub() {
    let nameEl = document.getElementById('sub-name');
    let amountEl = document.getElementById('sub-amount');
    let dayEl = document.getElementById('sub-day');

    if (!nameEl || !amountEl || !dayEl) return;

    const name = nameEl.value.trim();
    const amount = parseFloat(amountEl.value);
    const day = parseInt(dayEl.value);

    if(!name || !amount || isNaN(day) || day < 1 || day > 31) {
        alert("Заполните название, сумму и день месяца (1-31)!");
        return;
    }

    const timeEl = document.getElementById('sub-time');
    const sub = { id: Date.now().toString(), name, amount, day, time: (timeEl && timeEl.value) || '10:00' };
    if (typeof newSubReminderValues === 'function') sub.remind = newSubReminderValues(); // js/notify.js
    subscriptions.push(sub);

    nameEl.value = '';
    amountEl.value = '';
    dayEl.value = '1';

    updateUI(true);
}

function deleteSub(id) {
    if(confirm("Удалить подписку?")) {
        subscriptions = subscriptions.filter(s => s.id !== id);
        updateUI(true);
    }
}

function paySub(id) {
    let sub = subscriptions.find(s => s.id === id);
    if(!sub) return;

    let datetimeNow = almatyIsoNow();

    transactions.push({
        id: Date.now().toString(),
        type: 'expense',
        amount: sub.amount,
        category: `Подписка: ${sub.name}`,
        date: datetimeNow
    });

    updateUI(true);
    alert(`Подписка «${sub.name}» успешно списана (${sub.amount} ₸)!`);
}

function renderSubscriptions() {
    const subsList = document.getElementById('subs-list');
    if (!subsList) return;
    subsList.innerHTML = '';

    if(subscriptions.length === 0) {
        subsList.innerHTML = '<p class="hint" style="text-align:center; padding: 20px;">Нет активных подписок</p>';
        return;
    }

    subscriptions.forEach(sub => {
        let div = document.createElement('div');
        div.className = 'sub-item';
        div.innerHTML = `
            <div class="sub-info">
                <strong>${sub.name}</strong><br>
                <span style="font-size: 12px; color: var(--text-muted);">${sub.time ? `Списание: ${sub.day}-го числа каждого месяца в ${escapeHtml(sub.time)}` : `Списание: ${sub.day}-го числа каждого месяца`}</span>
                ${typeof subReminders === 'function' ? `<span class="sub-remind-info"><span class="material-icons">notifications</span> ${escapeHtml(remindersLabel(subReminders(sub)))}</span>` : ''}
            </div>
            <strong style="font-size: 16px; color: var(--expense);">-${sub.amount} ₸</strong>
            <div class="sub-actions">
                <button type="button" class="pay-btn" onclick="paySub('${sub.id}')"><span class="material-icons" style="font-size:16px;">check</span> Списать</button>
                <button type="button" onclick="openSubReminders('${sub.id}')" title="Время и напоминания" aria-label="Время списания и напоминания"><span class="material-icons" style="font-size:18px;">notifications</span></button>
                <button type="button" onclick="deleteSub('${sub.id}')"><span class="material-icons" style="font-size:18px; color:#d32f2f;">delete</span></button>
            </div>
        `;
        subsList.appendChild(div);
    });
}

function saveTx(type) {
    let amountEl = document.getElementById('amount');
    let categoryEl = document.getElementById('category');
    let datetimeEl = document.getElementById('tx-datetime');

    if (!amountEl || !categoryEl || !datetimeEl) return;

    const amount = parseFloat(String(amountEl.value).replace(',', '.'));
    const category = categoryEl.value.trim() || 'Без категории';
    const datetime = datetimeEl.value || almatyIsoNow();

    if (!(amount > 0)) {
        alert('Введите сумму.');
        return;
    }
    
    const conv = typeof formAmountInTenge === 'function' ? formAmountInTenge(amount) : { amount, extra: {} };
    if (!conv) return;
    const comment = getFormComment('tx');
    const tx = { id: Date.now().toString(), type, amount: conv.amount, category, date: datetime, ...conv.extra };
    if (comment) tx.comment = comment;
    transactions.push(tx);
    clearForm();
    updateUI(true);
}

function deleteTx(id) {
    if(confirm("Удалить запись?")) {
        transactions = transactions.filter(t => t.id !== id);
        updateUI(true);
    }
}

function editTx(id) {
    const tx = transactions.find(t => t.id === id);
    if (!tx) return;
    const el = i => document.getElementById(i);
    // запись в другой валюте редактируется в исходной валюте
    const foreign = tx.currency && tx.currency !== 'KZT' && tx.origAmount;
    window.mmOpenEntry(tx.type);
    el('edit-id').value = tx.id;
    el('tx-datetime').value = (tx.date && tx.date.includes('T')) ? tx.date : (tx.date + 'T00:00');
    el('amount').value = foreign ? tx.origAmount : tx.amount;
    if (typeof setTxCurrency === 'function') setTxCurrency(foreign ? tx.currency : 'KZT');
    el('category').value = tx.category;
    setFormComment('tx', tx.comment || '');
    renderCategoryTiles();
    window.mmEntrySync();
}

function saveEdit() {
    let editIdEl = document.getElementById('edit-id');
    let amountEl = document.getElementById('amount');
    let categoryEl = document.getElementById('category');
    let datetimeEl = document.getElementById('tx-datetime');

    if (!editIdEl || !amountEl || !categoryEl || !datetimeEl) return;

    const id = editIdEl.value;
    const amount = parseFloat(String(amountEl.value).replace(',', '.'));
    const category = categoryEl.value.trim() || 'Без категории';
    const datetime = datetimeEl.value;
    
    if (!(amount > 0) || !datetime) {
        alert('Введите сумму и дату.');
        return;
    }
    
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        const conv = typeof formAmountInTenge === 'function' ? formAmountInTenge(amount) : { amount, extra: {} };
        if (!conv) return;
        // курс при правке не меняется, если валюта и сумма прежние
        const keepRate = conv.extra.currency && tx.currency === conv.extra.currency && Number(tx.origAmount) === amount && tx.rate;
        if (!keepRate) {
            delete tx.currency; delete tx.origAmount; delete tx.rate;
            Object.assign(tx, conv.extra);
            tx.amount = conv.amount;
        }
        const typeBtn = document.querySelector('#entry [data-type].is-on');
        if (typeBtn) tx.type = typeBtn.dataset.type;
        tx.category = category;
        tx.date = datetime;
        const comment = getFormComment('tx');
        if (comment) tx.comment = comment; else delete tx.comment;
    }
    
    clearForm();
    updateUI(true);
}

function clearForm() {
    const el = i => document.getElementById(i);
    ['amount', 'category', 'edit-id'].forEach(i => { if (el(i)) el(i).value = ''; });
    setFormComment('tx', '');
    if (el('tx-datetime')) el('tx-datetime').value = almatyIsoNow();
    renderCategoryTiles();
    if (typeof setTxCurrency === 'function') setTxCurrency('KZT'); // валюта по умолчанию — тенге
    const voiceBox = document.getElementById('voice-result');
    if (voiceBox) voiceBox.hidden = true;
}

function generateReport() {
    let reportSelect = document.getElementById('report-type');
    const tbody = document.getElementById('report-tbody');
    if (!reportSelect || !tbody) return;

    let type = reportSelect.value;
    tbody.innerHTML = '';
    
    let groups = {};
    
    transactions.forEach(tx => {
        if(tx.isSystem) return; 
        let dt = (tx.date && tx.date.includes('T')) ? tx.date : ((tx.date || '') + 'T00:00');
        let key = '';
        
        if (type === 'days') {
            key = dt.split('T')[0];
        } else if (type === 'hours') {
            let parts = dt.split('T');
            let hour = (parts[1] || '00:00').split(':')[0];
            key = `${parts[0]} ${hour}:00`;
        } else if (type === 'weeks') {
            let dateObj = new Date(dt);
            if (isNaN(dateObj)) return;
            let d = new Date(Date.UTC(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate()));
            let dayNum = d.getUTCDay() || 7;
            d.setUTCDate(d.getUTCDate() + 4 - dayNum);
            let yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
            let weekNo = Math.ceil((((d - yearStart) / 86400000) + 1)/7);
            key = `Нед. ${weekNo} (${d.getUTCFullYear()})`;
        }
        
        if(!groups[key]) groups[key] = { inc: 0, exp: 0 };
        if(tx.type === 'income') groups[key].inc += tx.amount;
        else groups[key].exp += tx.amount;
    });
    
    let sortedKeys = Object.keys(groups).sort((a,b) => b.localeCompare(a));
    
    if (sortedKeys.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">Нет данных</td></tr>';
        return;
    }
    
    sortedKeys.forEach(k => {
        let g = groups[k];
        let total = g.inc - g.exp;
        let sign = total > 0 ? '+' : '';
        
        tbody.innerHTML += `<tr>
            <td>${k}</td>
            <td style="color:var(--income)">${g.inc}</td>
            <td style="color:var(--expense)">${g.exp}</td>
            <td style="font-weight:bold;">${sign}${total}</td>
        </tr>`;
    });
}

// --- ВЫГРУЗКА ФАЙЛОВ (Excel / JSON) ---
// 4.16.0: категория и подкатегория — отдельные столбцы («Семья: Отец» → «Семья» | «Отец»)
const EXPORT_COLUMNS = ['Дата', 'Время', 'Тип', 'Категория', 'Подкатегория', 'Комментарий', 'Сумма', 'ИТОГО'];
const EXPORT_AMOUNT_COLS = [6, 7]; // номера числовых колонок (Сумма, Итого)

function isMobileDevice() {
    const ua = navigator.userAgent || '';
    return /Android|iPhone|iPad|iPod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
}

// Строки таблицы выгрузки: kind = income | expense | day | total. Используются и для .xlsx, и для просмотра/копирования.
function buildExportRows(list = transactions, totalLabel = 'ИТОГО ЗА ВСЁ ВРЕМЯ') {
    const rows = [];
    const sortedTx = [...list].sort((a,b) => new Date((a.date||'').replace('T', ' ')) - new Date((b.date||'').replace('T', ' ')));
    let currentDate = null;
    let dailyTotal = 0;
    let allTimeTotal = 0;

    sortedTx.forEach(t => {
        const dt = (t.date && t.date.includes('T')) ? t.date : ((t.date || '') + 'T00:00');
        const parts = dt.split('T');
        const txDate = parts[0];

        if (currentDate !== null && txDate !== currentDate) {
            rows.push({ kind: 'day', cells: ['ИТОГО ЗА ДЕНЬ', '', '', '', '', '', dailyTotal, ''] });
            dailyTotal = 0;
        }
        currentDate = txDate;

        const amount = parseFloat(t.amount) || 0;
        const isIncome = t.type === 'income';
        dailyTotal += isIncome ? amount : -amount;
        allTimeTotal += isIncome ? amount : -amount;

        const catFull = String(t.category || '');
        const sepAt = catFull.indexOf(':');
        const cat = (sepAt >= 0 ? catFull.slice(0, sepAt) : catFull).trim();
        const sub = sepAt >= 0 ? catFull.slice(sepAt + 1).trim() : '';
        rows.push({
            kind: isIncome ? 'income' : 'expense',
            cells: [txDate, parts[1] || '', isIncome ? 'Доход' : 'Расход', cat, sub, t.comment || '', amount, '']
        });
    });

    if (currentDate !== null) {
        rows.push({ kind: 'day', cells: ['ИТОГО ЗА ДЕНЬ', '', '', '', '', '', dailyTotal, ''] });
        // Общий чистый итог за всё время находится в отдельном последнем столбце.
        rows.push({ kind: 'total', cells: [totalLabel, '', '', '', '', '', '', allTimeTotal] });
    }
    return rows;
}

async function buildExcelBlob(rows) {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Записи');
    const widths = [12, 8, 9, 18, 18, 30, 13, 20];
    worksheet.columns = EXPORT_COLUMNS.map((header, i) => ({ header, width: widths[i] }));

    // 4.16.0: мягкие пастельные цвета вместо ярких заливок — тёмный текст на светлом фоне, тонкие светлые рамки
    const border = { style: 'thin', color: { argb: 'FFE3E6EA' } };
    const borders = { top: border, left: border, bottom: border, right: border };
    const header = worksheet.getRow(1);
    header.height = 22;
    header.eachCell(cell => {
        cell.font = { bold: true, color: { argb: 'FF3E4A59' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE6EBF2' } };
        cell.alignment = { vertical: 'middle' };
        cell.border = borders;
    });

    const look = {
        income: { fill: 'FFEAF6EC', font: 'FF2F6B3A' },   // мятный
        expense: { fill: 'FFFCEDEE', font: 'FF9E3A3A' },  // пудрово-розовый
        day: { fill: 'FFFFF6DD', font: 'FF5B4A1E' },      // сливочный
        total: { fill: 'FFE6F0FA', font: 'FF24476B' }     // голубой
    };
    rows.forEach(r => {
        const row = worksheet.addRow(r.cells);
        const isSummary = r.kind === 'day' || r.kind === 'total';
        const lk = look[r.kind];
        row.eachCell({ includeEmpty: true }, (cell, col) => {
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: lk.fill } };
            cell.font = { color: { argb: lk.font }, bold: isSummary };
            cell.border = borders;
            if (EXPORT_AMOUNT_COLS.includes(col - 1) && typeof cell.value === 'number') cell.numFmt = '#,##0.##';
        });
    });

    worksheet.views = [{ state: 'frozen', ySplit: 1 }];
    worksheet.autoFilter = { from: 'A1', to: 'H1' };
    const buffer = await workbook.xlsx.writeBuffer();
    return new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

function loadExcelLibrary() {
    if (typeof ExcelJS !== 'undefined') return Promise.resolve(true);
    return new Promise(resolve => {
        const s = document.createElement('script');
        s.src = 'vendor/exceljs.min.js';
        s.onload = () => resolve(typeof ExcelJS !== 'undefined');
        s.onerror = () => resolve(false);
        document.head.appendChild(s);
    });
}

// Приложение внутри APK (Android WebView от WebIntoApp и подобных обёрток).
// Такие обёртки не обрабатывают скачивание: у WebView нет DownloadListener, а «Поделиться» (navigator.share)
// в WebView не существует, поэтому файл из JavaScript там не сохранить без нативного моста.
function isAndroidWebView() {
    const ua = navigator.userAgent || '';
    if (!/Android/i.test(ua) || /Firefox\//.test(ua)) return false;
    return /; wv\)/.test(ua) || /Dalvik\//.test(ua) || !/Chrome\//.test(ua)
        || (window.isSecureContext && typeof navigator.share !== 'function');
}

// Нативный мост из APK (см. ANDROID_EXPORT_BRIDGE_RU.txt): window.MoneyNative.saveFile(base64, имя, mime)
function nativeFileBridge() {
    const bridge = window.MoneyNative;
    return bridge && typeof bridge.saveFile === 'function' ? bridge : null;
}

function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(blob);
    });
}

// Отдаёт файл пользователю. Порядок: нативный мост APK → меню «Поделиться» на телефоне → обычное скачивание.
// Возвращает 'native' | 'shared' | 'downloaded' | 'unsupported' (APK без моста: сохранить файл нельзя).
async function deliverFile(blob, fileName) {
    const bridge = nativeFileBridge();
    if (bridge) {
        try {
            const ok = bridge.saveFile(await blobToBase64(blob), fileName, blob.type || 'application/octet-stream');
            if (ok !== false && ok !== 'false') return 'native';
        } catch (e) {
            console.warn('Нативный мост не сохранил файл', e);
        }
    }
    if (isAndroidWebView()) return 'unsupported';

    if (isMobileDevice() && navigator.canShare && typeof File !== 'undefined') {
        try {
            const file = new File([blob], fileName, { type: blob.type });
            if (navigator.canShare({ files: [file] })) {
                await navigator.share({ files: [file], title: fileName });
                return 'shared';
            }
        } catch (e) {
            if (e && e.name === 'AbortError') return 'shared';
            console.warn('Share не удался, пробуем скачивание', e);
        }
    }

    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = fileName;
    anchor.rel = 'noopener';
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    setTimeout(() => {
        anchor.remove();
        URL.revokeObjectURL(url);
    }, 60000);
    return 'downloaded';
}

function copyTextToClipboard(text) {
    const fallback = () => {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;';
        document.body.appendChild(ta);
        ta.select();
        ta.setSelectionRange(0, text.length);
        let ok = false;
        try { ok = document.execCommand('copy'); } catch (e) {}
        ta.remove();
        return ok;
    };
    // В APK (WebView) сначала синхронное копирование: оно срабатывает сразу в момент нажатия
    if (isAndroidWebView() && fallback()) return Promise.resolve(true);
    if (navigator.clipboard && window.isSecureContext) {
        return navigator.clipboard.writeText(text).then(() => true).catch(fallback);
    }
    return Promise.resolve(fallback());
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}

// Окно с таблицей прямо в приложении: работает даже там, где обёртка (WebIntoApp/Android WebView)
// не умеет сохранять сгенерированные файлы. Таблицу можно скопировать и вставить в Excel / Google Таблицы.
// actions: дополнительные кнопки [{ label, icon, onClick }]
function showExportSheet({ title, note, tableHtml, copyText, retry, actions = [] }) {
    closeExportSheet();
    const overlay = document.createElement('div');
    overlay.id = 'export-sheet';
    overlay.className = 'export-sheet-overlay';
    overlay.innerHTML = `
        <div class="export-sheet" role="dialog" aria-modal="true" aria-label="${escapeHtml(title)}">
            <div class="export-sheet-head">
                <h3>${escapeHtml(title)}</h3>
                <button type="button" class="export-sheet-close" aria-label="Закрыть"><span class="material-icons">close</span></button>
            </div>
            <p class="hint">${note}</p>
            <div class="export-sheet-table">${tableHtml}</div>
            <div class="export-sheet-actions">
                <button type="button" class="btn-primary" data-act="copy"><span class="material-icons">content_copy</span> Скопировать таблицу</button>
                ${retry ? '<button type="button" class="btn-secondary" data-act="retry"><span class="material-icons">download</span> Скачать ещё раз</button>' : ''}
                ${actions.map((a, i) => `<button type="button" class="btn-secondary" data-act="extra-${i}"><span class="material-icons">${a.icon}</span> ${escapeHtml(a.label)}</button>`).join('')}
            </div>
        </div>`;
    overlay.addEventListener('click', async (e) => {
        if (e.target === overlay || e.target.closest('.export-sheet-close')) { closeExportSheet(); playSound('close'); return; }
        const btn = e.target.closest('button[data-act]');
        if (!btn) return;
        if (btn.dataset.act === 'copy') {
            const ok = await copyTextToClipboard(copyText);
            alert(ok ? 'Таблица скопирована. Вставьте её в Excel или Google Таблицы.' : 'Не удалось скопировать. Выделите таблицу вручную.');
        } else if (btn.dataset.act === 'retry' && retry) {
            retry();
        } else if (btn.dataset.act.startsWith('extra-')) {
            const action = actions[Number(btn.dataset.act.slice(6))];
            if (action) action.onClick();
        }
    });
    document.body.appendChild(overlay);
    playSound('open');
}

function closeExportSheet() {
    const old = document.getElementById('export-sheet');
    if (old) old.remove();
}

async function exportExcel(options = {}) {
    // 4.17.0: кнопка «Скачать Excel» сначала открывает окно выбора периода и категорий (js/exportdlg.js);
    // авто-выгрузка в 23:00 (silent) — как раньше, все записи
    if (!options.list && !options.silent && typeof openExportDialog === 'function') { openExportDialog('xlsx'); return; }
    const silent = !!options.silent;
    const list = options.list || transactions;
    const rows = buildExportRows(list, options.totalLabel);
    if (rows.length === 0) {
        if (!silent) alert('Нет записей для выгрузки.');
        return;
    }

    const fileName = exportFileName('xlsx', options.suffix || '');
    let result = null;
    try {
        if (!(await loadExcelLibrary())) throw new Error('ExcelJS не загружен');
        const blob = await buildExcelBlob(rows);
        result = await deliverFile(blob, fileName);
    } catch (e) {
        console.error(e);
    }
    if (result === 'native' && !silent) alert(`Файл ${fileName} сохранён.`);
    if (silent || result === 'shared' || result === 'native') return;

    // Для настольного браузера скачивания достаточно. На телефоне, в APK и при ошибке показываем таблицу в приложении.
    if (result === 'downloaded' && !isMobileDevice()) return;

    const preview = buildExportPreview(rows);
    showExportSheet({
        title: 'Таблица Excel',
        note: result === 'downloaded'
            ? `Файл <b>${escapeHtml(fileName)}</b> отправлен на скачивание. Если он не появился в «Загрузках», скопируйте таблицу и вставьте её в Excel или Google Таблицы, либо скачайте PDF.`
            : result === 'unsupported'
                ? APK_NO_FILES_NOTE
                : 'Не удалось сформировать файл .xlsx (нет интернета для библиотеки выгрузки). Скопируйте таблицу и вставьте её в Excel или Google Таблицы.',
        tableHtml: preview.tableHtml,
        copyText: preview.tsv,
        retry: result === 'downloaded' ? () => exportExcel({ ...options, list, silent: true }) : null,
        actions: result === 'unsupported' ? [] : [{ label: 'Скачать PDF (A4)', icon: 'picture_as_pdf', onClick: () => exportPdf({ ...options, list }) }]
    });
}

const APK_NO_FILES_NOTE = 'Эта сборка приложения (APK) не умеет сохранять файлы, поэтому таблица показана здесь. ' +
    'Нажмите «Скопировать таблицу» и вставьте её в Excel, Google Таблицы или WPS Office: получится та же таблица с итогами. ' +
    'Файлы .xlsx и .pdf сохраняются, если открыть приложение в Chrome или собрать APK с нативным мостом (инструкция в архиве).';

function buildExportPreview(rows) {
    const head = `<tr>${EXPORT_COLUMNS.map(c => `<th>${escapeHtml(c)}</th>`).join('')}</tr>`;
    const body = rows.map(r => `<tr class="exp-${r.kind}">${r.cells.map(c => `<td>${escapeHtml(c)}</td>`).join('')}</tr>`).join('');
    const tsv = [EXPORT_COLUMNS, ...rows.map(r => r.cells)]
        .map(cells => cells.map(c => String(c).replace(/[\t\r\n]+/g, ' ')).join('\t')).join('\n');
    return { tableHtml: `<table class="analytics-table export-table"><thead>${head}</thead><tbody>${body}</tbody></table>`, tsv };
}

// --- PDF (A4) ---
// pdfmake со встроенным шрифтом Roboto (кириллица). PDF — стандартный формат A4, открывается на любом устройстве.
const PDFMAKE_URLS = [
    'vendor/pdfmake.min.js',
    'vendor/vfs_fonts.min.js'
];
const scriptPromises = {};

function loadScriptOnce(src) {
    if (!scriptPromises[src]) {
        scriptPromises[src] = new Promise((resolve, reject) => {
            const s = document.createElement('script');
            s.src = src;
            s.onload = resolve;
            s.onerror = () => { delete scriptPromises[src]; reject(new Error('Не загрузился ' + src)); };
            document.head.appendChild(s);
        });
    }
    return scriptPromises[src];
}

async function loadPdfLibrary() {
    if (window.pdfMake && window.pdfMake.vfs) return true;
    try {
        for (const src of PDFMAKE_URLS) await loadScriptOnce(src);
    } catch (e) {
        console.error(e);
        return false;
    }
    return !!(window.pdfMake && window.pdfMake.vfs);
}

const fmtMoney = v => Number(v || 0).toLocaleString('ru-RU', { maximumFractionDigits: 2 });

// list — записи выгрузки (по умолчанию все); title — заголовок (для выгрузки за день)
function buildPdfDefinition(rows, list = transactions, title = 'My Money — выписка операций') {
    const real = list.filter(t => !t.isSystem);
    const income = real.filter(t => t.type === 'income').reduce((s, t) => s + (parseFloat(t.amount) || 0), 0);
    const expense = real.filter(t => t.type === 'expense').reduce((s, t) => s + (parseFloat(t.amount) || 0), 0);
    const balance = transactions.reduce((s, t) => s + (t.type === 'income' ? 1 : -1) * (parseFloat(t.amount) || 0), 0);

    // Печатные цвета: светлая заливка, тёмный текст; доход зелёный, расход красный.
    const styles = {
        income: { fillColor: '#eaf6ec', color: '#2f6b3a' },
        expense: { fillColor: '#fcedee', color: '#9e3a3a' },
        day: { fillColor: '#fff6dd', color: '#5b4a1e', bold: true },
        total: { fillColor: '#e6f0fa', color: '#24476b', bold: true }
    };
    const body = [EXPORT_COLUMNS.map(c => ({ text: c, style: 'th' }))];
    rows.forEach(r => {
        const st = styles[r.kind];
        const cells = r.cells.map((c, i) => ({
            text: EXPORT_AMOUNT_COLS.includes(i) && c !== '' ? fmtMoney(c) : String(c),
            alignment: EXPORT_AMOUNT_COLS.includes(i) ? 'right' : 'left',
            italics: i === 5,
            ...st
        }));
        // Итоговые строки: подпись на 4 колонки, чтобы «ИТОГО ЗА ДЕНЬ» не переносилось
        if (r.kind === 'day' || r.kind === 'total') {
            cells[0].colSpan = 6;
            cells[1] = {}; cells[2] = {}; cells[3] = {}; cells[4] = {}; cells[5] = {};
        }
        body.push(cells);
    });

    const generated = formatAlmaty({ day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
    return {
        pageSize: 'A4',
        pageOrientation: 'portrait',
        pageMargins: [32, 40, 32, 44],
        info: { title: 'My Money — выписка', author: 'Money Pro' },
        defaultStyle: { font: 'Roboto', fontSize: 9 },
        content: [
            { text: title, style: 'title' },
            { text: (profileName ? `Владелец: ${profileName}. ` : '') + `Сформировано: ${generated} (Алматы). Суммы в тенге (тг).`, style: 'muted', margin: [0, 2, 0, 10] },
            {
                // В шрифте Roboto нет знака ₸, поэтому в PDF валюта пишется «тг»
                columns: [
                    { stack: [{ text: 'Доходы', style: 'muted' }, { text: fmtMoney(income) + ' тг', style: 'kpi', color: '#1b5e20' }] },
                    { stack: [{ text: 'Расходы', style: 'muted' }, { text: fmtMoney(expense) + ' тг', style: 'kpi', color: '#b71c1c' }] },
                    { stack: [{ text: 'Баланс', style: 'muted' }, { text: fmtMoney(balance) + ' тг', style: 'kpi' }] },
                ],
                margin: [0, 0, 0, 12]
            },
            {
                table: { headerRows: 1, widths: [46, 32, 34, '*', '*', '*', 50, 56], body },
                layout: {
                    hLineWidth: () => 0.5, vLineWidth: () => 0.5,
                    hLineColor: () => '#e3e6ea', vLineColor: () => '#e3e6ea',
                    paddingTop: () => 3, paddingBottom: () => 3
                }
            }
        ],
        footer: (page, pages) => ({ text: `Стр. ${page} из ${pages}`, alignment: 'center', fontSize: 8, color: '#757575', margin: [0, 14, 0, 0] }),
        styles: {
            title: { fontSize: 16, bold: true },
            muted: { fontSize: 8.5, color: '#616161' },
            kpi: { fontSize: 12, bold: true },
            th: { bold: true, color: '#3e4a59', fillColor: '#e6ebf2' }
        }
    };
}

async function exportPdf(options = {}) {
    // 4.17.0: сначала окно выбора периода и категорий (js/exportdlg.js)
    if (!options.list && typeof openExportDialog === 'function') { openExportDialog('pdf'); return; }
    const list = options.list || transactions;
    const rows = buildExportRows(list, options.totalLabel);
    if (rows.length === 0) {
        alert('Нет записей для выгрузки.');
        return;
    }
    // В APK без нативного моста PDF сохранить некуда: сразу показываем таблицу, не заставляя ждать загрузку модуля.
    if (!nativeFileBridge() && isAndroidWebView()) {
        const preview = buildExportPreview(rows);
        showExportSheet({ title: 'PDF (A4)', note: APK_NO_FILES_NOTE, tableHtml: preview.tableHtml, copyText: preview.tsv, retry: null });
        return;
    }
    if (!(await loadPdfLibrary())) {
        alert('Не удалось загрузить модуль PDF. Проверьте подключение к интернету и попробуйте снова.');
        return;
    }
    const fileName = exportFileName('pdf', options.suffix || '');
    let blob;
    try {
        blob = await new Promise((resolve, reject) => {
            try { window.pdfMake.createPdf(buildPdfDefinition(rows, list, options.title || undefined)).getBlob(resolve); } catch (e) { reject(e); }
        });
    } catch (e) {
        console.error(e);
        alert('Ошибка при создании PDF: ' + (e && e.message ? e.message : e));
        return;
    }
    const result = await deliverFile(blob, fileName);
    if (result === 'native') {
        alert(`Файл ${fileName} сохранён.`);
    } else if (result === 'downloaded' && isMobileDevice()) {
        const preview = buildExportPreview(rows);
        showExportSheet({
            title: 'PDF (A4)',
            note: `Файл <b>${escapeHtml(fileName)}</b> отправлен на скачивание. Если он не появился в «Загрузках», скопируйте таблицу ниже.`,
            tableHtml: preview.tableHtml,
            copyText: preview.tsv,
            retry: () => deliverFile(blob, fileName)
        });
    }
}



// Цели (приоритетные вещи) — js/goals.js

function saveSettings() {
    let mLimitEl = document.getElementById('manual-limit');
    manualLimit = mLimitEl ? (parseFloat(mLimitEl.value) || 0) : 0;
    updateUI(true);
    alert('Настройки сохранены!');
}

// Прежние котировки, покупки и цены (разделы убраны в 4.23.0): только хранятся и синхронизируются
const readList = key => { try { const v = JSON.parse(localStorage.getItem(key) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } };
let userQuotes = readList('finance_user_quotes');
let shopList = readList('finance_shop');
let priceRecords = readList('finance_prices');

function saveDataLocally() {
    stampLocalChanges(); // отметки изменений для слияния с аккаунтом (cloud.js)
    try {
        localStorage.setItem('finance_profile_name', profileName);
        localStorage.setItem('finance_oldbook', JSON.stringify(legacyObEntries));
        localStorage.setItem('finance_ob_links', JSON.stringify(legacyObLinks));
        localStorage.setItem('finance_categories', JSON.stringify(customCategories));
        if (typeof saveCustomThemesLocal === 'function') saveCustomThemesLocal(); // свои темы (updatedAt ставит stampLocalChanges)
        if (typeof persistSoundState === 'function') persistSoundState(); // свои звуки, звуки тем, «Мои звуки»
        if (typeof saveGoalsLocal === 'function') saveGoalsLocal();
        localStorage.setItem('finance_user_quotes', JSON.stringify(userQuotes));
        if (typeof saveUiPrefsLocal === 'function') saveUiPrefsLocal();
        localStorage.setItem('finance_shop', JSON.stringify(shopList));
        localStorage.setItem('finance_prices', JSON.stringify(priceRecords));
        localStorage.setItem('finance_tx', JSON.stringify(transactions));
        localStorage.setItem('finance_subs', JSON.stringify(subscriptions));
        localStorage.setItem('finance_savings', savings.toString());
        localStorage.setItem('finance_limit', manualLimit.toString());
        localStorage.setItem('finance_goal', JSON.stringify(priorityGoal));
    } catch(e) {}
}

async function exportBackup() {
    const data = localSnapshot(); // полная копия: записи, подписки, категории, настройки
    const json = JSON.stringify(data);
    const fileName = exportFileName('json', '_backup');
    const result = await deliverFile(new Blob([json], { type: 'application/json' }), fileName);
    if (result === 'native') {
        alert(`Файл ${fileName} сохранён.`);
    } else if ((result === 'downloaded' && isMobileDevice()) || result === 'unsupported') {
        showExportSheet({
            title: 'Локальная копия',
            note: result === 'unsupported'
                ? 'Эта сборка приложения (APK) не умеет сохранять файлы. Скопируйте данные и сохраните их в заметке или в облаке (раздел «Аккаунт»).'
                : `Файл <b>${escapeHtml(fileName)}</b> отправлен на скачивание. Если он не появился, скопируйте данные и сохраните их в заметке или файле с расширением .json.`,
            tableHtml: `<pre class="export-json">${escapeHtml(json.length > 4000 ? json.slice(0, 4000) + '…' : json)}</pre>`,
            copyText: json,
            retry: null
        });
    }
}

function importBackup(e) {
    const file = e.target.files ? e.target.files[0] : null;
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const data = JSON.parse(event.target.result);
            if (!Array.isArray(data.tx) && !Array.isArray(data.subs)) throw new Error('не та копия');
            // добавляем только то, чего здесь нет: имеющиеся записи не удаляются и не меняются
            const add = (cur, extra) => {
                const have = new Set(cur.map(i => String(i.id)));
                const fresh = asList(extra).filter(i => i.id && !have.has(String(i.id)));
                return [cur.concat(fresh), fresh.length];
            };
            let n, s;
            [transactions, n] = add(transactions, data.tx);
            [subscriptions, s] = add(subscriptions, data.subs);
            [customCategories] = add(customCategories, data.cats);
            // прежние цели, котировки, покупки и цены тоже возвращаются (разделов нет, но данные хранятся)
            [goalsList] = add(goalsList, data.goals);
            [userQuotes] = add(userQuotes, data.quotes);
            [shopList] = add(shopList, data.shop);
            [priceRecords] = add(priceRecords, data.prices);
            if (!savings && data.savings) savings = Number(data.savings) || 0;
            if (!manualLimit && data.limit) manualLimit = Number(data.limit) || 0;
            if (!profileName && data.profile && typeof data.profile.name === 'string') profileName = data.profile.name;
            updateUI(true);
            fillProfileInput();
            alert(`Готово: добавлено записей — ${n}, подписок — ${s}. Всего записей: ${transactions.length}.`);
        } catch (err) {
            alert('Не удалось прочитать файл. Нужна копия My Money в формате .json.');
        }
        e.target.value = '';
    };
    reader.readAsText(file);
}

function clearAllData() {
    const warning = 'ВНИМАНИЕ!\n\nБудут удалены ВСЕ данные: записи, подписки, категории, лимит, ПИН-код и настройки оформления'
        + (isCloudConnected() ? ', а также данные в вашем аккаунте и на других устройствах с ним' : '')
        + '.\nВосстановить их будет невозможно.\n\nВы точно хотите всё удалить?';
    if(confirm(warning)) {
        // Вход в аккаунт и служебные данные синхронизации сохраняем, чтобы удаление дошло до облака
        const keep = {};
        [...Object.values(CLOUD_KEYS), ...Object.values(ACCOUNT_KEYS)].forEach(k => { const v = localStorage.getItem(k); if (v !== null) keep[k] = v; });
        localStorage.clear();
        Object.entries(keep).forEach(([k, v]) => localStorage.setItem(k, v));
        profileName = '';
        fillProfileInput();
        savedPin = null;
        bioEnabled = false;
        refreshBiometricUi();
        const removePinBtn = document.getElementById('remove-pin-btn');
        if (removePinBtn) removePinBtn.style.display = 'none';
        transactions = [];
        subscriptions = [];
        savings = 0;
        manualLimit = 0;
        priorityGoal = { name: '', amount: 0, icon: '🎯' };
        legacyObEntries = [];
        legacyObLinks = [];
        customCategories = [];
        if (typeof onCustomThemesChanged === 'function') { customThemes = []; onCustomThemesChanged(); }
        if (typeof clearCustomSoundsLocal === 'function') clearCustomSoundsLocal();
        if (typeof goalsList !== 'undefined') goalsList = [];
        userQuotes = []; shopList = []; priceRecords = [];
        if (typeof setUiPrefs === 'function') setUiPrefs(null);
        renderMenus();
        updateUI(true);
    }
}

function showTab(tabId, btn, navId) {
    if (typeof adminLog === 'function' && tabId !== currentTabId) adminLog('tab', { id: tabId });
    document.querySelectorAll('.tab').forEach(t => {
        t.style.display = 'none';
        t.classList.remove('tab-enter');
    });
    document.querySelectorAll('.sidebar-nav button, .mobile-nav button').forEach(b => {
        if(b.classList.contains('active')) b.classList.remove('active');
    });

    let tabEl = document.getElementById(tabId);
    if (tabEl) {
        // Пустое значение отдаёт раскладку CSS (сетка карточек); класс запускает анимацию появления (0.3 с).
        tabEl.style.display = '';
        void tabEl.offsetWidth;
        tabEl.classList.add('tab-enter');
        // Страховка: снимаем класс после анимации, чтобы карточки не остались прозрачными, если анимации отключены системой.
        clearTimeout(tabEl._enterTimer);
        tabEl._enterTimer = setTimeout(() => tabEl.classList.remove('tab-enter'), 600);
        const mainWrapper = document.querySelector('.main-wrapper');
        if (mainWrapper) mainWrapper.scrollTop = 0;
    }
    
    if (typeof pagesOnTabShown === 'function') pagesOnTabShown(tabId); // 4.9.0: меню Настроек, внутренние страницы (js/pages.js)

    // Подсвечиваем пункт в обоих меню (боковом и нижнем). navId — пункт «блок как страница» (pg:<id блока>), он живёт в том же разделе
    currentTabId = tabId;
    currentNavId = navId || tabId;
    document.querySelectorAll('.sidebar-nav button, .mobile-nav button').forEach(b => {
        if (b.dataset.tab === currentNavId) b.classList.add('active');
    });
}

// --- НАСТРАИВАЕМОЕ МЕНЮ ---
// Порядок и скрытые пункты хранятся в localStorage ('finance_menu'). «Настройки» скрыть нельзя,
// иначе не останется способа вернуть пункты обратно.
const MENU_ITEMS = [
    { id: 'transactions', icon: 'list', label: 'Записи' },
    { id: 'subscriptions', icon: 'autorenew', label: 'Подписки' },
    { id: 'statistics', icon: 'pie_chart', label: 'Статистика' },
    { id: 'reports', icon: 'bar_chart', label: 'Отчёты' },
    { id: 'experimental', icon: 'science', label: 'Экспериментальные функции' }, // 4.18.0: js/experimental.js
    { id: 'settings', icon: 'settings', label: 'Настройки', locked: true }
];
const MENU_KEY = 'finance_menu';
let currentTabId = 'transactions';
let currentNavId = 'transactions'; // выбранный пункт меню

function getMenuState() {
    let state = null;
    try { state = JSON.parse(localStorage.getItem(MENU_KEY) || 'null'); } catch (e) {}
    const known = MENU_ITEMS.map(i => i.id);
    let order = Array.isArray(state && state.order) ? state.order.filter(id => known.includes(id)) : [];
    known.forEach(id => { if (!order.includes(id)) order.push(id); }); // новые пункты из будущих версий
    let hidden = Array.isArray(state && state.hidden) ? state.hidden.filter(id => known.includes(id) && id !== 'settings') : [];
    return { order: [...new Set(order)], hidden: [...new Set(hidden)] };
}

function saveMenuState(state) {
    try { localStorage.setItem(MENU_KEY, JSON.stringify(state)); } catch (e) {}
    renderMenus();
}

function menuItem(id) {
    return MENU_ITEMS.find(i => i.id === id);
}

// Пункты, которые сейчас видны в меню
function menuNavItems(state = getMenuState()) {
    return state.order.filter(id => !state.hidden.includes(id)).map(menuItem).filter(Boolean);
}

function openMenuItem(id, btn) { return showTab(id, btn); }

function renderMenus() {
    const state = getMenuState();
    const visible = menuNavItems(state);
    const navHtml = visible.map(it => {
        const id = it.id;
        const label = it.label;
        return `<button type="button" data-tab="${id}" class="${id === currentNavId ? 'active' : ''}" onclick="openMenuItem('${String(id).replace(/'/g, '')}', this)">` +
            `<span class="material-icons">${it.icon}</span><span class="nav-label">${label}</span></button>`;
    }).join('');
    // Название раздела для огромного заголовка в теме «Метро» (css/metro.css, attr(data-title))
    MENU_ITEMS.forEach(it => { const tab = document.getElementById(it.id); if (tab) tab.dataset.title = it.label.toLowerCase(); });
    const sidebar = document.getElementById('sidebar-nav');
    const mobile = document.getElementById('mobile-nav');
    if (sidebar) sidebar.innerHTML = navHtml;
    if (mobile) {
        mobile.innerHTML = navHtml;
        // 9–10 пунктов — 5 колонок, чтобы нижнее меню осталось в два ряда
        mobile.classList.toggle('nav-wide', visible.length > 8);
        mobile.classList.toggle('nav-xwide', visible.length > 10); // 11–12 пунктов — 6 колонок
    }
    updateMobileNavHeight();
    renderMenuEditor(state);
}

function renderMenuEditor(state = getMenuState()) {
    const list = document.getElementById('menu-editor');
    const hiddenList = document.getElementById('menu-hidden');
    const hiddenWrap = document.getElementById('menu-hidden-wrap');
    if (!list) return;
    list.innerHTML = state.order.filter(id => !state.hidden.includes(id)).map(id => {
        const it = menuItem(id);
        return `<li class="menu-row" data-id="${id}">
            <span class="material-icons drag-handle" title="Перетащить" aria-label="Перетащить">drag_indicator</span>
            <span class="material-icons menu-row-icon">${it.icon}</span>
            <span class="menu-row-label">${it.label}</span>
            ${it.locked
                ? '<span class="material-icons menu-row-lock" title="Этот пункт убрать нельзя">lock</span>'
                : `<button type="button" class="menu-row-btn is-remove" onclick="hideMenuItem('${id}')" aria-label="Убрать из меню"><span class="material-icons">remove_circle_outline</span></button>`}
        </li>`;
    }).join('');
    const hiddenIds = state.hidden;
    if (hiddenList && hiddenWrap) {
        hiddenWrap.style.display = hiddenIds.length ? '' : 'none';
        hiddenList.innerHTML = hiddenIds.map(id => {
            const it = menuItem(id);
            return `<li class="menu-row is-hidden" data-id="${id}">
                <span class="material-icons menu-row-icon">${it.icon}</span>
                <span class="menu-row-label">${it.label}</span>
                <button type="button" class="menu-row-btn is-add" onclick="showMenuItem('${id}')" aria-label="Вернуть в меню"><span class="material-icons">add_circle_outline</span></button>
            </li>`;
        }).join('');
    }
}

function hideMenuItem(id) {
    const state = getMenuState();
    if (id === 'settings' || state.hidden.includes(id)) return;
    state.hidden.push(id);
    saveMenuState(state);
}

function showMenuItem(id) {
    const state = getMenuState();
    state.hidden = state.hidden.filter(h => h !== id);
    // Возвращённый пункт ставим в конец видимого списка
    state.order = state.order.filter(o => o !== id).concat(id);
    saveMenuState(state);
}

function resetMenu() {
    try { localStorage.removeItem(MENU_KEY); } catch (e) {}
    renderMenus();
}

// Высота нижнего меню нужна для отступа контента и положения кнопки синхронизации
function updateMobileNavHeight() {
    const nav = document.getElementById('mobile-nav');
    if (!nav) return;
    requestAnimationFrame(() => {
        const h = nav.offsetHeight;
        if (h > 0) document.documentElement.style.setProperty('--mobile-nav-h', h + 'px');
        // 4.10.0: меню сверху (Настройки → «Разметка и меню»): приложение опускается под меню на его высоту (css/pages.css, раздел 11)
        const root = document.documentElement;
        const top = root.getAttribute('data-menu') === 'top' && root.getAttribute('data-w95') !== 'desk95' && h > 0 && window.innerWidth < 769;
        root.style.setProperty('--top-nav-h', top ? Math.ceil(nav.getBoundingClientRect().bottom) + 'px' : '0px');
    });
}
window.addEventListener('resize', updateMobileNavHeight);

// Перетаскивание пунктов в настройках: Pointer Events (палец, мышь, стилус), только за ручку.
function initMenuDrag() {
    const list = document.getElementById('menu-editor');
    if (!list || list._dragReady) return;
    list._dragReady = true;

    list.addEventListener('pointerdown', (e) => {
        const handle = e.target.closest('.drag-handle');
        if (!handle || (e.pointerType === 'mouse' && e.button !== 0)) return;
        const row = handle.closest('.menu-row');
        const rows = [...list.querySelectorAll('.menu-row')];
        if (rows.length < 2) return;
        e.preventDefault();

        const startIndex = rows.indexOf(row);
        const step = rows[1].getBoundingClientRect().top - rows[0].getBoundingClientRect().top;
        const startY = e.clientY;
        let targetIndex = startIndex;

        row.classList.add('is-dragging');
        list.classList.add('is-sorting');
        try { handle.setPointerCapture(e.pointerId); } catch (err) {}

        const onMove = (ev) => {
            const dy = ev.clientY - startY;
            const minDy = -startIndex * step;
            const maxDy = (rows.length - 1 - startIndex) * step;
            const clamped = Math.max(minDy, Math.min(maxDy, dy));
            row.style.transform = `translateY(${clamped}px)`;
            targetIndex = Math.max(0, Math.min(rows.length - 1, startIndex + Math.round(clamped / step)));
            rows.forEach((r, i) => {
                if (r === row) return;
                let shift = 0;
                if (startIndex < targetIndex && i > startIndex && i <= targetIndex) shift = -step;
                if (startIndex > targetIndex && i < startIndex && i >= targetIndex) shift = step;
                r.style.transform = shift ? `translateY(${shift}px)` : '';
            });
        };

        const onEnd = () => {
            handle.removeEventListener('pointermove', onMove);
            handle.removeEventListener('pointerup', onEnd);
            handle.removeEventListener('pointercancel', onEnd);
            list.classList.remove('is-sorting');
            rows.forEach(r => { r.style.transform = ''; r.classList.remove('is-dragging'); });
            if (targetIndex === startIndex) return;

            const state = getMenuState();
            const visible = rows.map(r => r.dataset.id);
            const [moved] = visible.splice(startIndex, 1);
            visible.splice(targetIndex, 0, moved);
            // Скрытые пункты сохраняют свои места в конце порядка
            state.order = visible.concat(state.order.filter(id => !visible.includes(id)));
            saveMenuState(state);
        };

        handle.addEventListener('pointermove', onMove);
        handle.addEventListener('pointerup', onEnd);
        handle.addEventListener('pointercancel', onEnd);
    });
}

// Полное отключение pull-to-refresh (свайп сверху вниз) в браузере и в обёртке WebIntoApp.
// Нативный SwipeRefreshLayout обёртки срабатывает только при scrollY == 0 у WebView.
// Интерфейс зафиксирован (position: fixed), а корневой документ всегда держится на смещении
// --ptr-guard от верха, поэтому WebView «может прокрутиться вверх» и жест обновления не запускается
// независимо от настроек обёртки.
(function disablePullToRefresh() {
    const guardPx = () => parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ptr-guard')) || 200;
    const rootEl = () => document.scrollingElement || document.documentElement;

    if ('scrollRestoration' in history) history.scrollRestoration = 'manual';

    function keepGuard() {
        const el = rootEl();
        const target = guardPx();
        if (Math.abs(el.scrollTop - target) > 0.5) el.scrollTop = target;
    }

    keepGuard();
    window.addEventListener('scroll', keepGuard, { passive: true });
    ['load', 'pageshow', 'resize', 'orientationchange', 'focus'].forEach(ev => window.addEventListener(ev, keepGuard));
    document.addEventListener('visibilitychange', keepGuard);
    document.addEventListener('touchstart', keepGuard, { passive: true, capture: true });
    document.addEventListener('focusin', () => setTimeout(keepGuard, 0));
    setInterval(keepGuard, 1000);
})();

// Авто-выгрузка статистики каждый день в 23:00
setInterval(() => {
    let [today, hhmm] = almatyIsoNow().split('T');
    if (hhmm.startsWith('23:00')) {
        let lastAuto = localStorage.getItem('finance_lastAutoExport');
        
        if (lastAuto !== today) {
            localStorage.setItem('finance_lastAutoExport', today);
            if (transactions.length > 0) {
                exportExcel({ silent: true }); // Триггерим выгрузку Excel
                scheduleCloudSync(); // Заодно синхронизация с аккаунтом
            }
        }
    }
}, 30000); // Проверяем каждые 30 секунд

// --- СИСТЕМА ЗАСТАВКИ И ПОГОДЫ ---
// Казахстан с 1 марта 2024 года живёт в едином поясе UTC+5. На многих телефонах и в Android WebView
// встроенная база часовых поясов устарела и для Asia/Almaty даёт UTC+6 (на час вперёд),
// поэтому время Алматы считаем от UTC с фиксированным смещением, не завися от настроек устройства.
const ALMATY_UTC_OFFSET_HOURS = 5;

function formatAlmaty(options, date = new Date()) {
    const shifted = new Date(date.getTime() + ALMATY_UTC_OFFSET_HOURS * 3600000);
    // язык дат — из js/i18n.js (ru-RU, en-GB, kk-KZ, fr-FR, de-DE)
    const s = new Intl.DateTimeFormat(window.APP_LOCALE || 'ru-RU', { timeZone: 'UTC', ...options }).format(shifted);
    return typeof window.APP_DATE_FIX === 'function' ? window.APP_DATE_FIX(s) : s; // казахские месяцы, если браузер их не знает
}

// Текущие дата и время Алматы в формате 'YYYY-MM-DDTHH:MM' (для полей ввода и записей).
function almatyIsoNow(dayShift = 0) {
    return new Date(Date.now() + ALMATY_UTC_OFFSET_HOURS * 3600000 + dayShift * 86400000).toISOString().slice(0, 16);
}

function capitalizeRu(str) {
    return str ? str.charAt(0).toLocaleUpperCase('ru-RU') + str.slice(1) : str;
}

const RATE_SOURCES = [
    { url: 'https://latest.currency-api.pages.dev/v1/currencies/kzt.json', parse: d => ({ usd: 1 / d.kzt.usd, eur: 1 / d.kzt.eur, rub: 1 / d.kzt.rub, date: d.date }) },
    { url: 'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/kzt.json', parse: d => ({ usd: 1 / d.kzt.usd, eur: 1 / d.kzt.eur, rub: 1 / d.kzt.rub, date: d.date }) },
    { url: 'https://open.er-api.com/v6/latest/KZT', parse: d => ({ usd: 1 / d.rates.USD, eur: 1 / d.rates.EUR, rub: 1 / d.rates.RUB, date: new Date(d.time_last_update_unix * 1000).toISOString().slice(0, 10) }) }
];
let ratesRequestInFlight = false;

async function fetchRates() {
    if (ratesRequestInFlight) return;
    ratesRequestInFlight = true;
    try {
        for (const source of RATE_SOURCES) {
            try {
                const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
                const timer = controller ? setTimeout(() => controller.abort(), 10000) : null;
                const response = await fetch(source.url, { cache: 'no-store', ...(controller ? { signal: controller.signal } : {}) });
                if (timer) clearTimeout(timer);
                if (!response.ok) throw new Error('HTTP ' + response.status);
                const rates = source.parse(await response.json());
                if (![rates.usd, rates.eur, rates.rub].every(v => Number.isFinite(v) && v > 0)) throw new Error('Пустые курсы');
                localStorage.setItem('finance_rates', JSON.stringify(rates));
                return;
            } catch (e) {
                console.warn('Источник курсов недоступен:', source.url, e);
            }
        }
    } finally {
        ratesRequestInFlight = false;
    }
}

setTimeout(fetchRates, 400);
setInterval(fetchRates, 30 * 60 * 1000); // курсы валют: каждые 30 минут
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') fetchRates(); });
window.addEventListener('online', fetchRates);

// --- СИСТЕМА ПИН-КОДА И БИОМЕТРИИ ---
let currentPinInput = "";
let savedPin = localStorage.getItem('finance_pin');
let bioEnabled = localStorage.getItem('finance_bio') === 'true';
let pinUnlocked = false; // ПИН уже введён в этот запуск — второй раз не спрашиваем

// Полностью убирает экран ПИН-кода (и после ввода ПИН, и после отпечатка).
function hidePinScreen(delay) {
    pinUnlocked = true;
    const pinScreen = document.getElementById('pin-screen');
    if (!pinScreen) return;
    pinScreen.style.opacity = '0';
    pinScreen.style.pointerEvents = 'none'; // пока тает — не перехватывает нажатия
    setTimeout(() => { pinScreen.style.display = 'none'; }, delay);
}

// Если задан ПИН-код, он спрашивается сразу при открытии
function showPinIfNeeded() {
    if (!savedPin || pinUnlocked) return;
    const pinScreen = document.getElementById('pin-screen');
    pinScreen.style.opacity = '';
    pinScreen.style.pointerEvents = '';
    pinScreen.style.display = 'flex';
    if (bioEnabled) {
        document.getElementById('bio-login-btn').style.visibility = 'visible';
        loginWithBiometrics();
    }
}

function addPinDigit(d) {
    if(currentPinInput.length < 4) {
        currentPinInput += d;
        updatePinDots();
        if(currentPinInput.length === 4) setTimeout(checkPin, 100);
    }
}

function deletePinDigit() {
    currentPinInput = currentPinInput.slice(0, -1);
    updatePinDots();
}

function updatePinDots() {
    let dots = document.querySelectorAll('#pin-dots .dot');
    dots.forEach((dot, i) => {
        dot.classList.toggle('filled', i < currentPinInput.length);
    });
}

function checkPin() {
    if (currentPinInput === savedPin) {
        playSound('success');
        hidePinScreen(400);
    } else {
        playSound('error');
        alert('Неверный ПИН-код!');
        currentPinInput = "";
        updatePinDots();
    }
}

function savePin() {
    let p = document.getElementById('new-pin').value;
    if(p.length === 4 && /^\d+$/.test(p)) {
        localStorage.setItem('finance_pin', p);
        savedPin = p;
        alert('ПИН-код успешно установлен!');
        document.getElementById('remove-pin-btn').style.display = 'inline-flex';
        document.getElementById('new-pin').value = '';
    } else {
        alert('ПИН-код должен состоять ровно из 4 цифр!');
    }
}

function removePin() {
    if(confirm('Вы уверены, что хотите удалить ПИН-код и защиту входа?')) {
        localStorage.removeItem('finance_pin');
        localStorage.removeItem('finance_bio');
        localStorage.removeItem(BIO_CRED_KEY);
        savedPin = null;
        bioEnabled = false;
        refreshBiometricUi();
        alert('Защита удалена!');
        document.getElementById('remove-pin-btn').style.display = 'none';
    }
}

// Биометрия (отпечаток пальца / Face ID) через WebAuthn.
// Работает там, где страница открыта в защищённом контексте (https или localhost) и браузер/обёртка
// поддерживает WebAuthn: Chrome и Samsung Internet на Android, Safari на iPhone, Chrome/Edge на ПК
// с Windows Hello. Обычный Android WebView (WebIntoApp и др.) отдаёт WebAuthn странице только если
// это включено в самом приложении-обёртке; иначе показываем понятное объяснение, а вход по ПИН работает всегда.
const BIO_CRED_KEY = 'finance_bio_cred';

function bytesToB64url(bytes) {
    let bin = '';
    new Uint8Array(bytes).forEach(b => { bin += String.fromCharCode(b); });
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function b64urlToBytes(str) {
    const b64 = str.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((str.length + 3) % 4);
    return Uint8Array.from(atob(b64), c => c.charCodeAt(0));
}

function randomBytes(n) {
    const arr = new Uint8Array(n);
    window.crypto.getRandomValues(arr);
    return arr;
}

// Возвращает { ok: true } или { ok: false, reason: '...' } с человеческим объяснением.
async function checkBiometricSupport() {
    if (window.MMApp) { // приложение Android: системное окно отпечатка
        const why = window.MMApp.bioStatus();
        return why ? { ok: false, reason: why } : { ok: true };
    }
    if (!window.isSecureContext) {
        return { ok: false, reason: 'Приложение открыто не через защищённое соединение (https), а в таком режиме система не даёт доступ к отпечатку. Так бывает, когда приложение собрано из ZIP-архива во встроенном окне Android.' };
    }
    if (!window.PublicKeyCredential || !navigator.credentials || !navigator.credentials.create) {
        return { ok: false, reason: 'Встроенное окно приложения (Android WebView) не передаёт странице доступ к сканеру отпечатка. Его должна разрешить сама обёртка приложения (WebIntoApp).' };
    }
    try {
        if (typeof PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function'
            && !(await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable())) {
            return { ok: false, reason: 'На устройстве не настроен отпечаток пальца / Face ID / Windows Hello, либо экран блокировки не защищён. Добавьте отпечаток в настройках телефона и попробуйте снова.' };
        }
    } catch (e) {}
    return { ok: true };
}

async function refreshBiometricUi() {
    // 4.16.0: тумблер «Вход по отпечатку» вместо кнопки
    const sw = document.getElementById('bio-sw');
    const rebind = document.getElementById('bio-rebind-btn');
    const hint = document.getElementById('bio-hint');
    if (!sw) return;
    const support = await checkBiometricSupport();
    sw.checked = bioEnabled && support.ok;
    sw.disabled = !support.ok;
    if (rebind) rebind.style.display = bioEnabled && support.ok ? '' : 'none';
    if (hint) {
        hint.textContent = support.ok ? '' : 'Вход по отпечатку недоступен: ' + support.reason + ' Вход по ПИН-коду работает всегда.';
        hint.style.display = support.ok ? 'none' : 'block';
    }
}

// Тумблер «Вход по отпечатку»: включить — привязать отпечаток, выключить — забыть привязку (ПИН-код остаётся)
async function bioSwitch(on) {
    if (on) { await registerBiometrics(); refreshBiometricUi(); return; }
    localStorage.removeItem('finance_bio');
    try { localStorage.removeItem(BIO_CRED_KEY); } catch (e) {}
    bioEnabled = false;
    refreshBiometricUi();
}

async function registerBiometrics() {
    if (!savedPin) {
        alert('Сначала установите цифровой ПИН-код!');
        return;
    }
    const support = await checkBiometricSupport();
    if (!support.ok) {
        alert('Вход по отпечатку недоступен.\n\n' + support.reason + '\n\nВход по ПИН-коду продолжит работать.');
        return;
    }
    if (window.MMApp) {
        if (await window.mmBioAsk('Привязать отпечаток')) {
            localStorage.setItem('finance_bio', 'true');
            bioEnabled = true;
            refreshBiometricUi();
            alert('Отпечаток успешно привязан! Теперь на экране ПИН-кода можно входить по отпечатку.');
        }
        return;
    }
    try {
        const publicKey = {
            challenge: randomBytes(32),
            rp: { name: 'Money Pro' },
            user: { id: randomBytes(16), name: 'moneypro-user', displayName: 'Money Pro' },
            pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
            authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required', residentKey: 'preferred' },
            attestation: 'none',
            timeout: 60000
        };
        const credential = await navigator.credentials.create({ publicKey });
        if (credential) {
            // Сохраняем id ключа: без него вход (credentials.get) не находит отпечаток на большинстве Android.
            localStorage.setItem(BIO_CRED_KEY, bytesToB64url(credential.rawId));
            localStorage.setItem('finance_bio', 'true');
            bioEnabled = true;
            refreshBiometricUi();
            alert('Отпечаток успешно привязан! Теперь на экране ПИН-кода можно входить по отпечатку.');
        }
    } catch (e) {
        console.error(e);
        const name = e && e.name;
        if (name === 'NotAllowedError' || name === 'AbortError') {
            alert('Привязка отпечатка отменена.');
        } else if (name === 'SecurityError') {
            alert('Система запретила доступ к отпечатку для этого адреса приложения. Вход по ПИН-коду продолжит работать.');
        } else {
            alert('Не удалось привязать отпечаток: ' + (e && e.message ? e.message : name || 'неизвестная ошибка'));
        }
    }
}

let bioLoginInFlight = false;

async function loginWithBiometrics() {
    if (bioLoginInFlight) return;
    const support = await checkBiometricSupport();
    if (!support.ok) {
        const bioBtn = document.getElementById('bio-login-btn');
        if (bioBtn) bioBtn.style.visibility = 'hidden';
        return;
    }
    bioLoginInFlight = true;
    try {
        if (window.MMApp) {
            if (await window.mmBioAsk('Вход в My Money')) hidePinScreen(300);
            return;
        }
        const credId = localStorage.getItem(BIO_CRED_KEY);
        const publicKey = {
            challenge: randomBytes(32),
            timeout: 60000,
            userVerification: 'required',
            ...(credId ? { allowCredentials: [{ type: 'public-key', id: b64urlToBytes(credId), transports: ['internal', 'hybrid'] }] } : {})
        };
        const credential = await navigator.credentials.get({ publicKey });
        if (credential) {
            hidePinScreen(300);
        }
    } catch(e) {
        console.log('Биометрия отменена или не удалась', e);
    } finally {
        bioLoginInFlight = false;
    }
}

// Подгрузка ПИНа и меню при запуске
window.addEventListener('DOMContentLoaded', () => {
    if(localStorage.getItem('finance_pin')) {
        let btn = document.getElementById('remove-pin-btn');
        if(btn) btn.style.display = 'inline-flex';
    }
    refreshBiometricUi();
    renderMenus();
    initMenuDrag();
    const verEl = document.getElementById('app-version-now');
    if (verEl) verEl.textContent = window.APP_VERSION || '—';
    // подпись внизу Настроек: версия, её название и год обновления (js/admin.js); на других языках текст свой
    [['app-footer-ver', window.APP_VERSION], ['app-footer-name', window.APP_VERSION_NAME], ['app-footer-year', window.APP_YEAR]].forEach(([id, v]) => {
        const el = document.getElementById(id);
        if (el && v) el.textContent = v;
    });
    const foot = document.getElementById('app-footer');
    if (foot && typeof appLang !== 'undefined') {
        const v = window.APP_VERSION || '', y = window.APP_YEAR || '';
        const T = {
            en: `My Money · version <b>${v}</b> “Extra” · updated in <b>${y}</b>`,
            kk: `My Money · <b>${v}</b> нұсқасы «Экстра» · <b>${y}</b> жылы жаңартылды`,
            fr: `My Money · version <b>${v}</b> « Extra » · mise à jour en <b>${y}</b>`,
            de: `My Money · Version <b>${v}</b> „Extra“ · aktualisiert <b>${y}</b>`
        };
        if (T[appLang]) foot.innerHTML = T[appLang];
    }

    showPinIfNeeded();
});

// Сумма в тенге для подписей
function fmtTenge(n) {
    return Math.round(Number(n) || 0).toLocaleString('ru-RU') + ' ₸';
}

// --- КАТЕГОРИИ (4.14.0) ---
// Все категории — свои: customCategories = [{ id, name, parent? }]. parent — id раздела: так делаются подкатегории
// («Семья» → «Отец», «Мать», «Коты»). В записи подкатегория хранится как «Семья: Отец» — статистика складывает её в «Семья»,
// картинка без своей берётся у раздела. У нового пользователя категорий нет совсем. Их можно менять и удалять.
function showCategories() {
    filterCategories();
    let drop = document.getElementById('category-dropdown');
    if (drop && drop.children.length) drop.style.display = 'block';
}

function hideCategories() {
    setTimeout(() => {
        let drop = document.getElementById('category-dropdown');
        if (drop) drop.style.display = 'none';
    }, 200);
}

const CAT_SEP = ': ';
function catClean(raw) { return String(raw || '').replace(/[:]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 40); }
function catById(id) { return customCategories.find(c => c && c.id === id) || null; }
// Раздел — категория без родителя (или с потерянным родителем)
function catIsTop(c) { return !c.parent || !catById(c.parent); }
function catTops() { return customCategories.filter(c => c && c.name && catIsTop(c)); }
function catChildren(id) { return customCategories.filter(c => c && c.name && c.parent === id && catById(id)); }
function catFullName(c) { return catIsTop(c) ? c.name : catById(c.parent).name + CAT_SEP + c.name; }

// Названия в порядке «раздел, его подкатегории, следующий раздел…»
function customCategoryNames() {
    const out = [];
    catTops().forEach(p => { out.push(p.name); catChildren(p.id).forEach(ch => out.push(p.name + CAT_SEP + ch.name)); });
    return out;
}

function allCategories(defaults = []) {
    const seen = new Set();
    return customCategoryNames().concat(defaults || []).filter(name => {
        const key = String(name).toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function catNewId() { return 'cat' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }

// parentId — id раздела ('' — новый раздел). «Семья: Отец», набранное в поле записи, тоже создаёт подкатегорию.
function addCustomCategory(rawName, { silent = false, parent = '' } = {}) {
    let raw = String(rawName || '');
    if (!parent && raw.includes(':')) {
        const [pName, ...rest] = raw.split(':');
        const pn = catClean(pName), cn = catClean(rest.join(' '));
        if (pn && cn) {
            let p = catTops().find(c => c.name.toLowerCase() === pn.toLowerCase());
            if (!p) { p = { id: catNewId(), name: pn }; customCategories.push(p); }
            parent = p.id; raw = cn;
        }
    }
    const name = catClean(raw);
    if (!name) {
        if (!silent) alert('Введите название категории.');
        return false;
    }
    const siblings = parent ? catChildren(parent) : catTops();
    if (siblings.some(c => c.name.toLowerCase() === name.toLowerCase())) {
        if (!silent) showToast(`Категория «${name}» уже есть`);
        return false;
    }
    customCategories.push(parent ? { id: catNewId(), name, parent } : { id: catNewId(), name });
    updateUI(true);
    if (!silent) showToast(parent ? `Подкатегория «${name}» добавлена в «${catById(parent).name}»` : `Категория «${name}» добавлена`);
    return true;
}

function addCategoryFromSettings() {
    const input = document.getElementById('new-category');
    const sel = document.getElementById('new-category-parent');
    if (addCustomCategory(input ? input.value : '', { parent: sel ? sel.value : '' }) && input) input.value = '';
}

// Переименование: меняется и в уже сделанных записях, картинка переезжает вместе с названием
function catRenameEverywhere(oldFull, newFull) {
    if (oldFull === newFull) return;
    const ok = String(oldFull).toLowerCase();
    transactions.forEach(t => {
        const c = String(t.category || '');
        if (c.toLowerCase() === ok) t.category = newFull;
        else if (c.toLowerCase().startsWith(ok + ':')) t.category = newFull + c.slice(oldFull.length);
    });
    if (typeof catKey === 'function' && typeof uiPrefs !== 'undefined') {
        ['form', 'history'].forEach(set => {
            const m = uiPrefs.catIcons[set] || {};
            const ko = catKey(oldFull), kn = catKey(newFull);
            if (typeof m[ko] === 'string') { m[kn] = m[ko]; delete m[ko]; }
        });
    }
}

function editCustomCategory(id) {
    const cat = catById(id);
    if (!cat) return;
    closeCatEditor();
    const kids = catChildren(cat.id);
    const parents = catTops().filter(p => p.id !== cat.id);
    const full = catFullName(cat);
    const em = typeof categoryEmoji === 'function' ? categoryEmoji(full, 'form') : '';
    const overlay = document.createElement('div');
    overlay.id = 'cat-editor';
    overlay.className = 'export-sheet-overlay';
    overlay.innerHTML = `
        <div class="export-sheet cat-editor" role="dialog" aria-modal="true" aria-label="Изменить категорию">
            <div class="export-sheet-head">
                <h3>Изменить категорию</h3>
                <button type="button" class="export-sheet-close" data-act="close" aria-label="Закрыть"><span class="material-icons">close</span></button>
            </div>
            <div class="ce-row">
                <button type="button" class="ce-emoji" data-act="emoji" aria-label="Картинка категории" title="Картинка категории">${em ? `<span class="sys-emoji">${em}</span>` : '<span class="material-icons">block</span>'}</button>
                <input type="text" id="ce-name" maxlength="40" value="${escapeHtml(cat.name)}" aria-label="Название">
            </div>
            <label class="field-inline ce-parent"><span>Раздел</span>
                <select id="ce-parent" ${kids.length ? 'disabled title="У категории есть подкатегории — она сама остаётся разделом"' : ''}>
                    <option value="">— нет (это раздел) —</option>
                    ${parents.map(p => `<option value="${escapeHtml(p.id)}"${p.id === cat.parent ? ' selected' : ''}>${escapeHtml(p.name)}</option>`).join('')}
                </select>
            </label>
            <p class="hint">Новое название появится и в уже сделанных записях.${kids.length ? ` Подкатегорий: ${kids.length}.` : ''}</p>
            <div class="export-sheet-actions">
                <button type="button" class="btn-secondary" data-act="delete"><span class="material-icons">delete</span> Удалить</button>
                <button type="button" class="btn-primary" data-act="save"><span class="material-icons">save</span> Сохранить</button>
            </div>
        </div>`;
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay || e.target.closest('[data-act="close"]')) { closeCatEditor(true); return; }
        const act = e.target.closest('[data-act]');
        if (!act) return;
        if (act.dataset.act === 'emoji') { closeCatEditor(); openEmojiPicker('both', full); return; }
        if (act.dataset.act === 'delete') { closeCatEditor(); deleteCustomCategory(cat.id); return; }
        if (act.dataset.act === 'save') {
            const name = catClean(document.getElementById('ce-name').value);
            const parent = kids.length ? '' : (document.getElementById('ce-parent').value || '');
            if (!name) { alert('Введите название категории.'); return; }
            const siblings = (parent ? catChildren(parent) : catTops()).filter(c => c.id !== cat.id);
            if (siblings.some(c => c.name.toLowerCase() === name.toLowerCase())) { alert(`Категория «${name}» там уже есть.`); return; }
            const oldFull = catFullName(cat);
            const oldKids = kids.map(k => [k, catFullName(k)]);
            cat.name = name;
            if (parent) cat.parent = parent; else delete cat.parent;
            catRenameEverywhere(oldFull, catFullName(cat));
            oldKids.forEach(([k, old]) => catRenameEverywhere(old, catFullName(k)));
            closeCatEditor(true);
            updateUI(true);
            if (typeof commitUiPrefs === 'function') commitUiPrefs();
            showToast('Категория сохранена');
        }
    });
    document.body.appendChild(overlay);
    const inp = document.getElementById('ce-name');
    if (inp) { inp.addEventListener('keydown', ev => { if (ev.key === 'Enter') overlay.querySelector('[data-act="save"]').click(); }); setTimeout(() => inp.focus(), 50); }
    if (typeof playSound === 'function') playSound('open');
}

function closeCatEditor(withSound) {
    const el = document.getElementById('cat-editor');
    if (!el) return;
    el.remove();
    if (withSound && typeof playSound === 'function') playSound('close');
}

function deleteCustomCategory(id) {
    const cat = catById(id);
    if (!cat) return;
    const kids = catChildren(cat.id);
    const msg = kids.length
        ? `Удалить раздел «${cat.name}» и его подкатегории (${kids.map(k => k.name).join(', ')})? Уже сделанные записи с ними не изменятся.`
        : `Удалить категорию «${catFullName(cat)}»? Уже сделанные записи с ней не изменятся.`;
    if (!confirm(msg)) return;
    const gone = new Set([cat.id, ...kids.map(k => k.id)]);
    customCategories = customCategories.filter(c => !gone.has(c.id));
    updateUI(true);
}

function addSubcategoryPrompt(parentId) {
    const p = catById(parentId);
    if (!p) return;
    const name = prompt(`Новая подкатегория в «${p.name}»:`, '');
    if (name !== null) addCustomCategory(name, { parent: p.id });
}

function renderCategorySettings() {
    const list = document.getElementById('custom-categories');
    const sel = document.getElementById('new-category-parent');
    const tops = catTops();
    if (sel) {
        const cur = sel.value;
        sel.innerHTML = '<option value="">Новый раздел</option>' + tops.map(p => `<option value="${escapeHtml(p.id)}">В раздел «${escapeHtml(p.name)}»</option>`).join('');
        if (tops.some(p => p.id === cur)) sel.value = cur;
    }
    if (!list) return;
    const emo = full => {
        const e = typeof categoryEmoji === 'function' ? categoryEmoji(full, 'form') : '';
        return `<button type="button" class="cm-emoji" data-cat="${escapeHtml(full)}" onclick="openEmojiPicker('both', this.dataset.cat)" title="Картинка" aria-label="Картинка для «${escapeHtml(full)}»">${e ? `<span class="sys-emoji">${e}</span>` : '<span class="material-icons">block</span>'}</button>`;
    };
    const row = (c, full, isSub) => `<div class="cm-row${isSub ? ' is-sub' : ''}">${emo(full)}<span class="cm-name">${escapeHtml(c.name)}</span>` +
        (isSub ? '' : `<button type="button" class="cm-btn" onclick="addSubcategoryPrompt('${escapeHtml(c.id)}')" title="Добавить подкатегорию" aria-label="Добавить подкатегорию в «${escapeHtml(c.name)}»"><span class="material-icons">add</span></button>`) +
        `<button type="button" class="cm-btn" onclick="editCustomCategory('${escapeHtml(c.id)}')" title="Изменить" aria-label="Изменить «${escapeHtml(full)}»"><span class="material-icons">edit</span></button>` +
        `<button type="button" class="cm-btn cm-del" onclick="deleteCustomCategory('${escapeHtml(c.id)}')" title="Удалить" aria-label="Удалить «${escapeHtml(full)}»"><span class="material-icons">delete</span></button></div>`;
    list.innerHTML = tops.length
        ? tops.map(p => `<div class="cm-group">${row(p, p.name, false)}${catChildren(p.id).map(ch => row(ch, p.name + CAT_SEP + ch.name, true)).join('')}</div>`).join('')
        : '<p class="hint cm-empty">Категорий пока нет. Добавьте первую: например раздел «Семья», а в нём подкатегории «Отец», «Мать», «Коты».</p>';
}

function filterCategories() {
    let catInput = document.getElementById('category');
    let drop = document.getElementById('category-dropdown');
    if (!catInput || !drop) return;

    const typed = catInput.value.trim();
    let input = typed.toLowerCase();
    drop.innerHTML = '';

    const all = allCategories();
    let filtered = all.filter(c => c.toLowerCase().includes(input));
    const customSet = new Set(customCategoryNames().map(c => c.toLowerCase()));

    filtered.forEach(c => {
        let div = document.createElement('div');
        div.className = 'dropdown-item' + (customSet.has(c.toLowerCase()) ? ' is-custom' : '');
        div.textContent = c;
        div.onclick = function() {
            catInput.value = c;
            drop.style.display = 'none';
        };
        drop.appendChild(div);
    });

    // Своя категория прямо из списка: «+ Добавить "…" в мои категории»
    if (typed && !all.some(c => c.toLowerCase() === input)) {
        let add = document.createElement('div');
        add.className = 'dropdown-item dropdown-add';
        add.innerHTML = `<span class="material-icons">add</span> Добавить «${escapeHtml(typed.slice(0, 60))}» в категории`;
        // mousedown срабатывает раньше, чем поле теряет фокус и список скрывается
        add.onmousedown = function(e) { e.preventDefault(); };
        add.onclick = function() {
            addCustomCategory(typed);
            catInput.value = typed.includes(':') ? typed.split(':').map(catClean).filter(Boolean).slice(0, 2).join(CAT_SEP) : catClean(typed);
            drop.style.display = 'none';
        };
        drop.appendChild(add);
    }

    drop.style.display = drop.children.length ? 'block' : 'none';
    renderCategoryTiles(); // подсветка выбранной плитки-картинки
}
