// Номер версии приложения
window.APP_VERSION = window.APP_VERSION || '4.23.0';
window.APP_VERSION_NAME = window.APP_VERSION_NAME || 'Экстра'; // название версии (подпись внизу Настроек)
window.APP_YEAR = window.APP_YEAR || 2026;                  // год обновления
