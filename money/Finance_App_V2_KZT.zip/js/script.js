
let transactions = [];
let priorityGoal = { name: '', amount: 0, icon: '🎯' };
let manualLimit = 0;
let savings = 0;
let chartInstance = null;

function init() {
    loadData();
    checkDailyRollover();
    
    // Установка сегодняшней даты в форму
    document.getElementById('tx-date').value = new Date().toISOString().split('T')[0];
    
    // Инициализация иконок
    document.querySelectorAll('.icon-btn').forEach(btn => {
        btn.onclick = (e) => {
            document.querySelectorAll('.icon-btn').forEach(b => b.classList.remove('selected'));
            e.target.classList.add('selected');
        }
    });

    updateUI();
}

function loadData() {
    const dTx = localStorage.getItem('finance_tx');
    const dGoal = localStorage.getItem('finance_goal');
    const dLimit = localStorage.getItem('finance_limit');
    const dSavings = localStorage.getItem('finance_savings');
    const dTheme = localStorage.getItem('finance_theme');

    if (dTx) transactions = JSON.parse(dTx);
    if (dGoal) priorityGoal = JSON.parse(dGoal);
    if (dLimit) manualLimit = parseFloat(dLimit);
    if (dSavings) savings = parseFloat(dSavings);
    
    if (dTheme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
        document.getElementById('theme-icon').innerText = 'light_mode';
    }

    document.getElementById('manual-limit').value = manualLimit > 0 ? manualLimit : '';
}

function toggleTheme() {
    const root = document.documentElement;
    const isDark = root.getAttribute('data-theme') === 'dark';
    root.setAttribute('data-theme', isDark ? 'light' : 'dark');
    document.getElementById('theme-icon').innerText = isDark ? 'dark_mode' : 'light_mode';
    localStorage.setItem('finance_theme', isDark ? 'light' : 'dark');
    updateChart();
}

function checkDailyRollover() {
    const today = new Date().toISOString().split('T')[0];
    let lastDate = localStorage.getItem('finance_lastDate');
    
    if (!lastDate) {
        localStorage.setItem('finance_lastDate', today);
        return;
    }
    
    if (lastDate !== today && manualLimit > 0) {
        let dayExpenses = transactions
            .filter(t => t.date === lastDate && t.type === 'expense' && !t.isSystem)
            .reduce((sum, t) => sum + t.amount, 0);
            
        let saved = manualLimit - dayExpenses;
        
        if (saved > 0 && priorityGoal.amount > 0) {
            savings += saved;
            transactions.push({
                id: Date.now().toString(),
                type: 'expense',
                amount: saved,
                category: 'Автоперенос в копилку (остаток лимита)',
                date: lastDate,
                isSystem: true
            });
            sendNotification("Перевод в копилку", `Вчера вы сэкономили ${saved} ₸, они отправлены на цель!`);
        }
        localStorage.setItem('finance_lastDate', today);
    }
}

function updateUI() {
    saveDataLocally();

    // Общий баланс
    let balance = transactions.reduce((acc, tx) => tx.type === 'income' ? acc + tx.amount : acc - tx.amount, 0);
    document.getElementById('balance').innerText = `${balance.toFixed(0)} ₸`;
    document.getElementById('savings').innerText = `${savings.toFixed(0)} ₸`;
    document.getElementById('daily-limit-display').innerText = manualLimit > 0 ? `${manualLimit} ₸` : 'Не установлен';

    renderTransactions();
    renderGoal();
    updateChart();
    renderAnalyticsTable();
}

function renderTransactions() {
    const txList = document.getElementById('tx-list');
    txList.innerHTML = '';
    
    if (transactions.length === 0) {
        txList.innerHTML = '<p class="hint" style="text-align:center;">Записей пока нет</p>';
        return;
    }

    // Сортировка по дате (по возрастанию для расчета баланса)
    let sortedAsc = [...transactions].sort((a,b) => new Date(a.date) - new Date(b.date));
    
    // Группировка и расчет баланса
    let groups = {};
    let runBalance = 0;
    
    sortedAsc.forEach(tx => {
        runBalance += (tx.type === 'income' ? tx.amount : -tx.amount);
        
        if(!groups[tx.date]) {
            groups[tx.date] = { income: 0, expense: 0, endBalance: 0, items: [] };
        }
        
        if(!tx.isSystem) {
            if(tx.type === 'income') groups[tx.date].income += tx.amount;
            else groups[tx.date].expense += tx.amount;
        }
        groups[tx.date].endBalance = runBalance;
        groups[tx.date].items.push(tx);
    });

    // Отрисовка с конца (новые сверху)
    let datesDesc = Object.keys(groups).sort((a,b) => new Date(b) - new Date(a));
    
    datesDesc.forEach(date => {
        let g = groups[date];
        let [y, m, d] = date.split('-');
        let fDate = `${d}.${m}.${y}`;
        
        let header = document.createElement('div');
        header.className = 'date-group-header';
        header.innerHTML = `
            <h4>${fDate}</h4>
            <p>
                <span style="color:var(--income)">+${g.income}</span> 
                <span style="color:var(--expense)">-${g.expense}</span> 
                <span>Итог дня: <strong>${g.endBalance} ₸</strong></span>
            </p>
        `;
        txList.appendChild(header);
        
        // Транзакции внутри дня тоже задом наперед
        let itemsDesc = g.items.reverse();
        itemsDesc.forEach(tx => {
            let sign = tx.type === 'income' ? '+' : '-';
            let div = document.createElement('div');
            div.className = `tx-item ${tx.type}`;
            div.innerHTML = `
                <div class="tx-info">
                    <strong>${tx.category}</strong>
                </div>
                <strong>${sign}${tx.amount} ₸</strong>
                ${tx.isSystem ? '' : `
                <div class="tx-actions">
                    <button onclick="editTx('${tx.id}')"><span class="material-icons" style="font-size:16px;">edit</span></button>
                    <button onclick="deleteTx('${tx.id}')"><span class="material-icons" style="font-size:16px; color:#f44336;">delete</span></button>
                </div>
                `}
            `;
            txList.appendChild(div);
        });
    });
}

function saveTx(type) {
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;
    const date = document.getElementById('tx-date').value;
    
    if (!amount || !category || !date) {
        alert('Заполните все поля!');
        return;
    }
    
    transactions.push({ id: Date.now().toString(), type, amount, category, date });
    
    // Проверка лимита
    if (type === 'expense' && manualLimit > 0) {
        let todayExp = transactions
            .filter(t => t.date === date && t.type === 'expense' && !t.isSystem)
            .reduce((sum, t) => sum + t.amount, 0);
            
        if (todayExp > manualLimit) {
            sendNotification("Превышен лимит!", `Вы потратили ${todayExp} ₸, что больше дневного лимита (${manualLimit} ₸).`);
        }
    }

    clearForm();
    updateUI();
}

function deleteTx(id) {
    if(confirm("Точно удалить запись?")) {
        transactions = transactions.filter(t => t.id !== id);
        updateUI();
    }
}

function editTx(id) {
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        document.getElementById('edit-id').value = tx.id;
        document.getElementById('tx-date').value = tx.date;
        document.getElementById('amount').value = tx.amount;
        document.getElementById('category').value = tx.category;
        
        document.getElementById('add-btns').style.display = 'none';
        document.getElementById('save-edit-btn').style.display = 'flex';
        showTab('transactions', document.querySelector('.tabs button'));
        window.scrollTo(0, 0);
    }
}

function saveEdit() {
    const id = document.getElementById('edit-id').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;
    const date = document.getElementById('tx-date').value;
    
    if (!amount || !category || !date) return;
    
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        tx.amount = amount;
        tx.category = category;
        tx.date = date;
    }
    
    clearForm();
    updateUI();
}

function clearForm() {
    document.getElementById('amount').value = '';
    document.getElementById('category').value = '';
    document.getElementById('edit-id').value = '';
    document.getElementById('add-btns').style.display = 'flex';
    document.getElementById('save-edit-btn').style.display = 'none';
    document.getElementById('tx-date').value = new Date().toISOString().split('T')[0];
}

function setPriorityGoal() {
    const name = document.getElementById('goal-name').value;
    const amount = parseFloat(document.getElementById('goal-amount').value);
    const icon = document.querySelector('.icon-btn.selected').getAttribute('data-icon');
    
    if (!name || !amount) return;
    priorityGoal = { name, amount, icon };
    updateUI();
}

function renderGoal() {
    const gd = document.getElementById('current-goal-display');
    if (priorityGoal.name && priorityGoal.amount > 0) {
        let percent = Math.min(100, (savings / priorityGoal.amount) * 100);
        gd.innerHTML = `
            <h4>${priorityGoal.icon} ${priorityGoal.name}</h4>
            <p>Собрано: ${savings.toFixed(0)} ₸ из ${priorityGoal.amount} ₸ (${percent.toFixed(1)}%)</p>
            <div class="goal-progress">
                <div class="goal-bar" style="width: ${percent}%"></div>
            </div>
        `;
    }
}

function saveSettings() {
    const l = parseFloat(document.getElementById('manual-limit').value);
    manualLimit = isNaN(l) ? 0 : l;
    updateUI();
    alert('Настройки сохранены!');
}

function saveDataLocally() {
    localStorage.setItem('finance_tx', JSON.stringify(transactions));
    localStorage.setItem('finance_savings', savings.toString());
    localStorage.setItem('finance_limit', manualLimit.toString());
    localStorage.setItem('finance_goal', JSON.stringify(priorityGoal));
}

function exportBackup() {
    const data = {
        tx: transactions,
        savings: savings,
        limit: manualLimit,
        goal: priorityGoal
    };
    const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `finance_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
}

function importBackup(event) {
    const file = event.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            if(data.tx) transactions = data.tx;
            if(data.savings !== undefined) savings = data.savings;
            if(data.limit !== undefined) manualLimit = data.limit;
            if(data.goal) priorityGoal = data.goal;
            updateUI();
            alert("Данные успешно восстановлены!");
        } catch (err) {
            alert("Ошибка чтения файла!");
        }
    };
    reader.readAsText(file);
}

function clearAllData() {
    if(confirm("ВНИМАНИЕ! Это удалит все ваши записи, цели и настройки безвозвратно. Продолжить?")) {
        localStorage.clear();
        transactions = [];
        savings = 0;
        manualLimit = 0;
        priorityGoal = { name: '', amount: 0, icon: '🎯' };
        updateUI();
    }
}

function exportAnalyticsCSV() {
    let csv = '\uFEFFДата,Тип,Категория,Сумма\n'; 
    transactions.forEach(tx => {
        csv += `${tx.date},${tx.type === 'income' ? 'Доход' : 'Расход'},"${tx.category}",${tx.amount}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `finance_analytics_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
}

function renderAnalyticsTable() {
    const tbody = document.getElementById('analytics-tbody');
    tbody.innerHTML = '';
    
    let expenses = transactions.filter(t => t.type === 'expense' && !t.isSystem);
    let cats = {};
    expenses.forEach(t => {
        cats[t.category] = (cats[t.category] || 0) + t.amount;
    });
    
    let sortedCats = Object.entries(cats).sort((a,b) => b[1] - a[1]);
    
    sortedCats.forEach(([cat, sum]) => {
        tbody.innerHTML += `<tr><td>${cat}</td><td>${sum} ₸</td></tr>`;
    });
}

function updateChart() {
    const ctx = document.getElementById('chart');
    if (!ctx) return;
    
    let expenses = transactions.filter(t => t.type === 'expense' && !t.isSystem);
    let cats = {};
    expenses.forEach(t => { cats[t.category] = (cats[t.category] || 0) + t.amount; });
    
    let labels = Object.keys(cats);
    let data = Object.values(cats);
    
    if (chartInstance) chartInstance.destroy();
    if (labels.length === 0) return;
    
    const root = getComputedStyle(document.documentElement);
    const textColor = root.getPropertyValue('--text-main').trim() || '#333';

    chartInstance = new Chart(ctx.getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{ 
                data: data, 
                backgroundColor: ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4'] 
            }]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: textColor } }
            }
        }
    });
}

function showTab(tabId, btn) {
    document.querySelectorAll('.tab').forEach(t => t.style.display = 'none');
    document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
    document.getElementById(tabId).style.display = 'block';
    btn.classList.add('active');
}

function sendNotification(title, body) {
    if(window.Notification && Notification.permission === "granted") {
        new Notification(title, {body: body});
    } else if (window.Notification && Notification.permission !== "denied") {
        Notification.requestPermission().then(perm => {
            if(perm === "granted") new Notification(title, {body: body});
        });
    }
}

window.onload = init;
