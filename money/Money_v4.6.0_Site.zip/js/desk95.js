// --- ТЕМА «WINDOWS 95_ПУСК» (И ПАПКА «WINDOWS 95_ЭКСТРА»): РАБОЧИЙ СТОЛ, ОКНА СТРАНИЦ, ПАНЕЛЬ ЗАДАЧ, МЕНЮ «ПУСК», ОБОИ ---
// Отдельная тема с другой логикой. После заставки и ПИН-кода — рабочий стол со значками разделов меню (Записи, Стена, Подписки,
// Зарплата, Статистика, Отчёты, Цели, Котировки, Цены, Настройки; порядок и набор — как в Настройки → «Пункты меню») и панелью задач внизу.
// Нажатие на значок открывает страницу в окне с анимацией (рамка «растёт» из значка, как в Windows 95); страница в окне — обычная
// страница сайта, но без блока с балансом, датой и временем (с 4.6.0), на сером «рабочем поле», блоки — как окна обычных программ.
// Крестик закрывает окно, «_» сворачивает, «□» разворачивает (на ПК), заголовок окна можно двигать.
//
// Панель задач (4.6.0): слева кнопка «Пуск», дальше квадратная иконка (без подписи) на каждую открытую страницу — как в Windows 95
// (нажатая — окно сверху, поднятая — свёрнуто; нажатие сворачивает или возвращает окно), справа квадратная кнопка «Свернуть все».
// Название страницы — всплывающей подсказкой: при наведении мыши или при долгом нажатии пальцем.
// «Пуск»: меню с основными страницами. Нажатие на страницу открывает следующее диалоговое окно — «папку» с блоками этой страницы;
// нажатие на блок открывает страницу и прокручивает её к блоку (блок на секунду подсвечивается).
// Обои (4.6.0): Настройки → «Обои рабочего стола» → «Изменить обои» (js/desk95-walls.js, 18 классических обоев).
//
// Как это устроено: раздел (div.tab) по-прежнему тот же самый элемент с теми же id и обработчиками — он только переезжает
// из <main> страницы в <main> окна и возвращается обратно при закрытии. Блок «Текущий баланс» (header) в окна не попадает — остаётся
// в скрытой обычной странице. Все остальные темы этот файл не затрагивает: пока тема не выбрана, ничего не создаётся.
// Оформление — css/desk95.css (только при html[data-w95="desk95"]), значки — js/desk95-icons.js.

(function () {
    'use strict';

    const THEME = 'desk95';
    const WALL_KEY = 'finance_desk95_wall';
    const root = document.documentElement;
    const isDesk = () => root.getAttribute('data-w95') === THEME;
    const isWide = () => window.innerWidth >= 769; // как isDesktopView() в js/layout.js
    const reduceMotion = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    const sound = (n) => { try { if (typeof playSound === 'function') playSound(n); } catch (e) {} };
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const iconSvg = (id) => (window.DESK95_ICONS && (window.DESK95_ICONS[id] || window.DESK95_ICONS.generic)) || '';

    let started = false;      // рабочий стол построен (тема выбрана)
    let root95 = null;        // #desk95 — весь экран темы
    let stage = null;         // .desk-stage — рабочий стол над панелью задач: значки и окна
    let iconsBox = null;      // контейнер значков
    let bar = null;           // панель задач
    let startBtn = null;      // «Пуск»
    let tasksBox = null;      // иконки открытых страниц
    let minBtn = null;        // «Свернуть все»
    let menu = null;          // меню «Пуск»
    let flyout = null;        // диалог с блоками страницы (открыт или null)
    let tip = null;           // всплывающая подсказка
    let origWrap = null;      // обычная страница (.main-wrapper), скрыта темой
    let origMain = null;      // её <main>: сюда возвращаются закрытые разделы
    const wins = new Map();   // id раздела → { id, el, body, main, tab, min, max } (в порядке открытия)
    const taskBtns = new Map(); // id раздела → кнопка на панели задач
    let order = [];           // id окон: впереди — верхнее
    let cascade = 0;          // сдвиг каждого нового окна на ПК

    // исходные функции script.js, extras.js: их вызывает тема, остальные темы работают как раньше
    const orig = {
        showTab: typeof window.showTab === 'function' ? window.showTab : null,
        renderMenus: typeof window.renderMenus === 'function' ? window.renderMenus : null,
        swipeBlocked: typeof window.swipeBlocked === 'function' ? window.swipeBlocked : null,
        editTx: typeof window.editTx === 'function' ? window.editTx : null
    };

    // ---------- меню ----------
    function menuItems() {
        const items = typeof MENU_ITEMS !== 'undefined' ? MENU_ITEMS : [];
        let ids = items.map(i => i.id);
        try {
            if (typeof getMenuState === 'function') {
                const st = getMenuState();
                ids = st.order.filter(id => !st.hidden.includes(id));
            }
        } catch (e) {}
        return ids.map(id => items.find(i => i.id === id)).filter(Boolean);
    }
    const itemOf = (id) => (typeof MENU_ITEMS !== 'undefined' ? MENU_ITEMS : []).find(i => i.id === id);

    // ---------- построение рабочего стола ----------
    function build() {
        const wrapper = document.querySelector('.app-wrapper');
        origWrap = document.querySelector('.main-wrapper');
        origMain = origWrap ? origWrap.querySelector(':scope > main') : null;
        if (!wrapper || !origMain) return false;

        root95 = document.createElement('div');
        root95.id = 'desk95';
        root95.innerHTML =
            '<div class="desk-stage"><div class="desk-icons" role="group" aria-label="Рабочий стол"></div></div>' +
            '<div class="desk-taskbar" role="toolbar" aria-label="Панель задач">' +
            '<button type="button" id="desk-start" class="tb-start" aria-haspopup="true" aria-expanded="false" aria-controls="desk-start-menu">' +
            '<span class="tb-start-ico"></span><span class="tb-start-text">Пуск</span></button>' +
            '<span class="tb-sep" aria-hidden="true"></span>' +
            '<div class="tb-tasks" role="group" aria-label="Открытые страницы"></div>' +
            '<span class="tb-sep" aria-hidden="true"></span>' +
            '<button type="button" id="desk-min-all" class="is-idle" data-tip="Свернуть все" aria-label="Свернуть все"></button>' +
            '</div>' +
            '<div id="desk-start-menu" class="desk-start-menu" role="menu" aria-label="Пуск" hidden></div>' +
            '<div class="desk-tip" role="tooltip" hidden></div>';
        wrapper.appendChild(root95);
        stage = root95.querySelector('.desk-stage');
        iconsBox = root95.querySelector('.desk-icons');
        bar = root95.querySelector('.desk-taskbar');
        startBtn = root95.querySelector('#desk-start');
        tasksBox = root95.querySelector('.tb-tasks');
        minBtn = root95.querySelector('#desk-min-all');
        menu = root95.querySelector('#desk-start-menu');
        tip = root95.querySelector('.desk-tip');
        startBtn.querySelector('.tb-start-ico').innerHTML = iconSvg('start');
        minBtn.innerHTML = iconSvg('minall');

        iconsBox.addEventListener('click', (e) => {
            const b = e.target.closest('.desk-icon');
            if (!b) return;
            selectIcon(b);
            open(b.dataset.id, b);
        });
        stage.addEventListener('pointerdown', (e) => {
            if (!e.target.closest('.desk-icon')) selectIcon(null);
        });
        minBtn.addEventListener('click', () => { if (!consumeLongPress()) minimizeAll(); });

        // панель задач: иконка страницы — свернуть / вернуть / поднять окно
        tasksBox.addEventListener('click', (e) => {
            const b = e.target.closest('.tb-task');
            if (!b || consumeLongPress()) return;
            const w = wins.get(b.dataset.id);
            if (!w) return;
            hideTip();
            closeMenus();
            if (w.min) open(w.id, b);
            else if (frontWin() === w) { minimize(w); const f = frontWin(); if (f) focusWin(f); else syncIconStates(); sound('close'); }
            else focusWin(w);
        });
        startBtn.addEventListener('click', () => toggleStart());
        menu.addEventListener('click', onMenuClick);
        setupTips();

        renderIcons();
        renderStart();
        applyWall();
        return true;
    }

    function renderIcons() {
        if (!iconsBox) return;
        iconsBox.innerHTML = menuItems().map(it =>
            `<button type="button" class="desk-icon" data-id="${esc(it.id)}" aria-label="${esc(it.label)}">` +
            `<span class="di-img">${iconSvg(it.id)}</span><span class="di-label">${esc(it.label)}</span></button>`).join('');
        syncIconStates();
    }

    function syncIconStates() {
        if (!iconsBox) return;
        iconsBox.querySelectorAll('.desk-icon').forEach(b => {
            const w = wins.get(b.dataset.id);
            b.classList.toggle('is-open', !!w);
            b.classList.toggle('is-min', !!(w && w.min));
        });
        if (minBtn) minBtn.classList.toggle('is-idle', !frontWin());
        syncTasks();
    }

    function selectIcon(btn) {
        if (!iconsBox) return;
        iconsBox.querySelectorAll('.desk-icon.is-sel').forEach(b => b.classList.remove('is-sel'));
        if (btn) btn.classList.add('is-sel');
    }

    const iconEl = (id) => (iconsBox ? iconsBox.querySelector(`.desk-icon[data-id="${id}"]`) : null);

    // ---------- панель задач ----------
    // Квадратные иконки без подписи: по кнопке на каждое открытое окно, в порядке открытия.
    // Нажатая (is-active) — окно сверху, поднятая (is-min) — окно свёрнуто.
    function syncTasks() {
        if (!tasksBox) return;
        const f = frontWin();
        taskBtns.forEach((b, id) => { if (!wins.has(id)) { b.remove(); taskBtns.delete(id); } });
        let prev = null;
        wins.forEach((w, id) => {
            let b = taskBtns.get(id);
            const it = itemOf(id);
            const label = it ? it.label : id;
            if (!b) {
                b = document.createElement('button');
                b.type = 'button';
                b.className = 'tb-task';
                b.dataset.id = id;
                b.innerHTML = iconSvg(id);
                taskBtns.set(id, b);
            }
            b.dataset.tip = label;
            b.setAttribute('aria-label', label);
            b.classList.toggle('is-min', !!w.min);
            b.classList.toggle('is-active', f === w);
            b.setAttribute('aria-pressed', f === w ? 'true' : 'false');
            const want = prev ? prev.nextSibling : tasksBox.firstChild;
            if (b.parentNode !== tasksBox || (prev ? b.previousSibling !== prev : b !== tasksBox.firstChild)) tasksBox.insertBefore(b, want);
            prev = b;
        });
    }

    // ---------- подсказки: наведение мыши и долгое нажатие пальцем ----------
    let tipFor = null, hoverT = 0, pressT = 0, hideT = 0, pressed = false, pressedT = 0;
    function showTip(el) {
        if (!tip || !el || !el.dataset.tip) return;
        tip.textContent = el.dataset.tip;
        tip.hidden = false;
        const R = root95.getBoundingClientRect(), b = el.getBoundingClientRect();
        const tw = tip.offsetWidth, th = tip.offsetHeight;
        const left = Math.max(4, Math.min(b.left - R.left + b.width / 2 - tw / 2, R.width - tw - 4));
        tip.style.left = Math.round(left) + 'px';
        tip.style.top = Math.round(b.top - R.top - th - 6) + 'px';
        tipFor = el;
    }
    function hideTip() {
        clearTimeout(hoverT); clearTimeout(pressT); clearTimeout(hideT);
        tipFor = null;
        if (tip) tip.hidden = true;
    }
    // после долгого нажатия палец отпускается — браузер может прислать «click»: его глотаем, чтобы окно не свернулось
    function consumeLongPress() {
        if (!pressed) return false;
        pressed = false;
        clearTimeout(pressedT);
        return true;
    }
    function setupTips() {
        bar.addEventListener('pointerover', (e) => {
            if (e.pointerType === 'touch') return;
            const el = e.target.closest('[data-tip]');
            if (!el || el === tipFor) return;
            clearTimeout(hoverT);
            hoverT = setTimeout(() => showTip(el), 380);
        });
        bar.addEventListener('pointerout', (e) => {
            if (e.pointerType === 'touch') return;
            const el = e.target.closest('[data-tip]');
            if (el && el.contains(e.relatedTarget)) return;
            hideTip();
        });
        bar.addEventListener('pointerdown', (e) => {
            hideTip();
            const el = e.target.closest('[data-tip]');
            if (!el || e.pointerType !== 'touch') return;
            pressT = setTimeout(() => {
                showTip(el);
                pressed = true;
                clearTimeout(pressedT);
                pressedT = setTimeout(() => { pressed = false; }, 900);
                hideT = setTimeout(hideTip, 2400);
            }, 450);
        });
        ['pointerup', 'pointercancel'].forEach(t => bar.addEventListener(t, () => clearTimeout(pressT)));
        bar.addEventListener('contextmenu', (e) => e.preventDefault()); // долгое нажатие на телефоне не открывает системное меню
        bar.addEventListener('focusin', (e) => { if (e.target.dataset && e.target.dataset.tip && e.target.matches(':focus-visible')) showTip(e.target); });
        bar.addEventListener('focusout', hideTip);
    }

    // ---------- меню «Пуск» ----------
    function renderStart() {
        if (!menu) return;
        menu.innerHTML =
            '<div class="sm-banner" aria-hidden="true"><span><b>Money</b> Pro 95</span></div>' +
            '<div class="sm-list">' + menuItems().map(it =>
                `<button type="button" class="sm-item" role="menuitem" aria-haspopup="dialog" data-id="${esc(it.id)}">` +
                `<span class="sm-ico">${iconSvg(it.id)}</span><span class="sm-label">${esc(it.label)}</span><span class="sm-arrow" aria-hidden="true"></span></button>`).join('') +
            '</div>';
    }

    const menuOpen = () => !!(menu && !menu.hidden);

    function toggleStart(force) {
        if (!started) return;
        const open = typeof force === 'boolean' ? force : !menuOpen();
        if (open === menuOpen()) return;
        hideTip();
        if (open) {
            closeWallDialog();
            menu.hidden = false;
            startBtn.classList.add('is-open');
            startBtn.setAttribute('aria-expanded', 'true');
            sound('open');
        } else {
            closeMenus();
        }
    }

    // silent — без звука (например, когда меню закрывается, потому что открывается окно)
    function closeMenus(silent) {
        closeFlyout();
        if (!menu) return;
        const was = !menu.hidden;
        menu.hidden = true;
        if (startBtn) { startBtn.classList.remove('is-open'); startBtn.setAttribute('aria-expanded', 'false'); }
        if (was && !silent) sound('close');
    }

    function onMenuClick(e) {
        const b = e.target.closest('.sm-item');
        if (!b) return;
        if (flyout && flyout.dataset.id === b.dataset.id) { closeFlyout(); return; }
        openFlyout(b.dataset.id, b);
    }

    // ---------- «папка» страницы: диалог с блоками ----------
    // Блоки страницы — карточки (.card) с заголовком: их список собирается в момент открытия, поэтому учитывает блоки, закреплённые на «Стене»
    function cardTitle(h3) {
        const c = h3.cloneNode(true);
        c.querySelectorAll('.material-icons, button, .w95-ctls, .w95-ctl, .cl-tag').forEach(n => n.remove());
        return c.textContent.replace(/\s+/g, ' ').trim();
    }

    function blocksOf(id) {
        const tab = document.getElementById(id);
        if (!tab) return [];
        const admin = root.getAttribute('data-admin') === '1';
        const shown = getComputedStyle(tab).display !== 'none'; // страница сейчас в окне: можно спросить у браузера, виден ли блок
        const out = [];
        tab.querySelectorAll('.card').forEach(card => {
            if (card.parentElement && card.parentElement.closest('.card')) return; // блок внутри блока
            if (card.id === 'header-settings-card') return; // настройка блока баланса: в этой теме такого блока нет
            if (card.hidden || card.closest('[hidden]') || card.style.display === 'none') return;
            if (shown && getComputedStyle(card).display === 'none') return;
            if (card.hasAttribute('data-admin-only') && !admin) return;
            const h3 = card.querySelector(':scope > h3') || card.querySelector('h3');
            if (!h3) return;
            const title = cardTitle(h3);
            if (!title) return;
            const mi = h3.querySelector('.material-icons');
            const glyph = mi && /^[a-z0-9_]{2,40}$/.test(mi.textContent.trim()) ? mi.textContent.trim() : 'view_agenda';
            out.push({ el: card, title, icon: glyph });
        });
        return out;
    }

    function openFlyout(id, itemBtn) {
        closeFlyout();
        const it = itemOf(id);
        if (!it || !menu) return;
        const blocks = blocksOf(id);
        flyout = document.createElement('section');
        flyout.className = 'desk-flyout';
        flyout.dataset.id = id;
        flyout.setAttribute('role', 'dialog');
        flyout.setAttribute('aria-label', it.label);
        flyout.innerHTML =
            '<div class="desk-titlebar">' +
            `<span class="dt-icon">${iconSvg(id)}</span><span class="dt-title">${esc(it.label)}</span>` +
            '<span class="dt-btns"><button type="button" class="dt-btn dt-close fl-close" title="Закрыть" aria-label="Закрыть"></button></span></div>' +
            '<div class="fl-tools"><button type="button" class="fl-open">' +
            `<span class="fl-open-ico">${iconSvg(id)}</span><span>Открыть страницу «${esc(it.label)}»</span></button></div>` +
            '<div class="fl-body" role="list">' + (blocks.length ? blocks.map((b, i) =>
                `<button type="button" class="fl-item" role="listitem" data-i="${i}" aria-label="${esc(b.title)}">` +
                `<span class="fl-bico"><span class="material-icons">${esc(b.icon)}</span></span><span class="fl-bname">${esc(b.title)}</span></button>`).join('')
                : '<p class="fl-empty">На этой странице пока нет блоков.</p>') + '</div>' +
            `<div class="fl-status">Блоков: ${blocks.length}</div>`;
        root95.appendChild(flyout);
        menu.querySelectorAll('.sm-item.is-open').forEach(x => x.classList.remove('is-open'));
        if (itemBtn) itemBtn.classList.add('is-open');
        placeFlyout(itemBtn);
        sound('open');

        const go = (title, idx) => { closeMenus(true); open(id, startBtn, false, () => setTimeout(() => goToBlock(id, title, idx), 40)); };
        flyout.querySelector('.fl-close').addEventListener('click', () => { closeFlyout(); sound('close'); });
        flyout.querySelector('.fl-open').addEventListener('click', () => { closeMenus(true); open(id, startBtn); });
        flyout.querySelector('.fl-body').addEventListener('click', (e) => {
            const b = e.target.closest('.fl-item');
            if (!b) return;
            const i = Number(b.dataset.i);
            go(blocks[i].title, i);
        });
        flyout.addEventListener('keydown', onFlyoutKey);
    }

    function placeFlyout(itemBtn) {
        if (!flyout) return;
        const wide = isWide();
        flyout.classList.toggle('is-sheet', !wide);
        flyout.style.left = flyout.style.top = '';
        if (!wide) return;
        const R = root95.getBoundingClientRect(), m = menu.getBoundingClientRect();
        const w = flyout.offsetWidth, h = flyout.offsetHeight, tb = bar.offsetHeight;
        let left = m.right - R.left - 2;
        if (left + w > R.width - 4) left = Math.max(4, R.width - w - 4);
        const ib = itemBtn ? itemBtn.getBoundingClientRect() : m;
        const top = Math.max(4, Math.min(ib.top - R.top - 3, R.height - tb - h - 4));
        flyout.style.left = Math.round(left) + 'px';
        flyout.style.top = Math.round(top) + 'px';
    }

    function closeFlyout() {
        if (!flyout) return;
        flyout.remove();
        flyout = null;
        if (menu) menu.querySelectorAll('.sm-item.is-open').forEach(x => x.classList.remove('is-open'));
    }

    function onFlyoutKey(e) {
        const items = [...flyout.querySelectorAll('.fl-open, .fl-item')];
        const i = items.indexOf(document.activeElement);
        let n = -1;
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') n = Math.min(items.length - 1, i + 1);
        else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') n = Math.max(0, i - 1);
        if (n >= 0) { e.preventDefault(); items[n].focus(); }
    }

    // Прокрутить страницу к блоку и ненадолго подсветить его
    function goToBlock(id, title, idx) {
        const w = wins.get(id);
        if (!w || w.min) return;
        const list = blocksOf(id);
        const b = list.find(x => x.title === title) || list[idx];
        if (!b) return;
        const sc = w.body;
        const top = b.el.getBoundingClientRect().top - sc.getBoundingClientRect().top + sc.scrollTop - 8;
        try { sc.scrollTo({ top: Math.max(0, top), behavior: reduceMotion() ? 'auto' : 'smooth' }); } catch (e) { sc.scrollTop = Math.max(0, top); }
        b.el.classList.remove('desk-flash');
        void b.el.offsetWidth;
        b.el.classList.add('desk-flash');
        setTimeout(() => b.el.classList.remove('desk-flash'), 1700);
    }

    // меню закрывается нажатием в любом другом месте и клавишей Esc; Ctrl+Esc открывает «Пуск», как в Windows
    document.addEventListener('pointerdown', (e) => {
        if (!started) return;
        if (menuOpen() && !e.target.closest('#desk-start-menu, .desk-flyout, #desk-start')) closeMenus();
    }, true);
    document.addEventListener('keydown', (e) => {
        if (!started || e.key !== 'Escape') return;
        if (e.ctrlKey) { e.preventDefault(); toggleStart(); return; }
        if (wallModal) { closeWallDialog(); return; }
        if (flyout) {
            const id = flyout.dataset.id;
            closeFlyout();
            const b = menu.querySelector(`.sm-item[data-id="${id}"]`);
            if (b) b.focus();
            return;
        }
        if (menuOpen()) { closeMenus(); startBtn.focus(); }
    });
    // стрелки вверх и вниз по пунктам «Пуска»
    document.addEventListener('keydown', (e) => {
        if (!started || !menuOpen() || !menu.contains(document.activeElement)) return;
        const items = [...menu.querySelectorAll('.sm-item')];
        const i = items.indexOf(document.activeElement);
        if (e.key === 'ArrowDown') { e.preventDefault(); items[(i + 1) % items.length].focus(); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); items[(i - 1 + items.length) % items.length].focus(); }
        else if (e.key === 'ArrowRight' && i >= 0) { e.preventDefault(); items[i].click(); const f = flyout && flyout.querySelector('.fl-item, .fl-open'); if (f) f.focus(); }
    });

    // ---------- окна ----------
    function frontWin() {
        for (const id of order) {
            const w = wins.get(id);
            if (w && !w.min) return w;
        }
        return null;
    }

    function applyZ() {
        order.forEach((id, i) => {
            const w = wins.get(id);
            if (w) w.el.style.zIndex = String(10 + (order.length - i));
        });
    }

    function focusWin(w) {
        order = [w.id].concat(order.filter(x => x !== w.id));
        applyZ();
        wins.forEach(x => x.el.classList.toggle('is-inactive', x !== w));
        if (typeof currentTabId === 'string') currentTabId = w.id;
        syncIconStates();
    }

    // Ширина полосы со значками (справа от неё на ПК открываются окна, чтобы значки оставались доступны)
    function iconStripWidth() {
        const icons = iconsBox ? iconsBox.querySelectorAll('.desk-icon') : [];
        if (!icons.length) return 0;
        const d = stage.getBoundingClientRect();
        let right = 0;
        icons.forEach(b => { right = Math.max(right, b.getBoundingClientRect().right - d.left); });
        return Math.round(right) + 12;
    }

    // Размер и положение нового окна: на телефоне окно на весь экран (css), на ПК — большое окно справа от значков со сдвигом «лесенкой»
    function placeWin(w) {
        if (!isWide()) return;
        const W = stage.clientWidth, H = stage.clientHeight, n = cascade++ % 5;
        const strip = iconStripWidth(), free = W - strip - 14;
        const width = Math.min(1100, Math.max(Math.min(640, W - 12), free)), height = Math.max(240, Math.min(920, H - 100));
        const slack = Math.max(0, free - width); // свободное место справа от значков: окно стоит посередине и сдвигается лесенкой
        const left = strip + Math.max(0, Math.min(slack, Math.round(slack / 2) + (n - 2) * 22));
        w.el.style.width = width + 'px';
        w.el.style.height = height + 'px';
        w.el.style.left = Math.max(6, Math.min(left, W - width - 6)) + 'px';
        w.el.style.top = (10 + n * 20) + 'px';
    }

    function createWindow(id) {
        const it = itemOf(id);
        const tab = document.getElementById(id);
        const el = document.createElement('section');
        el.className = 'desk-win';
        el.dataset.tab = id;
        el.setAttribute('role', 'dialog');
        el.setAttribute('aria-label', it.label);
        el.innerHTML =
            '<div class="desk-titlebar">' +
            `<span class="dt-icon">${iconSvg(id)}</span><span class="dt-title">${esc(it.label)}</span>` +
            '<span class="dt-btns">' +
            '<button type="button" class="dt-btn dt-min" title="Свернуть" aria-label="Свернуть"></button>' +
            '<button type="button" class="dt-btn dt-max" title="Развернуть" aria-label="Развернуть"></button>' +
            '<button type="button" class="dt-btn dt-close" title="Закрыть" aria-label="Закрыть"></button>' +
            '</span></div>' +
            '<div class="desk-body"><main></main></div>';
        const w = { id, el, tab, body: el.querySelector('.desk-body'), main: el.querySelector('main'), min: false, max: false };
        w.main.appendChild(tab);
        stage.appendChild(el);
        wins.set(id, w);
        order.unshift(id);
        placeWin(w);

        const bar2 = el.querySelector('.desk-titlebar');
        el.querySelector('.dt-min').addEventListener('click', () => { minimize(w); const f = frontWin(); if (f) focusWin(f); else syncIconStates(); sound('close'); });
        el.querySelector('.dt-max').addEventListener('click', () => toggleMax(w));
        el.querySelector('.dt-close').addEventListener('click', () => closeWin(id));
        bar2.addEventListener('dblclick', (e) => { if (!e.target.closest('.dt-btn')) toggleMax(w); });
        el.addEventListener('pointerdown', () => { if (order[0] !== id && !w.min) focusWin(w); }, true);
        enableDrag(w, bar2);
        return w;
    }

    function toggleMax(w) {
        if (!isWide()) return;
        w.max = !w.max;
        w.el.classList.toggle('is-max', w.max);
        const b = w.el.querySelector('.dt-max');
        b.title = w.max ? 'Восстановить' : 'Развернуть';
        b.setAttribute('aria-label', b.title);
        window.dispatchEvent(new Event('resize')); // диаграммы и полосы прокрутки подстраиваются
    }

    function enableDrag(w, bar2) {
        bar2.addEventListener('pointerdown', (e) => {
            if (e.button !== 0 || e.target.closest('.dt-btn') || !isWide() || w.max) return;
            const start = rectIn(w.el), sx = e.clientX, sy = e.clientY;
            try { bar2.setPointerCapture(e.pointerId); } catch (err) {}
            const move = (ev) => {
                const W = stage.clientWidth, H = stage.clientHeight;
                w.el.style.left = Math.max(-start.w + 120, Math.min(W - 60, start.x + ev.clientX - sx)) + 'px';
                w.el.style.top = Math.max(0, Math.min(H - 34, start.y + ev.clientY - sy)) + 'px';
            };
            const up = () => {
                bar2.removeEventListener('pointermove', move);
                bar2.removeEventListener('pointerup', up);
                bar2.removeEventListener('pointercancel', up);
                window.dispatchEvent(new Event('resize'));
            };
            bar2.addEventListener('pointermove', move);
            bar2.addEventListener('pointerup', up);
            bar2.addEventListener('pointercancel', up);
        });
    }

    // ---------- анимация «рамка из значка в окно» (как в Windows 95) ----------
    // координаты — внутри #desk95 (рабочий стол начинается в его левом верхнем углу, поэтому для окон они те же, что в рабочем столе)
    function rectIn(el) {
        const r = el.getBoundingClientRect(), d = root95.getBoundingClientRect();
        return { x: r.left - d.left, y: r.top - d.top, w: r.width, h: r.height };
    }

    // Несколько пунктирных рамок ступенчато движутся от from к to, затем вызывается done
    function wire(from, to, ms, done) {
        if (reduceMotion() || !from || !to) { done(); return; }
        const N = 3, STEPS = 6, frames = [];
        for (let i = 0; i < N; i++) {
            const f = document.createElement('div');
            f.className = 'desk-wire';
            f.style.display = 'none';
            root95.appendChild(f);
            frames.push(f);
        }
        const t0 = performance.now();
        const lerp = (a, b, t) => a + (b - a) * t;
        const step = (now) => {
            const p = Math.min(1, (now - t0) / ms), k = Math.ceil(p * STEPS);
            frames.forEach((f, i) => {
                const kk = k - i;
                if (kk < 1) { f.style.display = 'none'; return; }
                const t = kk / STEPS;
                f.style.display = '';
                f.style.left = lerp(from.x, to.x, t) + 'px';
                f.style.top = lerp(from.y, to.y, t) + 'px';
                f.style.width = Math.max(2, lerp(from.w, to.w, t)) + 'px';
                f.style.height = Math.max(2, lerp(from.h, to.h, t)) + 'px';
            });
            if (p < 1 && k < STEPS + N) requestAnimationFrame(step);
            else { frames.forEach(f => f.remove()); done(); }
        };
        requestAnimationFrame(step);
    }

    // ---------- открыть / свернуть / закрыть ----------
    // Побочные действия обычного showTab (подсветка, «Котировки», «Цены», размеры блоков, журнал администратора),
    // при этом остальные открытые окна остаются видимыми
    function runShowTab(id) {
        if (orig.showTab) orig.showTab(id, null);
        wins.forEach(x => { if (!x.min) x.tab.style.display = ''; });
        if (typeof currentTabId === 'string') currentTabId = id;
    }

    // after — что сделать, когда окно открыто и страница показана (например, прокрутить к блоку из «Пуска»)
    function open(id, fromEl, instant, after) {
        if (!started || !itemOf(id) || !document.getElementById(id)) return;
        let w = wins.get(id);
        if (w && !w.min) { focusWin(w); if (after) after(w); return; } // уже открыто — на передний план
        if (!w) w = createWindow(id);
        w.min = false;
        w.el.classList.remove('is-min');
        focusWin(w);
        sound('open');

        const reveal = () => {
            w.el.style.visibility = '';
            w.busy = false;
            if (w.min || wins.get(id) !== w) return;
            if (!instant) { w.el.classList.add('is-pop'); setTimeout(() => w.el.classList.remove('is-pop'), 200); }
            runShowTab(id);
            focusWin(w);
            window.dispatchEvent(new Event('resize'));
            if (after) after(w);
        };
        if (instant || reduceMotion()) { reveal(); return; }
        w.busy = true;
        w.el.style.visibility = 'hidden';
        const src = fromEl || taskBtns.get(id) || iconEl(id);
        const from = src ? rectIn(src.querySelector('.di-img') || src) : null;
        wire(from, rectIn(w.el), 200, reveal);
    }

    function minimize(w) {
        if (w.min) return;
        w.min = true;
        const target = taskBtns.get(w.id) || iconEl(w.id);
        const to = target ? rectIn(target.querySelector('.di-img') || target) : null;
        const from = rectIn(w.el);
        const finish = () => { if (w.min) { w.el.classList.add('is-min'); w.el.style.visibility = ''; } syncIconStates(); };
        if (reduceMotion() || w.busy || w.el.style.visibility === 'hidden') { finish(); return; }
        w.el.style.visibility = 'hidden';
        wire(from, to, 190, finish);
        syncIconStates();
    }

    function minimizeAll() {
        const list = order.map(id => wins.get(id)).filter(w => w && !w.min);
        if (!list.length) return;
        sound('close');
        closeMenus(true);
        list.forEach(minimize);
        syncIconStates();
    }

    function closeWin(id) {
        const w = wins.get(id);
        if (!w) return;
        sound('close');
        wins.delete(id);
        order = order.filter(x => x !== id);
        const f = frontWin();
        if (f) focusWin(f); else syncIconStates();
        const cleanup = () => {
            // раздел возвращается на скрытую обычную страницу (если его уже не забрало новое окно)
            if (w.tab.parentNode === w.main && origMain) { w.tab.style.display = 'none'; origMain.appendChild(w.tab); }
            w.el.remove();
            syncIconStates();
        };
        if (reduceMotion()) { cleanup(); return; }
        w.el.classList.add('is-closing');
        setTimeout(cleanup, 130);
    }

    // ---------- обои рабочего стола ----------
    const wallData = () => window.DESK95_WALLS || { list: [], byId: {} };
    function savedWall() { try { return localStorage.getItem(WALL_KEY) || ''; } catch (e) { return ''; } }
    function themeWallId() {
        try { const t = resolveTheme(currentThemeId); return (t && t.wall) || 'none'; } catch (e) { return 'none'; }
    }
    // выбранные пользователем обои, а если не выбраны — обои темы
    function activeWall() {
        const W = wallData();
        return W.byId[savedWall()] || W.byId[themeWallId()] || W.byId.none || null;
    }
    function applyWall() {
        if (!root95) return;
        const w = activeWall(), st = root95.style;
        ['image', 'size', 'repeat', 'color'].forEach(k => st.removeProperty('--desk-wall-' + k));
        if (w) { // у «(Нет)» картинки нет и цвета нет: остаётся цвет рабочего стола темы
            st.setProperty('--desk-wall-image', w.image);
            st.setProperty('--desk-wall-size', w.size);
            st.setProperty('--desk-wall-repeat', w.repeat);
            if (w.color) st.setProperty('--desk-wall-color', w.color);
        }
        renderWallCard();
    }
    // уменьшенный фон для предпросмотра: плитки сжимаются вдвое, большие картинки остаются на весь образец
    function swatchStyle(w, k) {
        let size = w.size;
        const m = /^(\d+)px (\d+)px$/.exec(size);
        if (m) size = Math.max(2, Math.round(m[1] * k)) + 'px ' + Math.max(2, Math.round(m[2] * k)) + 'px';
        const bg = w.id === 'none' ? 'var(--w95-desktop)' : (w.color || 'var(--w95-desktop)');
        return `background-color:${bg};background-image:${w.image};background-size:${size};background-repeat:${w.repeat};background-position:center;`;
    }
    function renderWallCard() {
        const card = document.getElementById('desk-wall-card');
        if (!card) return;
        const w = activeWall();
        if (!w) return;
        const th = card.querySelector('.dwc-thumb'), nm = card.querySelector('.dwc-name'), sub = card.querySelector('.dwc-sub');
        if (th) th.setAttribute('style', swatchStyle(w, 0.4));
        if (nm) nm.textContent = w.name;
        if (sub) sub.textContent = savedWall() && wallData().byId[savedWall()] ? 'выбраны вами' : 'обои темы по умолчанию';
        const reset = card.querySelector('.dwc-reset');
        if (reset) reset.disabled = !(savedWall() && wallData().byId[savedWall()]);
    }
    function resetWall() {
        try { localStorage.removeItem(WALL_KEY); } catch (e) {}
        applyWall();
        sound('success');
    }

    let wallModal = null;
    function closeWallDialog() {
        if (!wallModal) return;
        wallModal.remove();
        wallModal = null;
    }
    // Окно «Свойства: Экран» → «Фон»: образец на мониторе, список обоев, кнопки «OK», «Отмена», «Применить»
    function openWallDialog() {
        if (!started) return;
        closeMenus(true);
        closeWallDialog();
        const W = wallData();
        let sel = (activeWall() || W.byId.none).id;
        let useTheme = !savedWall() || !W.byId[savedWall()]; // обои темы по умолчанию (в памяти ничего не выбрано)
        wallModal = document.createElement('div');
        wallModal.className = 'desk-modal';
        wallModal.innerHTML =
            '<section class="desk-dlg" role="dialog" aria-modal="true" aria-label="Свойства: Экран">' +
            '<div class="desk-titlebar"><span class="dt-icon">' + iconSvg('settings') + '</span><span class="dt-title">Свойства: Экран</span>' +
            '<span class="dt-btns"><button type="button" class="dt-btn dt-close" data-act="cancel" title="Закрыть" aria-label="Закрыть"></button></span></div>' +
            '<div class="dlg-body"><div class="dlg-tab"><span>Фон</span></div><div class="dlg-page">' +
            '<div class="dlg-monitor" aria-hidden="true"><div class="dm-screen"></div><div class="dm-neck"></div><div class="dm-foot"></div></div>' +
            '<div class="dlg-list-wrap"><span class="dlg-cap" id="dlg-cap">Обои:</span>' +
            '<div class="dlg-list" role="listbox" tabindex="0" aria-labelledby="dlg-cap">' + W.list.map(w =>
                `<div class="dlg-item" role="option" data-id="${esc(w.id)}" aria-selected="false">` +
                `<span class="dlg-sw" style="${esc(swatchStyle(w, 0.4))}"></span><span class="dlg-name">${esc(w.name)}</span><span class="dlg-en">${esc(w.en)}</span></div>`).join('') +
            '</div></div></div></div>' +
            '<div class="dlg-btns"><button type="button" class="dlg-btn" data-act="ok">OK</button><button type="button" class="dlg-btn" data-act="cancel">Отмена</button>' +
            '<button type="button" class="dlg-btn" data-act="apply">Применить</button><button type="button" class="dlg-btn" data-act="theme">Как в теме</button></div>' +
            '</section>';
        root95.appendChild(wallModal);
        const screen = wallModal.querySelector('.dm-screen'), list = wallModal.querySelector('.dlg-list');
        const show = (scroll) => {
            const w = W.byId[sel];
            if (w) screen.setAttribute('style', swatchStyle(w, 0.5));
            list.querySelectorAll('.dlg-item').forEach(x => {
                const on = x.dataset.id === sel;
                x.classList.toggle('is-sel', on);
                x.setAttribute('aria-selected', on ? 'true' : 'false');
                if (on && scroll) x.scrollIntoView({ block: 'nearest' });
            });
        };
        const apply = () => {
            try { if (useTheme) localStorage.removeItem(WALL_KEY); else localStorage.setItem(WALL_KEY, sel); } catch (e) {}
            applyWall();
            sound('success');
        };
        wallModal.addEventListener('click', (e) => {
            const it = e.target.closest('.dlg-item');
            if (it) { sel = it.dataset.id; useTheme = false; show(false); return; }
            const b = e.target.closest('[data-act]');
            if (!b) return;
            const act = b.dataset.act;
            if (act === 'ok') { apply(); closeWallDialog(); sound('close'); }
            else if (act === 'apply') apply();
            else if (act === 'theme') { sel = themeWallId(); useTheme = true; show(true); }
            else if (act === 'cancel') { closeWallDialog(); sound('close'); }
        });
        wallModal.addEventListener('dblclick', (e) => {
            const it = e.target.closest('.dlg-item');
            if (it) { sel = it.dataset.id; useTheme = false; apply(); closeWallDialog(); sound('close'); }
        });
        list.addEventListener('keydown', (e) => {
            const ids = W.list.map(w => w.id), i = ids.indexOf(sel);
            if (/^(ArrowDown|ArrowUp|Home|End)$/.test(e.key)) useTheme = false;
            if (e.key === 'ArrowDown') { e.preventDefault(); sel = ids[Math.min(ids.length - 1, i + 1)]; show(true); }
            else if (e.key === 'ArrowUp') { e.preventDefault(); sel = ids[Math.max(0, i - 1)]; show(true); }
            else if (e.key === 'Home') { e.preventDefault(); sel = ids[0]; show(true); }
            else if (e.key === 'End') { e.preventDefault(); sel = ids[ids.length - 1]; show(true); }
            else if (e.key === 'Enter') { e.preventDefault(); apply(); closeWallDialog(); sound('close'); }
        });
        // окно поверх всего: нажатие рядом с ним ничего не закрывает (как модальное окно Windows), закрывают «Отмена» и Esc
        wallModal.addEventListener('pointerdown', (e) => { if (e.target === wallModal) e.preventDefault(); });
        show(true);
        sound('open');
        setTimeout(() => { try { list.focus({ preventScroll: true }); } catch (e) {} }, 30);
    }

    // ---------- вход в тему и выход из неё ----------
    function enter(boot) {
        if (started || !isDesk()) return;
        if (!build()) return;
        started = true;
        const cur = typeof currentTabId === 'string' ? currentTabId : '';
        // страницы без окон спрятаны; при запуске приложения рабочий стол пуст
        document.querySelectorAll('main > .tab').forEach(t => { t.style.display = 'none'; });
        if (!boot && cur && itemOf(cur)) open(cur, null, true); // тему выбрали из настроек: текущая страница остаётся в окне
        syncIconStates();
    }

    function leave() {
        if (!started) return;
        started = false;
        hideTip();
        closeWallDialog();
        closeMenus(true);
        const f = frontWin();
        const keep = (f && f.id) || (typeof currentTabId === 'string' ? currentTabId : 'transactions');
        wins.forEach(w => {
            if (origMain) { w.tab.style.display = 'none'; origMain.appendChild(w.tab); }
            w.el.remove();
        });
        wins.clear();
        taskBtns.clear();
        order = [];
        cascade = 0;
        if (root95) root95.remove();
        root95 = stage = iconsBox = bar = startBtn = tasksBox = minBtn = menu = tip = null;
        // обычный вид: открыта та страница, что была в верхнем окне
        if (orig.showTab) orig.showTab(itemOf(keep) ? keep : 'transactions', null);
        if (typeof renderMenus === 'function') { try { renderMenus(); } catch (e) {} }
        window.dispatchEvent(new Event('resize'));
    }

    // ---------- подключение к приложению ----------
    // showTab вызывают меню, свайпы, настройки: в теме «Пуск» это «открыть окно»
    if (orig.showTab) {
        window.showTab = function (tabId, btn) {
            if (started && isDesk()) { open(tabId); return; }
            return orig.showTab.apply(this, arguments);
        };
    }
    // перерисовка меню (порядок / скрытые пункты) обновляет и значки, и «Пуск»
    if (orig.renderMenus) {
        window.renderMenus = function () {
            const r = orig.renderMenus.apply(this, arguments);
            if (started) { renderIcons(); renderStart(); closeFlyout(); }
            return r;
        };
    }
    // свайпы влево / вправо в окнах не листают разделы
    if (orig.swipeBlocked) {
        window.swipeBlocked = function () { return (started && isDesk()) || orig.swipeBlocked.apply(this, arguments); };
    }
    // правка записи: форма «Новая запись» прокручивается вверх внутри окна
    if (orig.editTx) {
        window.editTx = function () {
            const r = orig.editTx.apply(this, arguments);
            if (started) {
                const f = document.getElementById('edit-id');
                const body = f && f.closest('.desk-body');
                if (body) body.scrollTo(0, 0);
            }
            return r;
        };
    }

    // «w95-theme» приходит при каждой смене темы (и при просмотре цветов в редакторе): внутри папки «Экстра» рабочий стол не пересоздаётся
    window.addEventListener('w95-theme', (e) => {
        const id = e && e.detail && e.detail.id;
        if (id === THEME) { enter(false); applyWall(); } else leave();
    });

    // окно при изменении размера экрана остаётся в пределах стола
    window.addEventListener('resize', () => {
        if (!started || !stage) return;
        const W = stage.clientWidth, H = stage.clientHeight;
        wins.forEach(w => {
            if (w.max || !isWide()) return;
            if (!w.el.style.width) { placeWin(w); return; } // окно открыто на узком экране, экран стал широким
            const r = rectIn(w.el);
            if (r.x > W - 60) w.el.style.left = Math.max(0, W - r.w - 6) + 'px';
            if (r.y > H - 34) w.el.style.top = Math.max(0, H - 60) + 'px';
        });
        if (flyout) placeFlyout(menu && menu.querySelector('.sm-item.is-open'));
    });

    // Запуск приложения с уже выбранной темой: пустой рабочий стол
    const boot = () => { if (isDesk()) enter(true); };
    if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', boot);
    else boot();

    // для кнопок в Настройках (index.html) и для проверки
    window.deskWallDialog = openWallDialog;
    window.deskWallReset = resetWall;
    window.deskOpen = open;
    window.deskStart = toggleStart;
    window.deskMinimizeAll = minimizeAll;
    window.deskCloseWindow = closeWin;
    window.deskWalls = { active: activeWall, apply: applyWall };
})();
