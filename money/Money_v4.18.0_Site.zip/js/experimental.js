// --- 4.18.0: «ЭКСПЕРИМЕНТАЛЬНЫЕ ФУНКЦИИ» ---
// Новый пункт меню с пятью идеями нового интерфейса. Каждая включается отдельным переключателем и ничего не ломает:
// выключили — приложение выглядит и работает как раньше (старая система полностью сохранена).
// Как это устроено: функция = класс на <html> (exp-balance, exp-quick, exp-history, exp-nav, exp-stats, exp-skeleton);
// все новые правила лежат в css/experimental.css и действуют только при своём классе. Этот файл рисует страницу
// «Экспериментальные функции», достраивает нужные элементы (прогресс лимита, свайп записей, нижняя панель, окна
// калькулятора и банка) и подписывается на обновления данных. Настройки хранятся на устройстве (finance_experimental).
// Подключается после script.js: использует его transactions, manualLimit, getTxDateStr, almatyIsoNow, showTab, MENU_ITEMS и др.

(function () {
    'use strict';

    const KEY = 'finance_experimental';
    const DEFAULT_SLOTS = ['transactions', 'statistics', 'wishlist'];

    // Описание функций: что было и что станет (показывается на странице)
    const FEATURES = [
        {
            id: 'balance', icon: 'account_balance_wallet', title: 'Главный баланс',
            sub: 'Баланс — самое крупное и заметное число экрана.',
            was: ['В шапке рядом семь чисел и строк: баланс, лимит, копилка, время, погода, курсы и цитата — всё одного веса.'],
            now: ['Баланс очень крупным числом.',
                'Под ним одна полоса: сколько потрачено сегодня из дневного лимита (краснеет, если лимит превышен).',
                'Копилка — маленькой строкой. Погода, курсы и цитата спрятаны: открываются кнопкой «i».']
        },
        {
            id: 'quick', icon: 'bolt', title: 'Быстрая запись',
            sub: 'Расход записывается за два касания: сумма и категория.',
            was: ['Сверху большая карточка «Чек по фото», затем дата, сумма, валюта, поле категории, плитки всех категорий, ряд значков и маленькие кнопки «Доход» и «Расход».'],
            now: ['Сумма крупно, сразу под ней цифровая клавиатура.',
                'Категории — одной лентой, недавно использованные слева (листается вбок).',
                'Две широкие кнопки внизу: красная «Расход» и зелёная «Доход».',
                'Дата, валюта и поле категории спрятаны под «Ещё» (при изменении записи открываются сами).',
                '«Чек по фото» — тонкая строка вместо большой карточки; рядом с клавиатурой значок калькулятора.']
        },
        {
            id: 'history', icon: 'swipe', title: 'Лёгкая история',
            sub: 'История читается проще, а действия — свайпом.',
            was: ['У каждой записи две кнопки (карандаш и корзина), заголовки дней — тяжёлые серые плашки.'],
            now: ['Свайп записи влево — удалить (с подтверждением), вправо — изменить. На ПК кнопки появляются при наведении.',
                'Сумма крупнее и выровнена вправо, цифры одинаковой ширины.',
                'Заголовки дней лёгкие и «прилипают» при прокрутке.',
                'Сверху — поиск и фильтры «Все / Расходы / Доходы».']
        },
        {
            id: 'nav', icon: 'dock_to_bottom', title: 'Нижняя панель',
            sub: 'Меньше пунктов на виду и большая кнопка «+».',
            was: ['Десять равнозначных пунктов меню в два ряда.'],
            now: ['Нижняя панель: две вкладки, круглая кнопка «+», третья вкладка и «Ещё» (там остальные разделы, калькулятор и «Мой банк»).',
                'Кнопка «+» открывает «Новую запись» из любого раздела.',
                'Какие три вкладки вынести на панель — выбираете сами (ниже).',
                'Работает на телефоне, когда меню внизу; на ПК остаётся меню слева.']
        },
        {
            id: 'stats', icon: 'donut_large', title: 'Статистика и единый стиль',
            sub: 'Статистика — один главный график; одинаковые отступы во всех темах.',
            was: ['Статистика — длинный набор карточек: калькулятор, «Мой банк» и восемь графиков подряд. У тем разные отступы и скругления.'],
            now: ['Сверху переключатель периода (7 дн / 30 дн / Месяц / Год / Всё) и главный график — расходы по категориям.',
                'Калькулятор и «Мой банк» открываются кнопками в окне; остальные графики — под «Ещё графики».',
                'Единые отступы, скругления и шрифты цифр (цифры одинаковой ширины) в большинстве тем; ретро-темы остаются ретро.']
        }
    ];

    // ---------- Хранение ----------
    function load() {
        let s = null;
        try { s = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) {}
        const on = {};
        FEATURES.forEach(f => { on[f.id] = !!(s && s.on && s.on[f.id]); });
        let slots = Array.isArray(s && s.slots) ? s.slots.slice(0, 3) : [];
        while (slots.length < 3) slots.push(DEFAULT_SLOTS[slots.length]);
        return { on, slots };
    }
    let state = load();
    function save() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} }

    // ---------- Мелочи ----------
    const $ = id => document.getElementById(id);
    const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const root = document.documentElement;
    function fmt(n) { return Math.round(n).toLocaleString('ru-RU').replace(/ /g, ' '); }
    function menuLabel(id) {
        try { const it = MENU_ITEMS.find(i => i.id === id); return it ? it.label : id; } catch (e) { return id; }
    }
    function menuIcon(id) {
        try { const it = MENU_ITEMS.find(i => i.id === id); return it ? it.icon : 'circle'; } catch (e) { return 'circle'; }
    }
    function curTab() { try { return currentTabId || 'transactions'; } catch (e) { return root.getAttribute('data-tab') || 'transactions'; } }
    function go(tabId) { try { showTab(tabId); } catch (e) {} }

    // ---------- Применение классов ----------
    function applyClasses() {
        FEATURES.forEach(f => root.classList.toggle('exp-' + f.id, !!state.on[f.id]));
        root.classList.toggle('exp-skeleton', !!state.on.stats);
        root.classList.toggle('exp-any', FEATURES.some(f => state.on[f.id]));
        refreshAll();
    }

    // ---------- 1. Баланс: полоса «сегодня / лимит», кнопка «i» ----------
    function injectBalance() {
        const h = $('balance');
        if (h && !$('exp-limit')) {
            const box = document.createElement('div');
            box.className = 'exp-limit'; box.id = 'exp-limit';
            box.innerHTML = '<div class="exp-limit-bar"><i></i></div><div class="exp-limit-text"></div>';
            h.insertAdjacentElement('afterend', box);
        }
        const info = document.querySelector('.balance-card .balance-info');
        if (info && !info.querySelector('.exp-info-toggle')) {
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'exp-info-toggle'; b.setAttribute('aria-label', 'Погода, курсы и цитата');
            b.innerHTML = '<span class="material-icons">info</span>';
            b.addEventListener('click', () => {
                const card = b.closest('.balance-card');
                if (card) card.classList.toggle('exp-info-open');
            });
            info.appendChild(b);
        }
    }
    function spentToday() {
        try {
            const today = almatyIsoNow().split('T')[0];
            return transactions.filter(t => !t.isSystem && t.type === 'expense' && getTxDateStr(t.date) === today)
                .reduce((s, t) => s + (parseFloat(t.amount) || 0), 0);
        } catch (e) { return 0; }
    }
    function refreshLimit() {
        const box = $('exp-limit');
        if (!box) return;
        const spent = spentToday();
        let limit = 0;
        try { limit = parseFloat(manualLimit) || 0; } catch (e) {}
        const bar = box.querySelector('.exp-limit-bar');
        const fill = box.querySelector('i');
        const text = box.querySelector('.exp-limit-text');
        if (limit > 0) {
            const pct = Math.min(100, Math.round(spent / limit * 100));
            fill.style.width = pct + '%';
            bar.classList.toggle('is-over', spent > limit);
            bar.classList.toggle('is-warn', spent <= limit && spent / limit >= 0.8);
            bar.style.display = '';
            text.textContent = spent > limit
                ? `Сегодня потрачено ${fmt(spent)} ₸ — на ${fmt(spent - limit)} ₸ больше лимита ${fmt(limit)} ₸`
                : `Сегодня потрачено ${fmt(spent)} ₸ из ${fmt(limit)} ₸`;
        } else {
            bar.style.display = 'none';
            text.textContent = `Сегодня потрачено ${fmt(spent)} ₸ · дневной лимит не задан`;
        }
    }

    // ---------- 2. Быстрая запись ----------
    function injectQuick() {
        const form = document.querySelector('#transactions .forms');
        const actions = $('tx-actions');
        if (!form || !actions) return;
        if (!$('exp-more-btn')) {
            const b = document.createElement('button');
            b.type = 'button'; b.id = 'exp-more-btn'; b.className = 'exp-more-btn';
            b.innerHTML = '<span>Дата, валюта, категория текстом</span><span class="material-icons">expand_more</span>';
            b.addEventListener('click', () => toggleMore());
            actions.insertAdjacentElement('beforebegin', b);
        }
        if (!$('exp-calc-btn')) {
            const c = document.createElement('button');
            c.type = 'button'; c.id = 'exp-calc-btn'; c.className = 'btn-secondary tx-icon-btn';
            c.title = 'Калькулятор'; c.setAttribute('aria-label', 'Калькулятор');
            c.innerHTML = '<span class="material-icons">calculate</span>';
            c.addEventListener('click', () => openCard('calc'));
            actions.insertBefore(c, actions.firstChild);
        }
    }
    function toggleMore(force) {
        const form = document.querySelector('#transactions .forms');
        if (!form) return;
        const open = typeof force === 'boolean' ? force : !form.classList.contains('exp-more-open');
        form.classList.toggle('exp-more-open', open);
        const b = $('exp-more-btn');
        if (b) b.classList.toggle('is-open', open);
    }
    // недавно использованные категории — слева
    let sortingTiles = false;
    function sortTiles() {
        const box = $('cat-tiles');
        if (!box || sortingTiles || !state.on.quick) return;
        const tiles = [...box.children].filter(el => el.classList && el.classList.contains('cat-tile'));
        if (tiles.length < 2) return;
        const last = {};
        try {
            transactions.forEach(t => {
                const top = String(t.category || '').split(':')[0].trim().toLowerCase();
                const d = String(t.date || '');
                if (top && (!last[top] || d > last[top])) last[top] = d;
            });
        } catch (e) {}
        const key = el => last[String(el.dataset.cat || '').split(':')[0].trim().toLowerCase()] || '';
        const sorted = tiles.slice().sort((a, b) => key(b).localeCompare(key(a)));
        if (sorted.every((el, i) => el === tiles[i])) return;
        sortingTiles = true;
        // опорная точка — первый узел после плиток (подкатегории раскрытого раздела остаются в конце)
        const ref = tiles[tiles.length - 1].nextSibling;
        sorted.forEach(el => box.insertBefore(el, ref));
        sortingTiles = false;
    }
    // «Изменить запись» открывает скрытые поля
    function hookEdit() {
        const orig = window.editTx;
        if (typeof orig !== 'function' || orig._exp) return;
        const wrapped = function () {
            const r = orig.apply(this, arguments);
            if (state.on.quick) toggleMore(true);
            return r;
        };
        wrapped._exp = true;
        window.editTx = wrapped;
    }

    // ---------- 3. История: свайп, поиск, фильтры ----------
    let histFilter = 'all';
    function injectHistory() {
        const card = document.querySelector('#transactions .history');
        const list = $('tx-list');
        if (!card || !list || $('exp-filter')) return;
        const f = document.createElement('div');
        f.className = 'exp-filter'; f.id = 'exp-filter';
        f.innerHTML = '<label class="exp-search"><span class="material-icons">search</span>' +
            '<input type="search" id="exp-search" placeholder="Поиск: категория, комментарий, сумма" autocomplete="off"></label>' +
            '<div class="exp-chips" role="group" aria-label="Фильтр записей">' +
            '<button type="button" data-f="all" class="on">Все</button>' +
            '<button type="button" data-f="expense">Расходы</button>' +
            '<button type="button" data-f="income">Доходы</button></div>';
        list.insertAdjacentElement('beforebegin', f);
        f.querySelector('#exp-search').addEventListener('input', applyHistFilter);
        f.querySelector('.exp-chips').addEventListener('click', e => {
            const b = e.target.closest('button[data-f]');
            if (!b) return;
            histFilter = b.dataset.f;
            f.querySelectorAll('.exp-chips button').forEach(x => x.classList.toggle('on', x === b));
            applyHistFilter();
        });
        new MutationObserver(() => { prepareItems(); applyHistFilter(); }).observe(list, { childList: true });
        prepareItems();
        initSwipe(list);
    }
    function prepareItems() {
        const list = $('tx-list');
        if (!list) return;
        list.querySelectorAll('.tx-item:not([data-exp])').forEach(item => {
            item.dataset.exp = '1';
            const inner = document.createElement('div');
            inner.className = 'exp-sw-in';
            while (item.firstChild) inner.appendChild(item.firstChild);
            const bg = document.createElement('div');
            bg.className = 'exp-sw-bg';
            bg.innerHTML = '<span class="exp-sw-edit"><span class="material-icons">edit</span></span><span class="exp-sw-del"><span class="material-icons">delete</span></span>';
            item.appendChild(bg);
            item.appendChild(inner);
        });
    }
    function applyHistFilter() {
        const list = $('tx-list');
        const input = $('exp-search');
        if (!list) return;
        const q = ((input && input.value) || '').trim().toLowerCase();
        const active = histFilter !== 'all' || q !== '';
        let header = null, shown = 0;
        const flush = () => { if (header) header.classList.toggle('exp-hidden', active && shown === 0); };
        [...list.children].forEach(el => {
            if (el.classList.contains('date-group-header')) { flush(); header = el; shown = 0; return; }
            if (!el.classList.contains('tx-item')) return;
            const typeOk = histFilter === 'all' || el.classList.contains(histFilter);
            const textOk = !q || el.textContent.toLowerCase().includes(q);
            const ok = typeOk && textOk;
            el.classList.toggle('exp-hidden', !ok);
            if (ok) shown++;
        });
        flush();
    }
    function txIdOf(item, kind) {
        const b = item.querySelector(`.tx-actions button[onclick^="${kind}"]`);
        const m = b && /\('([^']+)'\)/.exec(b.getAttribute('onclick') || '');
        return m ? m[1] : null;
    }
    function initSwipe(list) {
        let item = null, inner = null, x0 = 0, y0 = 0, dx = 0, locked = false, pid = null;
        const THRESH = 88;
        list.addEventListener('pointerdown', e => {
            if (!state.on.history || (e.pointerType === 'mouse' && e.button !== 0)) return;
            const it = e.target.closest('.tx-item');
            if (!it || !txIdOf(it, 'editTx')) return;
            item = it; inner = it.querySelector('.exp-sw-in');
            x0 = e.clientX; y0 = e.clientY; dx = 0; locked = false; pid = e.pointerId;
        });
        list.addEventListener('pointermove', e => {
            if (!item || e.pointerId !== pid) return;
            const mx = e.clientX - x0, my = e.clientY - y0;
            if (!locked) {
                if (Math.abs(my) > 12 && Math.abs(my) > Math.abs(mx)) { item = null; return; }
                if (Math.abs(mx) > 12 && Math.abs(mx) > Math.abs(my) * 1.5) {
                    locked = true;
                    item.classList.add('is-swiping');
                    try { list.setPointerCapture(e.pointerId); } catch (err) {}
                } else return;
            }
            dx = Math.max(-140, Math.min(140, mx));
            if (inner) inner.style.transform = `translateX(${dx}px)`;
            item.dataset.swipe = dx < -8 ? 'del' : dx > 8 ? 'edit' : '';
            item.classList.toggle('is-armed', Math.abs(dx) >= THRESH);
        });
        const end = e => {
            if (!item || (e && e.pointerId !== pid)) return;
            const it = item, inn = inner, d = dx, was = locked;
            item = null; inner = null; locked = false;
            try { list.releasePointerCapture(pid); } catch (err) {}
            it.classList.remove('is-swiping', 'is-armed');
            if (inn) inn.style.transform = '';
            it.dataset.swipe = '';
            if (!was) return;
            if (d <= -THRESH) { const id = txIdOf(it, 'deleteTx'); if (id && typeof deleteTx === 'function') deleteTx(id); }
            else if (d >= THRESH) {
                const id = txIdOf(it, 'editTx');
                if (id && typeof editTx === 'function') {
                    editTx(id);
                    const form = document.querySelector('#transactions .forms');
                    if (form) form.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        };
        list.addEventListener('pointerup', end);
        list.addEventListener('pointercancel', end);
    }

    // ---------- 4. Нижняя панель и окна ----------
    function visibleMenuIds() {
        try { return menuNavItems().filter(i => !i.page).map(i => i.id); } catch (e) { return MENU_ITEMS.map(i => i.id); }
    }
    function navBtn(id) {
        return `<button type="button" class="exp-nav-btn" data-go="${esc(id)}"><span class="material-icons">${esc(menuIcon(id))}</span><span>${esc(menuLabel(id))}</span></button>`;
    }
    function buildNav() {
        let nav = $('exp-nav');
        if (!nav) {
            nav = document.createElement('nav');
            nav.id = 'exp-nav'; nav.setAttribute('aria-label', 'Быстрое меню');
            document.body.appendChild(nav);
            nav.addEventListener('click', e => {
                const b = e.target.closest('button');
                if (!b) return;
                if (b.dataset.go) go(b.dataset.go);
                else if (b.id === 'exp-nav-add') quickAdd();
                else if (b.id === 'exp-nav-more') openSheet();
            });
        }
        const [a, b, c] = state.slots;
        nav.innerHTML = navBtn(a) + navBtn(b) +
            '<button type="button" id="exp-nav-add" class="exp-nav-add" aria-label="Новая запись"><span class="material-icons">add</span></button>' +
            navBtn(c) +
            '<button type="button" id="exp-nav-more" class="exp-nav-btn"><span class="material-icons">apps</span><span>Ещё</span></button>';
        syncNav();
        measureNav();
    }
    function syncNav() {
        const nav = $('exp-nav');
        if (!nav) return;
        const cur = curTab();
        let hit = false;
        nav.querySelectorAll('.exp-nav-btn[data-go]').forEach(b => { const on = b.dataset.go === cur; b.classList.toggle('on', on); if (on) hit = true; });
        const more = $('exp-nav-more');
        if (more) more.classList.toggle('on', !hit);
    }
    function measureNav() {
        const nav = $('exp-nav');
        if (!nav || !state.on.nav) return;
        requestAnimationFrame(() => {
            const h = nav.offsetHeight;
            if (h > 0) root.style.setProperty('--mobile-nav-h', h + 'px');
        });
    }
    function quickAdd() {
        go('transactions');
        const mw = document.querySelector('.main-wrapper');
        if (mw) mw.scrollTop = 0;
        const am = $('amount');
        if (am && !state.on.quick) { try { am.focus(); } catch (e) {} }
    }
    // «Ещё»: остальные разделы, калькулятор, «Мой банк»
    function openSheet() {
        let sheet = $('exp-sheet');
        if (!sheet) {
            sheet = document.createElement('div');
            sheet.id = 'exp-sheet'; sheet.className = 'exp-overlay';
            sheet.innerHTML = '<div class="exp-panel" role="dialog" aria-label="Все разделы"><div class="exp-panel-grip"></div><div class="exp-grid"></div></div>';
            document.body.appendChild(sheet);
            sheet.addEventListener('click', e => {
                if (e.target === sheet) { closeSheet(); return; }
                const b = e.target.closest('button');
                if (!b) return;
                closeSheet();
                if (b.dataset.go) go(b.dataset.go);
                else if (b.dataset.card) openCard(b.dataset.card);
            });
        }
        const onBar = state.slots;
        const items = visibleMenuIds().filter(id => !onBar.includes(id));
        sheet.querySelector('.exp-grid').innerHTML = items.map(navBtn).join('') +
            '<button type="button" class="exp-nav-btn" data-card="calc"><span class="material-icons">calculate</span><span>Калькулятор</span></button>' +
            '<button type="button" class="exp-nav-btn" data-card="bank"><span class="material-icons">account_balance</span><span>Мой банк</span></button>';
        sheet.classList.add('open');
    }
    function closeSheet() { const s = $('exp-sheet'); if (s) s.classList.remove('open'); }

    // Окно с карточкой из раздела «Статистика» (калькулятор, «Мой банк»): карточка переносится в окно и возвращается назад
    let movedCards = [];
    function openCard(kind) {
        const sels = kind === 'bank' ? ['.bank-card'] : ['.calc-card', '.calc-tape-card'];
        const title = kind === 'bank' ? 'Мой банк' : 'Калькулятор';
        let modal = $('exp-modal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'exp-modal'; modal.className = 'exp-overlay';
            modal.innerHTML = '<div class="exp-panel exp-panel-card" role="dialog"><div class="exp-modal-head"><h3></h3>' +
                '<button type="button" class="exp-modal-x" aria-label="Закрыть"><span class="material-icons">close</span></button></div><div class="exp-modal-body"></div></div>';
            document.body.appendChild(modal);
            modal.addEventListener('click', e => { if (e.target === modal || e.target.closest('.exp-modal-x')) closeCard(); });
            document.addEventListener('keydown', e => { if (e.key === 'Escape' && modal.classList.contains('open')) closeCard(); });
        }
        closeCard();
        const body = modal.querySelector('.exp-modal-body');
        sels.forEach(sel => {
            const card = document.querySelector('#statistics > ' + sel) || document.querySelector(sel);
            if (!card || modal.contains(card)) return;
            const ph = document.createComment('exp-' + sel);
            card.parentNode.insertBefore(ph, card);
            movedCards.push({ card, ph });
            body.appendChild(card);
        });
        if (!movedCards.length) return;
        modal.querySelector('h3').textContent = title;
        modal.classList.add('open');
        if (kind === 'bank' && typeof renderBank === 'function') { try { renderBank(); } catch (e) {} }
    }
    function closeCard() {
        const modal = $('exp-modal');
        movedCards.forEach(({ card, ph }) => { if (ph.parentNode) ph.parentNode.replaceChild(card, ph); });
        movedCards = [];
        if (modal) modal.classList.remove('open');
    }

    // ---------- 5. Статистика: период, главный график ----------
    function injectStats() {
        const tab = $('statistics');
        if (!tab) return;
        const donut = $('expenseCatChart');
        const donutCard = donut && donut.closest('.card');
        if (donutCard) donutCard.classList.add('exp-st-main');
        ['mainChart', 'incomeCatChart', 'balanceChart', 'monthsChart', 'weekdayChart', 'daypartChart'].forEach(id => {
            const c = $(id) && $(id).closest('.card');
            if (c) c.classList.add(id === 'mainChart' ? 'exp-st-week' : 'exp-st-extra');
        });
        if (!$('exp-period')) {
            const bar = document.createElement('div');
            bar.id = 'exp-period'; bar.className = 'exp-period';
            bar.innerHTML = '<div class="exp-chips" role="group" aria-label="Период">' +
                [['7', '7 дн'], ['30', '30 дн'], ['month', 'Месяц'], ['year', 'Год'], ['all', 'Всё']]
                    .map(([v, l]) => `<button type="button" data-p="${v}">${l}</button>`).join('') + '</div>' +
                '<div class="exp-period-tools"><button type="button" data-card="calc"><span class="material-icons">calculate</span>Калькулятор</button>' +
                '<button type="button" data-card="bank"><span class="material-icons">account_balance</span>Мой банк</button></div>';
            tab.insertBefore(bar, tab.firstChild);
            bar.addEventListener('click', e => {
                const b = e.target.closest('button');
                if (!b) return;
                if (b.dataset.card) { openCard(b.dataset.card); return; }
                const sel = $('stats-period');
                if (sel && b.dataset.p) { sel.value = b.dataset.p; if (typeof renderStatistics === 'function') renderStatistics(); syncPeriod(); }
            });
        }
        if (!$('exp-st-more')) {
            const m = document.createElement('button');
            m.type = 'button'; m.id = 'exp-st-more'; m.className = 'exp-st-more-btn';
            m.innerHTML = '<span>Ещё графики</span><span class="material-icons">expand_more</span>';
            m.addEventListener('click', () => {
                const open = tab.classList.toggle('exp-st-open');
                m.classList.toggle('is-open', open);
                setTimeout(() => window.dispatchEvent(new Event('resize')), 50); // графикам нужен видимый холст
            });
            tab.appendChild(m);
        }
        syncPeriod();
    }
    function syncPeriod() {
        const sel = $('stats-period');
        document.querySelectorAll('#exp-period [data-p]').forEach(b => b.classList.toggle('on', !!sel && b.dataset.p === sel.value));
    }

    // ---------- Страница «Экспериментальные функции» ----------
    function slotSelect(i) {
        const opts = MENU_ITEMS.map(it => `<option value="${esc(it.id)}"${state.slots[i] === it.id ? ' selected' : ''}>${esc(it.label)}</option>`).join('');
        return `<label class="exp-slot"><span>Вкладка ${i + 1}</span><select data-slot="${i}">${opts}</select></label>`;
    }
    function renderPage() {
        const box = $('exp-root');
        if (!box) return;
        const onCount = FEATURES.filter(f => state.on[f.id]).length;
        box.innerHTML = `
        <div class="card exp-intro wall-info">
            <h3><span class="material-icons">science</span> Экспериментальные функции</h3>
            <p>Здесь новые идеи интерфейса. Включайте по одной и смотрите, что удобнее. <b>Старый вид никуда не делся</b>: выключите переключатель — всё станет как раньше. Данные и записи эти функции не меняют, настройка хранится на этом устройстве.</p>
            <p class="exp-count">Включено: <b>${onCount}</b> из ${FEATURES.length}</p>
            <div class="exp-intro-btns">
                <button type="button" class="btn-primary" data-act="all-on">Включить все</button>
                <button type="button" class="btn-secondary" data-act="all-off">Вернуть старый вид</button>
            </div>
        </div>` + FEATURES.map((f, i) => `
        <section class="card exp-card wall-info${state.on[f.id] ? ' is-on' : ''}" data-f="${f.id}">
            <div class="exp-card-head">
                <span class="material-icons exp-card-ico">${f.icon}</span>
                <div class="exp-card-title"><h3>${i + 1}. ${esc(f.title)}</h3><p>${esc(f.sub)}</p></div>
                <label class="exp-switch" title="Включить или выключить"><input type="checkbox" data-f="${f.id}"${state.on[f.id] ? ' checked' : ''} aria-label="${esc(f.title)}"><span></span></label>
            </div>
            <div class="exp-diff">
                <div class="exp-was"><b>Сейчас</b><ul>${f.was.map(t => `<li>${esc(t)}</li>`).join('')}</ul></div>
                <div class="exp-now"><b>Что изменится</b><ul>${f.now.map(t => `<li>${esc(t)}</li>`).join('')}</ul></div>
            </div>
            ${f.id === 'nav' ? `<div class="exp-slots"><p class="hint">Вкладки нижней панели (слева направо: две, «+», третья, «Ещё»):</p>${[0, 1, 2].map(slotSelect).join('')}</div>` : ''}
        </section>`).join('') + '<p class="hint exp-foot">Нашли неудобство или хотите что-то изменить — скажите, доработаем. В темах «Windows 95_Пуск» нижняя панель не показывается.</p>';
    }
    function bindPage() {
        const box = $('exp-root');
        if (!box || box._bound) return;
        box._bound = true;
        box.addEventListener('change', e => {
            const cb = e.target.closest('input[data-f]');
            if (cb) { state.on[cb.dataset.f] = cb.checked; save(); applyClasses(); renderPage(); return; }
            const sel = e.target.closest('select[data-slot]');
            if (sel) {
                state.slots[parseInt(sel.dataset.slot, 10)] = sel.value;
                save(); buildNav();
            }
        });
        box.addEventListener('click', e => {
            const b = e.target.closest('button[data-act]');
            if (!b) return;
            FEATURES.forEach(f => { state.on[f.id] = b.dataset.act === 'all-on'; });
            save(); applyClasses(); renderPage();
        });
    }

    // ---------- Общее обновление ----------
    function refreshAll() {
        refreshLimit();
        sortTiles();
        syncNav();
        syncPeriod();
        if (state.on.nav) measureNav();
        if (!state.on.nav) closeSheet();
    }

    function init() {
        injectBalance(); injectQuick(); injectHistory(); injectStats(); buildNav();
        hookEdit();
        renderPage(); bindPage();
        // подписка на обновления данных
        const upd = window.updateUI;
        if (typeof upd === 'function' && !upd._exp) {
            const wrapped = function () {
                const r = upd.apply(this, arguments);
                try { refreshAll(); } catch (e) {}
                return r;
            };
            wrapped._exp = true;
            window.updateUI = wrapped;
        }
        // плитки категорий перерисовываются часто — держим порядок «недавние слева»
        const tiles = $('cat-tiles');
        if (tiles) new MutationObserver(() => sortTiles()).observe(tiles, { childList: true });
        // смена раздела: подсветка нижней панели (data-tab на <html> ставит js/pages.js)
        new MutationObserver(syncNav).observe(root, { attributes: true, attributeFilter: ['data-tab'] });
        window.addEventListener('resize', measureNav);
        applyClasses();
        setTimeout(refreshAll, 800);
    }

    window.expOpenCard = openCard;
    window.expState = () => JSON.parse(JSON.stringify(state));
    window.expRenderPage = renderPage;

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
