
let transactions = [];
let priorityGoal = { name: '', amount: 0, icon: '🎯' };
let manualLimit = 0;
let savings = 0;
let currentReportType = 'days';
let isSyncing = false; 

async function init() {
    loadData();
    checkDailyRollover();
    
    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('tx-datetime').value = now.toISOString().slice(0,16);
    
    document.querySelectorAll('.icon-btn').forEach(btn => {
        btn.onclick = (e) => {
            document.querySelectorAll('.icon-btn').forEach(b => b.classList.remove('selected'));
            e.target.classList.add('selected');
        }
    });

    // Сначала отрисовываем локальные данные
    updateUI(false);
    
    // Затем автоматически подтягиваем из облака
    autoSyncPull();
}

function loadData() {
    const dTx = localStorage.getItem('finance_tx');
    const dGoal = localStorage.getItem('finance_goal');
    const dLimit = localStorage.getItem('finance_limit');
    const dSavings = localStorage.getItem('finance_savings');
    const dTheme = localStorage.getItem('finance_theme');
    const dBg = localStorage.getItem('finance_bg');
    
    const dSyncUrl = localStorage.getItem('finance_sync_url');
    const dSyncId = localStorage.getItem('finance_sync_id');

    if (dTx) transactions = JSON.parse(dTx);
    if (dGoal) priorityGoal = JSON.parse(dGoal);
    if (dLimit) manualLimit = parseFloat(dLimit);
    if (dSavings) savings = parseFloat(dSavings);
    
    if (dTheme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
        document.getElementById('theme-icon').innerText = 'light_mode';
    }
    
    if (dBg) setHeaderBg(dBg);
    
    // Восстанавливаем данные синхронизации в поля ввода
    if (dSyncUrl) document.getElementById('sync-url').value = dSyncUrl;
    if (dSyncId) document.getElementById('sync-id').value = dSyncId;

    document.getElementById('manual-limit').value = manualLimit > 0 ? manualLimit : '';
}

// Авто-сохранение настроек синхронизации при вводе
function saveSyncConfig() {
    const url = document.getElementById('sync-url').value.trim();
    const id = document.getElementById('sync-id').value.trim();
    localStorage.setItem('finance_sync_url', url);
    localStorage.setItem('finance_sync_id', id);
}

function toggleTheme() {
    const root = document.documentElement;
    const isDark = root.getAttribute('data-theme') === 'dark';
    root.setAttribute('data-theme', isDark ? 'light' : 'dark');
    document.getElementById('theme-icon').innerText = isDark ? 'dark_mode' : 'light_mode';
    localStorage.setItem('finance_theme', isDark ? 'light' : 'dark');
}

function setHeaderBg(bgClass) {
    document.getElementById('main-header').className = bgClass;
    localStorage.setItem('finance_bg', bgClass);
}

function getTxDateStr(datetimeStr) {
    return datetimeStr.includes('T') ? datetimeStr.split('T')[0] : datetimeStr;
}

function checkDailyRollover() {
    let nowStr = new Date().toISOString();
    const today = nowStr.split('T')[0];
    let lastDate = localStorage.getItem('finance_lastDate');
    
    if (!lastDate) {
        localStorage.setItem('finance_lastDate', today);
        return;
    }
    
    if (lastDate !== today && manualLimit > 0) {
        let dayExpenses = transactions
            .filter(t => getTxDateStr(t.date) === lastDate && t.type === 'expense' && !t.isSystem)
            .reduce((sum, t) => sum + t.amount, 0);
            
        let saved = manualLimit - dayExpenses;
        
        if (saved > 0 && priorityGoal.amount > 0) {
            savings += saved;
            transactions.push({
                id: Date.now().toString(),
                type: 'expense',
                amount: saved,
                category: 'Автоперенос в копилку (остаток лимита)',
                date: lastDate + 'T23:59',
                isSystem: true
            });
            sendNotification("Перевод в копилку", `Вчера вы сэкономили ${saved} ₸, они отправлены на цель!`);
            updateUI(true);
        }
        localStorage.setItem('finance_lastDate', today);
    }
}

// Главная функция обновления. pushToCloud = true вызывает автоматическую отправку
function updateUI(pushToCloud = false) {
    saveDataLocally();

    let balance = transactions.reduce((acc, tx) => tx.type === 'income' ? acc + tx.amount : acc - tx.amount, 0);
    document.getElementById('balance').innerText = `${balance.toFixed(0)} ₸`;
    document.getElementById('savings').innerText = `${savings.toFixed(0)} ₸`;
    document.getElementById('daily-limit-display').innerText = manualLimit > 0 ? `${manualLimit} ₸` : 'Не установлен';

    renderTransactions();
    renderGoal();
    generateReport(); 
    
    if (pushToCloud) {
        autoSyncPush();
    }
}

function renderTransactions() {
    const txList = document.getElementById('tx-list');
    txList.innerHTML = '';
    
    if (transactions.length === 0) {
        txList.innerHTML = '<p class="hint" style="text-align:center; padding: 20px;">Записей пока нет</p>';
        return;
    }

    let sortedAsc = [...transactions].sort((a,b) => new Date(a.date.replace('T', ' ')) - new Date(b.date.replace('T', ' ')));
    let groups = {};
    let runBalance = 0;
    
    sortedAsc.forEach(tx => {
        runBalance += (tx.type === 'income' ? tx.amount : -tx.amount);
        let dDate = getTxDateStr(tx.date);
        
        if(!groups[dDate]) groups[dDate] = { income: 0, expense: 0, endBalance: 0, items: [] };
        
        if(!tx.isSystem) {
            if(tx.type === 'income') groups[dDate].income += tx.amount;
            else groups[dDate].expense += tx.amount;
        }
        groups[dDate].endBalance = runBalance;
        groups[dDate].items.push(tx);
    });

    let datesDesc = Object.keys(groups).sort((a,b) => new Date(b) - new Date(a));
    
    datesDesc.forEach(date => {
        let g = groups[date];
        let [y, m, d] = date.split('-');
        let fDate = `${d}.${m}.${y}`;
        
        let header = document.createElement('div');
        header.className = 'date-group-header';
        header.innerHTML = `
            <h4>${fDate}</h4>
            <p>
                <span style="color:var(--income)">+${g.income}</span> 
                <span style="color:var(--expense)">-${g.expense}</span> 
                <span>Итог: <strong>${g.endBalance} ₸</strong></span>
            </p>
        `;
        txList.appendChild(header);
        
        let itemsDesc = g.items.reverse();
        itemsDesc.forEach(tx => {
            let sign = tx.type === 'income' ? '+' : '-';
            let timeStr = tx.date.includes('T') ? ` <span style="font-size:12px;color:#aaa;">${tx.date.split('T')[1]}</span>` : '';
            let div = document.createElement('div');
            div.className = `tx-item ${tx.type}`;
            div.innerHTML = `
                <div class="tx-info">
                    <strong>${tx.category}</strong><br>${timeStr}
                </div>
                <strong style="font-size: 16px;">${sign}${tx.amount} ₸</strong>
                ${tx.isSystem ? '' : `
                <div class="tx-actions">
                    <button onclick="editTx('${tx.id}')"><span class="material-icons" style="font-size:18px;">edit</span></button>
                    <button onclick="deleteTx('${tx.id}')"><span class="material-icons" style="font-size:18px; color:#f44336;">delete</span></button>
                </div>
                `}
            `;
            txList.appendChild(div);
        });
    });
}

function saveTx(type) {
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;
    const datetime = document.getElementById('tx-datetime').value; 
    
    if (!amount || !category || !datetime) {
        alert('Заполните все поля!');
        return;
    }
    
    transactions.push({ id: Date.now().toString(), type, amount, category, date: datetime });
    
    let dDate = getTxDateStr(datetime);
    if (type === 'expense' && manualLimit > 0) {
        let todayExp = transactions
            .filter(t => getTxDateStr(t.date) === dDate && t.type === 'expense' && !t.isSystem)
            .reduce((sum, t) => sum + t.amount, 0);
            
        if (todayExp > manualLimit) {
            sendNotification("Превышен лимит!", `Потрачено ${todayExp} ₸, лимит: ${manualLimit} ₸.`);
        }
    }

    clearForm();
    updateUI(true);
}

function deleteTx(id) {
    if(confirm("Удалить запись?")) {
        transactions = transactions.filter(t => t.id !== id);
        updateUI(true);
    }
}

function editTx(id) {
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        document.getElementById('edit-id').value = tx.id;
        document.getElementById('tx-datetime').value = tx.date.includes('T') ? tx.date : tx.date + 'T00:00';
        document.getElementById('amount').value = tx.amount;
        document.getElementById('category').value = tx.category;
        
        document.getElementById('add-btns').style.display = 'none';
        document.getElementById('save-edit-btn').style.display = 'flex';
        
        if(window.innerWidth <= 768) {
             showTab('transactions', document.querySelector('.mobile-nav button'));
        }
        document.querySelector('.main-wrapper').scrollTo(0, 0);
    }
}

function saveEdit() {
    const id = document.getElementById('edit-id').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;
    const datetime = document.getElementById('tx-datetime').value;
    
    if (!amount || !category || !datetime) return;
    
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        tx.amount = amount;
        tx.category = category;
        tx.date = datetime;
    }
    
    clearForm();
    updateUI(true);
}

function clearForm() {
    document.getElementById('amount').value = '';
    document.getElementById('category').value = '';
    document.getElementById('edit-id').value = '';
    document.getElementById('add-btns').style.display = 'flex';
    document.getElementById('save-edit-btn').style.display = 'none';
    
    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('tx-datetime').value = now.toISOString().slice(0,16);
}

function generateReport() {
    let type = document.getElementById('report-type').value;
    currentReportType = type;
    const tbody = document.getElementById('report-tbody');
    tbody.innerHTML = '';
    
    let groups = {};
    
    transactions.forEach(tx => {
        if(tx.isSystem) return; 
        let dt = tx.date;
        if(!dt.includes('T')) dt += 'T00:00';
        
        let dateObj = new Date(dt);
        let key = '';
        
        if (type === 'days') {
            key = dt.split('T')[0];
        } else if (type === 'hours') {
            let hour = dt.split('T')[1].split(':')[0];
            key = `${dt.split('T')[0]} ${hour}:00`;
        } else if (type === 'weeks') {
            let d = new Date(Date.UTC(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate()));
            let dayNum = d.getUTCDay() || 7;
            d.setUTCDate(d.getUTCDate() + 4 - dayNum);
            let yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
            let weekNo = Math.ceil((((d - yearStart) / 86400000) + 1)/7);
            key = `Нед. ${weekNo} (${d.getUTCFullYear()})`;
        }
        
        if(!groups[key]) groups[key] = { inc: 0, exp: 0 };
        if(tx.type === 'income') groups[key].inc += tx.amount;
        else groups[key].exp += tx.amount;
    });
    
    let sortedKeys = Object.keys(groups).sort((a,b) => b.localeCompare(a));
    
    if (sortedKeys.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">Нет данных</td></tr>';
        return;
    }
    
    sortedKeys.forEach(k => {
        let g = groups[k];
        let total = g.inc - g.exp;
        let totalColor = total > 0 ? 'var(--income)' : (total < 0 ? 'var(--expense)' : 'inherit');
        let sign = total > 0 ? '+' : '';
        
        let displayKey = k;
        if(type === 'days') {
            let [y, m, d] = k.split('-');
            displayKey = `${d}.${m}.${y}`;
        } else if(type === 'hours') {
            let parts = k.split(' ');
            let [y, m, d] = parts[0].split('-');
            displayKey = `${d}.${m} ${parts[1]}`;
        }

        tbody.innerHTML += `<tr>
            <td>${displayKey}</td>
            <td style="color:var(--income)">${g.inc}</td>
            <td style="color:var(--expense)">${g.exp}</td>
            <td style="color:${totalColor}; font-weight:bold;">${sign}${total}</td>
        </tr>`;
    });
}

// ЭКСПОРТ В EXCEL (NATIVE XLSX)
function exportExcel() {
    if(typeof XLSX === 'undefined') {
        alert('Библиотека для Excel не загрузилась. Проверьте интернет.');
        return;
    }

    let txData = [['Дата', 'Время', 'Тип', 'Категория', 'Сумма']];
    let sortedTx = [...transactions].sort((a,b) => new Date(a.date.replace('T', ' ')) - new Date(b.date.replace('T', ' ')));
    
    let dailyGroups = {};

    sortedTx.forEach(tx => {
        let dt = tx.date;
        if(!dt.includes('T')) dt += 'T00:00';
        let dPart = dt.split('T')[0];
        let tPart = dt.split('T')[1];
        let typeStr = tx.type === 'income' ? 'Доход' : 'Расход';
        
        txData.push([dPart, tPart, typeStr, tx.category, tx.amount]);
        
        if(!tx.isSystem) {
            if(!dailyGroups[dPart]) dailyGroups[dPart] = {inc: 0, exp: 0};
            if(tx.type === 'income') dailyGroups[dPart].inc += tx.amount;
            else dailyGroups[dPart].exp += tx.amount;
        }
    });

    let dailyData = [['Дата', 'Доход', 'Расход', 'Итог дня']];
    Object.keys(dailyGroups).sort().forEach(date => {
        let g = dailyGroups[date];
        dailyData.push([date, g.inc, g.exp, g.inc - g.exp]);
    });

    const wb = XLSX.utils.book_new();
    const ws1 = XLSX.utils.aoa_to_sheet(txData);
    const ws2 = XLSX.utils.aoa_to_sheet(dailyData);
    
    ws1['!cols'] = [{wch: 12}, {wch: 10}, {wch: 10}, {wch: 25}, {wch: 10}];
    ws2['!cols'] = [{wch: 12}, {wch: 12}, {wch: 12}, {wch: 12}];

    XLSX.utils.book_append_sheet(wb, ws1, "Все записи");
    XLSX.utils.book_append_sheet(wb, ws2, "Итоги по дням");
    
    XLSX.writeFile(wb, `Money_Export_${new Date().toISOString().split('T')[0]}.xlsx`);
}

// ЭКСПОРТ ДЛЯ APPLE PAGES (ЧЕРЕЗ ФОРМАТ WORD/DOC)
function exportForPages() {
    let html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
    <head><meta charset="utf-8"><title>Финансовый Отчёт</title></head>
    <body style="font-family: Arial, sans-serif;">
    <h2 style="color: #3f51b5;">Финансовый Отчёт</h2>
    
    <h3>Все записи</h3>
    <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%; border: 1px solid #ddd;">
        <tr>
            <th style="background:#f0f0f0;">Дата</th>
            <th style="background:#f0f0f0;">Время</th>
            <th style="background:#f0f0f0;">Тип</th>
            <th style="background:#f0f0f0;">Категория</th>
            <th style="background:#f0f0f0;">Сумма</th>
        </tr>`;
    
    let sortedTx = [...transactions].sort((a,b) => new Date(a.date.replace('T', ' ')) - new Date(b.date.replace('T', ' ')));
    let dailyGroups = {};

    sortedTx.forEach(tx => {
        let dt = tx.date;
        if(!dt.includes('T')) dt += 'T00:00';
        let dPart = dt.split('T')[0];
        let tPart = dt.split('T')[1];
        let typeStr = tx.type === 'income' ? 'Доход' : 'Расход';
        let color = tx.type === 'income' ? '#4CAF50' : '#f44336';
        
        html += `<tr><td>${dPart}</td><td>${tPart}</td><td style="color:${color};">${typeStr}</td><td>${tx.category}</td><td style="font-weight:bold;">${tx.amount} ₸</td></tr>`;
        
        if(!tx.isSystem) {
            if(!dailyGroups[dPart]) dailyGroups[dPart] = {inc: 0, exp: 0};
            if(tx.type === 'income') dailyGroups[dPart].inc += tx.amount;
            else dailyGroups[dPart].exp += tx.amount;
        }
    });
    
    html += `</table><br><h3>Итоги по дням</h3>
    <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%; border: 1px solid #ddd;">
        <tr>
            <th style="background:#f0f0f0;">Дата</th>
            <th style="background:#f0f0f0;">Доход</th>
            <th style="background:#f0f0f0;">Расход</th>
            <th style="background:#f0f0f0;">Итог дня</th>
        </tr>`;
    
    Object.keys(dailyGroups).sort().forEach(date => {
        let g = dailyGroups[date];
        let total = g.inc - g.exp;
        let tColor = total > 0 ? '#4CAF50' : (total < 0 ? '#f44336' : '#333');
        html += `<tr><td>${date}</td><td style="color:#4CAF50;">${g.inc} ₸</td><td style="color:#f44336;">${g.exp} ₸</td><td style="color:${tColor}; font-weight:bold;">${total} ₸</td></tr>`;
    });
    
    html += `</table></body></html>`;
    
    const blob = new Blob(['\ufeff', html], { type: 'application/msword' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Money_Pages_Report_${new Date().toISOString().split('T')[0]}.doc`;
    link.click();
}

function setPriorityGoal() {
    const name = document.getElementById('goal-name').value;
    const amount = parseFloat(document.getElementById('goal-amount').value);
    const icon = document.querySelector('.icon-btn.selected').getAttribute('data-icon');
    
    if (!name || !amount) return;
    priorityGoal = { name, amount, icon };
    updateUI(true);
}

function renderGoal() {
    const gd = document.getElementById('current-goal-display');
    if (priorityGoal.name && priorityGoal.amount > 0) {
        let percent = Math.min(100, (savings / priorityGoal.amount) * 100);
        gd.innerHTML = `
            <h4>${priorityGoal.icon} ${priorityGoal.name}</h4>
            <p>Собрано: ${savings.toFixed(0)} ₸ из ${priorityGoal.amount} ₸ (${percent.toFixed(1)}%)</p>
            <div class="goal-progress">
                <div class="goal-bar" style="width: ${percent}%"></div>
            </div>
        `;
    }
}

function saveSettings() {
    const l = parseFloat(document.getElementById('manual-limit').value);
    manualLimit = isNaN(l) ? 0 : l;
    
    saveSyncConfig(); // принудительное сохранение настроек
    
    updateUI(true);
    alert('Настройки сохранены! Если ввели новые URL/ID, они тоже сохранены.');
}

function saveDataLocally() {
    localStorage.setItem('finance_tx', JSON.stringify(transactions));
    localStorage.setItem('finance_savings', savings.toString());
    localStorage.setItem('finance_limit', manualLimit.toString());
    localStorage.setItem('finance_goal', JSON.stringify(priorityGoal));
}

function exportBackup() {
    const data = { tx: transactions, savings: savings, limit: manualLimit, goal: priorityGoal, lastDate: localStorage.getItem('finance_lastDate') };
    const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `money1.5_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
}

function importBackup(event) {
    const file = event.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            if(data.tx) transactions = data.tx;
            if(data.savings !== undefined) savings = data.savings;
            if(data.limit !== undefined) manualLimit = data.limit;
            if(data.goal) priorityGoal = data.goal;
            if(data.lastDate) localStorage.setItem('finance_lastDate', data.lastDate);
            updateUI(true);
            alert("Данные успешно восстановлены!");
        } catch (err) {
            alert("Ошибка чтения файла!");
        }
    };
    reader.readAsText(file);
}

function clearAllData() {
    if(confirm("ВНИМАНИЕ! Это удалит все ваши записи локально. Продолжить?")) {
        localStorage.removeItem('finance_tx');
        localStorage.removeItem('finance_savings');
        localStorage.removeItem('finance_limit');
        localStorage.removeItem('finance_goal');
        localStorage.removeItem('finance_lastDate');
        
        transactions = [];
        savings = 0;
        manualLimit = 0;
        priorityGoal = { name: '', amount: 0, icon: '🎯' };
        updateUI(true); 
    }
}

// === УМНАЯ СИНХРОНИЗАЦИЯ ===
function setSyncIconState(state) {
    const mIcon = document.getElementById('cloud-indicator');
    const dIcon = document.getElementById('cloud-indicator-desktop');
    
    let classes = "material-icons sync-icon desktop-only";
    let mClasses = "material-icons sync-icon";
    let iconName = "cloud_done";

    if(state === 'syncing') {
        iconName = 'sync';
        mClasses += " syncing"; classes += " syncing";
    } else if (state === 'error') {
        iconName = 'cloud_off';
        mClasses += " sync-error"; classes += " sync-error";
    } else if (state === 'done') {
        iconName = 'cloud_done';
        mClasses += " synced"; classes += " synced";
    }

    if(mIcon) { mIcon.className = mClasses; mIcon.innerText = iconName; }
    if(dIcon) { dIcon.className = classes; dIcon.innerText = iconName; }
}

function getSyncConfig() {
    let url = document.getElementById('sync-url').value.trim() || localStorage.getItem('finance_sync_url');
    let id = document.getElementById('sync-id').value.trim() || localStorage.getItem('finance_sync_id');
    if(url && url.endsWith('/')) url = url.slice(0, -1);
    return { url, id };
}

function showSyncIndicator(show) {
    const ind = document.getElementById('sync-indicator');
    if(ind) ind.style.display = show ? 'inline-block' : 'none';
}

async function autoSyncPull() {
    const { url, id } = getSyncConfig();
    if(!url || !id) return;
    
    showSyncIndicator(true);
    try {
        const response = await fetch(`${url}/${id}.json`);
        if(response.ok) {
            const data = await response.json();
            if(data) {
                if(data.tx) transactions = data.tx;
                if(data.savings !== undefined) savings = data.savings;
                if(data.limit !== undefined) manualLimit = data.limit;
                if(data.goal) priorityGoal = data.goal;
                if(data.lastDate) localStorage.setItem('finance_lastDate', data.lastDate);
                
                updateUI(false); 
            }
        }
    } catch(e) { 
        console.error('Ошибка авто-скачивания:', e); 
    } finally { 
        showSyncIndicator(false); 
    }
}

async function autoSyncPush() {
    const { url, id } = getSyncConfig();
    if(!url || !id) return;
    
    showSyncIndicator(true);
    const data = {
        tx: transactions,
        savings: savings,
        limit: manualLimit,
        goal: priorityGoal,
        lastDate: localStorage.getItem('finance_lastDate')
    };
    
    try {
        await fetch(`${url}/${id}.json`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
    } catch(e) { 
        console.error('Ошибка авто-отправки:', e); 
    } finally { 
        showSyncIndicator(false); 
    }
}

async function pushToCloud() {
    const status = document.getElementById('sync-status');
    const { url, id } = getSyncConfig();
    
    if(!url || !id) {
        status.innerText = '❌ Заполните URL и ID!';
        status.style.color = '#f44336';
        return;
    }
    
    status.innerText = '⏳ Отправка...';
    status.style.color = '#607d8b';
    await autoSyncPush();
    status.innerText = '✅ Отправлено в облако!';
    status.style.color = '#4CAF50';
}

async function pullFromCloud() {
    const status = document.getElementById('sync-status');
    const { url, id } = getSyncConfig();
    
    if(!url || !id) {
        status.innerText = '❌ Заполните URL и ID!';
        status.style.color = '#f44336';
        return;
    }
    
    status.innerText = '⏳ Скачивание...';
    status.style.color = '#607d8b';
    await autoSyncPull();
    status.innerText = '✅ Данные загружены!';
    status.style.color = '#4CAF50';
}

// Кнопка быстрого обновления (FAB)
async function forceSyncPull() {
    const icon = document.getElementById('fab-icon');
    
    icon.style.animation = 'spin 1s linear infinite';
    await autoSyncPull();
    icon.style.animation = 'none';
    
    icon.style.transform = 'scale(1.3)';
    setTimeout(() => icon.style.transform = 'scale(1)', 200);
}

function showTab(tabId, btn) {
    document.querySelectorAll('.tab').forEach(t => t.style.display = 'none');
    document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
    
    let btnIndex = Array.from(btn.parentNode.children).indexOf(btn);
    if(document.querySelector('.sidebar-nav').children[btnIndex]) {
        document.querySelector('.sidebar-nav').children[btnIndex].classList.add('active');
    }
    if(document.querySelector('.mobile-nav').children[btnIndex]) {
        document.querySelector('.mobile-nav').children[btnIndex].classList.add('active');
    }
    
    document.getElementById(tabId).style.display = 'block';
}

function sendNotification(title, body) {
    if(window.Notification && Notification.permission === "granted") {
        new Notification(title, {body: body});
    } else if (window.Notification && Notification.permission !== "denied") {
        Notification.requestPermission().then(perm => {
            if(perm === "granted") new Notification(title, {body: body});
        });
    }
}

window.onload = init;
