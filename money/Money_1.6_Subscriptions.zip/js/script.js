
let transactions = [];
let subscriptions = [];
let priorityGoal = { name: '', amount: 0, icon: '🎯' };
let manualLimit = 0;
let savings = 0;

async function init() {
    loadData();
    checkDailyRollover();
    
    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('tx-datetime').value = now.toISOString().slice(0,16);
    
    document.querySelectorAll('.icon-btn').forEach(btn => {
        btn.onclick = (e) => {
            document.querySelectorAll('.icon-btn').forEach(b => b.classList.remove('selected'));
            e.target.classList.add('selected');
        }
    });

    updateUI(false);
    autoSyncPull();
}

function loadData() {
    if (localStorage.getItem('finance_tx')) transactions = JSON.parse(localStorage.getItem('finance_tx'));
    if (localStorage.getItem('finance_subs')) subscriptions = JSON.parse(localStorage.getItem('finance_subs'));
    if (localStorage.getItem('finance_goal')) priorityGoal = JSON.parse(localStorage.getItem('finance_goal'));
    if (localStorage.getItem('finance_limit')) manualLimit = parseFloat(localStorage.getItem('finance_limit'));
    if (localStorage.getItem('finance_savings')) savings = parseFloat(localStorage.getItem('finance_savings'));
    
    if (localStorage.getItem('finance_theme') === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
        document.getElementById('theme-icon').innerText = 'light_mode';
    }
    
    if (localStorage.getItem('finance_bg')) setHeaderBg(localStorage.getItem('finance_bg'));
    if (localStorage.getItem('finance_sync_url')) document.getElementById('sync-url').value = localStorage.getItem('finance_sync_url');
    if (localStorage.getItem('finance_sync_id')) document.getElementById('sync-id').value = localStorage.getItem('finance_sync_id');

    document.getElementById('manual-limit').value = manualLimit > 0 ? manualLimit : '';
}

function saveSyncConfig() {
    localStorage.setItem('finance_sync_url', document.getElementById('sync-url').value.trim());
    localStorage.setItem('finance_sync_id', document.getElementById('sync-id').value.trim());
}

function toggleTheme() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
    document.getElementById('theme-icon').innerText = isDark ? 'dark_mode' : 'light_mode';
    localStorage.setItem('finance_theme', isDark ? 'light' : 'dark');
}

function setHeaderBg(bgClass) {
    document.getElementById('main-header').className = bgClass;
    localStorage.setItem('finance_bg', bgClass);
}

function getTxDateStr(datetimeStr) {
    return datetimeStr.includes('T') ? datetimeStr.split('T')[0] : datetimeStr;
}

function checkDailyRollover() {
    let nowStr = new Date().toISOString();
    const today = nowStr.split('T')[0];
    let lastDate = localStorage.getItem('finance_lastDate');
    
    if (!lastDate) {
        localStorage.setItem('finance_lastDate', today);
        return;
    }
    
    if (lastDate !== today && manualLimit > 0) {
        let dayExpenses = transactions
            .filter(t => getTxDateStr(t.date) === lastDate && t.type === 'expense' && !t.isSystem)
            .reduce((sum, t) => sum + t.amount, 0);
            
        let saved = manualLimit - dayExpenses;
        
        if (saved > 0 && priorityGoal.amount > 0) {
            savings += saved;
            transactions.push({
                id: Date.now().toString(),
                type: 'expense',
                amount: saved,
                category: 'Автоперенос в копилку (остаток лимита)',
                date: lastDate + 'T23:59',
                isSystem: true
            });
            updateUI(true);
        }
        localStorage.setItem('finance_lastDate', today);
    }
}

function updateUI(pushToCloud = false) {
    saveDataLocally();

    let balance = transactions.reduce((acc, tx) => tx.type === 'income' ? acc + tx.amount : acc - tx.amount, 0);
    document.getElementById('balance').innerText = `${balance.toFixed(0)} ₸`;
    document.getElementById('savings').innerText = `${savings.toFixed(0)} ₸`;
    document.getElementById('daily-limit-display').innerText = manualLimit > 0 ? `${manualLimit} ₸` : 'Не установлен';

    renderTransactions();
    renderSubscriptions();
    renderGoal();
    generateReport(); 
    
    if (pushToCloud) autoSyncPush();
}

function renderTransactions() {
    const txList = document.getElementById('tx-list');
    txList.innerHTML = '';
    
    if (transactions.length === 0) {
        txList.innerHTML = '<p class="hint" style="text-align:center; padding: 25px;">Записей пока нет</p>';
        return;
    }

    let sortedAsc = [...transactions].sort((a,b) => new Date(a.date.replace('T', ' ')) - new Date(b.date.replace('T', ' ')));
    let groups = {};
    let runBalance = 0;
    
    sortedAsc.forEach(tx => {
        runBalance += (tx.type === 'income' ? tx.amount : -tx.amount);
        let dDate = getTxDateStr(tx.date);
        
        if(!groups[dDate]) groups[dDate] = { income: 0, expense: 0, endBalance: 0, items: [] };
        
        if(!tx.isSystem) {
            if(tx.type === 'income') groups[dDate].income += tx.amount;
            else groups[dDate].expense += tx.amount;
        }
        groups[dDate].endBalance = runBalance;
        groups[dDate].items.push(tx);
    });

    Object.keys(groups).sort((a,b) => new Date(b) - new Date(a)).forEach(date => {
        let g = groups[date];
        let [y, m, d] = date.split('-');
        let fDate = `${d}.${m}.${y}`;
        
        let header = document.createElement('div');
        header.className = 'date-group-header';
        header.innerHTML = `
            <h4>${fDate}</h4>
            <p>
                <span style="color:var(--income)">+${g.income}</span> 
                <span style="color:var(--expense)">-${g.expense}</span> 
                <span>Итог: <strong>${g.endBalance} ₸</strong></span>
            </p>
        `;
        txList.appendChild(header);
        
        g.items.reverse().forEach(tx => {
            let sign = tx.type === 'income' ? '+' : '-';
            let timeStr = tx.date.includes('T') ? ` <span style="font-size:12px;color:var(--text-muted);">${tx.date.split('T')[1]}</span>` : '';
            let div = document.createElement('div');
            div.className = `tx-item ${tx.type}`;
            div.innerHTML = `
                <div class="tx-info">
                    <strong>${tx.category}</strong><br>${timeStr}
                </div>
                <strong style="font-size: 15px;">${sign}${tx.amount} ₸</strong>
                ${tx.isSystem ? '' : `
                <div class="tx-actions">
                    <button onclick="editTx('${tx.id}')"><span class="material-icons" style="font-size:16px;">edit</span></button>
                    <button onclick="deleteTx('${tx.id}')"><span class="material-icons" style="font-size:16px; color:#e74c3c;">delete</span></button>
                </div>
                `}
            `;
            txList.appendChild(div);
        });
    });
}

// УПРАВЛЕНИЕ ПОДПИСКАМИ
function addSub() {
    const name = document.getElementById('sub-name').value.trim();
    const amount = parseFloat(document.getElementById('sub-amount').value);
    const day = parseInt(document.getElementById('sub-day').value);

    if(!name || !amount || isNaN(day) || day < 1 || day > 31) {
        alert("Заполните название, сумму и день месяца (1-31)!");
        return;
    }

    subscriptions.push({ id: Date.now().toString(), name, amount, day });

    document.getElementById('sub-name').value = '';
    document.getElementById('sub-amount').value = '';
    document.getElementById('sub-day').value = '1';

    updateUI(true);
}

function deleteSub(id) {
    if(confirm("Удалить подписку?")) {
        subscriptions = subscriptions.filter(s => s.id !== id);
        updateUI(true);
    }
}

function paySub(id) {
    let sub = subscriptions.find(s => s.id === id);
    if(!sub) return;

    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    let datetimeNow = now.toISOString().slice(0,16);

    transactions.push({
        id: Date.now().toString(),
        type: 'expense',
        amount: sub.amount,
        category: `Подписка: ${sub.name}`,
        date: datetimeNow
    });

    updateUI(true);
    alert(`Подписка «${sub.name}» успешно списана (${sub.amount} ₸)!`);
}

function renderSubscriptions() {
    const subsList = document.getElementById('subs-list');
    subsList.innerHTML = '';

    if(subscriptions.length === 0) {
        subsList.innerHTML = '<p class="hint" style="text-align:center; padding: 20px;">Нет активных подписок</p>';
        return;
    }

    subscriptions.forEach(sub => {
        let div = document.createElement('div');
        div.className = 'sub-item';
        div.innerHTML = `
            <div class="sub-info">
                <strong>${sub.name}</strong><br>
                <span style="font-size: 12px; color: var(--text-muted);">Списание: ${sub.day}-го числа каждого месяца</span>
            </div>
            <strong style="font-size: 16px; color: var(--expense);">-${sub.amount} ₸</strong>
            <div class="sub-actions">
                <button class="pay-btn" onclick="paySub('${sub.id}')"><span class="material-icons" style="font-size:16px;">check</span> Списать</button>
                <button onclick="deleteSub('${sub.id}')"><span class="material-icons" style="font-size:16px; color:#e74c3c;">delete</span></button>
            </div>
        `;
        subsList.appendChild(div);
    });
}

function saveTx(type) {
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;
    const datetime = document.getElementById('tx-datetime').value; 
    
    if (!amount || !category || !datetime) {
        alert('Заполните все поля!');
        return;
    }
    
    transactions.push({ id: Date.now().toString(), type, amount, category, date: datetime });
    clearForm();
    updateUI(true);
}

function deleteTx(id) {
    if(confirm("Удалить запись?")) {
        transactions = transactions.filter(t => t.id !== id);
        updateUI(true);
    }
}

function editTx(id) {
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        document.getElementById('edit-id').value = tx.id;
        document.getElementById('tx-datetime').value = tx.date.includes('T') ? tx.date : tx.date + 'T00:00';
        document.getElementById('amount').value = tx.amount;
        document.getElementById('category').value = tx.category;
        
        document.getElementById('add-btns').style.display = 'none';
        document.getElementById('save-edit-btn').style.display = 'flex';
        document.querySelector('.main-wrapper').scrollTo(0, 0);
    }
}

function saveEdit() {
    const id = document.getElementById('edit-id').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;
    const datetime = document.getElementById('tx-datetime').value;
    
    if (!amount || !category || !datetime) return;
    
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        tx.amount = amount;
        tx.category = category;
        tx.date = datetime;
    }
    
    clearForm();
    updateUI(true);
}

function clearForm() {
    document.getElementById('amount').value = '';
    document.getElementById('category').value = '';
    document.getElementById('edit-id').value = '';
    document.getElementById('add-btns').style.display = 'flex';
    document.getElementById('save-edit-btn').style.display = 'none';
    
    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('tx-datetime').value = now.toISOString().slice(0,16);
}

function generateReport() {
    let type = document.getElementById('report-type').value;
    const tbody = document.getElementById('report-tbody');
    tbody.innerHTML = '';
    
    let groups = {};
    
    transactions.forEach(tx => {
        if(tx.isSystem) return; 
        let dt = tx.date.includes('T') ? tx.date : tx.date + 'T00:00';
        let key = '';
        
        if (type === 'days') {
            key = dt.split('T')[0];
        } else if (type === 'hours') {
            let hour = dt.split('T')[1].split(':')[0];
            key = `${dt.split('T')[0]} ${hour}:00`;
        } else if (type === 'weeks') {
            let dateObj = new Date(dt);
            let d = new Date(Date.UTC(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate()));
            let dayNum = d.getUTCDay() || 7;
            d.setUTCDate(d.getUTCDate() + 4 - dayNum);
            let yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
            let weekNo = Math.ceil((((d - yearStart) / 86400000) + 1)/7);
            key = `Нед. ${weekNo} (${d.getUTCFullYear()})`;
        }
        
        if(!groups[key]) groups[key] = { inc: 0, exp: 0 };
        if(tx.type === 'income') groups[key].inc += tx.amount;
        else groups[key].exp += tx.amount;
    });
    
    let sortedKeys = Object.keys(groups).sort((a,b) => b.localeCompare(a));
    
    if (sortedKeys.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">Нет данных</td></tr>';
        return;
    }
    
    sortedKeys.forEach(k => {
        let g = groups[k];
        let total = g.inc - g.exp;
        let sign = total > 0 ? '+' : '';
        
        tbody.innerHTML += `<tr>
            <td>${k}</td>
            <td style="color:var(--income)">${g.inc}</td>
            <td style="color:var(--expense)">${g.exp}</td>
            <td style="font-weight:bold;">${sign}${total}</td>
        </tr>`;
    });
}

function exportExcel() {
    let data = [['Дата', 'Время', 'Тип', 'Категория', 'Сумма']];
    transactions.forEach(t => {
        let dt = t.date.includes('T') ? t.date : t.date + 'T00:00';
        data.push([dt.split('T')[0], dt.split('T')[1], t.type==='income'?'Доход':'Расход', t.category, t.amount]);
    });
    let wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(data), "Записи");
    XLSX.writeFile(wb, `Money_Export.xlsx`);
}

function exportForPages() { exportExcel(); }

function setPriorityGoal() {
    const name = document.getElementById('goal-name').value;
    const amount = parseFloat(document.getElementById('goal-amount').value);
    const icon = document.querySelector('.icon-btn.selected').getAttribute('data-icon');
    
    if (!name || !amount) return;
    priorityGoal = { name, amount, icon };
    updateUI(true);
}

function renderGoal() {
    const gd = document.getElementById('current-goal-display');
    if (priorityGoal.name && priorityGoal.amount > 0) {
        let percent = Math.min(100, (savings / priorityGoal.amount) * 100);
        gd.innerHTML = `
            <h4>${priorityGoal.icon} ${priorityGoal.name}</h4>
            <p>Собрано: ${savings.toFixed(0)} ₸ из ${priorityGoal.amount} ₸ (${percent.toFixed(1)}%)</p>
            <div class="goal-progress">
                <div class="goal-bar" style="width: ${percent}%"></div>
            </div>
        `;
    }
}

function saveSettings() {
    manualLimit = parseFloat(document.getElementById('manual-limit').value) || 0;
    saveSyncConfig();
    updateUI(true);
    alert('Настройки сохранены!');
}

function saveDataLocally() {
    localStorage.setItem('finance_tx', JSON.stringify(transactions));
    localStorage.setItem('finance_subs', JSON.stringify(subscriptions));
    localStorage.setItem('finance_savings', savings.toString());
    localStorage.setItem('finance_limit', manualLimit.toString());
    localStorage.setItem('finance_goal', JSON.stringify(priorityGoal));
}

function exportBackup() {
    const data = { tx: transactions, subs: subscriptions, savings, limit: manualLimit, goal: priorityGoal };
    const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `money_backup.json`;
    link.click();
}

function importBackup(e) {
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const data = JSON.parse(event.target.result);
            if(data.tx) transactions = data.tx;
            if(data.subs) subscriptions = data.subs;
            if(data.savings !== undefined) savings = data.savings;
            if(data.limit !== undefined) manualLimit = data.limit;
            if(data.goal) priorityGoal = data.goal;
            updateUI(true);
            alert("Данные успешно загружены!");
        } catch (err) {
            alert("Ошибка чтения файла!");
        }
    };
    reader.readAsText(file);
}

function clearAllData() {
    if(confirm("ВНИМАНИЕ! Это удалит все ваши данные. Продолжить?")) {
        localStorage.clear();
        transactions = [];
        subscriptions = [];
        savings = 0;
        manualLimit = 0;
        updateUI(true);
    }
}

async function autoSyncPull() {
    let url = localStorage.getItem('finance_sync_url');
    let id = localStorage.getItem('finance_sync_id');
    if(!url || !id) return;
    try {
        let res = await fetch(`${url.replace(/\/g, '')}/${id}.json`);
        if(res.ok) {
            let data = await res.json();
            if(data) {
                if(data.tx) transactions = data.tx;
                if(data.subs) subscriptions = data.subs;
                if(data.savings !== undefined) savings = data.savings;
                if(data.limit !== undefined) manualLimit = data.limit;
                if(data.goal) priorityGoal = data.goal;
                updateUI(false);
            }
        }
    } catch(e) {}
}

async function autoSyncPush() {
    let url = localStorage.getItem('finance_sync_url');
    let id = localStorage.getItem('finance_sync_id');
    if(!url || !id) return;
    let data = { tx: transactions, subs: subscriptions, savings, limit: manualLimit, goal: priorityGoal };
    try {
        await fetch(`${url.replace(/\/g, '')}/${id}.json`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
    } catch(e) {}
}

async function pushToCloud() { await autoSyncPush(); alert("Отправлено в облако!"); }
async function pullFromCloud() { await autoSyncPull(); alert("Загружено из облака!"); }
async function forceSyncPull() { await autoSyncPull(); alert("Обновлено!"); }

function showTab(tabId, btn) {
    document.querySelectorAll('.tab').forEach(t => t.style.display = 'none');
    document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
    document.getElementById(tabId).style.display = 'block';
    if(btn) btn.classList.add('active');
}

window.onload = init;
