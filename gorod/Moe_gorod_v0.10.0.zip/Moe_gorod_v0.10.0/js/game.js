// «Мое_город» — градостроитель на Babylon.js.
// Три вида: «3D» (свободная камера), «ИЗО» (изометрия с крупными пикселями, как в старых SimCity)
// и «ИЗО HD» (та же изометрия, но с полным разрешением, сглаживанием, SSAO и подробными текстурами).
// Одинаковые здания рисуются пачками (thin instances): тысячи домов — это десятки вызовов отрисовки.
(function () {
  'use strict';
  var G = window.GAME, N = G.mapSize, B = window.BABYLON;
  var SAVE_KEY = 'moe_gorod_save_v1', SEEN_KEY = 'moe_gorod_seen', VIEW_KEY = 'moe_gorod_view';
  var $ = function (id) { return document.getElementById(id); };
  var TOUCH = window.matchMedia && matchMedia('(pointer: coarse)').matches;

  // ---------- Случайные числа с зерном ----------
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function pick(r, arr) { return arr[Math.floor(r() * arr.length)]; }
  function rint(r, a, b) { return a + Math.floor(r() * (b - a + 1)); }
  function newSeed() { return (Math.random() * 2147483647) | 0; }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function hex(c) { return B.Color3.FromHexString(c); }

  // ---------- Состояние ----------
  // b.prog (0…1) есть только у зданий, которые ещё строятся.
  var state, occ = new Int32Array(N * N);
  function sizeOk(n) { return typeof n === 'number' && n >= 16 && n <= 160 && (n | 0) === n; }
  function idx(x, z) { return z * N + x; }
  function inMap(x, z) { return x >= 0 && z >= 0 && x < N && z < N; }
  function key(x, z) { return x + ',' + z; }
  function foot(sz, rot) { var s = G.sizes[sz]; return rot % 2 ? { w: s.d, d: s.w } : { w: s.w, d: s.d }; }
  function isSite(b) { return typeof b.prog === 'number' && b.prog < 1; }

  function demoState(n) {
    n = n || G.mapSize;
    var s = emptyState(n);
    var x, z, o = Math.floor((n - 48) / 2); // пример нарисован для 48×48 — ставим его в центр
    function rd(x, z, t) { x += o; z += o; if (x >= 0 && z >= 0 && x < n && z < n) s.roads[key(x, z)] = t; }
    for (x = 12; x <= 36; x++) rd(x, 24, 'asphalt');
    for (z = 12; z <= 36; z++) rd(24, z, 'asphalt');
    for (x = 8; x <= 23; x++) rd(x, 31, 'dirt');
    for (z = 14; z <= 23; z++) rd(30, z, 'asphalt');
    for (z = 25; z <= 30; z++) rd(12, z, 'dirt');
    for (x = 25; x <= 31; x++) rd(x, 31, 'asphalt'); // подъезд к небоскрёбу (с 0.8.0 без дороги здания не работают)
    rd(13, 26, 'dirt'); rd(13, 27, 'dirt');            // подъезд к казарме
    var list = [
      ['res', '1x1', 19, 23, 0], ['res', '1x1', 21, 23, 0], ['res', '2x1', 16, 23, 0], ['res', '1x1', 14, 30, 2],
      ['res', '2x1', 17, 30, 2], ['res', '1x1', 20, 30, 2], ['res', '2x2', 26, 22, 0], ['res', '4x4', 31, 19, 0],
      ['social', '2x2', 26, 25, 2], ['social', '1x1', 22, 25, 2], ['gov', '2x2', 19, 25, 2], ['gov', '4x4', 25, 18, 0],
      ['corp', '4x4', 28, 27, 3], ['corp', '2x1', 22, 22, 0], ['corp', '1x1', 25, 30, 1], ['army', '2x2', 14, 26, 1]
    ];
    list.forEach(function (b) {
      var f = foot(b[1], b[4]), bx = b[2] + o, bz = b[3] + o;
      if (bx < 0 || bz < 0 || bx + f.w > n || bz + f.d > n) return;
      s.buildings.push({ id: s.nextId++, cat: b[0], size: b[1], x: bx, z: bz, rot: b[4], seed: newSeed() });
    });
    return s;
  }
  // wear — износ асфальта по клеткам (0…1), rq — очередь ремонта, fql / fprog — очередь заказов завода, vehicles — машины завода
  function emptyState(n) { return { v: 1, size: n || G.mapSize, nextId: 1, buildings: [], roads: {}, brigades: [], nextBr: 1, spent: 0, wear: {}, rq: [], autoRepair: false, fql: [], fprog: 0, vehicles: [], nextVeh: 1 }; }
  function fixState(s) {
    if (!sizeOk(s.size)) s.size = 48;
    if (!Array.isArray(s.brigades)) s.brigades = [];
    s.nextBr = s.nextBr || s.brigades.length + 1;
    s.spent = s.spent || 0;
    if (!s.wear || typeof s.wear !== 'object') s.wear = {};
    if (!Array.isArray(s.rq)) s.rq = [];
    s.autoRepair = !!s.autoRepair; s.fprog = +s.fprog || 0;
    if (!Array.isArray(s.fql)) { s.fql = []; for (var i = 0; i < (s.fq | 0); i++) s.fql.push('brigade'); } // до 0.10.0 — число заказанных бригад
    delete s.fq;
    s.fql = s.fql.filter(function (k) { return k === 'brigade' || G.vehicles[k]; });
    if (!Array.isArray(s.vehicles)) s.vehicles = [];
    s.vehicles = s.vehicles.filter(function (v) { return v && G.vehicles[v.kind]; });
    s.nextVeh = s.nextVeh || s.vehicles.reduce(function (m, v) { return Math.max(m, v.id); }, 0) + 1;
    s.buildings = s.buildings.filter(function (b) { return G.cats[b.cat] && G.sizes[b.size]; });
    return s;
  }
  function catSizes(ck) { return G.cats[ck].sizes || ['1x1', '2x1', '2x2', '4x4']; }

  function load() {
    try {
      var s = JSON.parse(localStorage.getItem(SAVE_KEY));
      if (s && s.v === 1 && Array.isArray(s.buildings) && s.roads) return fixState(s);
    } catch (e) {}
    return null;
  }
  var saveTimer = 0;
  function save() { clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, 250); }
  function saveNow() {
    clearTimeout(saveTimer);
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(state)); } catch (e) {}
  }
  function rebuildOcc() { occ.fill(0); state.buildings.forEach(function (b) { markOcc(b, b.id); }); }
  function markOcc(b, val) {
    var f = foot(b.size, b.rot);
    for (var z = b.z; z < b.z + f.d; z++) for (var x = b.x; x < b.x + f.w; x++) if (inMap(x, z)) occ[idx(x, z)] = val;
  }
  var byId = {};
  function getB(id) { return byId[id] || null; }
  function canPlace(sz, rot, x, z, ignoreId) {
    var f = foot(sz, rot);
    for (var zz = z; zz < z + f.d; zz++) for (var xx = x; xx < x + f.w; xx++) {
      if (!inMap(xx, zz)) return false;
      var o = occ[idx(xx, zz)];
      if (o && o !== ignoreId) return false;
      if (state.roads[key(xx, zz)]) return false;
    }
    return true;
  }

  // ---------- Доллары ----------
  function money() { return isFinite(G.money) ? G.money - state.spent : Infinity; }
  function canPay(x) { return money() >= x; }
  function pay(x) { state.spent += x; updateMoney(); }
  function usd(n) { return isFinite(n) ? '$' + Math.round(n).toLocaleString('ru-RU') : '∞'; }
  function costOf(cat, size) { return Math.round(G.costs[size] * (G.costK[cat] || 1) / 1000) * 1000; }
  function buildTime(b) { return G.buildTime[b.size] || 20; }
  function updateMoney() { var m = money(); $('stMoney').textContent = isFinite(m) ? Math.round(m).toLocaleString('ru-RU') : '∞'; }

  // ---------- Движок Babylon.js ----------
  var canvas = $('scene');
  var engine = new B.Engine(canvas, true, { stencil: false, preserveDrawingBuffer: false, powerPreference: 'high-performance' }, false);
  var scene = new B.Scene(engine);
  scene.useRightHandedSystem = true;      // как в прежней версии: x вправо, z к зрителю
  scene.skipPointerMovePicking = true;    // свои обработчики касаний — движку не нужно искать объекты
  scene.autoClearDepthAndStencil = true;
  var SKY = '#a9d0f0', VOID = '#10141c';
  scene.clearColor = B.Color4.FromHexString(SKY + 'ff');
  scene.fogColor = hex(SKY);

  var camera = new B.FreeCamera('cam', new B.Vector3(0, 30, 30), scene);
  camera.fov = 45 * Math.PI / 180; camera.minZ = 0.1; camera.maxZ = 600;
  camera.inputs.clear();

  var hemi = new B.HemisphericLight('hemi', new B.Vector3(0, 1, 0), scene);
  hemi.diffuse = hex('#e8f2ff'); hemi.groundColor = hex('#6f8a5a'); hemi.specular = B.Color3.Black(); hemi.intensity = 0.72;
  // Солнце идёт за камерой: тени чёткие на карте любого размера.
  var SUN_OFF = new B.Vector3(-22, 40, 18);
  var sun = new B.DirectionalLight('sun', SUN_OFF.scale(-1).normalize(), scene);
  sun.diffuse = hex('#fff3dc'); sun.specular = B.Color3.Black(); sun.intensity = 0.62;
  sun.autoUpdateExtends = false; sun.autoCalcShadowZBounds = false;
  sun.shadowMinZ = 1; sun.shadowMaxZ = 200;
  var shadowGen = new B.ShadowGenerator(2048, sun);
  shadowGen.bias = 0.0015; shadowGen.normalBias = 0.01;
  function setShadowStyle(iso) {
    // Один и тот же фильтр в обоих видах: смена фильтра на лету пересобирает шейдеры.
    shadowGen.usePercentageCloserFiltering = true;
    shadowGen.filteringQuality = B.ShadowGenerator.QUALITY_MEDIUM;
    shadowGen.usePoissonSampling = false;
  }

  // ---------- Материалы (на каждую сцену свой набор) ----------
  function windowCanvas(style, wall) {
    var c = document.createElement('canvas'); c.width = c.height = 64;
    var g = c.getContext('2d');
    g.fillStyle = wall; g.fillRect(0, 0, 64, 64);
    function win(x, y, w, h, glass, frame) {
      if (frame) { g.fillStyle = frame; g.fillRect(x - 2, y - 2, w + 4, h + 4); }
      var gr = g.createLinearGradient(x, y, x + w, y + h);
      gr.addColorStop(0, glass[0]); gr.addColorStop(1, glass[1]);
      g.fillStyle = gr; g.fillRect(x, y, w, h);
    }
    if (style === 'res') win(18, 18, 28, 28, ['#a9cbe8', '#5f86ad'], '#fbf8f0');
    else if (style === 'office') win(4, 20, 56, 24, ['#9bbbd9', '#557aa1'], '#e8edf2');
    else if (style === 'glass') {
      var gr = g.createLinearGradient(0, 0, 64, 64); gr.addColorStop(0, '#7fb0dd'); gr.addColorStop(1, wall);
      g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
      g.fillStyle = 'rgba(220,235,250,.75)'; g.fillRect(0, 0, 64, 3); g.fillRect(0, 0, 3, 64);
    }
    else if (style === 'army') win(22, 24, 20, 14, ['#56634f', '#303a2c'], '#4b553a');
    else if (style === 'gov') win(22, 12, 20, 40, ['#a3c1dc', '#5d7fa0'], '#fffdf6');
    else if (style === 'shop') win(6, 14, 52, 42, ['#c3def2', '#6f98bd'], '#ffffff');
    return c;
  }
  // Окна для «ИЗО HD»: та же раскладка, но 256×256 — рамы, подоконники, блики на стекле, фактура стен.
  function shade(c, k) { // осветлить (k>0) или затемнить (k<0) цвет #rrggbb
    var n = parseInt(c.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    function f(v) { return Math.round(k > 0 ? v + (255 - v) * k : v * (1 + k)); }
    return 'rgb(' + f(r) + ',' + f(g) + ',' + f(b) + ')';
  }
  function windowCanvasHD(style, wall) {
    var S = 256, c = document.createElement('canvas'); c.width = c.height = S;
    var g = c.getContext('2d'), r = rng(style.length * 131 + parseInt(wall.slice(1), 16));
    g.fillStyle = wall; g.fillRect(0, 0, S, S);
    // штукатурка: мелкий шум
    for (var i = 0; i < 1800; i++) {
      g.fillStyle = r() > 0.5 ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.05)';
      g.fillRect(r() * S, r() * S, 1 + r() * 2, 1 + r() * 2);
    }
    // межэтажный пояс сверху и тень снизу
    g.fillStyle = shade(wall, 0.18); g.fillRect(0, 0, S, 6);
    g.fillStyle = 'rgba(0,0,0,.10)'; g.fillRect(0, 6, S, 3);
    g.fillStyle = 'rgba(0,0,0,.08)'; g.fillRect(0, S - 4, S, 4);
    function glass(x, y, w, h, c0, c1) {
      var gr = g.createLinearGradient(x, y, x + w * 0.4, y + h);
      gr.addColorStop(0, c0); gr.addColorStop(1, c1);
      g.fillStyle = gr; g.fillRect(x, y, w, h);
      // отражение неба — косая светлая полоса
      g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
      g.fillStyle = 'rgba(255,255,255,.22)';
      g.beginPath(); g.moveTo(x + w * 0.15, y + h); g.lineTo(x + w * 0.45, y); g.lineTo(x + w * 0.62, y); g.lineTo(x + w * 0.32, y + h); g.fill();
      g.fillStyle = 'rgba(255,255,255,.12)';
      g.beginPath(); g.moveTo(x + w * 0.5, y + h); g.lineTo(x + w * 0.8, y); g.lineTo(x + w * 0.88, y); g.lineTo(x + w * 0.58, y + h); g.fill();
      // тень от рамы сверху
      g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(x, y, w, Math.max(3, h * 0.06));
      g.restore();
    }
    function win(x, y, w, h, c0, c1, frame, opt) {
      opt = opt || {};
      x *= 4; y *= 4; w *= 4; h *= 4;
      var fw = opt.fw || 7;
      g.fillStyle = 'rgba(0,0,0,.18)'; g.fillRect(x - fw + 3, y - fw + 4, w + fw * 2, h + fw * 2); // тень проёма
      g.fillStyle = frame; g.fillRect(x - fw, y - fw, w + fw * 2, h + fw * 2);
      g.fillStyle = shade(frame, -0.18); g.fillRect(x - fw, y + h, w + fw * 2, fw);            // низ рамы темнее
      glass(x, y, w, h, c0, c1);
      g.fillStyle = frame;
      if (opt.cross) { g.fillRect(x + w / 2 - 3, y, 6, h); g.fillRect(x, y + h * 0.38 - 3, w, 6); }
      if (opt.vbars) for (var k = 1; k < opt.vbars; k++) g.fillRect(x + w * k / opt.vbars - 3, y, 6, h);
      if (opt.curtain) { g.fillStyle = opt.curtain; g.fillRect(x + 2, y + 2, w * 0.22, h - 4); g.fillRect(x + w - w * 0.22 - 2, y + 2, w * 0.22, h - 4); }
      if (opt.sill) { // подоконник
        g.fillStyle = '#f4f2ec'; g.fillRect(x - fw - 6, y + h + fw, w + fw * 2 + 12, 8);
        g.fillStyle = 'rgba(0,0,0,.22)'; g.fillRect(x - fw - 4, y + h + fw + 8, w + fw * 2 + 8, 5);
      }
    }
    var CUR = ['#f3e6c4', '#e9c9c0', '#d8e4c9', '#f1efe9'];
    if (style === 'res') win(18, 18, 28, 28, '#b9d6ee', '#557ca3', '#fbf8f0', { cross: true, sill: true, curtain: pick(r, CUR) });
    else if (style === 'office') win(4, 20, 56, 24, '#a9c7e3', '#4c7099', '#e8edf2', { vbars: 4, fw: 5 });
    else if (style === 'glass') {
      var gr = g.createLinearGradient(0, 0, S * 0.5, S); gr.addColorStop(0, '#9cc6ea'); gr.addColorStop(0.55, shade(wall, 0.1)); gr.addColorStop(1, shade(wall, -0.25));
      g.fillStyle = gr; g.fillRect(0, 0, S, S);
      g.fillStyle = 'rgba(255,255,255,.18)';
      g.beginPath(); g.moveTo(0, S * 0.9); g.lineTo(S * 0.55, 0); g.lineTo(S * 0.75, 0); g.lineTo(S * 0.2, S); g.lineTo(0, S); g.fill();
      g.fillStyle = 'rgba(200,225,248,.85)'; g.fillRect(0, 0, S, 8); g.fillRect(0, 0, 8, S);
      g.fillStyle = 'rgba(20,40,70,.35)'; g.fillRect(0, 8, S, 4); g.fillRect(S / 2 - 2, 8, 4, S - 8);
    }
    else if (style === 'army') win(22, 24, 20, 14, '#6a7a60', '#2c3628', '#4b553a', { fw: 5, vbars: 2 });
    else if (style === 'gov') win(22, 12, 20, 40, '#b4cfe6', '#53769a', '#fffdf6', { cross: true, sill: true, fw: 6 });
    else if (style === 'shop') {
      win(6, 14, 52, 42, '#d2e8f7', '#6690b6', '#ffffff', { vbars: 3, fw: 6 });
      g.fillStyle = 'rgba(0,0,0,.12)'; g.fillRect(0, 0, S, 40);   // тень от козырька
    }
    return c;
  }
  function makeKit(sc) {
    var mats = {}, wallM = {}, wallInfo = [], kitHD = false;
    function base(name) { var m = new B.StandardMaterial(name, sc); m.specularColor = B.Color3.Black(); return m; }
    return {
      scene: sc,
      mat: function (color) {
        if (mats[color]) return mats[color];
        var m = base('m' + color); m.diffuseColor = hex(color); return (mats[color] = m);
      },
      wall: function (style, wall) {
        var k = style + wall; if (wallM[k]) return wallM[k];
        var m = base('w' + k), info = { m: m, style: style, wall: wall, lo: null, hi: null };
        m.diffuseColor = B.Color3.White(); wallInfo.push(info);
        wallTex(info, kitHD);
        return (wallM[k] = m);
      },
      // переключить окна всех домов между обычными (64 px) и HD (256 px)
      setHD: function (hd) { kitHD = hd; wallInfo.forEach(function (i) { wallTex(i, hd); }); }
    };
    function wallTex(info, hd) {
      var slot = hd ? 'hi' : 'lo';
      if (!info[slot]) {
        var t = new B.DynamicTexture('t' + slot + info.style + info.wall, (hd ? windowCanvasHD : windowCanvas)(info.style, info.wall), sc, true);
        t.update(); t.wrapU = t.wrapV = B.Texture.WRAP_ADDRESSMODE; t.anisotropicFilteringLevel = hd ? 8 : 4;
        info[slot] = t;
      }
      info.m.diffuseTexture = info[slot];
      if (info.style === 'glass') info.m.specularColor = hd ? hex('#3a4656') : B.Color3.Black(); // блик на стеклянных башнях
      if (info.style === 'glass') info.m.specularPower = 48;
    }
  }
  var kit = makeKit(scene);

  // ---------- Модели зданий ----------
  // Модель собирается из простых фигур и сливается в ОДНУ сетку (с несколькими материалами).
  var RES_WALL = ['#f2d3a2', '#e9b98f', '#f4e7c8', '#d9c2a7', '#f0c9c0', '#cfe0c3', '#e3d0e8'];
  var RES_ROOF = ['#b8553a', '#8e4a3a', '#6b4c3b', '#a0522d', '#5e6a7a', '#3f6b5a'];
  var perUnit = { res: 1.5, office: 2.5, glass: 2.5, army: 2, gov: 2, shop: 1, plain: 0 };

  function Shapes(K, ox, oz) {
    var sc = K.scene, parts = [];
    function put(m, material, x, y, z) { m.position.set(x - ox, y, z - oz); m.material = material; parts.push(m); return m; }
    var api = {
      parts: parts,
      box: function (w, h, d, material, x, y, z, faceUV) {
        return put(B.MeshBuilder.CreateBox('b', { width: w, height: h, depth: d, faceUV: faceUV, wrap: true }, sc), material, x, y, z);
      },
      cube: function (x0, z0, x1, z1, y0, h, color) {
        return api.box(x1 - x0, h, z1 - z0, K.mat(color), (x0 + x1) / 2, y0 + h / 2, (z0 + z1) / 2);
      },
      cyl: function (rt, rb, h, seg, color, x, y, z) {
        return put(B.MeshBuilder.CreateCylinder('c', { diameterTop: rt * 2, diameterBottom: rb * 2, height: h, tessellation: seg }, sc), K.mat(color), x, y, z);
      },
      // поворот «запекается» в вершины, затем масштаб — как в прежней версии
      bake: function (m, rx, ry, rz) { m.rotation.set(rx || 0, ry || 0, rz || 0); var p = m.position.clone(); m.position.set(0, 0, 0); m.bakeCurrentTransformIntoVertices(); m.position.copyFrom(p); return m; },
      merge: function () {
        var m = B.Mesh.MergeMeshes(parts, true, true, undefined, false, true);
        m.refreshBoundingInfo();
        return m;
      }
    };
    return api;
  }

  function buildModel(K, cat, size, seed) {
    var s = G.sizes[size], W = s.w, D = s.d, m = 0.08;
    var r = rng(seed), S = Shapes(K, W / 2, D / 2);
    function part(x0, z0, x1, z1, y0, h, floors, style, wall, roof, roofType, roofH) {
      var w = x1 - x0, d = z1 - z0, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
      if (style === 'plain') S.box(w, h, d, K.mat(wall), cx, y0 + h / 2, cz);
      else {
        var uw = Math.max(1, Math.round(w * perUnit[style])), ud = Math.max(1, Math.round(d * perUnit[style])), cap = new B.Vector4(0.02, 0.02, 0.03, 0.03);
        S.box(w, h, d, K.wall(style, wall), cx, y0 + h / 2, cz,
          [new B.Vector4(0, 0, uw, floors), new B.Vector4(0, 0, uw, floors), new B.Vector4(0, 0, ud, floors), new B.Vector4(0, 0, ud, floors), cap, cap]);
      }
      if (roofType === 'hip') {
        var cone = B.MeshBuilder.CreateCylinder('r', { diameterTop: 0, diameterBottom: Math.SQRT2, height: 1, tessellation: 4 }, K.scene);
        cone.material = K.mat(roof);
        S.bake(cone, 0, Math.PI / 4, 0);
        cone.convertToFlatShadedMesh();
        cone.scaling.set(w * 1.12, roofH, d * 1.12);
        cone.position.set(cx - W / 2, y0 + h + roofH / 2, cz - D / 2);
        S.parts.push(cone);
      } else if (roofType === 'flat') {
        S.box(w + 0.04, 0.05, d + 0.04, K.mat(roof), cx, y0 + h + 0.025, cz);
      } else if (roofType === 'none' && style !== 'plain') {
        S.box(w, 0.01, d, K.mat(roof), cx, y0 + h + 0.005, cz);
      }
    }
    var cube = S.cube;
    function flag(x, y, z, color) {
      S.cyl(0.015, 0.015, 0.6, 6, '#c9ccd1', x, y + 0.3, z);
      S.box(0.26, 0.15, 0.01, K.mat(color || '#19a7c9'), x + 0.14, y + 0.51, z);
    }
    function tree(x, z, sc) {
      sc = sc || 1;
      S.cyl(0.03 * sc, 0.04 * sc, 0.2 * sc, 6, '#7a5634', x, 0.1 * sc, z);
      S.cyl(0, 0.17 * sc, 0.42 * sc, 7, '#3f8f46', x, 0.38 * sc, z);
    }
    function cross(x, y, z, color, flat) {
      if (flat) { cube(x - 0.25, z - 0.07, x + 0.25, z + 0.07, y, 0.03, color); cube(x - 0.07, z - 0.25, x + 0.07, z + 0.25, y, 0.03, color); }
      else { cube(x - 0.1, z - 0.012, x + 0.1, z + 0.012, y - 0.03, 0.06, color); cube(x - 0.03, z - 0.012, x + 0.03, z + 0.012, y - 0.1, 0.2, color); }
    }
    var F = [m, m, W - m, D - m];

    if (cat === 'res') {
      var wall = pick(r, RES_WALL), roof = pick(r, RES_ROOF);
      if (size === '1x1') { part(F[0], F[1], F[2], F[3], 0, 0.5, 1, 'res', wall, roof, 'hip', 0.38); cube(0.62, 0.3, 0.72, 0.4, 0.55, 0.35, '#8a6b5a'); }
      else if (size === '2x1') { part(F[0], F[1], F[2], F[3], 0, 0.55, 1, 'res', wall, roof, 'hip', 0.42); cube(1.45, 0.35, 1.56, 0.46, 0.6, 0.35, '#8a6b5a'); tree(0.25, 0.85, 0.6); }
      else if (size === '2x2') { part(F[0], F[1], F[2], F[3], 0, 1.5, 5, 'res', wall, roof, 'flat'); cube(0.4, 0.4, 0.75, 0.75, 1.55, 0.2, '#b9b2a6'); }
      else {
        part(m, m, W - m, 1.7, 0, 1.8, 6, 'res', wall, roof, 'flat');
        part(m, 1.7, 1.7, D - m, 0, 1.8, 6, 'res', pick(r, RES_WALL), roof, 'flat');
        part(2.3, 2.3, W - m, D - m, 0, 3.0, 10, 'res', wall, roof, 'flat');
        cube(1.75, 1.75, 3.92, 2.25, 0, 0.02, '#7fb25e'); cube(1.75, 2.25, 2.25, 3.92, 0, 0.02, '#7fb25e');
        tree(2.0, 3.4); tree(2.0, 2.6, 0.8); tree(3.2, 2.0, 0.9);
      }
    } else if (cat === 'social') {
      if (size === '1x1') { part(F[0], F[1], F[2], F[3], 0, 0.5, 1, 'shop', '#f3f0e6', '#9aa7ad', 'flat'); cross(0.5, 0.42, D - m + 0.015, '#2fa64a'); }
      else if (size === '2x1') {
        part(F[0], F[1], F[2], F[3], 0, 0.5, 1, 'res', '#fff1c9', '#e5664d', 'hip', 0.35);
        cube(0.15, 0.78, 0.45, 0.92, 0, 0.05, '#f2d16b');
      } else if (size === '2x2') {
        part(m, m, W - m, 1.25, 0, 0.95, 3, 'res', '#efe0c8', '#7a8d99', 'flat');
        part(m, 1.25, 1.05, D - m, 0, 0.7, 2, 'office', '#e9d6b8', '#7a8d99', 'flat');
        cube(1.15, 1.35, 1.92, 1.92, 0, 0.02, '#c9725a'); flag(1.85, 0.97, 0.15);
      } else {
        part(F[0], F[1], F[2], F[3], 0, 0.7, 2, 'office', '#f4f6f7', '#9aa7ad', 'flat');
        part(0.6, 0.8, 3.4, 3.2, 0.7, 1.6, 5, 'res', '#f4f6f7', '#b5c0c6', 'flat');
        cross(2.0, 2.35, 2.0, '#e03b3b', true);
        cube(0.3, D - m - 0.02, 1.0, D - m + 0.25, 0, 0.35, '#e03b3b');
      }
    } else if (cat === 'gov') {
      if (size === '1x1') { part(F[0], F[1], F[2], F[3], 0, 0.5, 1, 'gov', '#e8e3d2', '#3a6ea5', 'hip', 0.3); cube(0.75, D - m, 0.86, D - m + 0.1, 0, 0.22, '#2f6fc2'); }
      else if (size === '2x1') {
        part(F[0], F[1], F[2], F[3], 0, 0.75, 2, 'office', '#e3e7ee', '#7d8794', 'flat');
        cube(m - 0.01, m - 0.01, W - m + 0.01, D - m + 0.01, 0.33, 0.06, '#2c5aa0');
        flag(1.8, 0.8, 0.2);
      } else if (size === '2x2') {
        part(m, m, W - m, D - 0.45, 0, 1.0, 3, 'gov', '#e6e2d6', '#8c949e', 'flat');
        for (var i = 0; i < 5; i++) S.cyl(0.045, 0.05, 0.9, 10, '#f5f2ea', 0.25 + i * 0.375, 0.45, D - 0.22);
        cube(m, D - 0.45, W - m, D - m, 0.9, 0.12, '#e6e2d6');
        cube(m, D - 0.45, W - m, D - m + 0.04, 0, 0.05, '#cfcabd');
        flag(1.0, 1.05, 0.8);
      } else {
        part(F[0], F[1], F[2], F[3], 0, 0.8, 2, 'gov', '#ece6d6', '#8c949e', 'flat');
        part(0.8, 0.6, 3.2, 3.0, 0.8, 1.4, 4, 'gov', '#f1ebdc', '#8c949e', 'flat');
        var dome = B.MeshBuilder.CreateSphere('d', { diameter: 1.1, segments: 12, slice: 0.5 }, K.scene);
        dome.material = K.mat('#3f8fbf'); dome.position.set(2.0 - W / 2, 2.25, 1.8 - D / 2); S.parts.push(dome);
        flag(2.0, 2.8, 1.8);
        for (var j = 0; j < 6; j++) S.cyl(0.05, 0.055, 0.75, 10, '#fbf8f0', 0.9 + j * 0.44, 0.4, D - 0.02);
        cube(0.7, D - 0.1, 3.3, D - 0.0, 0.76, 0.1, '#ece6d6');
      }
    } else if (cat === 'army') {
      var aw = '#7d8b5a', ar = '#58623f';
      if (size === '1x1') {
        part(0.3, 0.3, 0.72, 0.72, 0, 0.45, 1, 'army', aw, ar, 'flat');
        cube(0.15, 0.82, 0.95, 0.86, 0.22, 0.04, '#e25b4a'); cube(0.12, 0.78, 0.18, 0.9, 0, 0.25, '#555555');
      } else if (size === '2x1') {
        part(F[0], F[1], F[2], F[3], 0, 0.7, 2, 'army', '#c9c2a0', ar, 'flat');
        cube(m - 0.01, m - 0.01, W - m + 0.01, D - m + 0.01, 0.05, 0.08, aw);
        flag(1.75, 0.75, 0.25, '#2f6b3a');
      } else if (size === '2x2') {
        part(m, 0.18, W - m, 0.92, 0, 0.55, 1, 'army', aw, ar, 'hip', 0.2);
        part(m, 1.1, W - m, 1.84, 0, 0.55, 1, 'army', aw, ar, 'hip', 0.2);
        flag(0.15, 0, 1.0, '#2f6b3a');
      } else {
        var fc = '#6b6b5e', fh = 0.18, ft = 0.04;
        cube(m, m, W - m, m + ft, 0, fh, fc); cube(m, D - m - ft, W - m, D - m, 0, fh, fc);
        cube(m, m, m + ft, D - m, 0, fh, fc); cube(W - m - ft, m, W - m, 1.6, 0, fh, fc); cube(W - m - ft, 2.4, W - m, D - m, 0, fh, fc);
        part(0.3, 0.35, 1.8, 1.05, 0, 0.5, 1, 'army', aw, ar, 'hip', 0.18);
        part(0.3, 1.35, 1.8, 2.05, 0, 0.5, 1, 'army', aw, ar, 'hip', 0.18);
        part(2.2, 0.35, 3.7, 1.75, 0, 0.8, 1, 'plain', '#8a9465', '#6c7650', 'flat');
        cube(2.2, 2.2, 3.7, 3.7, 0, 0.02, '#9e9e94');
        // танк
        cube(2.65, 2.75, 3.25, 3.15, 0.02, 0.16, '#4e5a35'); cube(2.8, 2.82, 3.1, 3.08, 0.18, 0.1, '#5b6840');
        S.bake(S.cyl(0.02, 0.02, 0.38, 6, '#3f4a2b', 2.95, 0.24, 2.72), Math.PI / 2, 0, 0);
        // вышка
        cube(0.35, 3.25, 0.65, 3.55, 0, 1.0, '#6c6a5a'); cube(0.25, 3.15, 0.75, 3.65, 1.0, 0.25, aw); cube(0.22, 3.12, 0.78, 3.68, 1.25, 0.04, ar);
        flag(1.2, 0, 2.8, '#2f6b3a');
      }
    } else if (cat === 'corp') {
      if (size === '1x1') {
        part(F[0], F[1], F[2], F[3], 0, 0.5, 1, 'shop', '#f6d9a0', '#8d8d8d', 'flat');
        S.bake(cube(0.12, D - m, 0.88, D - m + 0.16, 0.4, 0.03, '#d9534f'), 0.25, 0, 0);
      } else if (size === '2x1') {
        part(F[0], F[1], F[2], F[3], 0, 1.3, 4, 'office', '#cfd8e3', '#7b8794', 'flat');
        cube(0.3, 0.3, 0.55, 0.55, 1.35, 0.12, '#a9b1b9'); cube(1.3, 0.35, 1.6, 0.6, 1.35, 0.12, '#a9b1b9');
      } else if (size === '2x2') {
        part(F[0], F[1], F[2], F[3], 0, 2.8, 9, 'glass', '#2f5f93', '#5c6b7a', 'flat');
        cube(0.6, 0.6, 1.4, 1.4, 2.85, 0.25, '#8695a5');
      } else {
        part(F[0], F[1], F[2], F[3], 0, 0.6, 2, 'glass', '#264b78', '#5c6b7a', 'flat');
        part(0.7, 0.7, 3.3, 3.3, 0.65, 5.2, 17, 'glass', '#2f5f93', '#5c6b7a', 'none');
        part(1.0, 1.0, 3.0, 3.0, 5.85, 0.4, 1, 'plain', '#c7d2dd', '#9aa7b4', 'flat');
        S.cyl(0.02, 0.05, 1.1, 8, '#d0d6dc', 2.0, 6.85, 2.0);
      }
    } else if (cat === 'factory') {
      // Механический завод 3×3: цех с пилообразной крышей, ворота, офис, труба, бак, готовый грузовик во дворе
      var ROOF = '#7d838c', HH = 0.85, RH = 0.3, ZB = 2.0;
      part(m, m, W - m, ZB, 0, HH, 2, 'office', '#c4bdae', ROOF, 'none');
      var P = (ZB - m) / 4;
      for (var t = 0; t < 4; t++) {
        var z0 = m + t * P;
        S.bake(S.box(W - 2 * m, 0.03, Math.hypot(P, RH), K.mat(ROOF), W / 2, HH + RH / 2, z0 + P / 2), Math.atan2(RH, P), 0, 0);
        S.box(W - 2 * m - 0.02, RH, 0.02, K.mat('#9cc3dd'), W / 2, HH + RH / 2, z0 + 0.012);
      }
      cube(m - 0.01, m - 0.01, W - m + 0.01, ZB + 0.01, HH - 0.06, 0.06, '#e0a25a');                // оранжевый пояс
      cube(1.5, ZB - 0.005, 2.75, ZB + 0.02, 0, 0.62, '#5b6068');                                  // ворота
      for (var gl = 1; gl < 6; gl++) cube(1.5, ZB + 0.02, 2.75, ZB + 0.03, gl * 0.1, 0.012, '#7c828b');
      cube(1.45, ZB - 0.01, 2.8, ZB + 0.12, 0.62, 0.04, '#e0a25a');                                // козырёк
      part(m, ZB, 1.3, D - m, 0, 0.7, 2, 'office', '#e3dccb', '#6f7782', 'flat');                  // офис
      cube(0.28, D - m - 0.06, 1.1, D - m - 0.02, 0.72, 0.2, '#e0a25a');                           // вывеска
      S.bake(S.cyl(0.07, 0.07, 0.02, 12, '#3b3f45', 0.69, 0.82, D - m), Math.PI / 2, 0, 0);
      cube(1.3, ZB, W - m, D - m, 0, 0.012, '#5c6066');                                            // двор
      cube(1.42, D - 0.2, 1.62, D - m, 0, 0.016, '#f1f1e6');                                       // разметка выезда
      // готовый зелёный грузовик во дворе (смотрит к выезду)
      cube(2.05, 2.15, 2.33, 2.55, 0.06, 0.05, '#2c2c2a'); cube(2.04, 2.15, 2.34, 2.52, 0.11, 0.1, '#a8844f');
      cube(2.06, 2.55, 2.32, 2.78, 0.06, 0.2, '#4f8f3e'); cube(2.07, 2.7, 2.31, 2.79, 0.17, 0.07, '#9cc3dd');
      [[2.03, 2.25], [2.35, 2.25], [2.03, 2.68], [2.35, 2.68]].forEach(function (w) { cube(w[0] - 0.03, w[1] - 0.05, w[0] + 0.03, w[1] + 0.05, 0, 0.1, '#1c1c1c'); });
      // труба и бак на крыше
      S.cyl(0.1, 0.14, 2.3, 12, '#9a4a36', 0.45, 1.15, 0.42);
      S.cyl(0.106, 0.106, 0.1, 12, '#f2f2ea', 0.45, 1.95, 0.42); S.cyl(0.103, 0.103, 0.1, 12, '#c8362b', 0.45, 2.2, 0.42);
      S.cyl(0.2, 0.2, 0.32, 14, '#8f9aa6', 2.45, HH + RH + 0.2, 0.55); S.cyl(0, 0.21, 0.12, 14, '#6d7782', 2.45, HH + RH + 0.42, 0.55);
    } else if (cat === 'depot') {
      // Дорожное депо 2×2: гараж с двумя воротами, площадка, кучи щебня и асфальта, конусы
      part(m, m, W - m, 1.15, 0, 0.7, 1, 'plain', '#d8c27e', '#5c5f66', 'flat');
      [0.53, 1.47].forEach(function (x) {
        cube(x - 0.36, 1.145, x + 0.36, 1.17, 0, 0.52, '#6b6f76');
        for (var k = 1; k < 5; k++) cube(x - 0.36, 1.17, x + 0.36, 1.178, k * 0.1, 0.012, '#8d9299');
      });
      cube(m - 0.005, 1.14, W - m + 0.005, 1.19, 0.56, 0.06, '#f08a24'); cube(m - 0.005, 1.14, W - m + 0.005, 1.19, 0.62, 0.04, '#f4f2ec');
      cube(0.55, 0.9, 1.45, 0.94, 0.72, 0.2, '#f0c040'); cube(0.55, 0.94, 1.45, 0.95, 0.78, 0.06, '#2b2b2b');   // вывеска на крыше
      cube(m, 1.15, W - m, D - m, 0, 0.014, '#3c4047');                                            // асфальт перед гаражом
      S.cyl(0, 0.26, 0.24, 9, '#9b9384', 1.66, 0.12, 1.66);                                        // щебень
      S.cyl(0, 0.17, 0.15, 9, '#26282b', 1.25, 0.075, 1.74);                                       // асфальт
      [0.25, 0.45, 0.65].forEach(function (x) {
        S.cyl(0.006, 0.04, 0.1, 8, '#ff7a1a', x, 0.05, D - 0.16); S.cyl(0.022, 0.026, 0.02, 8, '#ffffff', x, 0.055, D - 0.16);
      });
    }
    return S.merge();
  }

  // ---------- Дорожный каток депо (оранжевый). Смотрит вперёд по +z ----------
  function rollerModel(K) {
    var S = Shapes(K, 0, 0), OR = '#f08a24', DK = '#3a3d42', YEL = '#ffcf3a';
    function box(w, h, d, color, x, y, z) { return S.box(w, h, d, K.mat(color), x, y, z); }
    S.bake(S.cyl(0.11, 0.11, 0.34, 18, '#5d6168', 0, 0.11, 0.22), 0, 0, Math.PI / 2);           // передний вальц
    S.bake(S.cyl(0.05, 0.05, 0.35, 10, OR, 0, 0.11, 0.22), 0, 0, Math.PI / 2);
    box(0.06, 0.12, 0.2, OR, 0.19, 0.16, 0.22); box(0.06, 0.12, 0.2, OR, -0.19, 0.16, 0.22);        // рама вальца
    box(0.3, 0.14, 0.36, OR, 0, 0.17, -0.1);                                                       // корпус с двигателем
    box(0.31, 0.02, 0.37, DK, 0, 0.245, -0.1);
    [0.16, -0.16].forEach(function (x) { S.bake(S.cyl(0.085, 0.085, 0.07, 14, '#1c1c1c', x, 0.085, -0.2), 0, 0, Math.PI / 2); });
    box(0.16, 0.07, 0.12, DK, 0, 0.29, -0.06);                                                     // сиденье и пульт
    [[0.12, 0.04], [-0.12, 0.04], [0.12, -0.24], [-0.12, -0.24]].forEach(function (p) { box(0.018, 0.22, 0.018, DK, p[0], 0.36, p[1]); });
    box(0.3, 0.025, 0.34, YEL, 0, 0.48, -0.1);                                                     // крыша
    box(0.05, 0.03, 0.05, '#ff9a2e', 0, 0.505, -0.1);                                              // маячок
    box(0.3, 0.03, 0.03, '#f4f2ec', 0, 0.2, 0.08);
    return S.merge();
  }

  // ---------- Грузовик «Бригада» (зелёный, в стиле 60-х). Смотрит вперёд по +z ----------
  function truckModel(K) {
    var S = Shapes(K, 0, 0);
    var GREEN = '#4f8f3e', DARK = '#3b6e2e', CREAM = '#ece4c8', CHROME = '#d9dcd2', TIRE = '#1c1c1c', WOOD = '#a8844f', GLASS = '#9cc3dd';
    function box(w, h, d, color, x, y, z) { return S.box(w, h, d, K.mat(color), x, y, z); }
    box(0.26, 0.05, 0.86, '#2c2c2a', 0, 0.12, -0.02);                                   // рама
    [[0.15, 0.27], [-0.15, 0.27], [0.15, -0.25], [-0.15, -0.25]].forEach(function (p) {   // колёса с белыми колпаками
      S.bake(S.cyl(0.075, 0.075, 0.06, 14, TIRE, p[0], 0.075, p[1]), 0, 0, Math.PI / 2);
      S.bake(S.cyl(0.035, 0.035, 0.064, 10, CHROME, p[0], 0.075, p[1]), 0, 0, Math.PI / 2);
    });
    [0.15, -0.15].forEach(function (x) { box(0.08, 0.03, 0.2, DARK, x, 0.17, 0.27); });  // крылья над передними колёсами
    box(0.22, 0.1, 0.22, GREEN, 0, 0.2, 0.33);                                            // капот
    var hood = S.bake(S.cyl(0.11, 0.11, 0.22, 14, GREEN, 0, 0.25, 0.33), Math.PI / 2, 0, 0); hood.scaling.set(1, 0.5, 1);
    box(0.15, 0.08, 0.012, CHROME, 0, 0.2, 0.445);                                        // решётка, бампер, фары
    for (var i = 0; i < 3; i++) box(0.15, 0.008, 0.016, '#7b7e78', 0, 0.175 + i * 0.025, 0.446);
    box(0.32, 0.03, 0.035, CHROME, 0, 0.12, 0.46);
    [0.085, -0.085].forEach(function (x) { S.bake(S.cyl(0.028, 0.028, 0.02, 12, '#fff4c2', x, 0.245, 0.447), Math.PI / 2, 0, 0); });
    box(0.3, 0.2, 0.2, GREEN, 0, 0.3, 0.12);                                              // кабина
    box(0.31, 0.035, 0.21, CREAM, 0, 0.418, 0.12);
    box(0.24, 0.085, 0.012, GLASS, 0, 0.345, 0.222);
    box(0.304, 0.075, 0.12, GLASS, 0, 0.345, 0.125);
    box(0.302, 0.02, 0.202, CREAM, 0, 0.27, 0.12);
    box(0.32, 0.03, 0.42, WOOD, 0, 0.17, -0.21);                                          // кузов
    box(0.02, 0.1, 0.42, WOOD, 0.15, 0.23, -0.21); box(0.02, 0.1, 0.42, WOOD, -0.15, 0.23, -0.21);
    box(0.32, 0.1, 0.02, WOOD, 0, 0.23, -0.41); box(0.32, 0.13, 0.02, DARK, 0, 0.245, 0.0);
    box(0.322, 0.012, 0.422, '#7d6136', 0, 0.255, -0.21);
    box(0.18, 0.07, 0.14, '#b5563c', -0.04, 0.22, -0.13);                                 // кирпич и доски
    box(0.08, 0.04, 0.33, '#e0c48a', 0.08, 0.205, -0.22);
    box(0.04, 0.02, 0.3, '#f0b23c', -0.07, 0.28, -0.26);                                  // стремянка
    return S.merge();
  }

  // ---------- Машины завода и легковые (с 0.10.0). Смотрят вперёд по +z ----------
  function wheelSet(S, pts, r, w, hub) {
    pts.forEach(function (p) {
      S.bake(S.cyl(r, r, w, 14, '#1c1c1c', p[0], r, p[1]), 0, 0, Math.PI / 2);
      S.bake(S.cyl(r * 0.5, r * 0.5, w + 0.004, 10, hub || '#c9ccd0', p[0], r, p[1]), 0, 0, Math.PI / 2);
    });
  }
  // кабина грузовика: cz — центр по длине, col — цвет
  function cabin(S, K, col, cz, w, h, y0) {
    function box(bw, bh, bd, c, x, y, z) { return S.box(bw, bh, bd, K.mat(c), x, y, z); }
    box(w, h, 0.22, col, 0, y0 + h / 2, cz);
    box(w * 0.82, h * 0.42, 0.012, '#9cc3dd', 0, y0 + h * 0.68, cz + 0.111);          // лобовое
    box(w + 0.004, h * 0.36, 0.13, '#9cc3dd', 0, y0 + h * 0.68, cz + 0.01);            // боковые окна
    box(w + 0.01, 0.03, 0.035, '#d9dcd2', 0, y0 + 0.02, cz + 0.12);                    // бампер
    [w / 2 - 0.05, -w / 2 + 0.05].forEach(function (x) { box(0.045, 0.03, 0.01, '#fff4c2', x, y0 + 0.08, cz + 0.112); }); // фары
  }
  function vehicleModel(K, kind) {
    var S = Shapes(K, 0, 0);
    function box(w, h, d, c, x, y, z) { return S.box(w, h, d, K.mat(c), x, y, z); }
    var y0 = 0.13;
    if (kind === 'garbage') {                     // мусоровоз: белая кабина, синий кузов с прессом
      box(0.26, 0.04, 0.84, '#2c2c2a', 0, 0.11, 0);
      wheelSet(S, [[0.14, 0.28], [-0.14, 0.28], [0.14, -0.2], [-0.14, -0.2], [0.14, -0.32], [-0.14, -0.32]], 0.07, 0.06);
      cabin(S, K, '#f1f1ec', 0.3, 0.3, 0.24, y0);
      box(0.32, 0.3, 0.5, '#2f6fb3', 0, y0 + 0.17, -0.1);
      for (var i = 0; i < 4; i++) box(0.326, 0.02, 0.5, '#255a93', 0, y0 + 0.06 + i * 0.07, -0.1);
      box(0.3, 0.26, 0.1, '#7b8691', 0, y0 + 0.15, -0.39);                              // задний пресс
      box(0.2, 0.06, 0.02, '#ffcf3a', 0, y0 + 0.05, -0.445);
      box(0.04, 0.03, 0.04, '#ff9a2e', 0, y0 + 0.26, 0.26);
    } else if (kind === 'ambulance') {           // скорая: белый фургон, красная полоса, маячки
      box(0.24, 0.04, 0.78, '#2c2c2a', 0, 0.1, 0);
      wheelSet(S, [[0.13, 0.25], [-0.13, 0.25], [0.13, -0.24], [-0.13, -0.24]], 0.065, 0.055);
      box(0.3, 0.12, 0.18, '#f6f6f2', 0, y0 + 0.04, 0.3);                               // капот
      box(0.3, 0.32, 0.6, '#f6f6f2', 0, y0 + 0.16, -0.08);                              // кузов
      box(0.244, 0.11, 0.012, '#9cc3dd', 0, y0 + 0.21, 0.222);
      box(0.304, 0.1, 0.12, '#9cc3dd', 0, y0 + 0.21, 0.15);
      box(0.306, 0.045, 0.6, '#d8262e', 0, y0 + 0.08, -0.08);                           // полоса
      box(0.308, 0.1, 0.03, '#d8262e', 0, y0 + 0.2, -0.12); box(0.308, 0.03, 0.1, '#d8262e', 0, y0 + 0.2, -0.12); // крест
      box(0.07, 0.04, 0.05, '#2f7cf0', 0.08, y0 + 0.34, 0.16); box(0.07, 0.04, 0.05, '#ff3030', -0.08, y0 + 0.34, 0.16);
      box(0.32, 0.03, 0.03, '#d9dcd2', 0, 0.12, 0.39);
      [0.1, -0.1].forEach(function (x) { box(0.05, 0.03, 0.01, '#fff4c2', x, y0 + 0.06, 0.391); });
    } else if (kind === 'police') {              // полиция: бело-синий седан с мигалкой
      box(0.26, 0.1, 0.66, '#f4f4f0', 0, 0.13, 0);
      wheelSet(S, [[0.12, 0.21], [-0.12, 0.21], [0.12, -0.2], [-0.12, -0.2]], 0.06, 0.05);
      box(0.262, 0.05, 0.66, '#1f4fa8', 0, 0.15, 0);                                     // синяя полоса
      box(0.23, 0.1, 0.3, '#f4f4f0', 0, 0.23, -0.04);                                   // салон
      box(0.234, 0.07, 0.24, '#5d7fa0', 0, 0.23, -0.04);
      box(0.2, 0.03, 0.08, '#2a2a2a', 0, 0.295, -0.04);
      box(0.08, 0.035, 0.07, '#2f7cf0', 0.05, 0.3, -0.04); box(0.08, 0.035, 0.07, '#ff3030', -0.05, 0.3, -0.04);
      [0.09, -0.09].forEach(function (x) { box(0.05, 0.025, 0.01, '#fff4c2', x, 0.15, 0.331); });
    } else if (kind === 'army') {                // армейский грузовик: хаки, тент
      var KH = '#5f6b3a', KD = '#4b5530';
      box(0.26, 0.05, 0.86, '#2a2a26', 0, 0.12, 0);
      wheelSet(S, [[0.15, 0.3], [-0.15, 0.3], [0.15, -0.16], [-0.15, -0.16], [0.15, -0.31], [-0.15, -0.31]], 0.075, 0.065, '#3b3f2c');
      box(0.26, 0.11, 0.16, KH, 0, y0 + 0.07, 0.36);                                     // капот
      cabin(S, K, KH, 0.2, 0.3, 0.24, y0);
      box(0.34, 0.04, 0.5, KD, 0, y0 + 0.05, -0.2);                                     // кузов
      box(0.34, 0.24, 0.5, '#6f7a47', 0, y0 + 0.19, -0.2);                              // тент
      S.bake(S.cyl(0.17, 0.17, 0.5, 14, '#6f7a47', 0, y0 + 0.31, -0.2), Math.PI / 2, 0, 0).scaling.set(1, 0.35, 1);
      box(0.25, 0.16, 0.012, '#3d4428', 0, y0 + 0.18, -0.451);
    } else if (kind === 'van') {                 // фургон доставки: синяя будка
      box(0.24, 0.04, 0.78, '#2c2c2a', 0, 0.1, 0);
      wheelSet(S, [[0.13, 0.26], [-0.13, 0.26], [0.13, -0.24], [-0.13, -0.24]], 0.065, 0.055);
      cabin(S, K, '#f2f2ee', 0.27, 0.28, 0.22, y0);
      box(0.32, 0.34, 0.5, '#2563c9', 0, y0 + 0.19, -0.12);
      box(0.324, 0.07, 0.36, '#ffcf3a', 0, y0 + 0.22, -0.12);                           // полоса компании
      box(0.3, 0.3, 0.012, '#1d4c9c', 0, y0 + 0.18, -0.372);
    } else if (kind === 'semi') {                // тягач с прицепом-контейнером
      box(0.24, 0.05, 0.36, '#2a2a28', 0, 0.12, 0.3);
      wheelSet(S, [[0.13, 0.4], [-0.13, 0.4], [0.13, 0.2], [-0.13, 0.2]], 0.07, 0.06);
      cabin(S, K, '#c8342c', 0.4, 0.3, 0.3, y0);
      box(0.3, 0.12, 0.08, '#a82a23', 0, y0 + 0.3, 0.38);                               // спальник
      box(0.24, 0.05, 0.72, '#2a2a28', 0, 0.14, -0.2);
      wheelSet(S, [[0.14, -0.4], [-0.14, -0.4], [0.14, -0.52], [-0.14, -0.52]], 0.07, 0.06);
      box(0.34, 0.32, 0.78, '#3c7d7a', 0, y0 + 0.24, -0.22);                            // контейнер
      for (var j = 0; j < 7; j++) box(0.346, 0.3, 0.015, '#336b68', 0, y0 + 0.24, -0.56 + j * 0.11);
      box(0.3, 0.28, 0.012, '#2c5e5b', 0, y0 + 0.24, -0.612);
    } else if (kind === 'dump') {                // самосвал: жёлтая кабина, оранжевый кузов со щебнем
      box(0.26, 0.05, 0.84, '#2c2c2a', 0, 0.12, 0);
      wheelSet(S, [[0.15, 0.28], [-0.15, 0.28], [0.15, -0.18], [-0.15, -0.18], [0.15, -0.31], [-0.15, -0.31]], 0.075, 0.065);
      cabin(S, K, '#f2c230', 0.3, 0.3, 0.26, y0);
      box(0.34, 0.04, 0.52, '#e0702a', 0, y0 + 0.06, -0.16);
      box(0.03, 0.16, 0.52, '#e0702a', 0.155, y0 + 0.14, -0.16); box(0.03, 0.16, 0.52, '#e0702a', -0.155, y0 + 0.14, -0.16);
      box(0.34, 0.16, 0.03, '#e0702a', 0, y0 + 0.14, -0.41); box(0.34, 0.22, 0.04, '#c45e1f', 0, y0 + 0.17, 0.1);
      box(0.28, 0.08, 0.44, '#6e6a64', 0, y0 + 0.17, -0.17);                            // щебень
      box(0.16, 0.05, 0.22, '#58554f', 0.03, y0 + 0.22, -0.2);
    }
    return S.merge();
  }
  function carModel(K, m) {
    var S = Shapes(K, 0, 0), info = G.cars.models.filter(function (c) { return c.id === m; })[0] || G.cars.models[0], C = info.color, GL = '#6f8fae';
    function box(w, h, d, c, x, y, z) { return S.box(w, h, d, K.mat(c), x, y, z); }
    var len = m === 'hatch' ? 0.48 : 0.58;
    box(0.26, 0.09, len, C, 0, 0.11, 0);                                                // кузов
    wheelSet(S, [[0.12, len / 2 - 0.1], [-0.12, len / 2 - 0.1], [0.12, -len / 2 + 0.1], [-0.12, -len / 2 + 0.1]], 0.055, 0.045, '#bfc3c8');
    if (m === 'sedan') { box(0.23, 0.09, 0.26, C, 0, 0.2, -0.03); box(0.234, 0.065, 0.2, GL, 0, 0.2, -0.03); box(0.2, 0.06, 0.012, GL, 0, 0.2, 0.1); }
    else if (m === 'hatch') { box(0.23, 0.1, 0.27, C, 0, 0.2, -0.06); box(0.234, 0.07, 0.22, GL, 0, 0.2, -0.05); box(0.2, 0.07, 0.012, GL, 0, 0.2, 0.076); }
    else { box(0.23, 0.1, 0.38, C, 0, 0.2, -0.07); box(0.234, 0.07, 0.33, GL, 0, 0.2, -0.06); box(0.2, 0.07, 0.012, GL, 0, 0.2, 0.121); box(0.18, 0.015, 0.3, '#3a3a3a', 0, 0.26, -0.08); }
    box(0.27, 0.025, 0.025, '#d9dcd2', 0, 0.08, len / 2); box(0.27, 0.025, 0.025, '#d9dcd2', 0, 0.08, -len / 2);
    [0.09, -0.09].forEach(function (x) { box(0.045, 0.022, 0.008, '#fff4c2', x, 0.13, len / 2 + 0.002); box(0.045, 0.022, 0.008, '#d8262e', x, 0.13, -len / 2 - 0.002); });
    return S.merge();
  }
  function vehicleThumb(k, car) {
    return thumbReq((car ? 'car_' : 'veh_') + k, function (K) {
      var root = new B.Mesh('thumb', K.scene), t = car ? carModel(K, k) : vehicleModel(K, k); t.rotation.y = -0.35; t.parent = root;
      var pad = B.MeshBuilder.CreateBox('pad', { width: 0.75, height: 0.04, depth: car ? 0.8 : 1.3 }, K.scene); pad.position.y = -0.02; pad.material = K.mat('#8cc068'); pad.parent = root;
      return root;
    });
  }

  // ---------- Пачки (thin instances): одна сетка — много копий ----------
  var batches = {}, dirtyBatches = {};
  var tmpM = B.Matrix.Identity(), tmpQ = new B.Quaternion(), tmpS = new B.Vector3(), tmpT = new B.Vector3();
  function getBatch(k, make) {
    var bt = batches[k];
    if (bt) return bt;
    var mesh = make();
    holdSSAO();
    mesh.isPickable = false; mesh.receiveShadows = true; mesh.alwaysSelectAsActiveMesh = true;
    mesh.setEnabled(false);
    shadowGen.addShadowCaster(mesh, false);
    bt = batches[k] = { key: k, mesh: mesh, h: mesh.getBoundingInfo().boundingBox.maximumWorld.y, ids: [], at: {}, buf: new Float32Array(16 * 8) };
    return bt;
  }
  function batchSet(bt, id, x, y, z, yaw, sx, sy, sz, roll, pitch) {
    var i = bt.at[id];
    if (i === undefined) {
      i = bt.at[id] = bt.ids.length; bt.ids.push(id);
      if (bt.buf.length < bt.ids.length * 16) { var nb = new Float32Array(bt.buf.length * 2); nb.set(bt.buf); bt.buf = nb; }
    }
    B.Quaternion.FromEulerAnglesToRef(pitch || 0, yaw, roll || 0, tmpQ);
    tmpS.set(sx, sy, sz); tmpT.set(x, y, z);
    B.Matrix.ComposeToRef(tmpS, tmpQ, tmpT, tmpM);
    tmpM.copyToArray(bt.buf, i * 16);
    dirtyBatches[bt.key] = bt;
  }
  function batchRemove(bt, id) {
    var i = bt.at[id]; if (i === undefined) return;
    var last = bt.ids.length - 1, lid = bt.ids[last];
    if (i !== last) { bt.buf.copyWithin(i * 16, last * 16, last * 16 + 16); bt.ids[i] = lid; bt.at[lid] = i; }
    bt.ids.pop(); delete bt.at[id];
    dirtyBatches[bt.key] = bt;
  }
  function flushBatches() {
    for (var k in dirtyBatches) {
      var bt = dirtyBatches[k], n = bt.ids.length;
      if (n) {
        bt.mesh.thinInstanceSetBuffer('matrix', bt.buf.subarray(0, n * 16), 16, false);
        bt.mesh.setEnabled(true);
      } else bt.mesh.setEnabled(false);
    }
    dirtyBatches = {};
  }

  // Вариант модели: у жилых — 6 расцветок, у остальных — одна.
  var RES_VARIANTS = 6;
  function variantOf(cat, seed) { return cat === 'res' ? (seed >>> 0) % RES_VARIANTS : 0; }
  function modelSeed(cat, v) { return cat === 'res' ? 9001 + v * 7919 : 1; }
  function tplKey(cat, size, seed) { return cat + '|' + size + '|' + variantOf(cat, seed); }
  function buildingBatch(b) {
    var v = variantOf(b.cat, b.seed);
    return getBatch(tplKey(b.cat, b.size, b.seed), function () { return buildModel(kit, b.cat, b.size, modelSeed(b.cat, v)); });
  }

  // ---------- Карта: земля, сетка, рамка, «срез» земли для изометрии ----------
  var mapNodes = [];
  var groundMat = kit.mat('#8cc068'), outerMat = kit.mat('#6f9a52'), frameMat = kit.mat('#c9b78f');
  var outerGround = null, slab = null, slabHD = null, gridMesh = null, groundMesh = null;
  function buildMapScene() {
    if (slabHD && slabHD.material) { slabHD.material.diffuseTexture.dispose(); slabHD.material.dispose(); }
    mapNodes.forEach(function (o) { o.dispose(); }); mapNodes = [];
    var ground = groundMesh = B.MeshBuilder.CreateGround('ground', { width: N, height: N }, scene);
    ground.material = groundMat; ground.receiveShadows = true; ground.isPickable = false; mapNodes.push(ground);
    outerGround = B.MeshBuilder.CreateGround('outer', { width: N * 6, height: N * 6 }, scene);
    outerGround.position.y = -0.03; outerGround.material = outerMat; outerGround.receiveShadows = true; outerGround.isPickable = false; mapNodes.push(outerGround);
    // Срез земли под картой (видно в изометрии, как в SimCity 2000): трава, земля, камень.
    slab = new B.TransformNode('slab', scene); mapNodes.push(slab);
    [['#7b5a3c', 0.9, -0.47], ['#5e4632', 0.7, -1.27], ['#4a4a4f', 0.5, -1.87]].forEach(function (L) {
      var s = B.MeshBuilder.CreateBox('slab', { width: N, height: L[1], depth: N }, scene);
      s.position.y = L[2]; s.material = kit.mat(L[0]); s.isPickable = false; s.parent = slab;
    });
    // Срез для «ИЗО HD»: один блок с нарисованными слоями — дёрн, земля с камнями, глина, скала.
    slabHD = B.MeshBuilder.CreateBox('slabHD', { width: N, height: 2.12, depth: N }, scene);
    slabHD.position.y = -1.06 - 0.001; slabHD.isPickable = false; slabHD.material = hdMats().slab(N); mapNodes.push(slabHD);
    var lines = [], h = N / 2;
    for (var i = 0; i <= N; i++) {
      lines.push([new B.Vector3(-h + i, 0.006, -h), new B.Vector3(-h + i, 0.006, h)]);
      lines.push([new B.Vector3(-h, 0.006, -h + i), new B.Vector3(h, 0.006, -h + i)]);
    }
    var grid = B.MeshBuilder.CreateLineSystem('grid', { lines: lines }, scene);
    grid.color = hex('#2d4a22'); grid.alpha = N > 80 ? 0.16 : 0.22; grid.isPickable = false; grid.applyFog = false; mapNodes.push(grid);
    gridMesh = grid;
    var t = 0.25, fh = 0.12;
    [[0, -N / 2 - t / 2, N + 2 * t, t], [0, N / 2 + t / 2, N + 2 * t, t], [-N / 2 - t / 2, 0, t, N], [N / 2 + t / 2, 0, t, N]].forEach(function (a) {
      var e = B.MeshBuilder.CreateBox('frame', { width: a[2], height: fh, depth: a[3] }, scene);
      e.position.set(a[0], fh / 2 - 0.02, a[1]); e.material = frameMat; e.receiveShadows = true; e.isPickable = false; mapNodes.push(e);
    });
    applyViewScenery();
  }

  function cellCenter(x, z) { return { x: x - N / 2 + 0.5, z: z - N / 2 + 0.5 }; }

  // ---------- Плоские четырёхугольники (дороги, подсветка) ----------
  function flatMat(color, opts) {
    opts = opts || {};
    var m = new B.StandardMaterial('f' + color, scene);
    m.specularColor = B.Color3.Black(); m.backFaceCulling = false;
    if (opts.overlay) { m.disableLighting = true; m.emissiveColor = hex(color); m.alpha = opts.alpha; m.zOffset = -3; m.disableDepthWrite = true; }
    else m.diffuseColor = hex(color);
    return m;
  }
  function quadsMesh(name, quads, material) { // quads: [cx, cz, w, d, y]
    var pos = [], nor = [], uv = [], ind = [];
    quads.forEach(function (q, i) {
      var x0 = q[0] - q[2] / 2, x1 = q[0] + q[2] / 2, z0 = q[1] - q[3] / 2, z1 = q[1] + q[3] / 2, y = q[4];
      pos.push(x0, y, z0, x1, y, z0, x1, y, z1, x0, y, z1);
      nor.push(0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0);
      var r = (q[5] || 0) & 3, U = [0, 0, 1, 0, 1, 1, 0, 1]; // q[5] — поворот текстуры на 90°×r (чтобы трещины не повторялись)
      for (var u = 0; u < 4; u++) uv.push(U[((u + r) % 4) * 2], U[((u + r) % 4) * 2 + 1]);
      var o = i * 4; ind.push(o, o + 2, o + 1, o, o + 3, o + 2);
    });
    var m = new B.Mesh(name, scene), vd = new B.VertexData();
    vd.positions = pos; vd.normals = nor; vd.uvs = uv; vd.indices = ind; vd.applyToMesh(m);
    m.material = material; m.isPickable = false;
    return m;
  }

  // ---------- Дороги: куски карты 16×16 клеток, каждый — одна сетка на материал ----------
  var roadMat = {};
  ['asphalt', 'dirt'].forEach(function (t) {
    var c = document.createElement('canvas'); c.width = c.height = 64; var g = c.getContext('2d');
    g.fillStyle = G.roads[t].color; g.fillRect(0, 0, 64, 64);
    var r = rng(t === 'dirt' ? 7 : 3);
    for (var i = 0; i < 260; i++) {
      var v = r(); g.fillStyle = t === 'dirt' ? (v > .5 ? 'rgba(120,90,55,.35)' : 'rgba(200,170,120,.3)') : (v > .5 ? 'rgba(0,0,0,.18)' : 'rgba(255,255,255,.07)');
      g.fillRect(r() * 64, r() * 64, 2, 2);
    }
    var m = flatMat('#ffffff'), tx = new B.DynamicTexture('road' + t, c, scene, true); tx.update();
    m.diffuseTexture = tx; roadMat[t] = m;
  });
  roadMat.line = flatMat('#f1f1e6'); roadMat.curb = flatMat('#c4c4bc'); roadMat.rut = flatMat('#8a6a44');
  roadMat.line1 = flatMat('#b9b9ad'); // выцветшая разметка на изношенном асфальте
  // Изношенный асфальт (с 0.9.0): 1 — средний износ (трещины, светлее), 2 — почти изношен (ямы, заплатки, щебень).
  function crack(g, r, x, y, n, len, w) {
    g.beginPath(); g.moveTo(x, y);
    var a = r() * Math.PI * 2;
    for (var i = 0; i < n; i++) { a += (r() - 0.5) * 1.4; x += Math.cos(a) * len; y += Math.sin(a) * len; g.lineTo(x, y); }
    g.lineWidth = w; g.stroke();
  }
  [1, 2].forEach(function (lv) {
    var S2 = 128, c = document.createElement('canvas'); c.width = c.height = S2; var g = c.getContext('2d'), r = rng(lv * 977);
    g.fillStyle = lv === 1 ? '#4a4e55' : '#5c5f63'; g.fillRect(0, 0, S2, S2);
    for (var i = 0; i < 900; i++) { // зерно и выкрошенный щебень
      var v = r(); g.fillStyle = v > 0.6 ? 'rgba(0,0,0,.2)' : v > 0.25 ? 'rgba(255,255,255,.08)' : 'rgba(170,160,140,' + (lv === 2 ? '.35' : '.15') + ')';
      g.fillRect(r() * S2, r() * S2, 2, 2);
    }
    if (lv === 2) { // заплатки свежим асфальтом
      for (i = 0; i < 2; i++) { var px = r() * 90, py = r() * 90, pw = 18 + r() * 20, ph = 14 + r() * 16; g.fillStyle = 'rgba(62,65,70,.9)'; g.fillRect(px, py, pw, ph); g.strokeStyle = 'rgba(35,36,40,.45)'; g.lineWidth = 1; g.strokeRect(px, py, pw, ph); }
    }
    g.strokeStyle = 'rgba(25,26,28,.85)'; g.lineCap = 'round';
    for (i = 0; i < (lv === 1 ? 5 : 11); i++) crack(g, r, r() * S2, r() * S2, 4 + Math.floor(r() * 5), 6 + r() * 6, lv === 1 ? 1.2 : 1.8);
    if (lv === 2) { // сетка мелких трещин и ямы
      g.strokeStyle = 'rgba(25,26,28,.55)';
      for (i = 0; i < 14; i++) crack(g, r, r() * S2, r() * S2, 3, 4 + r() * 3, 1);
      for (i = 0; i < 3; i++) {
        var hx = 16 + r() * 96, hy = 16 + r() * 96, rx = 6 + r() * 7, ry = 4 + r() * 5;
        g.fillStyle = 'rgba(150,140,120,.7)'; g.beginPath(); g.ellipse(hx, hy, rx + 2.5, ry + 2.5, r() * 3, 0, 7); g.fill();
        var hg = g.createRadialGradient(hx, hy - 1, 1, hx, hy, rx);
        hg.addColorStop(0, '#16171a'); hg.addColorStop(1, '#34363a');
        g.fillStyle = hg; g.beginPath(); g.ellipse(hx, hy, rx, ry, 0, 0, 7); g.fill();
      }
    }
    var m = flatMat('#ffffff'), tx = new B.DynamicTexture('roadW' + lv, c, scene, true); tx.update();
    m.diffuseTexture = tx; roadMat['asphalt' + lv] = m;
  });
  // Стадия износа клетки асфальта: 0 — новая, 1 — средний износ, 2 — почти изношена
  function wearOf(k) { return state.wear[k] || 0; }
  function wearStage(w) { return w < G.wear.mid ? 0 : w < G.wear.worn ? 1 : 2; }
  var CH = 16, chunks = {}, dirtyChunks = {};
  var DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  function markRoad(x, z) { dirtyChunks[Math.floor(x / CH) + ',' + Math.floor(z / CH)] = 1; }
  function buildChunk(ck) {
    (chunks[ck] || []).forEach(function (m) { m.dispose(); }); chunks[ck] = [];
    var p = ck.split(','), X0 = +p[0] * CH, Z0 = +p[1] * CH, Q = { asphalt: [], asphalt1: [], asphalt2: [], dirt: [], line: [], line1: [], curb: [], rut: [] };
    for (var z = Z0; z < Z0 + CH; z++) for (var x = X0; x < X0 + CH; x++) {
      var t = state.roads[key(x, z)]; if (!t || !inMap(x, z)) continue;
      var c = cellCenter(x, z), ws = t === 'asphalt' ? wearStage(wearOf(key(x, z))) : 0;
      Q[ws ? t + ws : t].push([c.x, c.z, 1, 1, 0.012, (x * 7 + z * 13) & 3]);
      DIRS.forEach(function (dv) {
        var n = state.roads[key(x + dv[0], z + dv[1])], hx = dv[0] !== 0, sgn = dv[0] + dv[1];
        if (t === 'asphalt') {
          if (n === 'asphalt') Q[ws ? 'line1' : 'line'].push(hx ? [c.x + sgn * 0.3, c.z, 0.22, 0.05, 0.016] : [c.x, c.z + sgn * 0.3, 0.05, 0.22, 0.016]);
          else if (!n) Q.curb.push(hx ? [c.x + sgn * 0.46, c.z, 0.08, 1, 0.018] : [c.x, c.z + sgn * 0.46, 1, 0.08, 0.018]);
        } else if (n) {
          Q.rut.push(hx ? [c.x + sgn * 0.25, c.z - 0.18, 0.5, 0.06, 0.015] : [c.x - 0.18, c.z + sgn * 0.25, 0.06, 0.5, 0.015]);
          Q.rut.push(hx ? [c.x + sgn * 0.25, c.z + 0.18, 0.5, 0.06, 0.015] : [c.x + 0.18, c.z + sgn * 0.25, 0.06, 0.5, 0.015]);
        }
      });
    }
    Object.keys(Q).forEach(function (k) {
      if (!Q[k].length) return;
      var m = quadsMesh('road', Q[k], roadMat[k]); m.receiveShadows = true; chunks[ck].push(m);
    });
  }
  function flushRoads() { for (var ck in dirtyChunks) buildChunk(ck); dirtyChunks = {}; }
  function refreshRoadAround(x, z) { markRoad(x, z); DIRS.forEach(function (d) { markRoad(x + d[0], z + d[1]); }); }

  // ---------- Здания и стройплощадки на сцене ----------
  var placed = {}, sites = {}; // id -> batch; id -> стройплощадка
  function bPos(b) { var f = foot(b.size, b.rot); return { x: b.x + f.w / 2 - N / 2, z: b.z + f.d / 2 - N / 2, yaw: -b.rot * Math.PI / 2 }; }
  function writeBuilding(b) {
    var bt = placed[b.id]; if (!bt) return;
    var p = bPos(b), hide = moving && moving.b.id === b.id;
    if (isSite(b)) {
      // готовое здание на стройке не рисуется пачкой — у площадки своя модель с отсечением по высоте
      batchRemove(bt, b.id);
      var st = sites[b.id];
      if (st && (st.bx !== b.x || st.bz !== b.z || st.rot !== b.rot)) { disposeSite(b.id); addSite(b); updateSite(b, 0); st = sites[b.id]; }
      if (st) { st.node.setEnabled(!hide); if (st.crane) st.crane.root.setEnabled(!hide); st.hidden = hide; }
    } else if (hide) batchSet(bt, b.id, p.x, -50, p.z, p.yaw, 0.001, 0.001, 0.001);
    else batchSet(bt, b.id, p.x, 0, p.z, p.yaw, 1, 1, 1);
    pinFor(b);
    dirty();
  }

  // Этапы стройки — как в жизни. to — до какой доли прогресса длится этап.
  var STAGES = [
    { to: 0.10, name: 'Подготовка площадки', about: 'забор, котлован, монтаж крана' },
    { to: 0.20, name: 'Фундамент', about: 'бетонная плита' },
    { to: 0.84, name: 'Возведение этажей', about: 'этаж за этажом, леса растут вместе с домом' },
    { to: 0.95, name: 'Отделка и снятие лесов', about: 'леса разбирают сверху вниз' },
    { to: 1.00, name: 'Уборка площадки', about: 'разбирают кран, рабочие уезжают' }
  ];
  function stageOf(p) { for (var i = 0; i < STAGES.length; i++) if (p < STAGES[i].to) return i; return STAGES.length - 1; }
  function seg(p, a, b) { return clamp((p - a) / (b - a), 0, 1); }
  function smooth(x) { return x * x * (3 - 2 * x); }
  function mix(a, b, k) { return a + (b - a) * k; }
  function mixAng(a, b, k) { return a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * k; }
  var LH = 0.3; // высота яруса лесов ≈ один этаж

  // Отрезок-балка от p0 до p1 (для кранов и лесов)
  function beam(S, color, x0, y0, z0, x1, y1, z1, th) {
    var dx = x1 - x0, dy = y1 - y0, dz = z1 - z0, len = Math.hypot(dx, dy, dz);
    var m = S.box(th, th, len, kit.mat(color), 0, 0, 0);
    S.bake(m, -Math.asin(dy / len), Math.atan2(dx, dz), 0);
    m.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
    return m;
  }
  function finishMesh(m, shadow) {
    m.isPickable = false; m.receiveShadows = true;
    if (shadow) shadowGen.addShadowCaster(m, false);
    return m;
  }

  // Модель будущего здания: свои копии материалов с плоскостью отсечения — дом «вырастает» снизу вверх.
  function siteModel(b, plane) {
    var m = buildModel(kit, b.cat, b.size, modelSeed(b.cat, variantOf(b.cat, b.seed))), pairs = [];
    function copy(src) {
      var d = new B.StandardMaterial('sm' + b.id, scene);
      pairs.push({ s: src, d: d }); syncMat(src, d); d.clipPlane = plane; return d;
    }
    if (m.material && m.material.subMaterials) {
      var mm = new B.MultiMaterial('smm' + b.id, scene);
      mm.subMaterials = m.material.subMaterials.map(copy);
      var old = m.material; m.material = mm; old.subMaterials = []; old.dispose();
    } else if (m.material) m.material = copy(m.material);
    m.isPickable = false; m.receiveShadows = true;
    return { mesh: m, pairs: pairs };
  }
  function syncMat(s, d) {
    d.diffuseColor = s.diffuseColor.clone(); d.diffuseTexture = s.diffuseTexture || null;
    d.specularColor = s.specularColor.clone(); d.specularPower = s.specularPower;
  }
  function syncSiteMats() { for (var id in sites) if (sites[id].model) sites[id].model.pairs.forEach(function (p) { syncMat(p.s, p.d); }); }

  // Ярус строительных лесов: стойки в два ряда, настил из досок, перила и зелёная сетка.
  var netMat = null;
  function scaffoldLevel(hx, hz) {
    var S = Shapes(kit, 0, 0), PIPE = '#b8c0c8', PLANK = '#c49a5c';
    var ri = 0.015, ro = 0.11, ax = hx + ri, bx = hx + ro, az = hz + ri, bz = hz + ro;
    function posts(x0, z0, x1, z1) { // стойки вдоль стороны
      var len = Math.hypot(x1 - x0, z1 - z0), n = Math.max(1, Math.ceil(len / 0.45));
      for (var i = 0; i <= n; i++) { var k = i / n; S.box(0.012, LH, 0.012, kit.mat(PIPE), mix(x0, x1, k), LH / 2, mix(z0, z1, k)); }
      return n;
    }
    [[ax, az], [bx, bz]].forEach(function (r) {
      posts(-r[0], -r[1], r[0], -r[1]); posts(-r[0], r[1], r[0], r[1]);
      posts(-r[0], -r[1] + 0.45, -r[0], r[1] - 0.45); posts(r[0], -r[1] + 0.45, r[0], r[1] - 0.45);
    });
    var mx = (ax + bx) / 2, mz = (az + bz) / 2, w = ro - ri + 0.02;
    // настил
    S.box(2 * bx, 0.012, w, kit.mat(PLANK), 0, LH - 0.006, -mz); S.box(2 * bx, 0.012, w, kit.mat(PLANK), 0, LH - 0.006, mz);
    S.box(w, 0.012, 2 * az, kit.mat(PLANK), -mx, LH - 0.006, 0); S.box(w, 0.012, 2 * az, kit.mat(PLANK), mx, LH - 0.006, 0);
    // перила снаружи и горизонтали
    [LH * 0.5, LH - 0.03].forEach(function (y) {
      S.box(2 * bx, 0.008, 0.008, kit.mat(PIPE), 0, y, -bz); S.box(2 * bx, 0.008, 0.008, kit.mat(PIPE), 0, y, bz);
      S.box(0.008, 0.008, 2 * bz, kit.mat(PIPE), -bx, y, 0); S.box(0.008, 0.008, 2 * bz, kit.mat(PIPE), bx, y, 0);
    });
    // диагональные связи на каждой стороне
    beam(S, PIPE, -bx, 0.01, -bz, -bx + Math.min(0.5, bx), LH - 0.02, -bz, 0.007);
    beam(S, PIPE, bx, 0.01, bz, bx - Math.min(0.5, bx), LH - 0.02, bz, 0.007);
    beam(S, PIPE, -bx, 0.01, bz, -bx, LH - 0.02, bz - Math.min(0.5, bz), 0.007);
    beam(S, PIPE, bx, 0.01, -bz, bx, LH - 0.02, -bz + Math.min(0.5, bz), 0.007);
    var frame = S.merge();
    // сетка — отдельная прозрачная сетка-оболочка
    if (!netMat) {
      netMat = new B.StandardMaterial('net', scene); netMat.diffuseColor = hex('#3f9a52'); netMat.specularColor = B.Color3.Black();
      netMat.alpha = 0.24; netMat.backFaceCulling = false;
    }
    var N2 = Shapes(kit, 0, 0), nh = LH * 0.62, ny = LH * 0.5 + 0.004;
    N2.box(2 * bx, nh, 0.002, netMat, 0, ny, -bz - 0.004); N2.box(2 * bx, nh, 0.002, netMat, 0, ny, bz + 0.004);
    N2.box(0.002, nh, 2 * bz, netMat, -bx - 0.004, ny, 0); N2.box(0.002, nh, 2 * bz, netMat, bx + 0.004, ny, 0);
    var net = B.Mesh.MergeMeshes(N2.parts, true, true); net.material = netMat; net.isPickable = false;
    net.parent = frame;
    return frame;
  }

  // Башенный кран. Стрела смотрит по +z, поворот — rotation.y.
  var SW = 0.1, SH = 0.16, YEL = '#f2b705';
  function craneSection() {
    var S = Shapes(kit, 0, 0), t = 0.012, h = SW / 2;
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (c) { S.box(t, SH, t, kit.mat(YEL), c[0] * h, SH / 2, c[1] * h); });
    S.box(SW, 0.008, 0.008, kit.mat(YEL), 0, 0.006, -h); S.box(SW, 0.008, 0.008, kit.mat(YEL), 0, 0.006, h);
    S.box(0.008, 0.008, SW, kit.mat(YEL), -h, 0.006, 0); S.box(0.008, 0.008, SW, kit.mat(YEL), h, 0.006, 0);
    beam(S, YEL, -h, 0.006, -h, h, SH, -h, 0.007); beam(S, YEL, h, 0.006, h, -h, SH, h, 0.007);
    beam(S, YEL, -h, 0.006, h, -h, SH, -h, 0.007); beam(S, YEL, h, 0.006, -h, h, SH, h, 0.007);
    return S.merge();
  }
  function craneTop(JL, CJ) {
    var S = Shapes(kit, 0, 0), y0 = 0.05;
    S.box(0.15, 0.05, 0.15, kit.mat('#d79c07'), 0, 0.025, 0);                         // поворотный круг
    S.box(0.08, 0.075, 0.085, kit.mat(YEL), 0.085, 0.0, 0.07);                      // кабина
    S.box(0.082, 0.04, 0.06, kit.mat('#9cc3dd'), 0.085, 0.01, 0.09);
    // оголовок
    beam(S, YEL, -0.04, y0, -0.04, 0, 0.36, 0, 0.012); beam(S, YEL, 0.04, y0, -0.04, 0, 0.36, 0, 0.012);
    beam(S, YEL, -0.04, y0, 0.04, 0, 0.36, 0, 0.012); beam(S, YEL, 0.04, y0, 0.04, 0, 0.36, 0, 0.012);
    // стрела: треугольная ферма
    var a = 0.035, top = y0 + 0.075;
    S.box(0.009, 0.009, JL, kit.mat(YEL), -a, y0 + 0.005, JL / 2); S.box(0.009, 0.009, JL, kit.mat(YEL), a, y0 + 0.005, JL / 2);
    S.box(0.009, 0.009, JL, kit.mat(YEL), 0, top, JL / 2);
    var bay = 0.12, n = Math.max(2, Math.round(JL / bay)); bay = JL / n;
    for (var i = 0; i < n; i++) {
      var z0 = i * bay, z1 = z0 + bay / 2, z2 = z0 + bay;
      beam(S, YEL, -a, y0 + 0.005, z0, 0, top, z1, 0.006); beam(S, YEL, 0, top, z1, -a, y0 + 0.005, z2, 0.006);
      beam(S, YEL, a, y0 + 0.005, z0, 0, top, z1, 0.006); beam(S, YEL, 0, top, z1, a, y0 + 0.005, z2, 0.006);
      S.box(2 * a, 0.006, 0.006, kit.mat(YEL), 0, y0 + 0.005, z2);
    }
    // противовесная консоль с бетонными блоками
    S.box(0.1, 0.025, CJ, kit.mat(YEL), 0, y0 + 0.012, -CJ / 2);
    S.box(0.12, 0.09, 0.1, kit.mat('#9a9a92'), 0, y0 - 0.02, -CJ + 0.07);
    S.box(0.12, 0.004, 0.004, kit.mat('#6d6d66'), 0, y0 - 0.02, -CJ + 0.07 + 0.051);
    // ванты от оголовка
    beam(S, '#7c6a2a', 0, 0.36, 0, 0, top, JL * 0.62, 0.005);
    beam(S, '#7c6a2a', 0, 0.36, 0, 0, y0 + 0.025, -CJ + 0.02, 0.005);
    var m = S.merge(); return m;
  }
  function craneLoad(kind) {
    var S = Shapes(kit, 0, 0);
    if (kind === 0) { // поддон с кирпичом
      S.box(0.15, 0.018, 0.11, kit.mat('#a8844f'), 0, -0.1, 0);
      S.box(0.13, 0.07, 0.095, kit.mat('#b5563c'), 0, -0.056, 0);
      for (var i = 0; i < 3; i++) S.box(0.132, 0.004, 0.097, kit.mat('#d9cbb5'), 0, -0.08 + i * 0.022, 0);
    } else if (kind === 1) { // двутавровая балка
      S.box(0.36, 0.008, 0.035, kit.mat('#5f6f80'), 0, -0.09, 0); S.box(0.36, 0.008, 0.035, kit.mat('#5f6f80'), 0, -0.06, 0);
      S.box(0.36, 0.03, 0.007, kit.mat('#5f6f80'), 0, -0.075, 0);
    } else { // бадья с бетоном
      S.cyl(0.045, 0.03, 0.08, 10, '#7a8088', 0, -0.06, 0); S.cyl(0.042, 0.042, 0.004, 10, '#b9b4a8', 0, -0.019, 0);
    }
    beam(S, '#3a3a3a', 0, 0, 0, kind === 1 ? -0.15 : -0.05, -0.05, 0, 0.004);
    beam(S, '#3a3a3a', 0, 0, 0, kind === 1 ? 0.15 : 0.05, -0.05, 0, 0.004);
    return S.merge();
  }
  // Место для крана: угол участка, снаружи — если соседняя клетка свободна.
  function cranePlace(b) {
    var f = foot(b.size, b.rot), c = siteCenter(b), best = null, score = -1;
    [[1, -1], [-1, 1], [-1, -1], [1, 1]].forEach(function (s) {
      var cx = s[0] > 0 ? b.x + f.w : b.x - 1, cz = s[1] > 0 ? b.z + f.d : b.z - 1, sc = 0;
      if (inMap(cx, cz) && !occ[idx(cx, cz)]) sc = state.roads[key(cx, cz)] ? 1 : 2;
      if (sc > score) { score = sc; best = s; }
    });
    var out = score > 0 ? 0.13 : -0.12;
    return { x: c.x + best[0] * (f.w / 2 + out), z: c.z + best[1] * (f.d / 2 + out), sx: best[0], sz: best[1] };
  }
  function buildCrane(b, st) {
    var cp = cranePlace(b), c = siteCenter(b), f = foot(b.size, b.rot);
    var mastH = Math.max(1.0, st.h + 0.55), nSec = Math.ceil(mastH / SH); mastH = nSec * SH + 0.05;
    var reach = Math.hypot(c.x - cp.x, c.z - cp.z), JL = Math.max(1.1, reach + 0.45), CJ = Math.min(0.55, 0.25 + JL * 0.12);
    var root = new B.TransformNode('crane' + b.id, scene); root.position.set(cp.x, 0, cp.z);
    var base = B.MeshBuilder.CreateBox('cbase', { width: 0.24, height: 0.05, depth: 0.24 }, scene);
    base.material = kit.mat('#8f8b82'); base.position.y = 0.025; base.parent = root; finishMesh(base, true);
    var sec0 = craneSection(); finishMesh(sec0, true); sec0.parent = root; sec0.position.y = 0.05;
    var secs = [sec0];
    for (var i = 1; i < nSec; i++) { var s = sec0.createInstance('cs'); s.parent = root; s.position.y = 0.05 + i * SH; s.isPickable = false; secs.push(s); }
    var slew = new B.TransformNode('slew', scene); slew.parent = root; slew.position.y = 0.05 + nSec * SH;
    var top = craneTop(JL, CJ); finishMesh(top, true); top.parent = slew;
    var trolley = B.MeshBuilder.CreateBox('trol', { width: 0.06, height: 0.025, depth: 0.07 }, scene);
    trolley.material = kit.mat('#3d4148'); trolley.parent = slew; trolley.position.y = 0.035; finishMesh(trolley, true);
    var cable = B.MeshBuilder.CreateBox('cab', { width: 0.005, height: 1, depth: 0.005 }, scene);
    cable.material = kit.mat('#2b2b2b'); cable.parent = trolley; finishMesh(cable, false);
    var hook = B.MeshBuilder.CreateBox('hook', { width: 0.034, height: 0.03, depth: 0.024 }, scene);
    hook.material = kit.mat('#e0402a'); hook.parent = trolley; finishMesh(hook, true);
    var loads = [0, 1, 2].map(function (k) { var l = craneLoad(k); l.parent = hook; finishMesh(l, true); l.setEnabled(false); return l; });
    // откуда берём груз: середина стороны участка у крана — там встаёт грузовик
    var pick = { x: c.x + cp.sx * 0, z: c.z + cp.sz * (f.d / 2 + 0.5) };
    var cr = { root: root, secs: secs, slew: slew, trolley: trolley, cable: cable, hook: hook, loads: loads, JL: JL,
      topY: slew.position.y, mast: { x: cp.x, z: cp.z }, pick: pick, drop: { x: c.x, z: c.z }, yaw: Math.atan2(c.x - cp.x, c.z - cp.z), r: Math.min(reach, JL - 0.05), hy: 0 };
    cr.hy = cr.topY - 0.25; placeHook(cr, -1);
    return cr;
  }
  function placeHook(cr, load) {
    cr.slew.rotation.y = cr.yaw;
    cr.trolley.position.z = clamp(cr.r, 0.22, cr.JL - 0.04);
    var drop = Math.max(0.05, cr.topY + 0.035 - cr.hy);
    cr.hook.position.y = -drop; cr.cable.scaling.y = drop; cr.cable.position.y = -drop / 2;
    cr.loads.forEach(function (l, i) { l.setEnabled(i === load); });
  }
  // Цикл крана: опустить крюк к грузовику → поднять → повернуть к дому → опустить на этаж → отцепить → вернуться.
  function animCrane(st, workH) {
    var cr = st.crane, PER = 8, u = (st.clock / PER) % 1, cyc = Math.floor(st.clock / PER);
    var A = cr.pick, Bp = cr.drop, M = cr.mast;
    var yA = Math.atan2(A.x - M.x, A.z - M.z), rA = Math.hypot(A.x - M.x, A.z - M.z);
    var yB = Math.atan2(Bp.x - M.x, Bp.z - M.z), rB = Math.hypot(Bp.x - M.x, Bp.z - M.z);
    var hiY = cr.topY - 0.25, loA = 0.3, loB = Math.min(hiY - 0.05, workH + 0.14), k;
    if (u < 0.12) { k = smooth(u / 0.12); cr.yaw = yA; cr.r = rA; cr.hy = mix(hiY, loA, k); }
    else if (u < 0.24) { cr.hy = mix(loA, hiY, smooth((u - 0.12) / 0.12)); }
    else if (u < 0.46) { k = smooth((u - 0.24) / 0.22); cr.yaw = mixAng(yA, yB, k); cr.r = mix(rA, rB, k); cr.hy = hiY; }
    else if (u < 0.58) { cr.yaw = yB; cr.r = rB; cr.hy = mix(hiY, loB, smooth((u - 0.46) / 0.12)); }
    else if (u < 0.66) { cr.hy = loB; }
    else if (u < 0.78) { cr.hy = mix(loB, hiY, smooth((u - 0.66) / 0.12)); }
    else { k = smooth((u - 0.78) / 0.22); cr.yaw = mixAng(yB, yA, k); cr.r = mix(rB, rA, k); cr.hy = hiY; }
    placeHook(cr, u > 0.1 && u < 0.62 ? cyc % 3 : -1);
  }

  // Рабочие-миниатюры: тело и ноги — пачки (thin instances), ноги шагают.
  function workerBody(K, carry) {
    var S = Shapes(K, 0, 0), VEST = '#ff7a1a', PANTS = '#2e3a55';
    S.box(0.046, 0.016, 0.028, K.mat(PANTS), 0, 0.074, 0);
    S.box(0.05, 0.056, 0.03, K.mat(VEST), 0, 0.108, 0);
    S.box(0.052, 0.006, 0.032, K.mat('#eef0d8'), 0, 0.098, 0);
    [-1, 1].forEach(function (s) {
      var arm = S.box(0.014, 0.05, 0.016, K.mat(VEST), s * 0.032, 0.105, 0);
      if (carry) { S.bake(arm, -1.1, 0, 0); arm.position.set(s * 0.032, 0.112, 0.018); }
    });
    if (carry) S.box(0.056, 0.024, 0.032, K.mat('#b5563c'), 0, 0.118, 0.042);
    var head = B.MeshBuilder.CreateSphere('hd', { diameter: 0.03, segments: 6 }, K.scene); head.material = K.mat('#e9b48f'); head.position.set(0, 0.148, 0); S.parts.push(head);
    var hel = B.MeshBuilder.CreateSphere('hl', { diameter: 0.036, segments: 6, slice: 0.5 }, K.scene); hel.material = K.mat(carry ? '#f6c623' : '#f4f4ee'); hel.position.set(0, 0.153, 0); S.parts.push(hel);
    S.cyl(0.023, 0.023, 0.004, 10, carry ? '#f6c623' : '#f4f4ee', 0, 0.153, 0.004);
    return S.merge();
  }
  function workerLeg(K) {
    var S = Shapes(K, 0, 0);
    S.box(0.018, 0.064, 0.022, K.mat('#2e3a55'), 0, -0.032, 0);
    S.box(0.02, 0.012, 0.03, K.mat('#3a2a1e'), 0, -0.064, 0.004);
    return S.merge();
  }
  function wBody(carry) { return getBatch(carry ? 'wbody1' : 'wbody0', function () { return workerBody(kit, carry); }); }
  function wLeg() { return getBatch('wleg', function () { return workerLeg(kit); }); }
  function removeWorker(id, k) {
    var wid = 'w' + id + '_' + k;
    batchRemove(wBody(0), wid); batchRemove(wBody(1), wid); batchRemove(wLeg(), wid + 'L'); batchRemove(wLeg(), wid + 'R');
  }
  var WS = 1.25; // масштаб человечков: чуть крупнее «настоящего», чтобы их было видно
  // поставить рабочего: x, z — в осях участка (до поворота), yaw — куда смотрит, walk — фаза шага
  function putWorker(st, k, carry, lx, y, lz, yaw, walk, bend) {
    var th = st.yaw, cs = Math.cos(th), sn = Math.sin(th), wx = st.cx + lx * cs + lz * sn, wz = st.cz - lx * sn + lz * cs, wy = yaw + th;
    var wid = 'w' + st.id + '_' + k, sw = walk === null ? 0 : Math.sin(walk) * 0.6, bob = walk === null ? 0 : Math.abs(Math.sin(walk)) * 0.008;
    batchRemove(wBody(!carry), wid);
    batchSet(wBody(carry), wid, wx, y + bob, wz, wy, WS, WS, WS, 0, bend || 0);
    var c2 = Math.cos(wy), s2 = Math.sin(wy);
    [[-1, 'L'], [1, 'R']].forEach(function (L) {
      var ox = L[0] * 0.012 * WS;
      batchSet(wLeg(), wid + L[1], wx + ox * c2, y + 0.07 * WS + bob, wz - ox * s2, wy, WS, WS, WS, 0, L[0] * sw);
    });
  }
  // точка на прямоугольном обходе (полупериметры hx, hz), s — пройденный путь
  function loopAt(hx, hz, s) {
    var P = 4 * (hx + hz); s = ((s % P) + P) % P;
    if (s < 2 * hx) return { x: -hx + s, z: hz, yaw: Math.PI / 2 };
    s -= 2 * hx; if (s < 2 * hz) return { x: hx, z: hz - s, yaw: Math.PI };
    s -= 2 * hz; if (s < 2 * hx) return { x: hx - s, z: -hz, yaw: -Math.PI / 2 };
    s -= 2 * hx; return { x: -hx, z: -hz + s, yaw: 0 };
  }
  function animWorkers(st, stage, levels, workH, here, moving) {
    var cap = { '1x1': 4, '2x1': 5, '2x2': 7, '4x4': 10 }[st.size] || 5;
    var n = here ? Math.min(cap, 2 + here * 2) : 0;
    if (stage === 4) n = Math.min(n, 2);
    for (var k = n; k < st.wn; k++) removeWorker(st.id, k);
    st.wn = n;
    var hx = st.hx, hz = st.hz, gx = hx + 0.155, gz = hz + 0.155, t = st.clock;
    for (k = 0; k < n; k++) {
      var role = stage >= 2 && stage <= 3 ? k % 3 : (k % 2 ? 1 : 2);
      var deck = Math.min(levels - 1, Math.floor(workH / LH) - 1) - (role === 2 ? 1 : 0);
      if (role !== 1 && deck >= 0 && stage >= 2 && stage <= 3) { // на лесах
        var side = (k + st.id) % 4, len = side % 2 ? hz : hx, dk = (deck + 1) * LH;
        if (role === 0) { // ходит по настилу туда-сюда
          var ph = (t * 0.22 + k * 0.37) % 2, pos = ph < 1 ? ph : 2 - ph, along = mix(-len + 0.06, len - 0.06, pos), dir = ph < 1 ? 1 : -1;
          var o = side % 2 ? hx + 0.062 : hz + 0.062;
          var P = [[along, o, dir > 0 ? Math.PI / 2 : -Math.PI / 2], [o, -along, dir > 0 ? Math.PI : 0], [-along, -o, dir > 0 ? -Math.PI / 2 : Math.PI / 2], [-o, along, dir > 0 ? 0 : Math.PI]][side];
          putWorker(st, k, false, P[0], dk, P[1], P[2], moving ? t * 9 + k : null, 0);
        } else { // стоит у стены и работает (кладёт кирпич)
          var a2 = (k * 0.29) % 1, o2 = (side % 2 ? hx : hz) + 0.05, al = mix(-len + 0.1, len - 0.1, a2);
          var Q = [[al, o2, Math.PI], [o2, -al, -Math.PI / 2], [-al, -o2, 0], [-o2, al, Math.PI / 2]][side];
          putWorker(st, k, false, Q[0], dk, Q[1], Q[2], null, moving ? 0.35 * Math.max(0, Math.sin(t * 5 + k * 2)) : 0);
        }
      } else if (role === 2 && stage <= 1) { // копает / заливает в центре площадки
        var a3 = k * 2.1 + st.id;
        putWorker(st, k, false, Math.cos(a3) * hx * 0.45, stage === 1 ? 0.05 : 0, Math.sin(a3) * hz * 0.45, a3 + Math.PI / 2, null,
          moving ? 0.45 * Math.max(0, Math.sin(t * 4 + k)) : 0);
      } else { // носит кирпич по кругу вдоль забора
        var L2 = loopAt(gx, gz, t * 0.2 + k * (gx + gz) * 1.3);
        putWorker(st, k, true, L2.x, 0, L2.z, L2.yaw, moving ? t * 9 + k : null, 0);
      }
    }
  }

  function addSite(b) {
    var s = G.sizes[b.size], W = s.w, D = s.d, p = bPos(b), c = siteCenter(b);
    var node = new B.TransformNode('site' + b.id, scene); node.position.set(p.x, 0, p.z); node.rotation.y = p.yaw;
    var hx = W / 2 - 0.08, hz = D / 2 - 0.08, h = Math.max(0.45, placed[b.id].h);
    var st = { id: b.id, size: b.size, node: node, bx: b.x, bz: b.z, rot: b.rot, yaw: p.yaw, cx: c.x, cz: c.z, W: W, D: D, hx: hx, hz: hz, h: h,
      levels: Math.max(1, Math.round(h * 0.85 / LH)), clock: (b.id * 1.7) % 8, wn: 0, stage: -1 };
    // забор (снаружи участка), котлован, фундамент
    var S = Shapes(kit, 0, 0), fx = W / 2 + 0.12, fz = D / 2 + 0.12, e = 0.014, OR = '#ff8a1f';
    [0.05, 0.11].forEach(function (y) {
      S.box(2 * fx, 0.022, e, kit.mat(OR), 0, y, -fz); S.box(2 * fx, 0.022, e, kit.mat(OR), 0, y, fz);
      S.box(e, 0.022, 2 * fz, kit.mat(OR), -fx, y, 0); S.box(e, 0.022, 2 * fz, kit.mat(OR), fx, y, 0);
    });
    for (var i = 0; i <= Math.round(2 * fx / 0.4); i++) { var xx = -fx + i * 2 * fx / Math.round(2 * fx / 0.4); S.box(0.016, 0.14, 0.016, kit.mat('#f2f2ea'), xx, 0.07, -fz); S.box(0.016, 0.14, 0.016, kit.mat('#f2f2ea'), xx, 0.07, fz); }
    for (i = 1; i < Math.round(2 * fz / 0.4); i++) { var zz = -fz + i * 2 * fz / Math.round(2 * fz / 0.4); S.box(0.016, 0.14, 0.016, kit.mat('#f2f2ea'), -fx, 0.07, zz); S.box(0.016, 0.14, 0.016, kit.mat('#f2f2ea'), fx, 0.07, zz); }
    S.box(2 * fx, 0.006, 2 * fz, kit.mat('#b49a74'), 0, 0.003, 0);             // утоптанная земля
    var fence = finishMesh(S.merge(), true); fence.parent = node;
    var pit = B.MeshBuilder.CreateBox('pit', { width: 2 * hx + 0.04, height: 0.01, depth: 2 * hz + 0.04 }, scene);
    pit.material = kit.mat('#5a3e26'); pit.position.y = 0.008; pit.parent = node; finishMesh(pit, false);
    var mound = B.MeshBuilder.CreateCylinder('mnd', { diameterTop: 0, diameterBottom: Math.min(0.5, W * 0.35), height: 0.14, tessellation: 7 }, scene);
    mound.material = kit.mat('#7b5a3c'); mound.position.set(-hx + 0.18, 0.07, -hz + 0.18); mound.parent = node; finishMesh(mound, true);
    var slabF = B.MeshBuilder.CreateBox('fnd', { width: 2 * hx + 0.02, height: 1, depth: 2 * hz + 0.02 }, scene);
    slabF.setEnabled(false); slabF.material = kit.mat('#a7a29a'); slabF.parent = node; finishMesh(slabF, true);
    st.fence = fence; st.pit = pit; st.mound = mound; st.slab = slabF;
    // полоска прогресса
    var bw = Math.min(W, 2.4) * 0.8, bar = new B.TransformNode('bar', scene); bar.parent = node;
    var bg = B.MeshBuilder.CreateBox('bbg', { width: bw + 0.06, height: 0.07, depth: 0.07 }, scene); bg.material = kit.mat('#26303d'); bg.parent = bar;
    var fill = B.MeshBuilder.CreateBox('bfill', { width: bw, height: 0.045, depth: 0.08 }, scene);
    fill.setPivotPoint(new B.Vector3(-bw / 2, 0, 0)); fill.material = kit.mat('#5fd35a'); fill.parent = bar;
    [bg, fill].forEach(function (m) { m.isPickable = false; });
    st.bar = bar; st.fill = fill;
    sites[b.id] = st;
  }
  // Тяжёлые части (модель, леса, кран) создаются, когда стройка реально началась.
  function siteHeavy(b, st) {
    if (st.model) return;
    st.plane = new B.Plane(0, 1, 0, 0);
    st.model = siteModel(b, st.plane); st.model.mesh.parent = st.node;
    shadowGen.addShadowCaster(st.model.mesh, false);
    // «крышки» на срезе стен — перекрытие этажа, который сейчас строят
    st.caps = []; var wallTop = 0.3;
    st.model.mesh.subMeshes.forEach(function (sm) {
      var bb = sm.getBoundingInfo().boundingBox, mn = bb.minimum, mx = bb.maximum, w = mx.x - mn.x, d = mx.z - mn.z, mat = st.model.mesh.material.subMaterials ? st.model.mesh.material.subMaterials[sm.materialIndex] : null;
      if (sm.verticesCount !== 24 || w * d < 0.12 || mx.y - mn.y < 0.2 || !(mat && mat.diffuseTexture || w * d > 0.3)) return; // только коробки-стены
      if (mat && mat.diffuseTexture) wallTop = Math.max(wallTop, mx.y);
      var cap = B.MeshBuilder.CreateBox('cap', { width: w - 0.01, height: 0.022, depth: d - 0.01 }, scene);
      cap.material = kit.mat('#b8b3aa'); cap.parent = st.node; cap.position.set((mn.x + mx.x) / 2, 0, (mn.z + mx.z) / 2); finishMesh(cap, false);
      cap.setEnabled(false); st.caps.push({ m: cap, y0: mn.y, y1: mx.y });
    });
    st.levels = Math.max(1, Math.ceil((wallTop - 0.05) / LH));
    var lv = scaffoldLevel(st.hx, st.hz); finishMesh(lv, true); lv.parent = st.node;
    st.scaf = [lv];
    for (var i = 1; i < st.levels; i++) { var c = lv.createInstance('sl'); c.parent = st.node; c.position.y = i * LH; c.isPickable = false; st.scaf.push(c);
      var nc = lv.getChildMeshes()[0].createInstance('sn'); nc.parent = c; }
    st.crane = buildCrane(b, st);
    if (st.hidden) { st.crane.root.setEnabled(false); }
  }
  function disposeSite(id) {
    var st = sites[id]; if (!st) return;
    for (var k = 0; k < st.wn; k++) removeWorker(id, k);
    if (st.model) st.model.pairs.forEach(function (p) { p.d.dispose(); });
    if (st.crane) st.crane.root.dispose(false, false);
    st.node.dispose(false, false);
    delete sites[id];
  }
  // Показать стройку в нужном этапе. moving — идёт ли работа (рабочие шагают, кран крутится).
  function updateSite(b, dt) {
    var st = sites[b.id]; if (!st) return;
    var p = clamp(b.prog, 0, 1), stage = stageOf(p), crew = siteCrew(b.id), working = crew.here > 0;
    if (p > 0 || working) siteHeavy(b, st);
    st.fill.scaling.x = Math.max(0.001, p);
    st.bar.position.y = st.h + 0.5;
    // котлован и фундамент
    var f1 = seg(p, 0.10, 0.20);
    st.pit.setEnabled(stage <= 1); st.mound.setEnabled(stage === 0);
    st.slab.setEnabled(p >= 0.10); st.slab.scaling.y = Math.max(0.001, 0.05 * f1); st.slab.position.y = 0.025 * f1;
    if (!st.model) return;
    // дом растёт этажами; леса на ярус впереди
    var f2 = seg(p, 0.20, 0.84), clipH = stage <= 1 ? 0 : stage === 2 ? mix(0.05, st.h + 0.02, f2) : st.h + 5;
    st.plane.d = -clipH; st.model.mesh.setEnabled(stage >= 2);
    var lv = 0;
    if (stage === 2) lv = Math.min(st.levels, Math.floor(clipH / LH) + 2);
    else if (stage === 3) lv = Math.round(st.levels * (1 - seg(p, 0.86, 0.95)));
    st.scaf.forEach(function (m, i) { m.setEnabled(i < lv); });
    st.caps.forEach(function (c) {
      var on = stage === 2 && clipH > c.y0 + 0.02 && clipH < c.y1 - 0.01;
      c.m.setEnabled(on); if (on) c.m.position.y = clipH - 0.011;
    });
    // кран: монтаж секций в начале, демонтаж в конце
    var cr = st.crane, ns = cr.secs.length, vis = ns, slewOn = true;
    if (stage === 0) { vis = Math.ceil(ns * seg(p, 0.005, 0.08)); slewOn = p >= 0.08; }
    else if (stage === 4) { var g = seg(p, 0.955, 0.995); vis = Math.ceil(ns * (1 - g)); slewOn = g <= 0; }
    cr.secs.forEach(function (m, i) { m.setEnabled(i < vis); });
    cr.slew.setEnabled(slewOn && vis === ns);
    if (working && dt) st.clock += dt;
    var workH = stage === 2 ? clipH : stage === 3 ? lv * LH : 0;
    if (working && slewOn && stage >= 1 && stage <= 3) animCrane(st, stage === 1 ? 0.05 : workH);
    else if (stage !== st.stage) placeHook(cr, -1);
    animWorkers(st, stage, lv, workH, crew.here, working);
    st.stage = stage;
    dirty();
  }
  function siteTop(b) { var st = sites[b.id]; if (!st) return 0.3; if (!st.model || st.stage < 2) return 0.3; return Math.max(0.3, Math.min(st.h, -st.plane.d)); }
  function addBuildingMesh(b) {
    byId[b.id] = b;
    placed[b.id] = buildingBatch(b);
    if (isSite(b)) { addSite(b); updateSite(b, 0); }
    writeBuilding(b);
  }
  function removeBuildingMesh(id) {
    if (placed[id]) { batchRemove(placed[id], id); delete placed[id]; }
    if (batches.noroad) batchRemove(batches.noroad, id);
    disposeSite(id);
    dirty();
  }

  // ---------- Бригады ----------
  function truckBatch() { return getBatch('truck', function () { return truckModel(kit); }); }
  function writeTruck(br, bob, roll) { batchSet(truckBatch(), br.id, br.x, bob || 0, br.z, br.yaw || 0, 0.78, 0.78, 0.78, roll || 0); }
  function parkSpot(i, n) { n = n || N; return { x: ((i % 6) - 2.5) * 0.9, z: n / 2 - 0.9 - Math.floor(i / 6) * 0.9 }; }
  function siteCenter(b) { var f = foot(b.size, b.rot); return { x: b.x + f.w / 2 - N / 2, z: b.z + f.d / 2 - N / 2 }; }
  // k-я машина на объекте встаёт вдоль сторон участка
  function slotPos(b, k) {
    var f = foot(b.size, b.rot), c = siteCenter(b);
    var sides = [[0, 1, f.w, f.d], [1, 0, f.d, f.w], [0, -1, f.w, f.d], [-1, 0, f.d, f.w]];
    for (var lap = 0; lap < 30; lap++) for (var s = 0; s < 4; s++) {
      var sd = sides[s], len = sd[2], cap = Math.max(1, Math.floor(len / 0.75));
      if (k < cap) {
        var t = -len / 2 + (k + 0.5) * len / cap, out = sd[3] / 2 + 0.5 + lap * 0.62;
        return { x: c.x + sd[0] * out + (sd[1] !== 0 ? t : 0), z: c.z + sd[1] * out + (sd[0] !== 0 ? t : 0), yaw: sd[0] !== 0 ? 0 : Math.PI / 2 };
      }
      k -= cap;
    }
    return { x: c.x, z: c.z, yaw: 0 };
  }
  // Бригады делятся между стройками поровну; уже работающие остаются на своём объекте.
  function assignBrigades() {
    var S = state.buildings.filter(isSite), n = state.brigades.length;
    if (!S.length) { state.brigades.forEach(function (br) { if (br.site) { br.park = { x: br.x, z: br.z }; } br.site = 0; }); return; }
    var want = {}, have = {};
    S.forEach(function (s, i) { want[s.id] = Math.floor(n / S.length) + (i < n % S.length ? 1 : 0); have[s.id] = 0; });
    var free = [];
    state.brigades.forEach(function (br) {
      if (br.site && want[br.site] !== undefined && have[br.site] < want[br.site]) have[br.site]++;
      else free.push(br);
    });
    free.forEach(function (br) {
      var best = 0, bd = 1e9;
      S.forEach(function (s) {
        if (have[s.id] >= want[s.id]) return;
        var c = siteCenter(s), d = Math.hypot(c.x - br.x, c.z - br.z);
        if (d < bd) { bd = d; best = s.id; }
      });
      br.site = best; if (best) have[best]++;
    });
  }
  function siteCrew(id) {
    var all = 0, here = 0;
    state.brigades.forEach(function (br) { if (br.site === id) { all++; if (br.work) here++; } });
    return { all: all, here: here };
  }
  function rebuildTrucks() {
    var bt = truckBatch();
    bt.ids.slice().forEach(function (id) { batchRemove(bt, id); });
    state.brigades.forEach(function (br) { writeTruck(br); });
    dirty();
  }
  function buyBrigade() {
    var u = G.units.brigade;
    if (state.brigades.length >= u.importMax) { hint('Привезти можно только ' + u.importMax + ' бригады. Дальше — заказывайте на Механическом заводе (🏭 Здания)', true); return; }
    if (!canPay(u.price)) { hint('Не хватает долларов на бригаду', true); return; }
    pay(u.price);
    var i = state.brigades.length, p = parkSpot(i);
    var br = { id: state.nextBr++, x: p.x, z: N / 2 + 1.6, yaw: Math.PI, park: p, site: 0 };
    state.brigades.push(br); writeTruck(br); dirty();
    assignBrigades(); save(); refreshNeed(); renderMech();
    hint(state.buildings.some(isSite) ? '🚚 Бригада выехала на стройку' : '🚚 Бригада куплена — теперь можно строить');
  }
  function sellBrigade() {
    if (!state.brigades.length) return;
    var j = state.brigades.length - 1;
    for (var i = state.brigades.length - 1; i >= 0; i--) if (!state.brigades[i].site) { j = i; break; } // сначала свободную
    var br = state.brigades.splice(j, 1)[0];
    batchRemove(truckBatch(), br.id);
    state.spent -= Math.round(G.units.brigade.price / 2); updateMoney();
    assignBrigades(); save(); refreshNeed(); renderMech(); dirty();
    hint('Бригада продана, вернули ' + usd(G.units.brigade.price / 2));
  }
  function angTo(a, b, k) { return a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * k; }
  // Шаг анимации: машины едут к объектам, стройка растёт. Возвращает true, если что-то двигалось.
  function tickBrigades(dt, t) {
    if (!state.brigades.length) return false;
    var any = false, perSite = {}, arrived = {}, u = G.units.brigade;
    state.brigades.forEach(function (br) {
      var b = br.site ? getB(br.site) : null, tgt = null, atSite = false;
      if (b && isSite(b)) { var k = perSite[b.id] || 0; perSite[b.id] = k + 1; tgt = slotPos(b, k); atSite = true; }
      else if (br.park) tgt = { x: br.park.x, z: br.park.z, yaw: br.yaw };
      var was = br.work, moved = false;
      br.work = false;
      if (tgt) {
        var dx = tgt.x - br.x, dz = tgt.z - br.z, d = Math.hypot(dx, dz);
        if (d > 0.02) {
          var v = Math.max(u.speed, d / 3), st = Math.min(d, v * dt);
          br.x += dx / d * st; br.z += dz / d * st;
          br.yaw = angTo(br.yaw || 0, Math.atan2(dx, dz), Math.min(1, dt * 10)); moved = true;
        } else {
          br.x = tgt.x; br.z = tgt.z;
          if (Math.abs(Math.atan2(Math.sin(tgt.yaw - br.yaw), Math.cos(tgt.yaw - br.yaw))) > 0.01) { br.yaw = angTo(br.yaw, tgt.yaw, Math.min(1, dt * 8)); moved = true; }
          if (atSite) { br.work = true; arrived[b.id] = (arrived[b.id] || 0) + 1; moved = true; }
        }
      }
      if (moved || was) {
        writeTruck(br, br.work ? Math.abs(Math.sin(t * 0.012 + br.id * 1.7)) * 0.012 : 0, br.work ? Math.sin(t * 0.02 + br.id) * 0.02 : 0);
        any = true;
      }
    });
    var done = [];
    state.buildings.forEach(function (b) {
      if (!isSite(b)) return;
      var a = arrived[b.id], st = sites[b.id];
      if (a) b.prog = Math.min(1, b.prog + dt * a * u.power / buildTime(b));
      if (a || (st && st.wn)) updateSite(b, dt);
      if (b.prog >= 1) done.push(b);
    });
    done.forEach(finishSite);
    if (any) dirty();
    return any;
  }
  function finishSite(b) {
    delete b.prog;
    removeBuildingMesh(b.id); addBuildingMesh(b);
    assignBrigades(); updateStats(); saveNow();
    if (infoId === b.id) renderInfo(b, true);
    if (hasRoad(b)) hint('✅ Построено: ' + G.cats[b.cat].names[b.size]);
    else hint('✅ Построено: ' + G.cats[b.cat].names[b.size] + '. Но к нему нет дороги — подведите, чтобы заработало', true);
    renderMech();
  }


  // ---------- Механический завод: выпуск машин (с 0.9.0; общая очередь и 7 новых машин — с 0.10.0) ----------
  function working(cat) { return state.buildings.filter(function (b) { return b.cat === cat && isWorking(b); }); }
  // точка здания в его собственных координатах (lx, lz от центра; +z — фасад) → мир
  function localPos(b, lx, lz) {
    var c = siteCenter(b), yaw = -b.rot * Math.PI / 2, cs = Math.cos(yaw), sn = Math.sin(yaw);
    return { x: c.x + lx * cs + lz * sn, z: c.z - lx * sn + lz * cs, yaw: yaw };
  }
  // Что заказывают: 'brigade' или ключ из G.vehicles
  function prodInfo(kind) {
    if (kind === 'brigade') { var u = G.units.brigade; return { name: 'Бригада', icon: '🚚', price: u.factoryPrice, time: u.makeTime }; }
    var v = G.vehicles[kind]; return { name: v.name, icon: v.icon, price: v.price, time: v.makeTime };
  }
  function queued(kind) { var n = 0; state.fql.forEach(function (k) { if (k === kind) n++; }); return n; }
  var factoryTurn = 0;
  // Сколько секунд до выхода машины номер i в очереди (число заводов скорость не меняет — правило 0.10.0)
  function factoryEta(i) {
    var t = 0;
    for (var j = 0; j <= i && j < state.fql.length; j++) t += prodInfo(state.fql[j]).time - (j === 0 ? state.fprog : 0);
    return Math.max(0, t);
  }
  function factoryNext() { return state.fql.length ? factoryEta(0) : 0; }
  function tickFactory(dt) {
    if (!state.fql.length) { state.fprog = 0; return false; }
    var F = working('factory'); if (!F.length) return false;
    state.fprog += dt;
    var guard = 0;
    while (state.fql.length && state.fprog >= prodInfo(state.fql[0]).time && guard++ < 20) {
      state.fprog -= prodInfo(state.fql[0]).time;
      var kind = state.fql.shift(), fb = F[factoryTurn++ % F.length];
      if (kind === 'brigade') spawnTruck(fb); else spawnVehicle(fb, kind);
    }
    if (!state.fql.length) state.fprog = 0;
    return false;
  }
  function spawnTruck(fb) {
    var g = localPos(fb, 0.6, 0.65), i = state.brigades.length;
    var br = { id: state.nextBr++, x: g.x, z: g.z, yaw: g.yaw, park: parkSpot(i), site: 0 };
    state.brigades.push(br); writeTruck(br);
    assignBrigades(); saveNow(); refreshNeed(); renderMech(); dirty();
    hint('🏭 Завод выпустил грузовик «Бригада»' + (br.site ? ' — он поехал на стройку' : ''));
  }
  function noFactoryMsg() {
    return state.buildings.some(function (b) { return b.cat === 'factory' && !isSite(b); }) ? '🏭 Завод не работает — подведите к нему дорогу' :
      state.buildings.some(function (b) { return b.cat === 'factory'; }) ? '🏭 Завод ещё строится' : '🏭 Сначала постройте Механический завод: 🚚 Механизмы → 🏭 Здания';
  }
  function orderKind(kind) {
    var p = prodInfo(kind);
    if (!working('factory').length) { hint(noFactoryMsg(), true); return; }
    if (!canPay(p.price)) { hint('Не хватает долларов: нужно ' + usd(p.price), true); return; }
    pay(p.price); state.fql.push(kind); save(); renderMech(); refreshLive();
    var n = state.fql.length;
    hint('🏭 ' + p.icon + ' «' + p.name + '» заказан' + (n > 1 ? ': в очереди ' + n + ', выйдет через ≈ ' + secText(factoryEta(n - 1)) : ' — выйдет через ≈ ' + secText(factoryEta(0))));
  }
  function orderTruck() { orderKind('brigade'); }
  function cancelKind(kind) {
    var i = state.fql.lastIndexOf(kind); if (i < 0) return;
    state.fql.splice(i, 1); if (i === 0) state.fprog = 0;
    var p = prodInfo(kind); state.spent -= p.price;
    updateMoney(); save(); renderMech(); refreshLive();
    hint('Заказ «' + p.name + '» отменён, вернули ' + usd(p.price));
  }
  function cancelOrder() { cancelKind('brigade'); }
  function fqText(kind) {
    var L = state.fql;
    if (kind) {
      var n = queued(kind); if (!n) return 'нет заказов';
      return '<b>' + n + '</b> · ' + (working('factory').length ? 'выйдет через ≈ ' + secText(factoryEta(L.indexOf(kind))) : '<span class="bad">завод не работает</span>');
    }
    if (!L.length) return 'нет заказов';
    var p = prodInfo(L[0]);
    return '<b>' + L.length + '</b> · ' + (working('factory').length ? 'сейчас ' + p.icon + ' ' + esc(p.name) + ', ≈ ' + secText(factoryNext()) : '<span class="bad">завод не работает</span>');
  }

  // ---------- Машины на дорогах (с 0.10.0) ----------
  // Машины завода (state.vehicles) и легковые жителей ездят по клеткам дорог по правой полосе.
  var agents = {}, carAgents = {}, LANE = 0.17, planBudget = 0, carsDriving = 0;
  function vehBatch(kind) { return getBatch('veh_' + kind, function () { return vehicleModel(kit, kind); }); }
  function carBatch(m) { return getBatch('car_' + m, function () { return carModel(kit, m); }); }
  function agentBatch(a) { return a.car ? carBatch(a.model) : vehBatch(a.kind); }
  function writeAgent(a) { var s = a.car ? 0.8 : 0.72; batchSet(agentBatch(a), a.id, a.x, 0, a.z, a.yaw, s, s, s); }
  function cellOf(x, z) { return { x: Math.floor(x + N / 2), z: Math.floor(z + N / 2) }; }
  // клетки дороги у стороны здания и место «у входа» на каждой (у бордюра, вдоль стороны)
  function curbSpots(b, inset) {
    inset = inset || 0.33;
    var f = foot(b.size, b.rot), out = [];
    edgeKeys(b, function (k) {
      if (!state.roads[k]) return;
      var p = k.split(','), x = +p[0], z = +p[1], nx = 0, nz = 0;
      if (x === b.x - 1) nx = 1; else if (x === b.x + f.w) nx = -1; else if (z === b.z - 1) nz = 1; else nz = -1;
      var c = cellCenter(x, z);
      out.push({ k: k, x: c.x + nx * inset, z: c.z + nz * inset, tx: nz, tz: nx, yaw: nx ? 0 : Math.PI / 2 });
    });
    return out;
  }
  function spotAt(b, n, inset) {
    var S = curbSpots(b, inset); if (!S.length) return null;
    var s = S[n % S.length], sh = (Math.floor(n / S.length) % 3 - 1) * 0.3; // если машин больше, чем клеток, — сдвиг вдоль бордюра
    return { k: s.k, x: s.x + s.tx * sh, z: s.z + s.tz * sh, yaw: s.yaw };
  }
  // Поиск пути по дорогам (в ширину). Возвращает список клеток от start до любой из goal.
  function roadPath(start, goal) {
    if (!state.roads[start] || !goal) return null;
    if (goal[start]) return [start];
    var prev = {}, q = [start], h = 0; prev[start] = '';
    while (h < q.length) {
      var k = q[h++], p = k.split(','), x = +p[0], z = +p[1];
      for (var d = 0; d < 4; d++) {
        var nk = key(x + DIRS[d][0], z + DIRS[d][1]);
        if (prev[nk] !== undefined || !state.roads[nk]) continue;
        prev[nk] = k;
        if (goal[nk]) { var path = [nk]; while (prev[path[0]]) path.unshift(prev[path[0]]); return path; }
        q.push(nk);
      }
    }
    return null;
  }
  // Клетки → точки на правой полосе (на поворотах — точка пересечения полос)
  function lanePoints(cells) {
    var pts = [], C = cells.map(function (k) { var p = k.split(','); return cellCenter(+p[0], +p[1]); });
    for (var i = 0; i < C.length; i++) {
      var a = C[i - 1], b = C[i], c = C[i + 1];
      var din = a ? { x: b.x - a.x, z: b.z - a.z } : null, dout = c ? { x: c.x - b.x, z: c.z - b.z } : null;
      din = din || dout; dout = dout || din; if (!din) { pts.push({ x: b.x, z: b.z }); continue; }
      var ri = { x: din.z, z: -din.x }, ro = { x: dout.z, z: -dout.x };
      if (ri.x === ro.x && ri.z === ro.z) pts.push({ x: b.x + ri.x * LANE, z: b.z + ri.z * LANE });
      else if (ri.x === -ro.x && ri.z === -ro.z) { // разворот в тупике
        pts.push({ x: b.x + ri.x * LANE + din.x * 0.3, z: b.z + ri.z * LANE + din.z * 0.3 });
        pts.push({ x: b.x + ro.x * LANE + din.x * 0.3, z: b.z + ro.z * LANE + din.z * 0.3 });
      } else pts.push({ x: b.x + (ri.x + ro.x) * LANE, z: b.z + (ri.z + ro.z) * LANE });
    }
    return pts;
  }
  function goalSet(b) { var g = {}, n = 0; curbSpots(b).forEach(function (s) { g[s.k] = 1; n++; }); return n ? g : null; }
  // Отправить машину к зданию b. Возвращает true, если путь найден.
  function sendTo(a, b, slot) {
    var inset = a.car ? 0.33 : 0.08; // машины завода встают прямо в полосе — не налезают на легковые у бордюра
    var spot = spotAt(b, slot, inset); if (!spot) return false;
    var path = roadPath(a.cell, goalSet(b));
    if (!path) return false;
    var pts = lanePoints(path);
    var last = path[path.length - 1];
    if (last !== spot.k) { var S2 = curbSpots(b, inset).filter(function (s) { return s.k === last; }); if (S2.length) spot = { k: last, x: S2[0].x, z: S2[0].z, yaw: S2[0].yaw }; }
    pts.push({ x: spot.x, z: spot.z });
    a.pts = pts; a.pi = 0; a.dest = b.id; a.spot = spot; a.mode = 'drive';
    return true;
  }
  function nearestRoad(x, z) {
    var c = cellOf(x, z);
    for (var r = 0; r <= 4; r++) for (var dx = -r; dx <= r; dx++) for (var dz = -r; dz <= r; dz++) {
      if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
      var k = key(c.x + dx, c.z + dz); if (state.roads[k]) return k;
    }
    return null;
  }
  // --- машины завода ---
  function spawnVehicle(fb, kind) {
    var g = localPos(fb, 0.6, 0.65), v = { id: state.nextVeh++, kind: kind };
    state.vehicles.push(v);
    var a = makeAgent(v, g.x, g.z, g.yaw);
    var S = curbSpots(fb); if (S.length) a.cell = S[0].k;
    a.t = 0.3; saveNow(); renderMech(); dirty();
    var info = G.vehicles[kind], has = working(info.serves).length;
    hint('🏭 Завод выпустил ' + info.icon + ' «' + info.name + '»' + (has ? ' — машина поехала по делам' : ' — машина ждёт: нет работающих зданий «' + G.cats[info.serves].label + '»'));
  }
  function makeAgent(v, x, z, yaw) {
    var a = agents[v.id] = { id: v.id, kind: v.kind, x: x, z: z, yaw: yaw || 0, cell: nearestRoad(x, z), mode: 'park', t: 0.5 + Math.random() * 2, pts: null };
    v.x = x; v.z = z; writeAgent(a); return a;
  }
  function sellVehicle(kind) {
    var j = -1; for (var i = state.vehicles.length - 1; i >= 0; i--) if (state.vehicles[i].kind === kind) { j = i; break; }
    if (j < 0) return;
    var v = state.vehicles.splice(j, 1)[0], a = agents[v.id];
    if (a) { batchRemove(agentBatch(a), a.id); delete agents[v.id]; }
    var p = G.vehicles[kind].price; state.spent -= Math.round(p / 2); updateMoney(); save(); renderMech(); dirty();
    hint('«' + G.vehicles[kind].name + '» продана, вернули ' + usd(p / 2));
  }
  function vehCount(kind) { var n = 0; state.vehicles.forEach(function (v) { if (v.kind === kind) n++; }); return n; }
  function clearAgents() {
    Object.keys(agents).forEach(function (id) { batchRemove(agentBatch(agents[id]), +id); });
    Object.keys(carAgents).forEach(function (id) { batchRemove(agentBatch(carAgents[id]), +id); });
    agents = {}; carAgents = {}; carsDriving = 0;
  }
  function rebuildAgents() {
    clearAgents();
    state.vehicles.forEach(function (v, i) {
      var p = typeof v.x === 'number' ? { x: clamp(v.x, -N / 2, N / 2), z: clamp(v.z, -N / 2, N / 2 + 2) } : parkSpot(i + state.brigades.length);
      makeAgent(v, p.x, p.z, 0);
    });
    syncCars();
  }
  // --- легковые жителей: сколько и где стоят ---
  function syncCars() {
    var C = G.cars, want = {}, total = 0;
    state.buildings.forEach(function (b) {
      if (b.cat !== 'res' || !isWorking(b) || total >= C.max) return;
      var n = Math.min(C.perHouse[b.size] || 1, C.max - total);
      for (var k = 0; k < n; k++) { want[b.id * 10 + k] = { b: b, k: k }; total++; }
    });
    Object.keys(carAgents).forEach(function (id) {
      var a = carAgents[id], w = want[id];
      if (!w || (a.mode === 'park' && a.dest === a.home && !spotAt(w.b, w.k))) { if (a.mode === 'drive') carsDriving--; batchRemove(agentBatch(a), +id); delete carAgents[id]; }
    });
    Object.keys(want).forEach(function (id) {
      var old = carAgents[id];
      if (old) { // стоит у дома, а дорогу у дома переложили — переставить к новому бордюру
        if (old.mode === 'park' && old.dest === old.home) { var s2 = spotAt(want[id].b, want[id].k); if (s2 && s2.k !== old.cell) { old.x = s2.x; old.z = s2.z; old.yaw = s2.yaw; old.cell = s2.k; writeAgent(old); } }
        return;
      }
      var w = want[id], s = spotAt(w.b, w.k); if (!s) return;
      var m = G.cars.models[((w.b.seed >>> 0) + w.k * 7) % G.cars.models.length].id;
      var a = carAgents[id] = { id: +id, car: 1, model: m, home: w.b.id, slot: w.k, x: s.x, z: s.z, yaw: s.yaw, cell: s.k, mode: 'park', dest: w.b.id,
        t: C.wait[0] + Math.random() * (C.wait[1] - C.wait[0]) };
      writeAgent(a);
    });
    dirty();
  }
  function carCount(bid) { var n = 0; for (var id in carAgents) if (carAgents[id].home === bid) n++; return n; }
  function randomOf(list, r) { return list.length ? list[Math.floor((r === undefined ? Math.random() : r) * list.length)] : null; }
  // Куда ехать машине: жители — на работу, в магазин, школу и т. п. (и назад домой); машины завода — к своим зданиям
  function planAgent(a) {
    if (planBudget <= 0) { a.t = 0.1; return; }
    planBudget--;
    if (!a.cell || !state.roads[a.cell]) a.cell = nearestRoad(a.x, a.z);
    var ok = false, target = null;
    if (a.car) {
      var home = getB(a.home);
      if (!home) return;
      if (a.dest !== a.home) target = home;
      else if (carsDriving < G.cars.driveMax) {
        var W = state.buildings.filter(function (b) { return b.cat !== 'res' && isWorking(b); });
        // предпочитаем места поближе: берём лучшее из нескольких случайных
        var hb = siteCenter(home), best = null, bd = 1e9;
        for (var i = 0; i < 4 && W.length; i++) { var c = randomOf(W), cc = siteCenter(c), d = Math.hypot(cc.x - hb.x, cc.z - hb.z) * (0.6 + Math.random()); if (d < bd) { bd = d; best = c; } }
        target = best;
      }
      if (target) ok = sendTo(a, target, target === home ? a.slot : 4 + (a.id % 5));
      if (ok) carsDriving++;
      a.t = ok ? 0 : 6 + Math.random() * 10;
    } else {
      var info = G.vehicles[a.kind], L = working(info.serves).filter(function (b) { return b.id !== a.dest; });
      if (!L.length) L = working(info.serves);
      for (var tries = 0; tries < 3 && L.length && !ok; tries++) { target = randomOf(L); ok = sendTo(a, target, 6 + (a.id % 3)); }
      a.t = ok ? 0 : 4 + Math.random() * 4;
    }
  }
  function tickAgent(a, dt) {
    if (a.mode === 'park') { a.t -= dt; if (a.t <= 0) planAgent(a); return a.mode === 'drive'; }
    var sp = (a.car ? G.cars.speed : G.vehicleSpeed) * dt, moved = false;
    while (sp > 0 && a.pts) {
      var p = a.pts[a.pi], dx = p.x - a.x, dz = p.z - a.z, d = Math.hypot(dx, dz);
      // дорогу убрали прямо перед машиной — встаём и ищем путь заново
      if (a.pi < a.pts.length - 1) { var ck = cellOf(p.x, p.z), kk = key(ck.x, ck.z); if (!state.roads[kk]) { arrive(a, false); return true; } }
      if (d > 1e-4) { a.yawT = Math.atan2(dx, dz); }
      if (d <= sp) { a.x = p.x; a.z = p.z; sp -= d; a.pi++; var c2 = cellOf(a.x, a.z), k2 = key(c2.x, c2.z); if (state.roads[k2]) a.cell = k2; if (a.pi >= a.pts.length) { arrive(a, true); break; } }
      else { a.x += dx / d * sp; a.z += dz / d * sp; sp = 0; }
      moved = true;
    }
    if (a.yawT !== undefined) a.yaw = angTo(a.yaw, a.mode === 'park' && a.spot ? a.spot.yaw : a.yawT, Math.min(1, dt * 9));
    writeAgent(a);
    return moved;
  }
  function arrive(a, ok) {
    if (a.car && a.mode === 'drive') carsDriving--;
    a.mode = 'park'; a.pts = null;
    if (ok && a.spot) { a.cell = a.spot.k; a.yaw = a.spot.yaw; a.yawT = undefined; }
    else { a.dest = a.car ? -1 : 0; a.cell = nearestRoad(a.x, a.z); }
    if (a.car) a.t = a.dest === a.home ? G.cars.wait[0] + Math.random() * (G.cars.wait[1] - G.cars.wait[0]) : 4 + Math.random() * 10;
    else a.t = 3 + Math.random() * 6;
    if (!a.car) { var v = state.vehicles.filter(function (x) { return x.id === a.id; })[0]; if (v) { v.x = a.x; v.z = a.z; } }
    writeAgent(a);
  }
  function tickTraffic(dt) {
    planBudget = 6;
    var any = false, id;
    for (id in agents) if (tickAgent(agents[id], dt)) any = true;
    for (id in carAgents) if (tickAgent(carAgents[id], dt)) any = true;
    if (any) dirty();
    return any;
  }
  // Какие машины завода обслуживают здания этого вида
  function servingText(cat) {
    var out = [];
    Object.keys(G.vehicles).forEach(function (k) { var v = G.vehicles[k]; if (v.serves === cat) out.push(v.icon + ' ' + v.name + ': ' + vehCount(k)); });
    return out.join(', ');
  }

  // ---------- Износ асфальта (с 0.9.0) ----------
  // Клетки асфальта стареют со временем; у работающих зданий движение больше — износ быстрее.
  var traffic = {}, cellKc = {};
  function edgeKeys(b, fn) {
    var f = foot(b.size, b.rot);
    for (var x = b.x - 1; x <= b.x + f.w; x++) for (var z = b.z - 1; z <= b.z + f.d; z++) {
      var onEdge = x === b.x - 1 || x === b.x + f.w || z === b.z - 1 || z === b.z + f.d;
      var corner = (x === b.x - 1 || x === b.x + f.w) && (z === b.z - 1 || z === b.z + f.d);
      if (onEdge && !corner) fn(key(x, z));
    }
  }
  function rebuildTraffic() {
    traffic = {};
    state.buildings.forEach(function (b) { if (isWorking(b)) edgeKeys(b, function (k) { if (state.roads[k]) traffic[k] = 1; }); });
  }
  function cellK(k) { // у каждой клетки своя скорость старения 0,75…1,25
    var v = cellKc[k];
    if (v === undefined) { var h = 7; for (var i = 0; i < k.length; i++) h = Math.imul(h ^ k.charCodeAt(i), 2654435761); v = cellKc[k] = 0.75 + ((h >>> 0) % 1000) / 2000; }
    return v;
  }
  function markRoadKey(k) { var p = k.split(','); markRoad(+p[0], +p[1]); }
  var wearAcc = 0, wearSaveT = 0, brokeHintT = 0;
  function tickWear(dt) {
    wearAcc += dt; if (wearAcc < 1) return;
    var step = wearAcc; wearAcc = 0;
    var base = step / G.wear.life, auto = state.autoRepair && working('depot').length > 0, qd = auto ? queuedSet() : null, broken = [], ch = false;
    for (var k in state.roads) {
      if (state.roads[k] !== 'asphalt' || fixing[k]) continue;
      var w = state.wear[k] || 0, nw = w + base * cellK(k) * (traffic[k] ? G.wear.traffic : 1);
      if (wearStage(nw) !== wearStage(w)) { markRoadKey(k); ch = true; }
      if (nw >= 1) { broken.push(k); continue; }
      state.wear[k] = nw;
      if (auto && nw >= G.repair.autoAt && !qd[k]) { state.rq.push(k); qd[k] = 1; }
    }
    // разбитый асфальт становится простой дорогой — здания у неё продолжают работать
    broken.forEach(function (k) { var p = k.split(','); state.roads[k] = 'dirt'; delete state.wear[k]; refreshRoadAround(+p[0], +p[1]); });
    if (broken.length) {
      var t = performance.now();
      if (t - brokeHintT > 20000) { brokeHintT = t; hint('🕳️ Асфальт разбит (' + broken.length + ' ' + plural(broken.length, 'клетка', 'клетки', 'клеток') + ') и стал простой дорогой. Чините дороги в Дорожном депо', true); }
      statsSoon();
    }
    if (ch || broken.length) dirty();
    wearSaveT += step; if (wearSaveT >= 5 || broken.length) { wearSaveT = 0; save(); }
  }
  function roadStats() {
    var r = { asphalt: 0, dirt: 0, mid: 0, worn: 0, sum: 0, todo: 0, todoCost: 0 }, qd = queuedSet();
    for (var k in state.roads) {
      if (state.roads[k] !== 'asphalt') { r.dirt++; continue; }
      var w = state.wear[k] || 0, sg = wearStage(w);
      r.asphalt++; r.sum += w; if (sg === 1) r.mid++; else if (sg === 2) r.worn++;
      if (w >= G.repair.manualAt && !qd[k]) { r.todo++; r.todoCost += repairCost(w); }
    }
    r.avg = r.asphalt ? r.sum / r.asphalt : 0;
    return r;
  }
  function pctText(v) { return Math.round(v * 100) + '%'; }
  function wearName(w) { var s = wearStage(w); return s === 0 ? 'хороший' : s === 1 ? 'средний износ' : 'почти изношен'; }

  // ---------- Дорожное депо: ремонт асфальта катком (с 0.9.0) ----------
  var rollers = {}, fixing = {}; // id депо -> каток; клетки, которые сейчас ремонтируют
  function repairCost(w) { return Math.max(G.repair.min, Math.round(G.repair.full * w / 10) * 10); }
  function rollerBatch() { return getBatch('roller', function () { return rollerModel(kit); }); }
  function writeRoller(r, bob) { batchSet(rollerBatch(), r.id, r.x, bob || 0, r.z, r.yaw, 0.82, 0.82, 0.82); dirty(); }
  function depotHome(b) { return localPos(b, -0.47, 0.5); } // на площадке у левых ворот, носом к выезду
  function syncRollers() {
    var on = {};
    working('depot').forEach(function (b) {
      on[b.id] = 1;
      var h = depotHome(b), r = rollers[b.id];
      if (!r) { r = rollers[b.id] = { id: b.id, x: h.x, z: h.z, yaw: h.yaw, job: null, work: false, t: 0 }; writeRoller(r); }
      r.home = h;
    });
    Object.keys(rollers).forEach(function (id) {
      if (on[id]) return;
      var r = rollers[id]; if (r.job) { delete fixing[r.job]; state.rq.unshift(r.job); }
      batchRemove(rollerBatch(), +id); delete rollers[id]; dirty();
    });
  }
  function clearRollers() {
    Object.keys(rollers).forEach(function (id) { batchRemove(rollerBatch(), +id); });
    for (var k in fixing) state.rq.unshift(k);
    rollers = {}; fixing = {};
  }
  function queuedSet() { var o = {}; state.rq.forEach(function (k) { o[k] = 1; }); for (var k in fixing) o[k] = 1; return o; }
  function queueRepair(min, only) {
    var qd = queuedSet(), n = 0, cost = 0;
    (only ? [only] : Object.keys(state.roads)).forEach(function (k) {
      if (state.roads[k] !== 'asphalt' || qd[k]) return;
      var w = state.wear[k] || 0; if (w < min || w < 0.005) return;
      state.rq.push(k); qd[k] = 1; n++; cost += repairCost(w);
    });
    return { n: n, cost: cost };
  }
  function takeJob(r) {
    state.rq = state.rq.filter(function (k, i, a) { return state.roads[k] === 'asphalt' && state.wear[k] > 0.005 && !fixing[k] && a.indexOf(k) === i; });
    var best = -1, bd = 1e9;
    state.rq.forEach(function (k, i) {
      var p = k.split(','), c = cellCenter(+p[0], +p[1]), d = Math.hypot(c.x - r.x, c.z - r.z);
      if (d < bd) { bd = d; best = i; }
    });
    if (best < 0) return null;
    var k = state.rq.splice(best, 1)[0]; fixing[k] = 1; return k;
  }
  function finishJob(r) { if (r.job) delete fixing[r.job]; r.job = null; r.work = false; save(); }
  var repairedN = 0;
  function tickRepair(dt, t) {
    var ids = Object.keys(rollers); if (!ids.length) return false;
    var any = false, R = G.repair;
    ids.forEach(function (id) {
      var r = rollers[id];
      if (!r.job && state.rq.length) r.job = takeJob(r);
      if (r.job && r.work) { // укатывает клетку: катается вперёд-назад, износ уходит
        var k = r.job;
        if (state.roads[k] !== 'asphalt') { finishJob(r); return; }
        r.t += dt;
        var q = Math.min(1, r.t / R.work), s0 = wearStage(state.wear[k] || 0), w = r.w0 * (1 - q);
        state.wear[k] = w; if (wearStage(w) !== s0) markRoadKey(k);
        var off = Math.sin(r.t * 3.2) * 0.26;
        r.x = r.bx + Math.sin(r.yaw) * off; r.z = r.bz + Math.cos(r.yaw) * off;
        writeRoller(r, Math.abs(Math.sin(t * 0.03)) * 0.005); any = true;
        if (q >= 1) { delete state.wear[k]; markRoadKey(k); repairedN++; finishJob(r); }
        return;
      }
      var tgt = r.home;
      if (r.job) { var p = r.job.split(','), c = cellCenter(+p[0], +p[1]); tgt = { x: c.x, z: c.z, yaw: r.yaw }; }
      var dx = tgt.x - r.x, dz = tgt.z - r.z, d = Math.hypot(dx, dz);
      if (d > 0.02) {
        var v = Math.max(R.speed, d / 3), st = Math.min(d, v * dt);
        r.x += dx / d * st; r.z += dz / d * st;
        r.yaw = angTo(r.yaw, Math.atan2(dx, dz), Math.min(1, dt * 10));
        writeRoller(r); any = true; return;
      }
      r.x = tgt.x; r.z = tgt.z;
      if (!r.job) { // в гараже: развернуться как надо
        if (Math.abs(Math.atan2(Math.sin(tgt.yaw - r.yaw), Math.cos(tgt.yaw - r.yaw))) > 0.01) { r.yaw = angTo(r.yaw, tgt.yaw, Math.min(1, dt * 8)); writeRoller(r); any = true; }
        return;
      }
      // приехал: оплата и начало укатки
      var kk = r.job, ww = state.wear[kk] || 0;
      if (state.roads[kk] !== 'asphalt' || ww < 0.005) { finishJob(r); return; }
      var cost = repairCost(ww);
      if (!canPay(cost)) { hint('Не хватает долларов на ремонт дороги: нужно ' + usd(cost), true); state.rq = []; finishJob(r); return; }
      pay(cost); r.work = true; r.w0 = ww; r.t = 0; r.bx = r.x; r.bz = r.z;
      r.yaw = Math.round(r.yaw / (Math.PI / 2)) * (Math.PI / 2); // вдоль дороги
      any = true;
    });
    return any;
  }
  function rollerText(id) {
    var r = rollers[id]; if (!r) return '<span class="bad">не работает</span>';
    if (r.job && r.work) return '🚧 ремонтирует (' + Math.floor(Math.min(1, r.t / G.repair.work) * 100) + '%)';
    if (r.job) return '🚜 едет к дороге';
    return '🅿️ в гараже';
  }
  function rollersText() {
    var ids = Object.keys(rollers);
    if (!ids.length) return state.buildings.some(function (b) { return b.cat === 'depot'; }) ? '<span class="bad">депо не работает</span>' : 'нет депо';
    return ids.map(rollerText).join('<br>');
  }
  function noDepotMsg() {
    return state.buildings.some(function (b) { return b.cat === 'depot' && !isSite(b); }) ? '🛠️ Депо не работает — подведите к нему дорогу' :
      state.buildings.some(function (b) { return b.cat === 'depot'; }) ? '🛠️ Депо ещё строится' : '🛠️ Сначала постройте Дорожное депо: 🚚 Механизмы → 🏭 Здания';
  }
  function repairAllAct() {
    if (!working('depot').length) { hint(noDepotMsg(), true); return; }
    var r = queueRepair(G.repair.manualAt);
    hint(r.n ? '🛠️ В ремонт: ' + r.n + ' ' + plural(r.n, 'клетка', 'клетки', 'клеток') + ' асфальта, ≈ ' + usd(r.cost) : 'Изношенного асфальта нет — ремонтировать нечего');
    save(); refreshLive();
  }
  function repairOneAct(k) {
    if (!working('depot').length) { hint(noDepotMsg(), true); return; }
    var r = queueRepair(0, k);
    hint(r.n ? '🛠️ Клетка в очереди на ремонт, ≈ ' + usd(r.cost) : 'Эту клетку ремонтировать не нужно');
    save(); refreshLive();
  }
  function toggleAuto() {
    state.autoRepair = !state.autoRepair;
    if (state.autoRepair && working('depot').length) queueRepair(G.repair.autoAt);
    save(); refreshLive();
    hint(state.autoRepair ? '🔄 Автоматический ремонт включён: депо само чинит асфальт с износом от ' + pctText(G.repair.autoAt) +
      (working('depot').length ? '' : ' (когда заработает депо)') : 'Автоматический ремонт выключен');
  }
  function autoLabel() { return '🔄 Ремонтировать автоматически: <b>' + (state.autoRepair ? 'ВКЛ' : 'ВЫКЛ') + '</b>'; }

  // Живые надписи в справке и в «Механизмах» — обновляются по id, без пересборки кнопок.
  function refreshLive() {
    function set(id, v) { var e = $(id); if (e && e.innerHTML !== v) e.innerHTML = v; }
    var need = $('iRs') || $('mRs') || $('irWear') || $('iFq') || $('mFq') || $('mFqAll') || $('mVq_garbage');
    if (!need && !infoRoad) return;
    if (infoRoad) {
      var t = state.roads[infoRoad];
      if (!t) { closeInfo(); return; }
      if (t !== infoRoadT) { renderRoadInfo(); return; }
      if (t === 'asphalt') {
        var w = state.wear[infoRoad] || 0, qd = queuedSet();
        set('irWear', pctText(w));
        set('irState', fixing[infoRoad] ? '🚧 ремонтируется' : qd[infoRoad] ? '⏳ в очереди на ремонт' : wearName(w));
        set('irCost', w < 0.005 ? 'не нужен' : usd(repairCost(w)));
        var bar = $('irBar'); if (bar) { bar.style.width = Math.max(2, w * 100) + '%'; bar.className = 'w' + wearStage(w); }
      }
    }
    if ($('iRs') || $('mRs')) {
      var R = roadStats(), rs = R.asphalt ? R.asphalt + ' кл., средний износ ' + pctText(R.avg) : 'асфальта нет';
      set('iRs', rs); set('mRs', rs);
      set('mMid', String(R.mid)); set('mWorn', R.worn ? '<span class="bad">' + R.worn + '</span>' : '0');
      set('iWornN', R.mid + ' / ' + (R.worn ? '<span class="bad">' + R.worn + '</span>' : '0'));
      var qn = state.rq.length + Object.keys(fixing).length, qt = qn ? qn + ' ' + plural(qn, 'клетка', 'клетки', 'клеток') : 'пусто';
      set('iQ', qt); set('mQ', qt);
      set('iRoller', rollersText()); set('mRoller', rollersText());
      var rb = '🛠️ Отремонтировать изношенные' + (R.todo ? ' · ' + R.todo + ' кл. ≈ ' + usd(R.todoCost) : '');
      set('iRep', rb); set('mRep', rb);
      ['iAuto', 'mAuto'].forEach(function (id) { var e = $(id); if (e) { set(id, autoLabel()); e.classList.toggle('on', state.autoRepair); } });
    }
    set('iFq', fqText()); set('mFq', fqText('brigade')); set('mFqAll', fqText());
    ['iCancel', 'mCancel'].forEach(function (id) { var e = $(id); if (e) e.disabled = !queued('brigade'); });
    if ($('mVq_garbage')) Object.keys(G.vehicles).forEach(function (k) {
      set('mVq_' + k, fqText(k)); set('mVn_' + k, String(vehCount(k)));
      var c = $('mVc_' + k); if (c) c.disabled = !queued(k);
      var sl = $('mVs_' + k); if (sl) sl.disabled = !vehCount(k);
      var w = working(G.vehicles[k].serves).length; set('mVw_' + k, w ? w + ' ' + plural(w, 'здание', 'здания', 'зданий') : '<span class="bad">нет работающих</span>');
    });
    if ($('mCarsN')) set('mCarsN', String(Object.keys(carAgents).length));
  }

  function rebuildAll() {
    if (!mapNodes.length || state.size !== N) { N = state.size; occ = new Int32Array(N * N); buildMapScene(); }
    Object.keys(placed).forEach(function (id) { removeBuildingMesh(+id); });
    byId = {};
    Object.keys(chunks).forEach(function (ck) { chunks[ck].forEach(function (m) { m.dispose(); }); }); chunks = {};
    rebuildOcc();
    state.buildings.forEach(addBuildingMesh);
    Object.keys(state.roads).forEach(function (k) { var p = k.split(','); markRoad(+p[0], +p[1]); });
    rebuildTrucks(); assignBrigades(); clearRollers(); rebuildAgents();
    resCache = {}; workCache = {};
    updateStats(); updateMoney(); refreshNeed(); dirty();
  }

  // ---------- Призрак и курсор ----------
  var ghost = null, ghostKey = '';
  var ghostFoot = quadsMesh('gfoot', [[0, 0, 1, 1, 0.03]], flatMat('#4cd964', { overlay: true, alpha: 0.45 }));
  var cursor = quadsMesh('cursor', [[0, 0, 1, 1, 0.035]], flatMat('#ffffff', { overlay: true, alpha: 0.4 }));
  var hl = quadsMesh('hl', [[0, 0, 1, 1, 0.025]], flatMat('#ffc94a', { overlay: true, alpha: 0.55 }));
  [ghostFoot, cursor, hl].forEach(function (m) { m.setEnabled(false); });
  function setOverlay(m, x, z, w, d, color) {
    m.position.set(x, 0, z); m.scaling.set(w, 1, d);
    if (color) m.material.emissiveColor = hex(color);
    m.setEnabled(true); dirty();
  }

  function setGhost(cat, size, seed) {
    var k = tplKey(cat, size, seed);
    if (k === ghostKey && ghost) return;
    if (ghost) { var mm = ghost.material; ghost.dispose(); if (mm) mm.dispose(); ghost = null; }
    ghostKey = k;
    ghost = buildModel(kit, cat, size, modelSeed(cat, variantOf(cat, seed)));
    ghost.visibility = 0.6; ghost.isPickable = false;
    ghost.setEnabled(false);
  }
  function showGhostAt(size, rot, x, z, ok) {
    var b = { size: size, rot: rot, x: x, z: z }, f = foot(size, rot), p = bPos(b);
    ghost.position.set(p.x, 0, p.z); ghost.rotation.y = p.yaw; ghost.setEnabled(true);
    setOverlay(ghostFoot, p.x, p.z, f.w, f.d, ok ? '#4cd964' : '#ff3b30');
  }
  function hideGhost() { if (ghost) ghost.setEnabled(false); ghostFoot.setEnabled(false); dirty(); }
  function showCursor(x, z, color) {
    if (!inMap(x, z)) { cursor.setEnabled(false); dirty(); return; }
    var c = cellCenter(x, z); setOverlay(cursor, c.x, c.z, 1, 1, color);
  }

  // ---------- Камера: 3D и изометрия ----------
  var ISO_PITCH = Math.PI / 6; // 30° — пропорция клетки 2:1, как в SimCity 2000
  var view = 'persp';
  try { var sv = localStorage.getItem(VIEW_KEY); if (sv === 'iso' || sv === 'isohd') view = sv; } catch (e) {}
  var cam = { tx: 0, tz: 2, dist: 34, yaw: Math.PI / 4, pitch: 0.95, yawGoal: null };
  function isIso() { return view !== 'persp'; }   // обе изометрии: «ИЗО» (пиксели) и «ИЗО HD»
  function isHD() { return view === 'isohd'; }
  function snapYaw(y) { var q = Math.PI / 2; return Math.round((y - Math.PI / 4) / q) * q + Math.PI / 4; }
  function camHome() {
    cam.tx = 0; cam.tz = 2; cam.yaw = Math.PI / 4; cam.pitch = isIso() ? ISO_PITCH : 0.95; cam.yawGoal = null;
    cam.dist = clamp(N * 0.72, 24, 90) * (window.innerWidth < window.innerHeight ? 1.3 : 1);
    updateCam();
  }
  function aspect() { return engine.getRenderWidth() / Math.max(1, engine.getRenderHeight()); }
  function updateCam() {
    cam.dist = clamp(cam.dist, 5, Math.max(80, N * 1.3));
    cam.pitch = isIso() ? ISO_PITCH : clamp(cam.pitch, 0.35, 1.45);
    cam.tx = clamp(cam.tx, -N / 2, N / 2); cam.tz = clamp(cam.tz, -N / 2, N / 2);
    var cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch), dx = cp * Math.sin(cam.yaw), dz = cp * Math.cos(cam.yaw);
    var halfH = cam.dist * Math.tan(camera.fov / 2), ext;
    if (isIso()) {
      // Ортографическая камера: дальние дома не уменьшаются, все линии параллельны.
      var far = N * 2 + 60;
      camera.mode = B.Camera.ORTHOGRAPHIC_CAMERA;
      camera.orthoTop = halfH; camera.orthoBottom = -halfH;
      camera.orthoLeft = -halfH * aspect(); camera.orthoRight = halfH * aspect();
      camera.position.set(cam.tx + far * dx, far * sp, cam.tz + far * dz);
      camera.minZ = 1; camera.maxZ = far * 2.5;
      ext = halfH * Math.max(1, aspect()) * 1.6;
      if (hdState && hdState.ssao) hdState.ssao.maxZ = camera.maxZ;
    } else {
      camera.mode = B.Camera.PERSPECTIVE_CAMERA;
      camera.position.set(cam.tx + cam.dist * dx, cam.dist * sp, cam.tz + cam.dist * dz);
      camera.minZ = 0.1; camera.maxZ = Math.max(400, cam.dist * 6);
      scene.fogStart = cam.dist * 1.6 + 15; scene.fogEnd = cam.dist * 3.2 + 60;
      ext = clamp(cam.dist * 1.1, 18, 70);
    }
    camera.setTarget(new B.Vector3(cam.tx, 0, cam.tz));
    // солнце и тени следуют за камерой
    sun.position.set(cam.tx + SUN_OFF.x * 2, SUN_OFF.y * 2, cam.tz + SUN_OFF.z * 2);
    sun.orthoLeft = -ext; sun.orthoRight = ext; sun.orthoTop = ext; sun.orthoBottom = -ext;
    sun.shadowMaxZ = 200 + ext;
    dirty();
  }
  function applyViewScenery() {
    var iso = isIso(), hd = isHD();
    if (outerGround) outerGround.setEnabled(!iso);
    if (slab) slab.setEnabled(iso && !hd);
    if (slabHD) slabHD.setEnabled(hd);
    if (gridMesh) gridMesh.alpha = (N > 80 ? 0.16 : 0.22) * (hd ? 0.35 : iso ? 0.7 : 1);
    scene.fogMode = iso ? B.Scene.FOGMODE_NONE : B.Scene.FOGMODE_LINEAR;
    scene.clearColor = B.Color4.FromHexString((hd ? VOID_HD : iso ? VOID : SKY) + 'ff');
    setShadowStyle(iso);
    setQuality(hd);
    if (groundMesh) {
      var gm = hdMats().grass;
      gm.diffuseTexture.uScale = gm.diffuseTexture.vScale = N / 3; // одна «плитка» травы на 3 клетки
      groundMesh.material = hd ? gm : groundMat;
    }
  }

  // ---------- «ИЗО HD»: та же изометрия, но картинка намного качественнее ----------
  // Полное разрешение экрана, сглаживание (MSAA + FXAA), мягкое затенение углов (SSAO),
  // тени 4096, кинематографичная цветокоррекция (ACES), окна 256 px, трава и срез земли с фактурой.
  var VOID_HD = '#141b27', hdState = null, hdMatCache = null;
  function canvasTex(name, c, uS, vS) {
    var t = new B.DynamicTexture(name, c, scene, true); t.update();
    t.wrapU = t.wrapV = B.Texture.WRAP_ADDRESSMODE; t.anisotropicFilteringLevel = 8;
    t.uScale = uS || 1; t.vScale = vS || 1; return t;
  }
  function hdMats() {
    if (hdMatCache) return hdMatCache;
    // трава: пятна разного оттенка и короткие травинки
    var c = document.createElement('canvas'); c.width = c.height = 256; var g = c.getContext('2d'), r = rng(42);
    g.fillStyle = '#86bd62'; g.fillRect(0, 0, 256, 256);
    for (var i = 0; i < 90; i++) {
      var x = r() * 256, y = r() * 256, rad = 10 + r() * 30;
      var gr = g.createRadialGradient(x, y, 0, x, y, rad), col = r() > 0.5 ? '120,178,84' : '150,196,104';
      gr.addColorStop(0, 'rgba(' + col + ',.3)'); gr.addColorStop(1, 'rgba(' + col + ',0)');
      g.fillStyle = gr;
      [[0, 0], [-256, 0], [256, 0], [0, -256], [0, 256]].forEach(function (o) { g.fillRect(x + o[0] - rad, y + o[1] - rad, rad * 2, rad * 2); });
    }
    for (i = 0; i < 2600; i++) {
      g.fillStyle = r() > 0.55 ? 'rgba(60,110,40,.35)' : 'rgba(205,232,150,.35)';
      g.fillRect(r() * 256, r() * 256, 1, 2 + r() * 3);
    }
    var grass = new B.StandardMaterial('grassHD', scene); grass.specularColor = B.Color3.Black();
    grass.diffuseTexture = canvasTex('grassHDt', c, 1, 1);
    // срез земли
    function slabCanvas() {
      var W = 512, H = 256, s = document.createElement('canvas'); s.width = W; s.height = H; var q = s.getContext('2d'), rr = rng(7);
      var L = [[0, 0.07, '#5f9a43'], [0.07, 0.43, '#7b5a3c'], [0.43, 0.76, '#5e4632'], [0.76, 1, '#4a4a50']];
      L.forEach(function (l, k) {
        var y0 = l[0] * H, y1 = l[1] * H, gr = q.createLinearGradient(0, y0, 0, y1);
        gr.addColorStop(0, shade(l[2], 0.08)); gr.addColorStop(1, shade(l[2], -0.12));
        q.fillStyle = gr; q.fillRect(0, y0, W, y1 - y0 + 1);
        // волнистая граница слоя
        if (k) { q.fillStyle = shade(l[2], -0.2); for (var x = 0; x < W; x += 4) q.fillRect(x, y0 + Math.sin(x / 23 + k) * 3, 4, 3); }
      });
      for (var i = 0; i < 520; i++) { // камешки
        var x = rr() * W, y = (0.1 + rr() * 0.9) * H, w = 2 + rr() * (y > H * 0.76 ? 14 : 6);
        q.fillStyle = y > H * 0.76 ? (rr() > 0.5 ? '#5d5d64' : '#38383d') : (rr() > 0.5 ? 'rgba(160,130,95,.7)' : 'rgba(40,28,18,.5)');
        q.beginPath(); q.ellipse(x, y, w, w * 0.6, 0, 0, Math.PI * 2); q.fill();
      }
      for (i = 0; i < 160; i++) { q.fillStyle = 'rgba(70,120,50,.8)'; q.fillRect(rr() * W, 0.06 * H, 2, 2 + rr() * 6); } // корешки травы
      return s;
    }
    var slabC = slabCanvas();
    hdMatCache = {
      grass: grass,
      slab: function (n) {
        var m = new B.StandardMaterial('slabHD', scene); m.specularColor = B.Color3.Black();
        m.emissiveColor = new B.Color3(0.3, 0.28, 0.26); // срез в тени не должен уходить в черноту
        m.diffuseTexture = canvasTex('slabHDt', slabC, n / 8, -1); // -1: дёрн сверху, скала снизу
        return m;
      }
    };
    return hdMatCache;
  }
  // Пачка, созданная при включённом SSAO, не рисуется (особенность Babylon): первые кадры новой пачки
  // рисуем без SSAO, потом включаем его обратно.
  var ssaoHold = 0;
  function holdSSAO() {
    if (!hdState || !hdState.ssao) return;
    if (!ssaoHold) try { scene.postProcessRenderPipelineManager.detachCamerasFromRenderPipeline(hdState.ssao._name, camera); } catch (e) {}
    ssaoHold = 3; dirty();
  }
  function releaseSSAO() {
    if (!ssaoHold || !scene.isReady() || --ssaoHold > 0) return;
    if (hdState && hdState.ssao) try { scene.postProcessRenderPipelineManager.attachCamerasToRenderPipeline(hdState.ssao._name, camera); } catch (e) {}
  }
  function setQuality(hd) {
    if (!!hdState === hd) return;
    ssaoHold = 0;
    kit.setHD(hd); syncSiteMats();
    if (hd) {
      var dpr = window.devicePixelRatio || 1;
      hdState = { hemi: hemi.intensity, sun: sun.intensity, sunC: sun.diffuse.clone(), ground: hemi.groundColor.clone() };
      hemi.intensity = 0.7; hemi.groundColor = hex('#66745a');
      sun.intensity = 1.0; sun.diffuse = hex('#fff1d8'); sun.specular = hex('#ffffff');
      shadowGen.getShadowMap().resize(TOUCH ? 2048 : 4096);
      shadowGen.filteringQuality = B.ShadowGenerator.QUALITY_HIGH;
      shadowGen.darkness = 0.04;
      try {
        // мягкие тени в углах и у основания домов
        var ssao = new B.SSAO2RenderingPipeline('ssao', scene, { ssaoRatio: TOUCH ? 0.5 : 1, blurRatio: TOUCH ? 0.5 : 1 }, [camera], true);
        ssao.radius = 0.9; ssao.totalStrength = 1.15; ssao.base = 0.08; ssao.samples = TOUCH ? 8 : 16;
        ssao.expensiveBlur = !TOUCH; ssao.maxZ = 400; ssao.minZAspect = 0.2;
        hdState.ssao = ssao;
      } catch (e) { hdState.ssao = null; }
      var pp = new B.DefaultRenderingPipeline('hd', true, scene, [camera]);
      pp.samples = 4; pp.fxaaEnabled = true;
      pp.imageProcessingEnabled = true;
      var ip = pp.imageProcessing;
      ip.toneMappingEnabled = true; ip.toneMappingType = B.ImageProcessingConfiguration.TONEMAPPING_ACES;
      ip.exposure = 1.32; ip.contrast = 1.18;
      ip.vignetteEnabled = true; ip.vignetteWeight = 2.2; ip.vignetteStretch = 0.4; ip.vignetteColor = new B.Color4(0.02, 0.03, 0.06, 0);
      pp.sharpenEnabled = true; pp.sharpen.edgeAmount = 0.22; pp.sharpen.colorAmount = 1;
      hdState.pp = pp;
    } else {
      // снять эффекты с камеры и убрать их из движка целиком (иначе он пытается обновлять удалённые)
      var pm = scene.postProcessRenderPipelineManager;
      [hdState.pp, hdState.ssao].forEach(function (pl) {
        if (!pl) return;
        try { pm.detachCamerasFromRenderPipeline(pl._name, camera); } catch (e) {}
        try { pl.dispose(); } catch (e) {}
        if (pm.removePipeline) pm.removePipeline(pl._name);
      });
      hemi.intensity = hdState.hemi; hemi.groundColor = hdState.ground;
      sun.intensity = hdState.sun; sun.diffuse = hdState.sunC; sun.specular = B.Color3.Black();
      shadowGen.getShadowMap().resize(2048);
      shadowGen.filteringQuality = B.ShadowGenerator.QUALITY_MEDIUM;
      shadowGen.darkness = 0;
      // убрать цветокоррекцию HD, иначе она остаётся в материалах и «ИЗО»/3D становятся контрастными
      var ipc = scene.imageProcessingConfiguration;
      ipc.toneMappingEnabled = false; ipc.exposure = 1; ipc.contrast = 1; ipc.vignetteEnabled = false; ipc.applyByPostProcess = false;
      hdState = null;
    }
    dirty();
  }

  function pixelScale() {
    var dpr = window.devicePixelRatio || 1;
    // «ИЗО»: рисуем в пониженном разрешении и растягиваем без сглаживания — крупные пиксели.
    // «ИЗО HD» и 3D — полное разрешение экрана (до 2× на «ретина»-экранах).
    return view === 'iso' ? (TOUCH ? 1.5 : 2) : 1 / Math.min(dpr, 2);
  }
  var VIEWS = { persp: { btn: '3D', name: '🎥 Вид 3D' }, iso: { btn: 'ИЗО', name: '🧱 Изометрия (пиксели, как в SimCity)' }, isohd: { btn: 'HD', name: '✨ Изометрия HD (качественная картинка)' } };
  var VIEW_ORDER = ['persp', 'iso', 'isohd'];
  function nextView() { return VIEW_ORDER[(VIEW_ORDER.indexOf(view) + 1) % VIEW_ORDER.length]; }
  function setView(v) {
    if (!VIEWS[v]) v = 'persp';
    var wasIso = isIso();
    view = v;
    try { localStorage.setItem(VIEW_KEY, v); } catch (e) {}
    canvas.classList.toggle('iso', v === 'iso'); document.body.classList.toggle('iso', isIso());
    // на кнопке — текущий вид; нажатие переключает по кругу 3D → ИЗО → HD
    $('camMode').textContent = VIEWS[v].btn;
    $('camMode').classList.toggle('hd', v === 'isohd');
    $('camMode').title = 'Вид: ' + VIEWS[v].btn + '. Нажмите — ' + VIEWS[nextView()].btn;
    if (isIso()) { cam.pitch = ISO_PITCH; if (!wasIso) { cam.yaw = snapYaw(cam.yaw); cam.yawGoal = null; } }
    else cam.pitch = 0.95;
    applyViewScenery(); resize();
  }
  function rotateCam(dir) { // dir: +1 влево, -1 вправо
    if (isIso()) { cam.yawGoal = snapYaw((cam.yawGoal === null ? cam.yaw : cam.yawGoal) + dir * Math.PI / 2); }
    else { cam.yaw += dir * Math.PI / 8; updateCam(); }
  }
  function tickCam(dt) {
    if (cam.yawGoal === null) return;
    var d = cam.yawGoal - cam.yaw;
    if (Math.abs(d) < 0.002) { cam.yaw = cam.yawGoal; cam.yawGoal = null; }
    else cam.yaw += d * Math.min(1, dt * 12);
    updateCam();
  }
  function resize() {
    engine.setHardwareScalingLevel(pixelScale());
    engine.resize();
    camera.fov = (window.innerWidth < window.innerHeight ? 55 : 45) * Math.PI / 180;
    updateCam();
  }
  window.addEventListener('resize', resize);

  // Луч из точки экрана: пересечение с землёй и со зданиями (без помощи движка — быстро и на тысячах домов).
  var rayM = B.Matrix.Identity();
  function rayAt(sx, sy) {
    var rc = canvas.getBoundingClientRect();
    return scene.createPickingRay(sx - rc.left, sy - rc.top, rayM, camera, false);
  }
  function groundAt(sx, sy) {
    var r = rayAt(sx, sy);
    if (Math.abs(r.direction.y) < 1e-6) return null;
    var t = -r.origin.y / r.direction.y; if (t < 0) return null;
    return { x: r.origin.x + r.direction.x * t, z: r.origin.z + r.direction.z * t };
  }
  function cellAt(sx, sy) {
    var p = groundAt(sx, sy); if (!p) return null;
    return { x: Math.floor(p.x + N / 2), z: Math.floor(p.z + N / 2), px: p.x + N / 2, pz: p.z + N / 2 };
  }
  function rayBox(o, d, x0, y0, z0, x1, y1, z1) {
    var tmin = -Infinity, tmax = Infinity, a = [o.x, o.y, o.z], v = [d.x, d.y, d.z], lo = [x0, y0, z0], hi = [x1, y1, z1];
    for (var i = 0; i < 3; i++) {
      if (Math.abs(v[i]) < 1e-9) { if (a[i] < lo[i] || a[i] > hi[i]) return -1; continue; }
      var t1 = (lo[i] - a[i]) / v[i], t2 = (hi[i] - a[i]) / v[i];
      if (t1 > t2) { var tt = t1; t1 = t2; t2 = tt; }
      if (t1 > tmin) tmin = t1; if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return -1;
    }
    return tmax < 0 ? -1 : Math.max(0, tmin);
  }
  function pickBuilding(sx, sy) {
    var r = rayAt(sx, sy), best = null, bt = Infinity;
    state.buildings.forEach(function (b) {
      var f = foot(b.size, b.rot), x0 = b.x - N / 2, z0 = b.z - N / 2, bh = placed[b.id] ? placed[b.id].h : 1;
      var h = isSite(b) ? siteTop(b) : bh;
      var t = rayBox(r.origin, r.direction, x0 + 0.05, 0, z0 + 0.05, x0 + f.w - 0.05, h, z0 + f.d - 0.05);
      if (t >= 0 && t < bt) { bt = t; best = b; }
    });
    if (best) return best;
    var c = cellAt(sx, sy);
    if (c && inMap(c.x, c.z) && occ[idx(c.x, c.z)]) return getB(occ[idx(c.x, c.z)]);
    return null;
  }
  function originFor(size, rot, c) {
    var f = foot(size, rot);
    return { x: clamp(Math.round(c.px - f.w / 2), 0, N - f.w), z: clamp(Math.round(c.pz - f.d / 2), 0, N - f.d) };
  }

  // ---------- Инструменты ----------
  var tool = 'view', buildCat = 'res', buildSize = '1x1', buildRot = 0, buildSeed = newSeed(), roadType = 'asphalt';
  var moving = null; // {b, offX, offZ, rot, x, z}

  var HINTS = {
    view: TOUCH ? 'Нажмите на здание — справка. Два пальца — масштаб и поворот.' : 'Нажмите на здание — справка. ЛКМ/ПКМ — двигать карту, колесо — масштаб, Q/E — поворот.',
    build: TOUCH ? 'Ведите пальцем, отпустите — начнётся стройка.' : 'Наведите на карту и нажмите — начнётся стройка. R — повернуть.',
    road: 'Ведите по клеткам, чтобы проложить дорогу.',
    move: TOUCH ? 'Возьмите здание пальцем и перетащите на новое место.' : 'Зажмите здание и перетащите на новое место. R — повернуть.',
    delete: 'Нажмите на здание или ведите по дороге, чтобы удалить.'
  };
  var NO_BRIGADE = 'Сначала купите бригаду: 🚚 Механизмы → Строительство';
  var hintTimer = 0;
  function hint(text, warn) {
    var h = $('hint'); h.textContent = text || HINTS[tool]; h.className = 'hint' + (warn ? ' warn' : ''); h.style.opacity = 1;
    clearTimeout(hintTimer);
    hintTimer = warn ? setTimeout(function () { hint(); }, 2200) : setTimeout(function () { h.style.opacity = 0; }, 6000);
  }

  function setTool(t) {
    tool = t;
    document.querySelectorAll('.tool').forEach(function (b) { b.classList.toggle('on', b.dataset.tool === t); });
    $('panelBuild').hidden = t !== 'build';
    $('panelRoad').hidden = t !== 'road';
    hideGhost(); cursor.setEnabled(false);
    if (moving) cancelMove();
    if (t !== 'view') closeInfo();
    if (t === 'build') { setGhost(buildCat, buildSize, buildSeed); refreshNeed(); }
    if (t === 'build' && !state.brigades.length) hint(NO_BRIGADE, true); else hint();
  }
  function refreshNeed() { $('needBr').hidden = state.brigades.length > 0; }
  $('needBuy').addEventListener('click', function () { openMech('build'); });

  // --- миниатюры: отдельный маленький движок, рисуются по очереди и подставляются в карточки ---
  var thumbs = {}, tq = [], T = null, tBusy = false;
  function thumbReq(k, make) {
    if (thumbs[k] !== undefined) return thumbs[k];
    thumbs[k] = ''; tq.push({ k: k, make: make }); pumpThumbs();
    return '';
  }
  function thumbInit() {
    var tc = document.createElement('canvas'); tc.width = tc.height = 160;
    var en = new B.Engine(tc, true, { preserveDrawingBuffer: true, stencil: false, alpha: true }, false);
    var sc = new B.Scene(en); sc.useRightHandedSystem = true; sc.clearColor = new B.Color4(0, 0, 0, 0);
    var h = new B.HemisphericLight('h', new B.Vector3(0, 1, 0), sc); h.diffuse = hex('#eef6ff'); h.groundColor = hex('#6d8a55'); h.intensity = 0.85; h.specular = B.Color3.Black();
    var dl = new B.DirectionalLight('d', new B.Vector3(3, -6, -4), sc); dl.intensity = 0.6; dl.specular = B.Color3.Black();
    var c = new B.FreeCamera('c', new B.Vector3(0, 3, 3), sc); c.fov = 30 * Math.PI / 180; c.minZ = 0.05; c.maxZ = 100;
    T = { canvas: tc, engine: en, scene: sc, cam: c, kit: makeKit(sc) };
  }
  function pumpThumbs() { if (tBusy || !tq.length) return; tBusy = true; requestAnimationFrame(thumbStep); }
  function thumbStep() {
    try {
      if (!T) thumbInit();
      var it = tq[0];
      if (!it.mesh) {
        it.mesh = it.make(T.kit);
        it.mesh.computeWorldMatrix(true);
        var bi = it.mesh.getHierarchyBoundingVectors(true), ctr = bi.min.add(bi.max).scale(0.5), rad = bi.max.subtract(bi.min).length() / 2;
        var dist = rad / Math.sin(T.cam.fov / 2) * 1.02;
        T.cam.position.set(ctr.x + dist * 0.55, ctr.y + dist * 0.5, ctr.z + dist * 0.67);
        T.cam.setTarget(ctr);
        it.tries = 0;
      }
      if (!T.scene.isReady() && it.tries++ < 60) { requestAnimationFrame(thumbStep); return; }
      T.scene.render();
      var url = T.canvas.toDataURL('image/png');
      thumbs[it.k] = url;
      document.querySelectorAll('img[data-th="' + it.k + '"]').forEach(function (im) { im.src = url; });
      it.mesh.getChildMeshes(false).concat([it.mesh]).forEach(function (m) { var mm = m.material; m.dispose(); if (mm && mm.subMaterials) mm.dispose(); });
    } catch (e) { if (tq[0]) thumbs[tq[0].k] = ''; }
    tq.shift();
    if (tq.length) requestAnimationFrame(thumbStep); else tBusy = false;
  }
  function thumbUrl(cat, size) {
    return thumbReq(cat + size, function (K) {
      var root = new B.Mesh('thumb', K.scene), g = buildModel(K, cat, size, modelSeed(cat, 0)), s0 = G.sizes[size];
      g.parent = root;
      var pad = B.MeshBuilder.CreateBox('pad', { width: s0.w, height: 0.06, depth: s0.d }, K.scene); pad.position.y = -0.03; pad.material = K.mat('#8cc068'); pad.parent = root;
      return root;
    });
  }
  function truckThumb() {
    return thumbReq('truck', function (K) {
      var root = new B.Mesh('thumb', K.scene), t = truckModel(K); t.rotation.y = -0.35; t.parent = root;
      var pad = B.MeshBuilder.CreateBox('pad', { width: 0.75, height: 0.04, depth: 1.05 }, K.scene); pad.position.y = -0.02; pad.material = K.mat('#8cc068'); pad.parent = root;
      return root;
    });
  }
  function thumbImg(cls, k, src) { return '<img class="' + cls + '" alt="" data-th="' + k + '"' + (src ? ' src="' + src + '"' : '') + '>'; }

  function workText(cat, size) {
    var c = G.cats[cat];
    if (cat === 'res') { var f = c.families[size]; return '👥 ' + f + ' ' + plural(f, 'семья', 'семьи', 'семей'); }
    var n = c.staff[size]; return '👷 ~' + n.toLocaleString('ru-RU') + '<span class="wl"> работают</span><span class="ws"> чел.</span>';
  }
  var buildFilter = 'all';
  function renderChips() {
    $('catChips').innerHTML = '<button class="chip' + (buildFilter === 'all' ? ' on' : '') + '" data-cat="all">Все</button>' + Object.keys(G.cats).filter(function (k) { return !G.cats[k].mech; }).map(function (k) {
      var c = G.cats[k];
      return '<button class="chip' + (k === buildFilter ? ' on' : '') + '" data-cat="' + k + '"><span class="sw" style="background:' + c.tag + '"></span>' + c.label + '</button>';
    }).join('') + '<button class="chip' + (buildFilter === 'mech' ? ' on' : '') + '" data-cat="mech"><span class="sw" style="background:#e0a25a"></span>🏭 Механизмы</button>';
    $('roadChips').innerHTML = Object.keys(G.roads).map(function (k) {
      return '<button class="chip' + (k === roadType ? ' on' : '') + '" data-road="' + k + '"><span class="sw" style="background:' + G.roads[k].color + '"></span>' + G.roads[k].label + '</button>';
    }).join('');
    renderCards();
  }
  function renderCards() {
    var cats = filterCats(buildFilter), h = '';
    cats.forEach(function (ck) {
      var c = G.cats[ck];
      catSizes(ck).forEach(function (sk) {
        var on = ck === buildCat && sk === buildSize;
        h += '<button class="bcard' + (on ? ' on' : '') + '" data-cat="' + ck + '" data-size="' + sk + '">' + thumbImg('th', ck + sk, thumbUrl(ck, sk)) +
          '<span class="tx"><b>' + esc(c.names[sk]) + '</b><small>' + workText(ck, sk) + '</small>' +
          '<span class="sz"><i style="background:' + c.tag + '"></i>' + G.sizes[sk].label + ' · <em>' + usd(costOf(ck, sk)) + '</em></span></span></button>';
      });
    });
    $('bGrid').innerHTML = h;
    var sel = $('bGrid').querySelector('.bcard.on');
    if (sel) sel.scrollIntoView({ block: 'nearest' });
  }
  function secText(s) { if (s < 10) { var h = Math.max(0.5, Math.ceil(s * 2) / 2); return String(h).replace('.', ',') + ' с'; } s = Math.ceil(s); return s < 60 ? s + ' с' : Math.floor(s / 60) + ' мин ' + (s % 60 ? s % 60 + ' с' : ''); }
  function buildHint() {
    var n = state.brigades.length;
    if (!n) { hint(NO_BRIGADE, true); return; }
    hint('Строим: ' + G.cats[buildCat].names[buildSize] + ' (' + G.sizes[buildSize].label + ') · ' + usd(costOf(buildCat, buildSize)) +
      ' · ⏱ ~' + secText(G.buildTime[buildSize] / n) + ' (' + n + ' ' + plural(n, 'бригада', 'бригады', 'бригад') + ')');
  }
  function filterCats(f) {
    var all = Object.keys(G.cats);
    return f === 'all' ? all : f === 'mech' ? all.filter(function (k) { return G.cats[k].mech; }) : [f];
  }
  $('catChips').addEventListener('click', function (e) {
    var b = e.target.closest('[data-cat]'); if (!b) return;
    buildFilter = b.dataset.cat;
    var fc = filterCats(buildFilter), ch = false;
    if (fc.indexOf(buildCat) < 0) { buildCat = fc[0]; ch = true; }
    if (catSizes(buildCat).indexOf(buildSize) < 0) { buildSize = catSizes(buildCat)[0]; ch = true; }
    if (ch) { buildSeed = newSeed(); setGhost(buildCat, buildSize, buildSeed); buildHint(); }
    renderChips(); $('bGrid').scrollTop = 0;
  });
  // Кнопка «Построить» на странице «Механизмы» → «Здания»
  function startPlace(ck) {
    buildCat = ck; buildSize = catSizes(ck)[0]; buildFilter = 'mech'; buildSeed = newSeed();
    closeMech(); setTool('build'); renderChips();
    if (state.brigades.length) hint('Поставьте «' + G.cats[ck].names[buildSize] + '» вплотную к дороге · ' + usd(costOf(ck, buildSize)));
  }
  $('bGrid').addEventListener('click', function (e) {
    var b = e.target.closest('.bcard'); if (!b) return;
    buildCat = b.dataset.cat; buildSize = b.dataset.size; buildSeed = newSeed();
    $('bGrid').querySelectorAll('.bcard').forEach(function (x) { x.classList.toggle('on', x === b); });
    setGhost(buildCat, buildSize, buildSeed); buildHint();
  });
  $('roadChips').addEventListener('click', function (e) {
    var b = e.target.closest('[data-road]'); if (!b) return;
    roadType = b.dataset.road; renderChips();
  });
  function rotateCurrent() {
    if (moving) { moving.rot = (moving.rot + 1) % 4; if (lastHover) moveGhostTo(lastHover); return; }
    buildRot = (buildRot + 1) % 4;
    if (tool === 'build' && lastHover && ghost && ghost.isEnabled()) buildGhostTo(lastHover);
  }
  $('btnRotate').addEventListener('click', rotateCurrent);
  $('toolbar').addEventListener('click', function (e) {
    var b = e.target.closest('.tool'); if (!b) return;
    if (b.dataset.tool === 'mech') openMech(); else setTool(b.dataset.tool);
  });

  // --- действия ---
  var lastHover = null;
  function buildGhostTo(c) {
    var o = originFor(buildSize, buildRot, c);
    showGhostAt(buildSize, buildRot, o.x, o.z, canPlace(buildSize, buildRot, o.x, o.z, 0) && state.brigades.length > 0);
    return o;
  }
  function placeBuilding(c) {
    if (!state.brigades.length) { hint(NO_BRIGADE, true); return; }
    var o = originFor(buildSize, buildRot, c), cost = costOf(buildCat, buildSize);
    if (!canPlace(buildSize, buildRot, o.x, o.z, 0)) { hint('Здесь занято или край карты', true); return; }
    if (!canPay(cost)) { hint('Не хватает долларов: нужно ' + usd(cost), true); return; }
    pay(cost);
    var b = { id: state.nextId++, cat: buildCat, size: buildSize, x: o.x, z: o.z, rot: buildRot, seed: buildSeed, prog: 0 };
    state.buildings.push(b); markOcc(b, b.id); addBuildingMesh(b);
    assignBrigades();
    buildSeed = newSeed(); setGhost(buildCat, buildSize, buildSeed);
    save(); updateStats(); renderMech(); dirty();
    var crew = siteCrew(b.id).all;
    var msg = crew ? '🏗️ Стройка началась: ' + G.cats[b.cat].names[b.size] : '🏗️ Стройка ждёт: все бригады заняты — купите ещё, чтобы быстрее';
    hint(hasRoad(b) ? msg : msg + '. 🛣️ Не забудьте дорогу — без неё здание не заработает');
  }
  function deleteBuilding(b) {
    markOcc(b, 0); removeBuildingMesh(b.id); delete byId[b.id];
    state.buildings.splice(state.buildings.indexOf(b), 1);
    if (infoId === b.id) closeInfo();
    if (isSite(b)) { assignBrigades(); renderMech(); }
    save(); updateStats(); dirty();
  }
  function setRoad(x, z, t) {
    if (!inMap(x, z)) return;
    var k = key(x, z);
    if (t) { if (occ[idx(x, z)] || state.roads[k] === t) return; state.roads[k] = t; delete state.wear[k]; }
    else { if (!state.roads[k]) return; delete state.roads[k]; delete state.wear[k]; }
    refreshRoadAround(x, z); save(); statsSoon(); dirty();
  }
  function lineCells(a, b, fn) { // Брезенхэм
    var x0 = a.x, z0 = a.z, x1 = b.x, z1 = b.z, dx = Math.abs(x1 - x0), dz = Math.abs(z1 - z0), sx = x0 < x1 ? 1 : -1, sz = z0 < z1 ? 1 : -1, err = dx - dz;
    for (var guard = 0; guard < 500; guard++) {
      fn(x0, z0);
      if (x0 === x1 && z0 === z1) break;
      var e2 = 2 * err;
      if (e2 > -dz && e2 < dx) { // без диагональных шагов: дорога остаётся связной
        if (Math.abs(x1 - x0) >= Math.abs(z1 - z0)) { err -= dz; x0 += sx; } else { err += dx; z0 += sz; }
      } else {
        if (e2 > -dz) { err -= dz; x0 += sx; }
        if (e2 < dx) { err += dx; z0 += sz; }
      }
    }
  }
  function deleteAt(sx, sy, c) {
    if (c && inMap(c.x, c.z) && state.roads[key(c.x, c.z)]) { setRoad(c.x, c.z, null); return; }
    var b = pickBuilding(sx, sy); if (b) deleteBuilding(b);
  }

  function startMove(b, c) {
    moving = { b: b, offX: c.px - b.x, offZ: c.pz - b.z, rot: b.rot, x: b.x, z: b.z };
    writeBuilding(b);
    setGhost(b.cat, b.size, b.seed);
    moveGhostTo(c);
  }
  function moveGhostTo(c) {
    var f = foot(moving.b.size, moving.rot), fo = foot(moving.b.size, moving.b.rot);
    // центр захвата сохраняется при повороте
    var cx = c.px - moving.offX + fo.w / 2, cz = c.pz - moving.offZ + fo.d / 2;
    moving.x = clamp(Math.round(cx - f.w / 2), 0, N - f.w); moving.z = clamp(Math.round(cz - f.d / 2), 0, N - f.d);
    showGhostAt(moving.b.size, moving.rot, moving.x, moving.z, canPlace(moving.b.size, moving.rot, moving.x, moving.z, moving.b.id));
  }
  function finishMove() {
    var mv = moving, b = mv.b; moving = null;
    if (canPlace(b.size, mv.rot, mv.x, mv.z, b.id)) {
      markOcc(b, 0); b.x = mv.x; b.z = mv.z; b.rot = mv.rot; markOcc(b, b.id);
      save(); updateStats();
      if (!isSite(b) && !hasRoad(b)) hint('🛣️ Здесь нет дороги — здание не работает, пока её не подведёте', true);
    } else hint('Сюда нельзя — здание вернулось на место', true);
    writeBuilding(b);
    hideGhost();
  }
  function cancelMove() { if (!moving) return; var b = moving.b; moving = null; writeBuilding(b); hideGhost(); }

  // ---------- Указатель: мышь и касания ----------
  var ptrs = new Map(), gest = null;
  function centroid() { var a = Array.from(ptrs.values()); return { x: (a[0].x + a[1].x) / 2, y: (a[0].y + a[1].y) / 2, d: Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y), ang: Math.atan2(a[1].y - a[0].y, a[1].x - a[0].x) }; }
  function startPan(e, tap) { var p = groundAt(e.clientX, e.clientY); gest = { type: 'pan', grab: p, sx: e.clientX, sy: e.clientY, moved: false, tap: tap, t: Date.now() }; }

  canvas.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  canvas.addEventListener('pointerdown', function (e) {
    canvas.focus();
    try { canvas.setPointerCapture(e.pointerId); } catch (er) {}
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (ptrs.size === 2) {
      cancelAction();
      var c = centroid();
      gest = { type: 'two', c: c, grab: groundAt(c.x, c.y), dist: cam.dist, yaw: cam.yaw, pitch: cam.pitch };
      return;
    }
    if (ptrs.size > 2) return;
    var mouse = e.pointerType === 'mouse';
    if (mouse && e.button === 1) { gest = { type: 'rotate', lx: e.clientX, ly: e.clientY, acc: 0 }; return; }
    if (mouse && e.button === 2) { if (e.shiftKey) gest = { type: 'rotate', lx: e.clientX, ly: e.clientY, acc: 0 }; else startPan(e, false); return; }
    if (tool === 'view') { startPan(e, true); return; }
    var c2 = cellAt(e.clientX, e.clientY); if (!c2) return;
    gest = { type: 'action', sx: e.clientX, sy: e.clientY, t: Date.now(), touch: !mouse, last: c2 };
    if (tool === 'build') buildGhostTo(c2);
    else if (tool === 'road') { gest.snap = JSON.stringify(state.roads); setRoad(c2.x, c2.z, roadType); }
    else if (tool === 'delete') { gest.snap = JSON.stringify(state); deleteAt(e.clientX, e.clientY, c2); }
    else if (tool === 'move') {
      var b = pickBuilding(e.clientX, e.clientY);
      if (b) startMove(b, c2); else startPan(e, false);
    }
  });

  canvas.addEventListener('pointermove', function (e) {
    var p = ptrs.get(e.pointerId);
    if (p) { p.x = e.clientX; p.y = e.clientY; }
    if (!gest) { // наведение мышью
      if (e.pointerType !== 'mouse') return;
      var h = cellAt(e.clientX, e.clientY); lastHover = h; if (!h) return;
      if (tool === 'build') buildGhostTo(h);
      else if (tool === 'road') showCursor(h.x, h.z, G.roads[roadType].color === '#3c4047' ? '#ffffff' : '#ffe08a');
      else if (tool === 'delete') showCursor(h.x, h.z, '#ff3b30');
      return;
    }
    if (gest.type === 'two' && ptrs.size === 2) {
      var c = centroid();
      cam.dist = gest.dist * (gest.c.d / Math.max(c.d, 1));
      if (isIso()) { // в изометрии поворот двумя пальцами — щелчком на 90°
        var da = c.ang - gest.c.ang;
        if (Math.abs(da) > 0.6) { rotateCam(da > 0 ? -1 : 1); gest.c.ang = c.ang; }
      } else cam.yaw = gest.yaw - (c.ang - gest.c.ang);
      updateCam();
      var g2 = groundAt(c.x, c.y);
      if (g2 && gest.grab) { cam.tx -= g2.x - gest.grab.x; cam.tz -= g2.z - gest.grab.z; updateCam(); }
      return;
    }
    if (gest.type === 'rotate') {
      if (isIso()) {
        gest.acc += e.clientX - gest.lx; gest.lx = e.clientX;
        if (Math.abs(gest.acc) > 80) { rotateCam(gest.acc > 0 ? -1 : 1); gest.acc = 0; }
        return;
      }
      cam.yaw -= (e.clientX - gest.lx) * 0.008; cam.pitch += (e.clientY - gest.ly) * 0.005;
      gest.lx = e.clientX; gest.ly = e.clientY; updateCam(); return;
    }
    if (gest.type === 'pan') {
      if (Math.hypot(e.clientX - gest.sx, e.clientY - gest.sy) > 6) gest.moved = true;
      if (!gest.moved || !gest.grab) return;
      var g = groundAt(e.clientX, e.clientY);
      if (g) { cam.tx -= g.x - gest.grab.x; cam.tz -= g.z - gest.grab.z; updateCam(); }
      return;
    }
    if (gest.type === 'action') {
      var cl = cellAt(e.clientX, e.clientY); if (!cl) return; lastHover = cl;
      if (tool === 'build') buildGhostTo(cl);
      else if (tool === 'move' && moving) moveGhostTo(cl);
      else if (tool === 'road') { lineCells(gest.last, cl, function (x, z) { setRoad(x, z, roadType); }); showCursor(cl.x, cl.z, '#ffffff'); }
      else if (tool === 'delete') {
        lineCells(gest.last, cl, function (x, z) { if (inMap(x, z) && state.roads[key(x, z)]) setRoad(x, z, null); });
        if (cl.x !== gest.last.x || cl.z !== gest.last.z) { var bb = pickBuilding(e.clientX, e.clientY); if (bb) deleteBuilding(bb); }
        showCursor(cl.x, cl.z, '#ff3b30');
      }
      gest.last = cl;
    }
  });

  function endPointer(e) {
    ptrs.delete(e.pointerId);
    if (!gest) return;
    if (gest.type === 'two') { if (ptrs.size === 0) gest = null; return; }
    if (ptrs.size > 0) return;
    var g = gest; gest = null;
    if (e.type === 'pointercancel') { cancelAction(g); return; }
    if (g.type === 'pan' && g.tap && !g.moved) {
      var b = pickBuilding(e.clientX, e.clientY);
      if (b) openInfo(b);
      else { var rc = cellAt(e.clientX, e.clientY); if (rc && inMap(rc.x, rc.z) && state.roads[key(rc.x, rc.z)]) openRoadInfo(rc.x, rc.z); else closeInfo(); }
      return;
    }
    if (g.type === 'action') {
      var c = cellAt(e.clientX, e.clientY) || g.last;
      if (tool === 'build') { placeBuilding(c); if (g.touch) hideGhost(); else buildGhostTo(c); }
      else if (tool === 'move' && moving) finishMove();
      if (g.touch) { cursor.setEnabled(false); dirty(); }
    }
  }
  canvas.addEventListener('pointerup', endPointer);
  canvas.addEventListener('pointercancel', endPointer);
  canvas.addEventListener('pointerleave', function (e) { if (e.pointerType === 'mouse' && !gest) { if (!moving) hideGhost(); cursor.setEnabled(false); dirty(); } });

  function cancelAction(g) {
    g = g || gest;
    if (!g || g.type !== 'action') return;
    if (tool === 'build') hideGhost();
    if (tool === 'move') cancelMove();
    // второй палец быстро после первого — отменить случайную дорогу/удаление
    if (g.touch && Date.now() - g.t < 450) {
      if (tool === 'road' && g.snap) { state.roads = JSON.parse(g.snap); rebuildAll(); save(); }
      if (tool === 'delete' && g.snap) { state = fixState(JSON.parse(g.snap)); rebuildAll(); save(); }
    }
    cursor.setEnabled(false); gest = null; dirty();
  }

  canvas.addEventListener('wheel', function (e) {
    e.preventDefault();
    var before = groundAt(e.clientX, e.clientY);
    cam.dist *= Math.exp(e.deltaY * 0.0012); updateCam();
    var after = groundAt(e.clientX, e.clientY);
    if (before && after) { cam.tx -= after.x - before.x; cam.tz -= after.z - before.z; updateCam(); }
  }, { passive: false });

  var keys = {};
  window.addEventListener('keydown', function (e) {
    if (e.target.tagName === 'INPUT') return;
    var k = e.key.toLowerCase();
    if (k === 'q' || k === 'й') rotateCam(1);
    else if (k === 'e' || k === 'у') rotateCam(-1);
    else if (k === 'r' || k === 'к') rotateCurrent();
    else if (k === 'i' || k === 'ш') cycleView();
    else if (k === 'escape') { if (!$('modal').hidden) closeModal(); else if (!$('mech').hidden) closeMech(); else { closeInfo(); setTool('view'); } }
    else if (k === '6') openMech();
    else if ('12345'.indexOf(k) >= 0 && k) setTool(['view', 'build', 'road', 'move', 'delete'][+k - 1]);
    else if (k === '+' || k === '=') { cam.dist /= 1.2; updateCam(); }
    else if (k === '-') { cam.dist *= 1.2; updateCam(); }
    keys[k] = true;
  });
  window.addEventListener('keyup', function (e) { keys[e.key.toLowerCase()] = false; });
  window.addEventListener('blur', function () { keys = {}; });
  function keyPan(dt) {
    if (!$('mech').hidden) return;
    var f = 0, s = 0;
    if (keys.w || keys['ц'] || keys.arrowup) f += 1;
    if (keys.s || keys['ы'] || keys.arrowdown) f -= 1;
    if (keys.d || keys['в'] || keys.arrowright) s += 1;
    if (keys.a || keys['ф'] || keys.arrowleft) s -= 1;
    if (!f && !s) return;
    var sp = cam.dist * 0.9 * dt, sy = Math.sin(cam.yaw), cy = Math.cos(cam.yaw);
    cam.tx += (-sy * f + cy * s) * sp; cam.tz += (-cy * f - sy * s) * sp; updateCam();
  }

  function cycleView() {
    setView(nextView());
    hint(view === 'isohd' ? '✨ Изометрия HD: сглаживание, мягкие тени, чёткие окна' : view === 'iso' ? '🧱 Изометрия: крупные пиксели, поворот ⟲ ⟳ — на 90°' : '🎥 Вид 3D');
  }
  $('camMode').addEventListener('click', cycleView);
  $('camRotL').addEventListener('click', function () { rotateCam(1); });
  $('camRotR').addEventListener('click', function () { rotateCam(-1); });
  $('camIn').addEventListener('click', function () { cam.dist /= 1.25; updateCam(); });
  $('camOut').addEventListener('click', function () { cam.dist *= 1.25; updateCam(); });

  // ---------- Страница «Механизмы» ----------
  var mechTab = 'build';
  function openMech(tab) {
    if (tab) mechTab = tab;
    closeInfo(); if (moving) cancelMove();
    $('mech').hidden = false;
    document.querySelector('.tool.mech').classList.add('open');
    $('mechTabs').innerHTML = G.mechTabs.map(function (t) { return '<button class="tab' + (t.id === mechTab ? ' on' : '') + '" data-tab="' + t.id + '">' + t.label + '</button>'; }).join('');
    $('mechBody').innerHTML = mechTab === 'plants' ? plantsHtml() : mechTab === 'cars' ? carsHtml() : brigadeHtml();
    $('mechBody').scrollTop = 0;
    renderMech();
  }
  function brigadeHtml() {
    var h = '';
    Object.keys(G.units).forEach(function (k) {
      var u = G.units[k]; if (u.tab !== 'build') return;
      h += '<div class="unit">' + (k === 'brigade' ? thumbImg('uimg', 'truck', truckThumb()) : '<span class="uimg"></span>') +
        '<div class="uinfo"><h3>' + esc(u.name) + '</h3><p>' + esc(u.about) + '</p>' +
        '<div class="ukv"><span>Цена</span><span class="usd">' + usd(u.price) + ' · на заводе ' + usd(u.factoryPrice) + '</span>' +
        '<span>В парке</span><span><b id="mHave">0</b></span>' +
        '<span>Сейчас строят</span><span id="mBusy">—</span>' +
        '<span>Скорость</span><span id="mSpeed">—</span>' +
        '<span>Заказ на заводе</span><span id="mFq">—</span></div></div></div>' +
        '<div class="ubtns wrap"><button class="btn-buy" data-act="buy" id="mBuy">Купить за ' + usd(u.price) + '</button>' +
        '<button class="btn-buy alt" data-act="order" id="mOrder">🏭 Заказать на заводе · ' + usd(u.factoryPrice) + '</button>' +
        '<button class="btn-sell" data-act="sell" id="mSell">Продать</button></div>' +
        '<div class="unote" id="mBuyNote"></div>';
    });
    h += '<h4>Стройки</h4><div id="mSites"></div>' +
      '<p class="note">Как это работает: без бригады строить нельзя. Поставьте здание — бригада приедет, поставит кран и леса, и дом начнёт расти этаж за этажом. ' +
      'Бригады делятся между стройками поровну; две бригады на одном доме строят вдвое быстрее. Без завода можно привезти только ' + G.units.brigade.importMax +
      ' бригады — остальные собирает Механический завод (🏭 Здания). Деньги пока бесконечные (∞), продажа возвращает половину цены.</p>';
    return h;
  }
  function plantsHtml() {
    var u = G.units.brigade, R = G.repair, W = G.wear;
    function card(ck) {
      var c = G.cats[ck], sz = catSizes(ck)[0];
      return '<div class="unit">' + thumbImg('uimg', ck + sz, thumbUrl(ck, sz)) +
        '<div class="uinfo"><h3>' + esc(c.names[sz]) + '</h3><p>' + esc(c.about[sz]) + '</p>' +
        '<div class="ukv"><span>Размер</span><span>' + G.sizes[sz].label + '</span>' +
        '<span>Цена</span><span class="usd">' + usd(costOf(ck, sz)) + '</span>' +
        '<span>Работников</span><span>~' + c.staff[sz] + '</span>' +
        '<span>Стройка</span><span>' + secText(G.buildTime[sz]) + ' одной бригадой</span>' +
        '<span>На карте</span><span id="mCnt_' + ck + '">—</span></div></div></div>' +
        '<div class="ubtns"><button class="btn-buy" data-act="place" data-cat="' + ck + '">🏗️ Построить</button></div>';
    }
    return card('factory') +
      '<div class="pbox"><b>🏭 Выпуск машин</b>' +
      '<div class="ukv"><span>Очередь завода</span><span id="mFqAll">—</span><span>«Бригада»</span><span class="usd">' + usd(u.factoryPrice) + '</span>' +
      '<span>Время</span><span>' + secText(u.makeTime) + ' на грузовик; машины выходят по очереди, число заводов скорость не меняет</span></div>' +
      '<div class="ubtns wrap"><button class="btn-buy alt" data-act="order">🚚 Заказать «Бригаду»</button><button class="btn-sell" data-act="cancel" id="mCancel">Отменить</button>' +
      '<button class="btn-buy" data-act="cars">🚗 Ещё 7 машин</button></div></div>' +
      card('depot') +
      '<div class="pbox"><b>🛠️ Ремонт дорог</b>' +
      '<div class="ukv"><span>Асфальт</span><span id="mRs">—</span><span>Средний износ</span><span id="mMid">0</span><span>Почти изношен</span><span id="mWorn">0</span>' +
      '<span>Очередь ремонта</span><span id="mQ">—</span><span>Каток</span><span id="mRoller">—</span></div>' +
      '<button class="btn-buy wide" data-act="repair" id="mRep">🛠️ Отремонтировать изношенные</button>' +
      '<button class="btn-tog" data-act="auto" id="mAuto">' + autoLabel() + '</button></div>' +
      '<p class="note">Асфальт изнашивается со временем — у работающих зданий быстрее: средний износ с ' + pctText(W.mid) + ' (трещины), почти изношен с ' + pctText(W.worn) +
      ' (ямы и заплатки), при 100% асфальт разбит и становится простой дорогой. Ремонт клетки стоит до ' + usd(R.full) + ' (зависит от износа). ' +
      'Кнопка «Отремонтировать изношенные» отправляет в ремонт всё с износом от ' + pctText(R.manualAt) + '; автоматический ремонт сам чинит клетки с износом от ' + pctText(R.autoAt) + '. Простая дорога не изнашивается.</p>';
  }
  function carsHtml() {
    var h = '<div class="pbox"><b>🏭 Очередь Механического завода</b><div class="ukv"><span>В очереди</span><span id="mFqAll">—</span></div>' +
      '<div class="unote" style="margin-top:6px">' + (working('factory').length ? 'Машины собираются по одной, по очереди. Число заводов скорость не меняет — ворота заводов чередуются.' : esc(noFactoryMsg())) + '</div></div>';
    Object.keys(G.vehicles).forEach(function (k) {
      var v = G.vehicles[k];
      h += '<div class="unit">' + thumbImg('uimg', 'veh_' + k, vehicleThumb(k)) +
        '<div class="uinfo"><h3>' + v.icon + ' ' + esc(v.name) + '</h3><p>' + esc(v.about) + '</p>' +
        '<div class="ukv"><span>Обслуживает</span><span>' + esc(G.cats[v.serves].label) + ' · <span id="mVw_' + k + '">—</span></span>' +
        '<span>Цена</span><span class="usd">' + usd(v.price) + '</span>' +
        '<span>Сборка</span><span>' + secText(v.makeTime) + '</span>' +
        '<span>В городе</span><span><b id="mVn_' + k + '">0</b></span>' +
        '<span>Заказано</span><span id="mVq_' + k + '">—</span></div></div></div>' +
        '<div class="ubtns wrap"><button class="btn-buy alt" data-act="vorder" data-kind="' + k + '">🏭 Заказать · ' + usd(v.price) + '</button>' +
        '<button class="btn-sell" data-act="vcancel" data-kind="' + k + '" id="mVc_' + k + '">Отменить</button>' +
        '<button class="btn-sell" data-act="vsell" data-kind="' + k + '" id="mVs_' + k + '">Продать</button></div>';
    });
    h += '<h4>🚗 Легковые машины жителей</h4>';
    G.cars.models.forEach(function (m) {
      h += '<div class="unit">' + thumbImg('uimg', 'car_' + m.id, vehicleThumb(m.id, true)) +
        '<div class="uinfo"><h3>' + esc(m.name) + '</h3><p>Появляется сама у жилых домов с дорогой. Ездит к работе, магазинам и школам и возвращается домой.</p></div></div>';
    });
    var P = G.cars.perHouse;
    h += '<p class="note">Сейчас легковых машин в городе: <b id="mCarsN">0</b>. У частного дома и дома на две семьи — ' + P['1x1'] + ' машина, у многоквартирного — ' + P['2x2'] +
      ', у жилого комплекса — ' + P['4x4'] + '. Машины ездят только по дорогам, по правой полосе. Машина завода ездит между работающими зданиями своего вида; если таких нет — стоит и ждёт. ' +
      'Продажа возвращает половину цены, отмена заказа — всю.</p>';
    return h;
  }
  function closeMech() { $('mech').hidden = true; document.querySelector('.tool.mech').classList.remove('open'); }
  function renderMech() {
    if ($('mech').hidden) return;
    if (mechTab === 'cars') { refreshLive(); return; }
    if (mechTab === 'plants') {
      ['factory', 'depot'].forEach(function (ck) {
        var e = $('mCnt_' + ck); if (!e) return;
        var all = state.buildings.filter(function (b) { return b.cat === ck; }), wk = all.filter(isWorking).length, st = all.filter(isSite).length;
        var t = all.length ? all.length + ' шт.' + (wk ? ', работает ' + wk : '') + (st ? ', строится ' + st : '') + (all.length - wk - st ? ', <span class="bad">без дороги ' + (all.length - wk - st) + '</span>' : '') : 'нет';
        if (e.innerHTML !== t) e.innerHTML = t;
      });
      refreshLive();
      return;
    }
    if (!$('mHave')) return;
    var n = state.brigades.length, busy = 0, u = G.units.brigade, nf = working('factory').length;
    state.brigades.forEach(function (br) { if (br.site) busy++; });
    $('mHave').textContent = n;
    $('mBusy').textContent = n ? busy + ' из ' + n : 'нет бригад';
    $('mSpeed').textContent = n ? 'одна стройка — до ×' + n : 'стройка невозможна';
    $('mSell').disabled = !n;
    $('mBuy').disabled = n >= u.importMax;
    $('mOrder').disabled = !nf;
    var note = n >= u.importMax ? 'Привезти из другого города можно только ' + u.importMax + ' бригады. ' : '';
    note += nf ? '🏭 Завод работает: грузовик ' + usd(u.factoryPrice) + ', ' + secText(u.makeTime) + '.' : noFactoryMsg().replace('🏭 ', '🏭 Чтобы собирать свои грузовики: ') + '.';
    if ($('mBuyNote').textContent !== note) $('mBuyNote').textContent = note;
    refreshLive();
    var S = state.buildings.filter(isSite), h = '';
    S.forEach(function (b) {
      var crew = siteCrew(b.id), left = (1 - b.prog) * buildTime(b) / Math.max(1, crew.all), pct = Math.floor(b.prog * 100);
      h += '<div class="site-row"><div class="sr-top"><b>' + esc(G.cats[b.cat].names[b.size]) + '</b><span>' + esc(STAGES[stageOf(b.prog)].name.toLowerCase()) + ' · ' + pct + '%</span></div>' +
        '<div class="pbar"><i style="width:' + pct + '%"></i></div>' +
        '<div style="font-size:13px;color:#a9b6c8;margin:-4px 0 8px">' + (crew.all ? '🚚 ' + crew.all + ' ' + plural(crew.all, 'бригада', 'бригады', 'бригад') +
          (crew.here < crew.all ? ' (едут: ' + (crew.all - crew.here) + ')' : '') + ' · осталось ≈ ' + secText(left) : '<span class="wait">ждёт свободную бригаду</span>') + '</div></div>';
    });
    h = h || '<div class="empty">Сейчас ничего не строится.</div>';
    if ($('mSites').innerHTML !== h) $('mSites').innerHTML = h;
  }
  function mechAct(a, el) {
    if (a === 'buy') buyBrigade(); else if (a === 'sell') sellBrigade();
    else if (a === 'order') orderTruck(); else if (a === 'cancel') cancelOrder();
    else if (a === 'place') startPlace(el.dataset.cat);
    else if (a === 'repair') repairAllAct(); else if (a === 'auto') toggleAuto();
    else if (a === 'fixone' && infoRoad) repairOneAct(infoRoad);
    else if (a === 'vorder') orderKind(el.dataset.kind); else if (a === 'vcancel') cancelKind(el.dataset.kind); else if (a === 'vsell') sellVehicle(el.dataset.kind);
    else if (a === 'cars') { openMech('cars'); return; }
    renderMech();
  }
  $('mechClose').addEventListener('click', closeMech);
  $('mech').addEventListener('click', function (e) {
    if (e.target === $('mech')) { closeMech(); return; }
    var t = e.target.closest('[data-tab]'); if (t) { openMech(t.dataset.tab); return; }
    var a = e.target.closest('[data-act]'); if (!a) return;
    mechAct(a.dataset.act, a);
  });
  $('infoBody').addEventListener('click', function (e) {
    var a = e.target.closest('[data-act]'); if (!a) return;
    mechAct(a.dataset.act, a);
  });

  // ---------- Жители и сотрудники ----------
  var P = G.people;
  function person(r, male, sur, ageMin, ageMax) {
    var age = rint(r, ageMin, ageMax);
    var job = age < 7 ? 'дошкольник' : age < 18 ? 'школьник' : age < 22 && r() < 0.6 ? 'студент' : age >= 63 ? 'пенсионер' : pick(r, P.jobs);
    return { name: (male ? pick(r, P.male) : pick(r, P.female)) + ' ' + (male ? sur[0] : sur[1]), age: age, job: job, m: male };
  }
  function ageWord(n) { var a = n % 10, b = n % 100; return n + ' ' + (b >= 11 && b <= 14 ? 'лет' : a === 1 ? 'год' : a >= 2 && a <= 4 ? 'года' : 'лет'); }
  function canWork(m) { return m.age >= 18 && m.age < 63 && m.job !== 'студент'; }
  var resCache = {};
  function residents(b) {
    var ck = b.id + ':' + b.seed; if (resCache[ck]) return resCache[ck];
    var r = rng(b.seed ^ 0x5bd1e995), nf = G.cats.res.families[b.size], fams = [], total = 0, adults = 0;
    for (var i = 0; i < nf; i++) {
      var sur = pick(r, P.surnames), roll = r(), mem = [], male = r() < 0.5;
      if (roll < 0.18) mem.push(person(r, male, sur, 20, 80));
      else if (roll < 0.4) { mem.push(person(r, true, sur, 24, 60)); mem.push(person(r, false, sur, 22, 58)); }
      else if (roll < 0.88) {
        var pa = person(r, true, sur, 28, 50); mem.push(pa); mem.push(person(r, false, sur, 26, 48));
        var kids = rint(r, 1, 3);
        for (var k = 0; k < kids; k++) mem.push(person(r, r() < 0.5, sur, 1, Math.min(20, pa.age - 20)));
      } else { mem.push(person(r, true, sur, 63, 85)); mem.push(person(r, false, sur, 61, 83)); }
      var fam = { surname: sur, members: mem, pet: r() < 0.35 ? pick(r, P.pets) : null, flat: b.size === '2x2' || b.size === '4x4' ? String(i + 1) : null };
      total += mem.length; mem.forEach(function (m) { if (canWork(m)) adults++; }); fams.push(fam);
    }
    return (resCache[ck] = { families: fams, total: total, adults: adults });
  }
  var workCache = {};
  function workplace(b) {
    var ck = b.id + ':' + b.seed; if (workCache[ck]) return workCache[ck];
    var c = G.cats[b.cat], r = rng(b.seed ^ 0x27d4eb2f);
    var staff = Math.max(2, Math.round(c.staff[b.size] * (0.85 + r() * 0.3)));
    var sur = pick(r, P.surnames), male = r() < 0.55;
    var head = (male ? pick(r, P.male) : pick(r, P.female)) + ' ' + (male ? sur[0] : sur[1]);
    var team = [];
    for (var i = 0; i < Math.min(4, staff - 1); i++) {
      var s2 = pick(r, P.surnames), m2 = r() < 0.5;
      team.push({ name: (m2 ? pick(r, P.male) : pick(r, P.female)) + ' ' + (m2 ? s2[0] : s2[1]), role: pick(r, c.roles), age: rint(r, 20, 60) });
    }
    var vn = c.visitN[b.size];
    var res = { staff: staff, head: head, team: team, visits: rint(r, vn[0], vn[1]), company: c.company ? pick(r, c.company) : null };
    return (workCache[ck] = res);
  }
  function address(b) { return G.streets[Math.floor(b.z / 4) % G.streets.length] + ', ' + (b.x + 1); }
  // Правило (с 0.8.0): здание работает, только если к нему подведена дорога — любая.
  // Дорога должна касаться стороны здания; клетка наискосок от угла не считается.
  function roadsAt(sz, rot, bx, bz) {
    var f = foot(sz, rot), seen = {};
    for (var x = bx - 1; x <= bx + f.w; x++) for (var z = bz - 1; z <= bz + f.d; z++) {
      var onEdge = x === bx - 1 || x === bx + f.w || z === bz - 1 || z === bz + f.d;
      var corner = (x === bx - 1 || x === bx + f.w) && (z === bz - 1 || z === bz + f.d);
      if (onEdge && !corner) { var t = state.roads[key(x, z)]; if (t) seen[t] = 1; }
    }
    return seen;
  }
  function hasRoad(b) { var s = roadsAt(b.size, b.rot, b.x, b.z); return !!(s.asphalt || s.dirt); }
  function isWorking(b) { return !isSite(b) && hasRoad(b); }
  function roadNear(b) {
    var seen = roadsAt(b.size, b.rot, b.x, b.z);
    if (seen.asphalt && seen.dirt) return 'асфальт и простая';
    if (seen.asphalt) return 'асфальт';
    if (seen.dirt) return 'простая дорога';
    return '<span class="bad">нет</span>';
  }

  // ---------- Расчёт жителей в фоне (js/sim.js) ----------
  var sim = { people: 0, adults: 0, employed: 0, unemployed: 0, jobs: 0, freeJobs: 0, home: {}, work: {}, ms: 0, ready: false };
  var simTimer = 0;
  function simRequest() {
    clearTimeout(simTimer);
    simTimer = setTimeout(function () {
      var homes = [], works = [];
      state.buildings.forEach(function (b) {
        if (!isWorking(b)) return; // без дороги здание не работает
        var c = siteCenter(b);
        if (b.cat === 'res') { var R = residents(b); homes.push([b.id, c.x, c.z, R.adults, R.total]); }
        else works.push([b.id, c.x, c.z, workplace(b).staff]);
      });
      window.SIM.run({ homes: homes, works: works });
    }, 200);
  }
  window.SIM.onResult(function (r) {
    sim.people = r.people; sim.adults = r.adults; sim.employed = r.employed; sim.unemployed = r.unemployed;
    sim.jobs = r.jobs; sim.freeJobs = r.freeJobs; sim.ms = r.ms; sim.ready = true;
    sim.home = {}; sim.work = {};
    r.homes.forEach(function (h) { sim.home[h[0]] = h[1]; });
    r.works.forEach(function (w) { sim.work[w[0]] = w[1]; });
    $('stJobsWrap').title = 'Рабочие места: ' + r.jobs.toLocaleString('ru-RU') + ', занято ' + r.employed.toLocaleString('ru-RU') + ', без работы ' + r.unemployed.toLocaleString('ru-RU');
    if (infoId) { var ib = getB(infoId); if (ib) renderInfo(ib, true); }
  });

  // ---------- Справка о здании ----------
  var infoId = 0;
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function openInfo(b) { renderInfo(b, false); }
  function renderInfo(b, keepScroll) {
    infoId = b.id; infoRoad = '';
    var c = G.cats[b.cat], name = c.names[b.size], h = '';
    h += '<h2>' + esc(name) + '</h2>';
    h += '<div class="sub"><span class="tag" style="background:' + c.tag + '">' + esc(c.label) + '</span>' + esc(address(b)) + ' · ' + G.sizes[b.size].label + '</div>';
    if (isSite(b)) {
      var crew = siteCrew(b.id), pct = Math.floor(b.prog * 100), left = (1 - b.prog) * buildTime(b) / Math.max(1, crew.all);
      var sg = stageOf(b.prog);
      h += '<div class="build-now">🏗️ Идёт стройка — ' + pct + '%</div><div class="pbar"><i style="width:' + pct + '%"></i></div>';
      h += '<ol class="stages">' + STAGES.map(function (x, i) {
        return '<li class="' + (i < sg ? 'done' : i === sg ? 'now' : '') + '"><b>' + (i < sg ? '✓ ' : '') + esc(x.name) + '</b>' + (i === sg ? '<small>' + esc(x.about) + '</small>' : '') + '</li>';
      }).join('') + '</ol>';
      h += '<div class="kv"><span>Бригады</span><span>' + (crew.all ? crew.all + (crew.here < crew.all ? ' (в пути ' + (crew.all - crew.here) + ')' : ' на месте') : state.brigades.length ? 'ждёт свободную' : 'нет — купите в «Механизмы»') + '</span>' +
        (crew.all ? '<span>Осталось</span><span>≈ ' + secText(left) + '</span>' : '') +
        '<span>Цена</span><span>' + usd(costOf(b.cat, b.size)) + '</span>' +
        '<span>После стройки</span><span>' + (b.cat === 'res' ? 'заедут ' + c.families[b.size] + ' ' + plural(c.families[b.size], 'семья', 'семьи', 'семей') : 'работа для ~' + c.staff[b.size] + ' чел.') + '</span>' +
        '<span>Дорога рядом</span><span>' + roadNear(b) + '</span></div>';
      if (!hasRoad(b)) h += '<div class="noroad">🛣️ К стройке нет дороги. Достроить можно, но работать здание начнёт, только когда к нему подведут дорогу.</div>';
    } else if (!hasRoad(b)) {
      h += '<div class="noroad"><b>⛔ Не работает — нет дороги</b>Подведите к зданию любую дорогу (асфальт или простую): она должна касаться его стороны. ' +
        (b.cat === 'res' ? 'Тогда заедут ' + c.families[b.size] + ' ' + plural(c.families[b.size], 'семья', 'семьи', 'семей') + '.' : 'Тогда откроется ' + workplace(b).staff + ' рабочих мест.') + '</div>';
      if (b.cat !== 'res') h += '<div class="about">' + esc(c.about[b.size]) + '</div>';
      h += '<div class="kv"><span>Дорога рядом</span><span>' + roadNear(b) + '</span>' +
        (b.cat === 'res' ? '<span>Живут</span><span>никого — дом пустой</span>' : '<span>Работают</span><span>никто — закрыто</span>') + '</div>';
    } else if (b.cat === 'res') {
      var R = residents(b), emp = sim.home[b.id];
      h += '<div class="kv"><span>Живут</span><span><b>' + R.total + '</b> чел., ' + R.families.length + ' ' + plural(R.families.length, 'семья', 'семьи', 'семей') + '</span>' +
        '<span>Работают</span><span>' + (emp === undefined ? '…считаем' : emp + ' из ' + R.adults + ' взрослых' + (emp < R.adults ? ' — ' + (R.adults - emp) + ' ищут работу' : '')) + '</span>' +
        '<span>Машины жильцов</span><span>🚗 ' + carCount(b.id) + '</span>' +
        '<span>Мусоровозы в городе</span><span>' + vehCount('garbage') + '</span>' +
        '<span>Дорога рядом</span><span>' + roadNear(b) + '</span></div>';
      var show = R.families.slice(0, 8);
      show.forEach(function (f) {
        var adults = f.members.length;
        h += '<div class="fam"><b>' + (f.flat ? 'Кв. ' + f.flat + ' — ' : '') + (adults > 1 ? 'Семья ' + esc(famName(f.surname[0])) : ('Живёт ' + (f.members[0].m ? 'один' : 'одна'))) + '</b>' +
          f.members.map(function (m) { return '<div>' + esc(m.name) + ', ' + ageWord(m.age) + ' — ' + esc(m.job) + '</div>'; }).join('') +
          (f.pet ? '<div>🐾 ' + esc(f.pet) + '</div>' : '') + '</div>';
      });
      if (R.families.length > show.length) h += '<div class="more">…и ещё ' + (R.families.length - show.length) + ' ' + plural(R.families.length - show.length, 'семья', 'семьи', 'семей') + '</div>';
    } else {
      var w = workplace(b), headLabel = c.head[b.size] + (c.rank ? ' (' + c.rank[b.size] + ')' : ''), filled = sim.work[b.id];
      h += '<div class="about">' + esc(c.about[b.size]) + '</div>';
      if (b.cat === 'factory') {
        var u = G.units.brigade;
        h += '<div class="pbox"><b>🏭 Выпуск машин</b><div class="kv"><span>Очередь</span><span id="iFq">' + fqText() + '</span>' +
          '<span>«Бригада»</span><span>' + usd(u.factoryPrice) + ', ' + secText(u.makeTime) + '</span><span>Другие машины</span><span>7 моделей, от ' + secText(3) + '</span></div>' +
          '<div class="ubtns wrap"><button class="btn-buy alt" data-act="order">🚚 Заказать «Бригаду»</button><button class="btn-sell" data-act="cancel" id="iCancel"' + (queued('brigade') ? '' : ' disabled') + '>Отменить</button>' +
          '<button class="btn-buy" data-act="cars">🚗 Другие машины</button></div></div>';
      } else if (b.cat === 'depot') {
        h += '<div class="pbox"><b>🛠️ Ремонт дорог</b><div class="kv"><span>Каток</span><span id="iRoller">' + rollerText(b.id) + '</span>' +
          '<span>Асфальт</span><span id="iRs">—</span><span>Средний / почти изношен</span><span id="iWornN">—</span><span>Очередь</span><span id="iQ">—</span></div>' +
          '<button class="btn-buy wide" data-act="repair" id="iRep">🛠️ Отремонтировать изношенные</button>' +
          '<button class="btn-tog' + (state.autoRepair ? ' on' : '') + '" data-act="auto" id="iAuto">' + autoLabel() + '</button></div>';
      }
      h += '<div class="kv">' + (w.company ? '<span>Компания</span><span>«' + esc(w.company) + '»</span>' : '') +
        '<span>' + esc(headLabel) + '</span><span>' + esc(w.head) + '</span>' +
        '<span>Мест</span><span><b>' + w.staff + '</b></span>' +
        '<span>Из горожан</span><span>' + (filled === undefined ? '…считаем' : filled + ' чел.' + (filled < w.staff ? ' — свободно ' + (w.staff - filled) : ' — все места заняты')) + '</span>' +
        '<span>' + esc(cap(c.visitors[b.size])) + '</span><span>' + w.visits + '</span>' +
        (servingText(b.cat) ? '<span>Машины в городе</span><span>' + esc(servingText(b.cat)) + '</span>' : '') +
        '<span>Дорога рядом</span><span>' + roadNear(b) + '</span></div>';
      if (w.team.length) {
        h += '<div class="fam"><b>Сотрудники</b>' + w.team.map(function (t) { return '<div>' + esc(t.name) + ', ' + ageWord(t.age) + ' — ' + esc(t.role) + '</div>'; }).join('') + '</div>';
        if (w.staff - 1 > w.team.length) h += '<div class="more">…и ещё ' + (w.staff - 1 - w.team.length) + ' чел.</div>';
      }
    }
    $('infoBody').innerHTML = h; $('info').hidden = false; if (!keepScroll) $('info').scrollTop = 0;
    highlight(b.id);
    refreshLive();
  }
  // Справка о клетке дороги (с 0.9.0): износ, цена ремонта, кнопка ремонта
  var infoRoad = '', infoRoadT = '';
  function openRoadInfo(x, z) { closeInfo(); infoRoad = key(x, z); renderRoadInfo(); }
  function renderRoadInfo() {
    var k = infoRoad, t = state.roads[k]; if (!t) { closeInfo(); return; }
    infoRoadT = t;
    var p = k.split(','), x = +p[0], z = +p[1], h = '<h2>' + (t === 'asphalt' ? '🛣️ Асфальт' : '🟫 Простая дорога') + '</h2>' +
      '<div class="sub">' + esc(G.streets[Math.floor(z / 4) % G.streets.length]) + ' · клетка ' + (x + 1) + ':' + (z + 1) + (traffic[k] ? ' · у работающего здания' : '') + '</div>';
    if (t === 'asphalt') {
      h += '<div class="kv"><span>Износ</span><span id="irWear">—</span><span>Состояние</span><span id="irState">—</span><span>Ремонт</span><span id="irCost">—</span></div>' +
        '<div class="pbar wear"><i id="irBar"></i></div>';
      h += working('depot').length ? '<button class="btn-buy wide" data-act="fixone">🛠️ Отремонтировать эту клетку</button>' :
        '<div class="noroad"><b>Ремонтировать некому</b>Постройте Дорожное депо: 🚚 Механизмы → 🏭 Здания. Без него асфальт будет только изнашиваться.</div>';
      h += '<p class="note">Асфальт стареет со временем, у работающих зданий — в ' + String(G.wear.traffic).replace('.', ',') + ' раза быстрее. С ' + pctText(G.wear.mid) +
        ' — трещины, с ' + pctText(G.wear.worn) + ' — ямы. При 100% он разбит и становится простой дорогой.</p>';
    } else h += '<div class="about">Простая дорога не изнашивается и ремонта не требует. Здания у неё работают так же, как у асфальта. Чтобы положить асфальт: 🛣️ «Дорога» → «Асфальт» и проведите по клеткам.</div>';
    $('infoBody').innerHTML = h; $('info').hidden = false; $('info').scrollTop = 0;
    var c = cellCenter(x, z); setOverlay(hl, c.x, c.z, 1.12, 1.12);
    refreshLive();
  }
  function famName(s) { return /(ов|ев|ин)$/.test(s) ? s + 'ых' : s; }
  function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function plural(n, a, b, c) { var x = n % 10, y = n % 100; return y >= 11 && y <= 14 ? c : x === 1 ? a : x >= 2 && x <= 4 ? b : c; }
  function closeInfo() { infoId = 0; infoRoad = ''; $('info').hidden = true; highlight(0); }
  $('infoClose').addEventListener('click', closeInfo);
  function highlight(id) {
    var b = id && getB(id);
    if (!b) { hl.setEnabled(false); dirty(); return; }
    var f = foot(b.size, b.rot), p = bPos(b);
    setOverlay(hl, p.x, p.z, f.w + 0.2, f.d + 0.2);
  }

  // ---------- Статистика ----------
  var noRoadCount = 0, statsTimer = 0;
  function updateStats() {
    clearTimeout(statsTimer);
    var people = 0, jobs = 0, built = 0, off = 0;
    state.buildings.forEach(function (b) {
      pinFor(b);
      if (isSite(b)) return; built++;
      if (!hasRoad(b)) { off++; return; }
      if (b.cat === 'res') people += residents(b).total; else jobs += workplace(b).staff;
    });
    noRoadCount = off;
    $('stPeople').textContent = people.toLocaleString('ru-RU');
    $('stJobs').textContent = jobs.toLocaleString('ru-RU');
    $('stBuild').textContent = built;
    $('stOff').textContent = off; $('stOffWrap').hidden = !off;
    $('stOffWrap').title = 'Без дороги: ' + off + ' ' + plural(off, 'здание', 'здания', 'зданий') + ' не работают. Подведите к ним дорогу.';
    rebuildTraffic(); syncRollers(); syncCars();
    if (infoId) { var ib = getB(infoId); if (ib) renderInfo(ib, true); }
    simRequest();
  }
  function statsSoon() { clearTimeout(statsTimer); statsTimer = setTimeout(updateStats, 120); }

  // ---------- Меню ----------
  function openModal(html) { $('modalBody').innerHTML = html; $('modal').hidden = false; }
  function closeModal() { $('modal').hidden = true; }
  $('modalClose').addEventListener('click', closeModal);
  $('modal').addEventListener('click', function (e) { if (e.target === $('modal')) closeModal(); });

  // Гайд: текст в js/guide.js (тот же текст — в файле GUIDE.txt)
  function guideHtml(welcome) {
    var g = window.GUIDE, open = { start: 1, roads: 1 };
    open[TOUCH ? 'touch' : 'pc'] = 1;
    if (!g) return '<p>Гайд не загрузился.</p>';
    return (welcome ? '' : '<h2>📖 ' + esc(g.title) + '</h2><p style="font-size:13px;color:#a9b6c8">Версия ' + esc(g.version) + ' · ' + esc(g.date) + '</p>') +
      '<div class="gtoc">' + g.sections.map(function (x) { return '<button class="chip" data-m="gsec" data-s="' + x.id + '">' + esc(x.title) + '</button>'; }).join('') + '</div>' +
      g.sections.map(function (x) {
        return '<details class="guide" id="g-' + x.id + '"' + (open[x.id] ? ' open' : '') + '><summary>' + esc(x.title) + '</summary><ul>' +
          x.items.map(function (i) { return '<li>' + i + '</li>'; }).join('') + '</ul></details>';
      }).join('');
  }
  function cityHtml() {
    var f = function (n) { return Number(n).toLocaleString('ru-RU'); };
    var nb = Object.keys(batches).filter(function (k) { return batches[k].ids.length; }).length;
    return '<h2>📊 Город</h2><div class="kv">' +
      '<span>Жителей</span><span><b>' + f(sim.people) + '</b></span>' +
      '<span>Взрослых, кто может работать</span><span>' + f(sim.adults) + '</span>' +
      '<span>Работают</span><span>' + f(sim.employed) + '</span>' +
      '<span>Ищут работу</span><span>' + f(sim.unemployed) + '</span>' +
      '<span>Рабочих мест</span><span>' + f(sim.jobs) + ' (свободно ' + f(sim.freeJobs) + ')</span>' +
      '<span>Зданий</span><span>' + f(state.buildings.length) + '</span>' +
      '<span>Не работают — нет дороги</span><span>' + (noRoadCount ? '<span class="bad">' + f(noRoadCount) + '</span>' : '0') + '</span>' +
      (function () { var R = roadStats(); return '<span>Асфальт</span><span>' + f(R.asphalt) + ' кл., средний износ ' + pctText(R.avg) + '</span>' +
        '<span>Средний износ / почти изношен</span><span>' + f(R.mid) + ' / ' + (R.worn ? '<span class="bad">' + f(R.worn) + '</span>' : '0') + '</span>' +
        '<span>Простая дорога</span><span>' + f(R.dirt) + ' кл.</span>' +
        '<span>Автоматический ремонт</span><span>' + (state.autoRepair ? 'включён' : 'выключен') + '</span>' +
        '<span>Очередь завода</span><span>' + state.fql.length + '</span>' +
        '<span>Машины завода</span><span>' + f(state.vehicles.length) + '</span>' +
        '<span>Легковые машины жителей</span><span>' + f(Object.keys(carAgents).length) + '</span>'; })() + '</div>' +
      '<p style="font-size:13px;color:#a9b6c8">Расчёт жителей: ' + (window.SIM.threaded() ? 'в фоновом потоке' : 'на странице') + ', ' + sim.ms + ' мс. ' +
      'Отрисовка: Babylon.js ' + B.Engine.Version + ', ' + nb + ' ' + plural(nb, 'пачка', 'пачки', 'пачек') + ' одинаковых моделей.</p>';
  }
  function changelogHtml() {
    return G.changelog.map(function (c) { return '<p><b>' + c.v + '</b> · ' + c.date + '</p><ul>' + c.items.map(function (i) { return '<li>' + esc(i) + '</li>'; }).join('') + '</ul>'; }).join('');
  }
  function openMenu() {
    openModal('<h2>Мое_город ' + G.version + '</h2>' +
      '<button class="menu-btn" data-m="help">📖 Гайд по игре</button>' +
      '<button class="menu-btn" data-m="news">📝 Что нового</button>' +
      '<button class="menu-btn" data-m="city">📊 Город</button>' +
      VIEW_ORDER.map(function (v) { return '<button class="menu-btn' + (v === view ? ' cur' : '') + '" data-m="view" data-v="' + v + '">' + VIEWS[v].name + (v === view ? ' <span style="float:right;color:#a9b6c8">сейчас</span>' : '') + '</button>'; }).join('') +
      '<button class="menu-btn" data-m="mech">🚚 Механизмы</button>' +
      '<button class="menu-btn" data-m="size">🗺️ Размер карты <span style="float:right;color:#a9b6c8">' + N + '×' + N + '</span></button>' +
      '<button class="menu-btn" data-m="demo">🏘️ Загрузить город-пример</button>' +
      '<button class="menu-btn danger" data-m="clear">🧹 Новая пустая карта</button>' +
      '<p style="font-size:13px;color:#a9b6c8">Город сохраняется сам в этом браузере. Бригады переезжают на новую карту вместе с вами.</p>');
  }
  var pickSize = 0;
  function sizeLabel(n) { for (var i = 0; i < G.mapSizes.length; i++) if (G.mapSizes[i].n === n) return G.mapSizes[i].label; return 'Своя'; }
  function lostCount(n) { // сколько зданий и дорог не поместится при смене размера
    var o = Math.floor((n - N) / 2), lb = 0, lr = 0;
    state.buildings.forEach(function (b) { var f = foot(b.size, b.rot); if (b.x + o < 0 || b.z + o < 0 || b.x + o + f.w > n || b.z + o + f.d > n) lb++; });
    Object.keys(state.roads).forEach(function (k) { var p = k.split(','), x = +p[0] + o, z = +p[1] + o; if (x < 0 || z < 0 || x >= n || z >= n) lr++; });
    return { b: lb, r: lr };
  }
  function openSize() {
    if (!pickSize) pickSize = N;
    var h = '<h2>Размер карты</h2><p>Сейчас: <b>' + sizeLabel(N).toLowerCase() + ', ' + N + '×' + N + '</b> клеток.</p><div class="size-grid">' +
      G.mapSizes.map(function (m) {
        return '<button class="size-opt' + (m.n === pickSize ? ' on' : '') + '" data-n="' + m.n + '"><i style="width:' + Math.round(14 + m.n / 128 * 30) + 'px;height:' + Math.round(14 + m.n / 128 * 30) + 'px"></i><b>' + m.label + '</b><span>' + m.n + '×' + m.n + '</span></button>';
      }).join('') + '</div>';
    if (pickSize !== N) {
      var L = lostCount(pickSize), warn = '';
      if (L.b || L.r) warn = '<p class="warn">Не поместятся у края: ' + (L.b ? L.b + ' ' + plural(L.b, 'здание', 'здания', 'зданий') : '') + (L.b && L.r ? ' и ' : '') + (L.r ? L.r + ' ' + plural(L.r, 'клетка', 'клетки', 'клеток') + ' дороги' : '') + ' — они будут удалены.</p>';
      h += '<button class="menu-btn" data-m="resize">' + (pickSize > N ? '↔️ Расширить карту — город останется в центре' : '↘️ Уменьшить карту — город останется в центре') + '</button>' + warn +
        '<button class="menu-btn" data-m="newdemo">🏘️ Новая карта ' + pickSize + '×' + pickSize + ' с городом-примером</button>' +
        '<button class="menu-btn danger" data-m="newempty">🧹 Новая пустая карта ' + pickSize + '×' + pickSize + '</button>';
    } else h += '<p style="font-size:13px;color:#a9b6c8">Выберите другой размер, чтобы расширить или уменьшить карту.</p>';
    h += '<p style="font-size:13px;color:#a9b6c8">Огромные карты на слабых телефонах могут работать медленнее.</p>';
    openModal(h);
  }
  function resizeMap(n) {
    var o = Math.floor((n - N) / 2), nb = [], nr = {};
    state.buildings.forEach(function (b) {
      var f = foot(b.size, b.rot); b.x += o; b.z += o;
      if (b.x >= 0 && b.z >= 0 && b.x + f.w <= n && b.z + f.d <= n) nb.push(b);
    });
    Object.keys(state.roads).forEach(function (k) {
      var p = k.split(','), x = +p[0] + o, z = +p[1] + o;
      if (x >= 0 && z >= 0 && x < n && z < n) nr[key(x, z)] = state.roads[k];
    });
    state.brigades.forEach(function (br, i) {
      br.x = clamp(br.x, -n / 2, n / 2); br.z = clamp(br.z, -n / 2, n / 2 + 2);
      if (br.park) br.park = parkSpot(i, n);
    });
    var nw = {};
    function shift(k) { var p = k.split(','), x = +p[0] + o, z = +p[1] + o; return x >= 0 && z >= 0 && x < n && z < n ? key(x, z) : null; }
    Object.keys(state.wear).forEach(function (k) { var k2 = shift(k); if (k2) nw[k2] = state.wear[k]; });
    clearRollers();
    state.rq = state.rq.map(shift).filter(Boolean);
    state.buildings = nb; state.roads = nr; state.size = n; state.wear = nw;
    resCache = {}; workCache = {};
  }
  // Новая карта: бригады и потраченные доллары переезжают с игроком
  function carryUnits(s) {
    s.brigades = state.brigades.map(function (br, i) { var p = parkSpot(i, s.size); return { id: br.id, x: p.x, z: p.z, yaw: Math.PI, park: p, site: 0 }; });
    s.nextBr = state.nextBr; s.spent = state.spent;
    s.fql = state.fql.slice(); s.fprog = state.fprog; s.autoRepair = state.autoRepair; // заказы на заводе и настройка депо тоже переезжают
    s.vehicles = state.vehicles.map(function (v) { return { id: v.id, kind: v.kind }; }); s.nextVeh = state.nextVeh; // и машины завода
    return s;
  }
  function applyState(s, keepCam) {
    closeInfo(); cancelMove(); state = s; rebuildAll(); save();
    if (keepCam) updateCam(); else camHome();
    pickSize = 0; closeModal();
    hint('Карта ' + N + '×' + N + ' готова');
  }
  $('btnMenu').addEventListener('click', openMenu);
  var confirmArm = '';
  $('modalBody').addEventListener('click', function (e) {
    var b = e.target.closest('[data-m],[data-n]'); if (!b) return;
    var m = b.dataset.m;
    var sb = e.target.closest('[data-n]');
    if (sb) { pickSize = +sb.dataset.n; confirmArm = ''; openSize(); return; }
    if (m === 'help') openModal(guideHtml());
    else if (m === 'gsec') { var d = document.getElementById('g-' + b.dataset.s); if (d) { d.open = true; d.scrollIntoView({ block: 'start' }); } }
    else if (m === 'city') openModal(cityHtml());
    else if (m === 'view') { closeModal(); setView(b.dataset.v); }
    else if (m === 'mech') { closeModal(); openMech(); }
    else if (m === 'size') { pickSize = N; confirmArm = ''; openSize(); }
    else if (m === 'resize') {
      var L = lostCount(pickSize);
      if ((L.b || L.r) && confirmArm !== m) { confirmArm = m; b.textContent = 'Точно? Часть города у края пропадёт — нажмите ещё раз'; return; }
      confirmArm = ''; resizeMap(pickSize); applyState(state, false);
    }
    else if (m === 'newdemo' || m === 'newempty') {
      if (confirmArm !== m) { confirmArm = m; b.textContent = 'Точно? Текущий город пропадёт — нажмите ещё раз'; return; }
      confirmArm = ''; applyState(carryUnits(m === 'newdemo' ? demoState(pickSize) : emptyState(pickSize)), false);
    }
    else if (m === 'news') openModal('<h2>Что нового</h2>' + changelogHtml());
    else if (m === 'demo' || m === 'clear') {
      if (confirmArm !== m) { confirmArm = m; b.textContent = 'Точно? Текущий город пропадёт — нажмите ещё раз'; return; }
      confirmArm = ''; applyState(carryUnits(m === 'demo' ? demoState(N) : emptyState(N)), true);
    }
  });

  // ---------- Цикл отрисовки ----------
  // Кадр рисуется только когда что-то изменилось — телефон не греется на пустом месте.
  // ---------- Метка «нет дороги» над зданием (красный шар с белой полосой) ----------
  function pinModel(K) {
    var S = Shapes(K, 0, 0), sc = K.scene;
    function glow(name, c, e) { var m = new B.StandardMaterial(name, sc); m.diffuseColor = hex(c); m.emissiveColor = hex(e); m.specularColor = B.Color3.Black(); return m; }
    var red = glow('pinRed', '#e8352b', '#8a1810'), white = glow('pinWhite', '#ffffff', '#9a9a9a');
    var cone = B.MeshBuilder.CreateCylinder('pc', { diameterTop: 0.2, diameterBottom: 0, height: 0.26, tessellation: 16 }, sc);
    cone.position.set(0, 0.13, 0); cone.material = red; S.parts.push(cone);
    var ball = B.MeshBuilder.CreateSphere('ps', { diameter: 0.34, segments: 12 }, sc);
    ball.position.set(0, 0.4, 0); ball.material = red; S.parts.push(ball);
    var band = B.MeshBuilder.CreateCylinder('pb', { diameter: 0.352, height: 0.075, tessellation: 24 }, sc);
    band.position.set(0, 0.4, 0); band.material = white; S.parts.push(band);
    return S.merge();
  }
  function pinBatch() { return getBatch('noroad', function () { return pinModel(kit); }); }
  function pinFor(b) {
    var pb = pinBatch(), bt = placed[b.id];
    var show = bt && !isSite(b) && !hasRoad(b) && !(moving && moving.b.id === b.id);
    if (!show) { batchRemove(pb, b.id); dirty(); return; }
    var p = bPos(b);
    batchSet(pb, b.id, p.x, bt.h + 0.2, p.z, 0, 1.6, 1.6, 1.6);
    dirty();
  }

  var needRender = true, lastT = performance.now(), lastSave = 0, lastUi = 0, frames = 0;
  function dirty() { needRender = true; }
  function loop() {
    var t = performance.now(), dt = Math.min(0.05, (t - lastT) / 1000); lastT = t;
    keyPan(dt); tickCam(dt);
    var active = tickBrigades(dt, t);
    tickFactory(dt); tickWear(dt); tickTraffic(dt);
    var fixingNow = tickRepair(dt, t);
    if ((active || fixingNow) && t - lastSave > 2000) { saveNow(); lastSave = t; }
    if (t - lastUi > 400) {
      lastUi = t;
      if (infoId) { var ib = getB(infoId); if (ib && isSite(ib)) renderInfo(ib, true); }
      renderMech(); refreshLive();
    }
    flushRoads(); flushBatches();
    if (needRender) {
      needRender = false;
      scene.render();
      frames++;
      if (ssaoHold) { releaseSSAO(); needRender = true; }
      if (!scene.isReady()) needRender = true; // шейдеры ещё собираются — дорисуем следующим кадром
    }
  }
  window.addEventListener('pagehide', saveNow);

  // ---------- Старт ----------
  state = load() || demoState(G.mapSize);
  $('ver').textContent = G.version;
  setView(view);
  renderChips(); rebuildAll(); setTool('view');
  camHome();
  engine.runRenderLoop(loop);
  scene.executeWhenReady(function () { $('loading').classList.add('done'); dirty(); });
  setTimeout(function () { $('loading').classList.add('done'); }, 5000);
  try {
    var seen = localStorage.getItem(SEEN_KEY);
    if (seen !== G.version) {
      openModal(seen ? '<h2>Что нового в ' + G.version + '</h2>' + changelogHtml() : '<h2>Добро пожаловать в «Мое_город»!</h2><p>Купите бригаду в 🚚 «Механизмы», проложите дорогу и стройте вдоль неё дома и службы. Здание без дороги не работает! Нажмите на любое здание, чтобы узнать, кто там живёт.</p>' + guideHtml(true));
      localStorage.setItem(SEEN_KEY, G.version);
    }
  } catch (e) {}
  window.__gorod = {
    state: function () { return state; }, size: function () { return N; }, cam: cam, setTool: setTool, openInfo: function (id) { openInfo(getB(id)); }, updateCam: updateCam,
    road: function (x, z, t) { setRoad(x, z, t); }, stats: updateStats,
    scene: scene, buy: buyBrigade, siteAt: function (id, p) { var b = getB(id); b.prog = p; writeBuilding(b); updateSite(b, 0.016); }, openMech: openMech, setView: setView, sim: function () { return sim; }, frames: function () { return frames; },
    batches: function () { return Object.keys(batches).map(function (k) { return k + ':' + batches[k].ids.length; }); },
    wearAll: function (w) { for (var k in state.roads) if (state.roads[k] === 'asphalt') { state.wear[k] = typeof w === 'function' ? w(k) : w; markRoadKey(k); } dirty(); },
    finishAll: function () { state.buildings.forEach(function (b) { if (isSite(b)) { b.prog = 1; finishSite(b); } }); },
    canPlace: canPlace, agents: function () { return { veh: agents, cars: carAgents, driving: carsDriving }; }, orderKind: orderKind, rollers: function () { return rollers; }, roadInfo: openRoadInfo, startPlace: startPlace, order: orderTruck, repairAll: repairAllAct, toggleAuto: toggleAuto,
    place: function (cat, size, x, z) { buildCat = cat; buildSize = size; buildRot = 0; placeBuilding({ px: x + G.sizes[size].w / 2, pz: z + G.sizes[size].d / 2 }); },
    bulk: function (n) { // тест: мгновенно застроить карту n зданиями
      var cats = Object.keys(G.cats), sz = ['1x1', '2x1', '2x2'], made = 0;
      for (var tries = 0; tries < n * 20 && made < n; tries++) {
        var cat = cats[made % cats.length], s = sz[made % 3], f = foot(s, 0), x = Math.floor(Math.random() * (N - f.w)), z = Math.floor(Math.random() * (N - f.d));
        if (!canPlace(s, 0, x, z, 0)) continue;
        var b = { id: state.nextId++, cat: cat, size: s, x: x, z: z, rot: 0, seed: newSeed() };
        state.buildings.push(b); markOcc(b, b.id); addBuildingMesh(b); made++;
      }
      updateStats(); save(); return made;
    }
  };
})();
