// «Мое_город» — программа для Windows (с 1.6.0): раздел меню «💻 Программа», окошко обновления, скачивание музыки, дописывание мира при закрытии.
// В браузере (window.MoeDesktop нет) этот файл ничего не делает. Сама оболочка (окно, файлы сохранений, обновления) — папка gorod-pc/.
(function () {
  'use strict';
  var D = window.MoeDesktop;
  if (!D) { window.MoeDesktopUI = null; return; }

  var api = null;                       // его отдаёт game.js при старте: view(html, sub), hint(текст, тревога), saveNow(), flush(), version
  var upd = null, mus = null, musP = null, dismissed = false, cloudTxt = '';
  var NOCLOUD = '☁️ Войдите в аккаунт («👤 Аккаунт»), и миры появятся ещё и в облаке — на другом компьютере они откроются так же.';
  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function mb(b) { b = +b || 0; return (b >= 1e8 ? Math.round(b / 1048576) : (b / 1048576).toFixed(1)).toString().replace('.', ',') + ' МБ'; }
  function hhmm(t) { return t ? new Date(t).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) : ''; }
  function files() { return (window.MoeAudio && window.MoeAudio.tracks ? window.MoeAudio.tracks : []).map(function (t) { return t.f; }); }

  // ---------- стили ----------
  var css = document.createElement('style');
  css.textContent =
    '.dk-box{background:rgba(255,255,255,.07);border-radius:12px;padding:12px 14px;margin:0 0 10px;font-size:14px;line-height:1.45}' +
    '.dk-box h3{margin:0 0 6px;font-size:15px}.dk-box p{margin:4px 0}.dk-box small,.dk-sub{color:#a9b6c8;font-size:12.5px}' +
    '.dk-path{display:block;word-break:break-all;background:rgba(0,0,0,.25);border-radius:8px;padding:6px 8px;margin:6px 0;font-size:12.5px;color:#dfe8f5}' +
    '.dk-btn{display:inline-block;border:0;border-radius:10px;padding:9px 13px;margin:6px 6px 0 0;background:rgba(255,255,255,.12);color:inherit;font:inherit;font-size:14px;cursor:pointer}' +
    '.dk-btn:hover{background:rgba(255,255,255,.2)}.dk-btn.acc{background:#f4c542;color:#2a2205;font-weight:600}.dk-btn.acc:hover{background:#ffd467}' +
    '.dk-bar{height:8px;border-radius:5px;background:rgba(255,255,255,.14);overflow:hidden;margin:8px 0 2px}.dk-bar i{display:block;height:100%;background:#8cc068;width:0;transition:width .3s}' +
    '.dk-notes{margin:6px 0 2px;padding-left:18px;font-size:13px;color:#d3deee}.dk-notes li{margin:2px 0}' +
    '.dk-ok{color:#9be28f}.dk-bad{color:#ffb4a8}.dk-chk{display:flex;gap:8px;align-items:flex-start;margin-top:8px;font-size:13.5px;cursor:pointer}' +
    '.dk-banner{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:30;max-width:min(560px,calc(100% - 24px));background:#2b4468;color:#fff;border-radius:14px;padding:12px 16px;' +
    'box-shadow:0 10px 34px rgba(0,0,0,.45);font-size:14px;line-height:1.4}.dk-banner b{display:block;margin-bottom:2px}' +
    '.dk-banner .dk-btn{margin:8px 8px 0 0}.dk-banner[hidden]{display:none}';
  document.head.appendChild(css);

  // ---------- окошко обновления (внизу экрана) ----------
  var banner = document.createElement('div');
  banner.className = 'dk-banner'; banner.hidden = true;
  function renderBanner() {
    var u = upd; if (!u || dismissed) { banner.hidden = true; return; }
    var h = '';
    if (u.status === 'ready') {
      h = '<b>⬆️ Готова новая версия ' + esc(u.latest) + '</b>' + (u.kind === 'setup' ? 'Программа сама поставит обновление и откроется заново.' : 'Игра перезапустится, миры сохранятся.') +
        '<br><button class="dk-btn acc" data-dk="install">Обновить сейчас</button><button class="dk-btn" data-dk="later">Позже</button>';
    } else if (u.status === 'available' && u.kind === 'setup') {
      h = '<b>⬆️ Вышла версия ' + esc(u.latest) + '</b>Обновляется сама программа (≈' + mb(u.size) + '). Миры не пострадают.' +
        '<br><button class="dk-btn acc" data-dk="fetch">Скачать и обновить</button><button class="dk-btn" data-dk="later">Позже</button>';
    } else if (u.status === 'available' && u.kind === 'game') {
      h = '<b>⬆️ Вышла версия ' + esc(u.latest) + '</b>Обновление небольшое (≈' + mb(u.size) + ').<br><button class="dk-btn acc" data-dk="fetch">Скачать</button><button class="dk-btn" data-dk="later">Позже</button>';
    } else if (u.status === 'downloading') {
      h = '<b>⬇️ Скачиваем версию ' + esc(u.latest) + ': ' + Math.round((u.progress || 0) * 100) + '%</b><div class="dk-bar"><i style="width:' + Math.round((u.progress || 0) * 100) + '%"></i></div>';
    } else { banner.hidden = true; return; }
    banner.innerHTML = h; banner.hidden = false;
  }
  document.body.appendChild(banner);
  banner.addEventListener('click', function (e) { var b = e.target.closest('[data-dk]'); if (b) act(b.getAttribute('data-dk')); });

  // ---------- раздел меню «💻 Программа» ----------
  function updBlock() {
    var u = upd || { status: 'idle' }, h = '';
    if (u.status === 'checking') h = '<p>⏳ Проверяем, есть ли новая версия…</p>';
    else if (u.status === 'uptodate' || u.status === 'idle') h = '<p class="dk-ok">✅ У вас последняя версия.</p>' + (u.checkedAt ? '<small>Проверено в ' + hhmm(u.checkedAt) + '</small>' : '<small>Программа проверяет сама при запуске и каждые 6 часов.</small>') +
      '<br><button class="dk-btn" data-dk="check">🔄 Проверить сейчас</button>';
    else if (u.status === 'available') {
      h = '<p><b>Вышла версия ' + esc(u.latest) + '</b>' + (u.date ? ' · ' + esc(u.date) : '') + '</p>' + notes(u) +
        '<small>' + (u.kind === 'setup' ? 'Обновляется сама программа, размер ≈' + mb(u.size) + '.' : 'Небольшое обновление игры, ≈' + mb(u.size) + '.') + '</small><br>' +
        '<button class="dk-btn acc" data-dk="fetch">' + (u.kind === 'setup' ? 'Скачать и обновить' : 'Скачать') + '</button>';
    } else if (u.status === 'downloading') {
      h = '<p>⬇️ Скачиваем версию ' + esc(u.latest) + ': <b>' + Math.round((u.progress || 0) * 100) + '%</b></p><div class="dk-bar"><i style="width:' + Math.round((u.progress || 0) * 100) + '%"></i></div>';
    } else if (u.status === 'ready') {
      h = '<p class="dk-ok"><b>✅ Версия ' + esc(u.latest) + ' скачана.</b></p>' + notes(u) + '<small>Игра перезапустится, миры сохранятся.</small><br><button class="dk-btn acc" data-dk="install">Перезапустить и обновить</button>';
    } else if (u.status === 'error') {
      h = '<p class="dk-bad">⚠️ ' + esc(u.error || 'Не получилось') + '</p><button class="dk-btn" data-dk="check">🔄 Повторить</button>';
    }
    return h + '<label class="dk-chk"><input type="checkbox" data-dk="auto"' + (!upd || upd.auto !== false ? ' checked' : '') + '> <span>Сами скачивать небольшие обновления игры (установить можно, когда удобно)</span></label>';
  }
  function notes(u) { return u.notes && u.notes.length ? '<ul class="dk-notes">' + u.notes.slice(0, 5).map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ul>' : ''; }
  function musBlock() {
    var p = musP, m = mus, h = '';
    if (p && p.state === 'running') {
      var pc = p.total ? Math.round(p.done / p.total * 100) : 0;
      h = '<p>⬇️ Скачано ' + p.done + ' из ' + p.total + ' · ' + mb(p.bytes) + '</p><div class="dk-bar"><i style="width:' + pc + '%"></i></div><button class="dk-btn" data-dk="mstop">Остановить</button>';
    } else {
      if (m) h += '<p>На компьютере: <b>' + m.have + ' из ' + m.total + '</b> · ' + mb(m.bytes) + '</p>';
      if (p && p.state === 'error') h += '<p class="dk-bad">Часть треков не скачалась (' + p.failed + '). Нажмите ещё раз — докачается недостающее.</p>';
      if (p && p.state === 'done') h += '<p class="dk-ok">✅ Вся музыка на компьютере.</p>';
      h += m && m.have >= m.total && m.total ? '<small>Музыка играет без интернета.</small>' :
        '<small>Пока трек не скачан, он играет с сайта (нужен интернет).</small><br><button class="dk-btn acc" data-dk="mdl">⬇️ Скачать всю музыку (≈515 МБ)</button>';
    }
    return h;
  }
  function body() {
    var P = D.paths || {};
    return '<div class="dk-box"><h3>Мое_город ' + esc(D.gameVersion) + '</h3><small>программа ' + esc(D.shellVersion) + ' · Windows' + (D.gameKind === 'update' ? ' · игра из обновления' : '') + '</small></div>' +
      '<div class="dk-box"><h3>⬆️ Обновления</h3>' + updBlock() + '</div>' +
      '<div class="dk-box"><h3>💾 Сохранения</h3><p>Миры сохраняются сами — в обычных файлах на этом компьютере:</p><span class="dk-path">' + esc(P.saves) + '</span>' +
      '<small>Папку можно копировать как резервную копию. Удалённые миры 14 дней лежат в папке «_Удалённые».</small><br>' +
      '<button class="dk-btn" data-dk="open-saves">📂 Открыть папку</button>' +
      '<p id="dk-cloud" style="margin-top:8px">' + (cloudTxt || NOCLOUD) + '</p></div>' +
      '<div class="dk-box"><h3>🎵 Музыка</h3><div id="dk-mus">' + musBlock() + '</div></div>' +
      '<div class="dk-box"><h3>🖥️ Окно и помощь</h3><button class="dk-btn" data-dk="full">⛶ Во весь экран · F11</button><button class="dk-btn" data-dk="open-logs">📄 Журнал программы</button>' +
      '<br><small>Если что-то работает не так — пришлите файл main.log из этой папки.</small></div>';
  }
  function show() {
    if (!api) return;
    api.view('<h2>💻 Программа</h2><div id="dk-root">' + body() + '</div>', true);
    refreshMus(); refreshCloud();
  }
  function rerender() { var r = $('dk-root'); if (r) r.innerHTML = body(); renderBanner(); }
  function refreshMus() { D.music.stat(files()).then(function (s) { mus = s; var e = $('dk-mus'); if (e) e.innerHTML = musBlock(); }).catch(function () {}); }
  function refreshCloud() {
    try {
      var c = window.WORLD && WORLD.cloud ? WORLD.cloud.status() : null;
      if (c && c.user) cloudTxt = '☁️ Облако: вы вошли как ' + esc(c.user.email) + (c.text ? ' · ' + esc(c.text) : '');
      else cloudTxt = '';
    } catch (e) { cloudTxt = ''; }
    var el = $('dk-cloud'); if (el) el.innerHTML = cloudTxt || NOCLOUD;
  }

  function act(a) {
    if (a === 'check') D.update.check().then(function (s) { upd = s; rerender(); });
    else if (a === 'fetch') D.update.fetch().then(function (s) { upd = s; rerender(); });
    else if (a === 'install') {
      if (api) { try { api.saveNow(); } catch (e) {} }
      D.update.install();
    }
    else if (a === 'later') { dismissed = true; renderBanner(); }
    else if (a === 'open-saves') D.open('saves');
    else if (a === 'open-logs') D.open('logs');
    else if (a === 'full') D.fullscreen();
    else if (a === 'mdl') { musP = { state: 'running', done: (mus && mus.have) || 0, total: files().length, bytes: 0, failed: 0 }; rerender(); D.music.download(files()); }
    else if (a === 'mstop') D.music.cancel();
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('#dk-root [data-dk]'); if (!b || b.tagName === 'INPUT') return;
    act(b.getAttribute('data-dk'));
  });
  document.addEventListener('change', function (e) {
    var t = e.target; if (t && t.getAttribute && t.getAttribute('data-dk') === 'auto') D.update.setAuto(t.checked).then(function (v) { if (upd) upd.auto = v; });
  });

  // ---------- связь с программой ----------
  D.update.onState(function (s) { var was = upd && upd.status; upd = s; if (s.status !== 'ready' && s.status !== 'available') dismissed = dismissed && s.status === 'downloading'; rerender(); if (was !== s.status && (s.status === 'ready') && api) api.hint('⬆️ Готова версия ' + s.latest + ' — «💻 Программа» → «Перезапустить и обновить»'); });
  D.music.onProgress(function (p) { musP = p; if (p.state !== 'running') refreshMus(); var e = $('dk-mus'); if (e) e.innerHTML = musBlock(); });
  D.update.state().then(function (s) { upd = s; rerender(); }).catch(function () {});
  // Программа закрывается или перезапускается: дописываем мир на диск и отправляем в облако (не дольше 4 секунд)
  D.onBeforeQuit(function () {
    return new Promise(function (resolve) {
      var t = setTimeout(resolve, 4000);
      try { if (api) api.saveNow(); } catch (e) {}
      Promise.resolve(api ? api.flush() : null).catch(function () {}).then(function () { clearTimeout(t); resolve(); });
    });
  });
  // ошибки страницы — в журнал программы (его можно прислать)
  window.addEventListener('error', function (e) { try { D.log('error', (e.message || 'ошибка') + ' @ ' + String(e.filename || '').split('/').pop() + ':' + e.lineno); } catch (x) {} });
  window.addEventListener('unhandledrejection', function (e) { try { D.log('error', 'promise: ' + ((e.reason && (e.reason.stack || e.reason.message)) || e.reason)); } catch (x) {} });

  window.MoeDesktopUI = {
    attach: function (a) { api = a; renderBanner(); },
    menuButton: function () {
      var sub = upd && upd.status === 'ready' ? '⬆️ есть обновление ' + upd.latest : 'версия ' + D.gameVersion + ' · обновления, сохранения, музыка';
      return '<button class="menu-btn" data-m="desk">💻 Программа<span class="mb-sub">' + esc(sub) + '</span></button>';
    },
    show: show,
    refresh: function () { if ($('dk-root')) { refreshCloud(); } }
  };
})();
