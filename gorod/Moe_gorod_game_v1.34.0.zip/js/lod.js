/* Модели для дальнего вида (с 1.24.0). Камера ортографическая, поэтому «далеко» — это мелкий масштаб:
   уровень 0 (вблизи) — полные модели, 1 — упрощённые, 2 (самый дальний вид) — совсем лёгкие.
   Лёгкие сетки считаются из полных прямо в игре (meshoptimizer), отдельных файлов с моделями нет. */
(function () {
  'use strict';
  var NEAR = 80, FAR = 24;      // пикселей экрана на клетку карты
  var MIN_TRIS = 8000;          // сетки легче этого не упрощаются (в том числе деревья облегчённого леса)
  var LEVEL = [null, { ratio: 0.12, error: 0.02 }, { ratio: 0.025, error: 0.09 }];
  // Ратуша, цех, фонтан и парк крупные и их немного — упрощаются бережнее
  var DECOR = [null, { ratio: 0.3, error: 0.006 }, { ratio: 0.14, error: 0.015 }];
  var ready = false, S = window.MeshoptSimplifier;
  var supported = !!(S && S.supported && window.WebAssembly);

  // Уровень по масштабу; запас 8 %, чтобы модели не мигали на границе
  function levelFor(ppc, prev) {
    var near = prev === 0 ? NEAR * 0.92 : NEAR * 1.08, far = prev === 2 ? FAR * 1.08 : FAR * 0.92;
    return ppc >= near ? 0 : ppc < far ? 2 : 1;
  }

  // Упростить один кусок сетки (subMesh): вернуть новые индексы
  // gentle — часть дома без фактуры (лепнина, фонари, кусты): ошибка меньше пикселя на этом масштабе
  function simplify(ind, pos, attr, stride, weights, lv, gentle, decor) {
    if (gentle) {
      if (ind.length <= 900) return ind;
      var res0 = S.simplifyWithAttributes(ind, pos, 3, attr, stride, weights, null, Math.floor(ind.length * (lv === 2 ? 0.08 : 0.3) / 3) * 3, lv === 2 ? 0.012 : 0.004, ['Prune'])[0];
      return res0.length >= 12 ? res0 : ind;
    }
    var cfg = (decor ? DECOR : LEVEL)[lv], target = Math.max(36, Math.floor(ind.length * cfg.ratio / 3) * 3);
    if (ind.length <= 900) return ind;   // мелкие части (стены-коробки) не трогаем
    var res = stride ? S.simplifyWithAttributes(ind, pos, 3, attr, stride, weights, null, target, cfg.error, ['Prune'])[0]
      : S.simplify(ind, pos, 3, target, cfg.error, ['Prune'])[0];
    // листва и мелкие детали не склеиваются обычным способом — для дальнего вида огрубляем сильнее
    if (!decor && res.length > target * 2.5) {
      var rough = S.simplifySloppy(res, pos, 3, null, lv === 2 ? target : target * 2, lv === 2 ? 0.2 : 0.04)[0];
      if (rough.length >= 36 && rough.length < res.length) res = rough;
    }
    return res.length >= 12 ? res : ind;
  }

  // Новая лёгкая сетка из полной (материалы и расцветка те же). null — упрощать незачем.
  function make(B, src, lv) {
    if (!ready) return null;
    var ind = src.getIndices(), pos = src.getVerticesData('position');
    if (!ind || !pos || ind.length / 3 < MIN_TRIS) return null;
    var nor = src.getVerticesData('normal'), uv = src.getVerticesData('uv'), col = src.getVerticesData('color');
    var n = pos.length / 3, fpos = new Float32Array(pos), parts = [[nor, 3, 0.5], [col, 4, 1.0], [uv, 2, 0.5]].filter(function (p) { return p[0] && p[0].length === n * p[1]; });
    var stride = 0, weights = [], i, j;
    parts.forEach(function (p) { stride += p[1]; for (j = 0; j < p[1]; j++) weights.push(p[2]); });
    var attr = new Float32Array(n * stride), o = 0;
    parts.forEach(function (p) { for (i = 0; i < n; i++) for (j = 0; j < p[1]; j++) attr[i * stride + o + j] = p[0][i * p[1] + j]; o += p[1]; });
    var multi = src.material && src.material.subMaterials;
    var subs = multi ? src.subMeshes.map(function (s) { return { start: s.indexStart, count: s.indexCount, mat: s.materialIndex }; }) : [{ start: 0, count: ind.length, mat: 0 }];
    var mats = multi ? src.material.subMaterials : [src.material];
    function textured(m) { return !!(m && (m.diffuseTexture || m.albedoTexture)); }
    var building = mats.some(textured);   // у машин, деревьев и памятников фактур нет — только цвета вершин
    var out = [], ranges = [], map = new Int32Array(n).fill(-1), used = [];
    subs.forEach(function (s) {
      var part = new Uint32Array(s.count);
      for (var k = 0; k < s.count; k++) part[k] = ind[s.start + k];
      var res = building && textured(mats[s.mat]) ? part : simplify(part, fpos, attr, stride, weights, lv, building, /^decor_/.test(src.name)), first = out.length;
      for (k = 0; k < res.length; k++) { var v = res[k]; if (map[v] < 0) { map[v] = used.length; used.push(v); } out.push(map[v]); }
      ranges.push({ start: first, count: res.length, mat: s.mat });
    });
    if (out.length > ind.length * 0.8) return null;
    function pick(a, size) { var r = new Float32Array(used.length * size); for (var k = 0; k < used.length; k++) for (var c = 0; c < size; c++) r[k * size + c] = a[used[k] * size + c]; return r; }
    var mesh = new B.Mesh(src.name + '_lod' + lv, src.getScene()), vd = new B.VertexData();
    vd.positions = pick(fpos, 3); vd.indices = out;
    if (nor) vd.normals = pick(nor, 3);
    if (uv && uv.length === n * 2) vd.uvs = pick(uv, 2);
    if (col && col.length === n * 4) vd.colors = pick(col, 4);
    vd.applyToMesh(mesh);
    mesh.material = src.material;
    if (multi) {
      mesh.subMeshes = [];
      ranges.forEach(function (r) { if (r.count) new B.SubMesh(r.mat, 0, used.length, r.start, r.count, mesh); });
    }
    mesh.refreshBoundingInfo();
    return mesh;
  }

  window.LOD = { levelFor: levelFor, make: make, MIN_TRIS: MIN_TRIS, isReady: function () { return ready; },
    ready: supported ? S.ready.then(function () { ready = true; }, function () {}) : Promise.resolve() };
})();
