'use strict';
function parse(v) { var m = /^(\d+)\.(\d+)\.(\d+)/.exec(String(v || '')); return m ? [+m[1], +m[2], +m[3]] : [0, 0, 0]; }
// -1 если a < b, 0 если равны, 1 если a > b
function cmp(a, b) {
  var x = parse(a), y = parse(b);
  for (var i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
  return 0;
}
module.exports = { parse: parse, cmp: cmp };
