'use strict';
// Мост между игрой (страницей) и программой: игра видит только window.MoeDesktop и ничего больше.
const { contextBridge, ipcRenderer } = require('electron');

const inv = function (ch) { const a = Array.prototype.slice.call(arguments, 1); return ipcRenderer.invoke.apply(ipcRenderer, [ch].concat(a)); };
const info = ipcRenderer.sendSync('app:info');

const quitHandlers = [];
ipcRenderer.on('app:before-quit', function () {
  // программа закрывается: даём игре дописать мир и отправить его в облако (не дольше нескольких секунд)
  Promise.all(quitHandlers.map(function (h) { try { return Promise.resolve(h()); } catch (e) { return null; } }))
    .catch(function () {}).then(function () { ipcRenderer.send('app:quit-ready'); });
});

contextBridge.exposeInMainWorld('MoeDesktop', {
  isDesktop: true,
  platform: info.platform,
  shellVersion: info.shellVersion,
  gameVersion: info.gameVersion,
  gameKind: info.gameKind,
  paths: info.paths,
  fs: {
    get: function (s, k) { return inv('fs:get', s, k); },
    put: function (s, k, v) { return inv('fs:put', s, k, v); },
    del: function (s, k) { return inv('fs:del', s, k); },
    all: function (s) { return inv('fs:all', s); },
    keys: function (s, p) { return inv('fs:keys', s, p); },
    trashWorld: function (id) { return inv('fs:trash', id); }
  },
  open: function (what) { return inv('app:open', what); },
  update: {
    state: function () { return inv('upd:state'); },
    check: function () { return inv('upd:check'); },
    fetch: function () { return inv('upd:fetch'); },
    install: function () { return inv('upd:install'); },
    setAuto: function (on) { return inv('upd:auto', !!on); },
    onState: function (cb) { ipcRenderer.on('upd:state', function (_e, s) { cb(s); }); }
  },
  music: {
    stat: function (files) { return inv('mus:stat', files); },
    download: function (files) { return inv('mus:dl', files); },
    cancel: function () { return inv('mus:cancel'); },
    onProgress: function (cb) { ipcRenderer.on('mus:progress', function (_e, p) { cb(p); }); }
  },
  fullscreen: function () { return inv('win:fs'); },
  onBeforeQuit: function (cb) { quitHandlers.push(cb); },
  log: function (level, msg) { ipcRenderer.send('app:log', String(level), String(msg).slice(0, 2000)); }
});
