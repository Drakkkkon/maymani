'use strict';
// Настройки оболочки «Мое_город» для Windows.
module.exports = {
  // Версия оболочки (окно, сохранения, обновления, установщик). Растёт редко — только когда меняется эта папка (src/, build/).
  // Версия самой игры — в ../gorod/js/data.js (GAME.version) и в game/version.json.
  SHELL_VERSION: '1.0.0',
  APP_ID: 'com.drakkkkon.moegorod',
  // Описание последней версии: номер, заметки, ссылки на файлы обновления (как у «Мое_граббер» и «Мое_лимиты»).
  MANIFEST_URL: process.env.MOE_MANIFEST_URL || 'https://drakkkkon.github.io/maymani/updates/gorod.json',
  // Музыка лежит на сайте (515 МБ), в установщик не входит: играет из интернета, а «Скачать всю музыку» кладёт её на компьютер.
  MUSIC_BASE: process.env.MOE_MUSIC_BASE || 'https://drakkkkon.github.io/maymani/gorod/music/',
  PORT: 47318,
  CHECK_FIRST_MS: 15 * 1000,
  CHECK_EVERY_MS: 6 * 3600 * 1000
};
