'use strict';
// Сохранения миров в обычных файлах на компьютере (вместо IndexedDB браузера).
//
//   <папка сохранений>/
//     <мир>/world.json            — сведения о мире (название, размер, камера, бригады, деньги…)
//     <мир>/Название мира.txt     — только для людей: чтобы в проводнике было понятно, какой мир в какой папке
//     <мир>/chunks/<cx>_<cz>.json — куски карты 100×100 клеток (здания, дороги, износ)
//     _sync.json                  — что ещё не отправлено в облако
//     _Удалённые/                 — удалённые миры лежат здесь 14 дней, потом стираются
//
// Запись всегда «через временный файл и переименование»: при выключении света файл не остаётся наполовину записанным.
const fs = require('fs'), fsp = fs.promises, path = require('path');
const log = require('./log');

const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const CK_RE = /^([A-Za-z0-9_-]{1,64})\|(-?\d{1,6}),(-?\d{1,6})$/;
const TRASH = '_Удалённые';
const TRASH_DAYS = 14;
const BAK_EVERY_MS = 5 * 60 * 1000;

function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

function create(root) {
  fs.mkdirSync(root, { recursive: true });
  const chains = new Map();          // путь файла → конец очереди записей (запись в один файл идёт по порядку)
  const lastBak = new Map();         // мир → когда в последний раз делали копию world.json.bak
  const names = new Map();           // мир → название, записанное в «Название мира.txt»
  let pending = 0; const idleWaiters = [];
  let dirty = {}, dirtyTimer = null, dirtyLoaded = false;

  function track(p) {
    pending++;
    return p.then(function (v) { done(); return v; }, function (e) { done(); throw e; });
  }
  function done() { pending--; if (!pending) idleWaiters.splice(0).forEach(function (f) { f(); }); }
  function serial(key, fn) {
    const prev = chains.get(key) || Promise.resolve();
    const next = prev.catch(function () {}).then(fn);
    chains.set(key, next);
    next.then(function () { if (chains.get(key) === next) chains.delete(key); }, function () { if (chains.get(key) === next) chains.delete(key); });
    return track(next);
  }
  function flush() {
    if (dirtyTimer) { clearTimeout(dirtyTimer); dirtyTimer = null; saveDirtyNow(); }
    return pending ? new Promise(function (r) { idleWaiters.push(r); }) : Promise.resolve();
  }

  async function writeAtomic(file, text) {
    const tmp = file + '.tmp';
    await fsp.mkdir(path.dirname(file), { recursive: true });
    await fsp.writeFile(tmp, text);
    for (let i = 0; ; i++) {
      try { await fsp.rename(tmp, file); return; }
      catch (e) { if (i >= 6 || !/^(EPERM|EBUSY|EACCES)$/.test(e.code)) throw e; await sleep(60 * (i + 1)); }   // антивирус на секунду занял файл
    }
  }
  async function readJson(file) {
    let txt;
    try { txt = await fsp.readFile(file, 'utf8'); } catch (e) { if (e.code === 'ENOENT') return undefined; throw e; }
    return JSON.parse(txt);
  }

  const worldDir = function (id) { return path.join(root, id); };
  const worldFile = function (id) { return path.join(root, id, 'world.json'); };
  const chunkFile = function (id, cx, cz) { return path.join(root, id, 'chunks', cx + '_' + cz + '.json'); };

  async function readWorld(id) {
    const f = worldFile(id);
    try { return await readJson(f); }
    catch (e) {
      log.error('world.json повреждён (' + id + '): ' + e.message + ' — пробую копию .bak');
      try { return await readJson(f + '.bak'); } catch (e2) { log.error('копия .bak тоже не открылась (' + id + ')'); return undefined; }
    }
  }
  async function readChunk(id, cx, cz) {
    const f = chunkFile(id, cx, cz);
    try { return await readJson(f); }
    catch (e) {
      log.error('кусок повреждён ' + id + ' ' + cx + ',' + cz + ': ' + e.message);
      try { await fsp.rename(f, f + '.corrupt-' + Date.now()); } catch (e2) {}
      return undefined;
    }
  }

  // ---- сведения о том, что не ушло в облако (одна маленькая запись в _sync.json) ----
  async function loadDirty() {
    if (dirtyLoaded) return;
    dirtyLoaded = true;
    try { const j = await readJson(path.join(root, '_sync.json')); if (j && typeof j === 'object') dirty = j; } catch (e) { log.warn('_sync.json не прочитался: ' + e.message); dirty = {}; }
  }
  function saveDirtyNow() { serial('_sync', function () { return writeAtomic(path.join(root, '_sync.json'), JSON.stringify(dirty)); }).catch(function (e) { log.error('_sync.json: ' + e.message); }); }
  function saveDirtySoon() { if (dirtyTimer) return; dirtyTimer = setTimeout(function () { dirtyTimer = null; saveDirtyNow(); }, 400); }

  // ---- те же операции, что у IndexedDB в js/world.js: get / put / del / all / keys ----
  async function get(store, key) {
    if (store === 'dirty') { await loadDirty(); return dirty[key]; }
    if (store === 'worlds') { if (!ID_RE.test(key)) return undefined; return readWorld(key); }
    if (store === 'chunks') { const m = CK_RE.exec(key); if (!m) return undefined; return readChunk(m[1], +m[2], +m[3]); }
    throw new Error('store?');
  }
  async function put(store, key, value) {
    if (store === 'dirty') { await loadDirty(); dirty[key] = value; saveDirtySoon(); return; }
    if (store === 'worlds') {
      const id = (value && value.id) || key;
      if (!ID_RE.test(id)) throw new Error('имя мира');
      const f = worldFile(id), text = JSON.stringify(value);
      return serial(f, async function () {
        const now = Date.now();
        if (now - (lastBak.get(id) || 0) > BAK_EVERY_MS) {      // раз в пять минут кладём рядом копию предыдущей версии
          lastBak.set(id, now);
          try { await fsp.copyFile(f, f + '.bak'); } catch (e) {}
        }
        await writeAtomic(f, text);
        const nm = String((value && value.name) || '');
        if (nm && names.get(id) !== nm) {
          names.set(id, nm);
          try { await fsp.writeFile(path.join(worldDir(id), 'Название мира.txt'), nm + '\r\n'); } catch (e) {}
        }
      });
    }
    if (store === 'chunks') {
      const m = CK_RE.exec(key); if (!m) throw new Error('имя куска');
      const f = chunkFile(m[1], +m[2], +m[3]);
      return serial(f, function () { return writeAtomic(f, JSON.stringify(value)); });
    }
    throw new Error('store?');
  }
  async function del(store, key) {
    if (store === 'dirty') { await loadDirty(); delete dirty[key]; saveDirtySoon(); return; }
    if (store === 'worlds') {
      if (!ID_RE.test(key)) return;
      const f = worldFile(key);
      return serial(f, async function () {
        await fsp.rm(f, { force: true }); await fsp.rm(f + '.bak', { force: true });
        await fsp.rm(path.join(worldDir(key), 'Название мира.txt'), { force: true });
        names.delete(key); lastBak.delete(key);
        try { await fsp.rmdir(path.join(worldDir(key), 'chunks')); } catch (e) {}
        try { await fsp.rmdir(worldDir(key)); } catch (e) {}      // папка не пуста (внутри что-то чужое) — не трогаем
      });
    }
    if (store === 'chunks') {
      const m = CK_RE.exec(key); if (!m) return;
      const f = chunkFile(m[1], +m[2], +m[3]);
      return serial(f, function () { return fsp.rm(f, { force: true }); });
    }
    throw new Error('store?');
  }
  async function all(store) {
    if (store === 'dirty') { await loadDirty(); return Object.keys(dirty).map(function (k) { return dirty[k]; }); }
    if (store === 'worlds') {
      const ents = await fsp.readdir(root, { withFileTypes: true }).catch(function () { return []; }), out = [];
      for (const e of ents) {
        if (!e.isDirectory() || !ID_RE.test(e.name)) continue;
        const m = await readWorld(e.name);
        if (!m || typeof m !== 'object') continue;
        if (m.id !== e.name) { log.warn('папка мира «' + e.name + '» не совпадает с id внутри (' + m.id + ') — пропущена'); continue; }
        out.push(m);
      }
      return out;
    }
    throw new Error('store?');
  }
  async function keys(store, prefix) {
    if (store === 'dirty') { await loadDirty(); return Object.keys(dirty).filter(function (k) { return k.indexOf(prefix) === 0; }); }
    if (store === 'chunks') {
      const id = String(prefix).replace(/\|$/, '');
      if (!ID_RE.test(id)) return [];
      const ents = await fsp.readdir(path.join(worldDir(id), 'chunks')).catch(function () { return []; }), out = [];
      ents.forEach(function (n) { const m = /^(-?\d+)_(-?\d+)\.json$/.exec(n); if (m) out.push(id + '|' + m[1] + ',' + m[2]); });
      return out;
    }
    if (store === 'worlds') { return (await all('worlds')).map(function (m) { return m.id; }).filter(function (k) { return k.indexOf(prefix) === 0; }); }
    throw new Error('store?');
  }

  // Удаление мира из игры: сначала папка уезжает в «_Удалённые» (14 дней можно вернуть вручную), потом игра стирает остатки.
  async function trashWorld(id) {
    if (!ID_RE.test(id)) return false;
    const src = worldDir(id);
    try { await fsp.access(src); } catch (e) { return false; }
    const dst = path.join(root, TRASH, id + '-' + Date.now());
    await fsp.mkdir(path.dirname(dst), { recursive: true });
    await serial('trash:' + id, function () { return fsp.rename(src, dst); });
    names.delete(id); lastBak.delete(id);
    return true;
  }
  async function pruneTrash() {
    const dir = path.join(root, TRASH), ents = await fsp.readdir(dir).catch(function () { return []; });
    for (const n of ents) {
      const m = /-(\d{10,})$/.exec(n);
      if (m && Date.now() - Number(m[1]) > TRASH_DAYS * 86400000) { await fsp.rm(path.join(dir, n), { recursive: true, force: true }).catch(function () {}); log.info('стёрт старый удалённый мир ' + n); }
    }
  }

  return { root: root, get: get, put: put, del: del, all: all, keys: keys, trashWorld: trashWorld, pruneTrash: pruneTrash, flush: flush };
}

module.exports = { create: create };
