'use strict';
// «Скачать всю музыку»: кладёт треки в папку музыки на компьютере, после этого они играют без интернета.
const fs = require('fs'), fsp = fs.promises, path = require('path');
const { net } = require('electron');
const log = require('./log');

const NAME_RE = /^[A-Za-z0-9_.-]+\.(mp3|m4a)$/;

function create(dir, base, onProgress) {
  fs.mkdirSync(dir, { recursive: true });
  let job = null;    // { ac, state }

  async function stat(files) {
    let have = 0, bytes = 0, total = 0, size = 0;
    for (const f of files) {
      if (!NAME_RE.test(f)) continue;
      total++;
      const st = await fsp.stat(path.join(dir, f)).catch(function () { return null; });
      if (st && st.isFile() && st.size > 0) { have++; bytes += st.size; }
    }
    return { have: have, total: total, bytes: bytes, running: !!job };
  }

  async function fetchTo(name, signal, count) {
    const dst = path.join(dir, name), part = dst + '.part';
    let stall = null, lastErr = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      const ac = new AbortController();
      const onAbort = function () { ac.abort(); };
      signal.addEventListener('abort', onAbort);
      const arm = function () { clearTimeout(stall); stall = setTimeout(function () { ac.abort(); }, 45000); };
      try {
        arm();
        const r = await net.fetch(base + encodeURIComponent(name), { signal: ac.signal, redirect: 'follow' });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        const total = Number(r.headers.get('content-length')) || 0;
        const ws = fs.createWriteStream(part);
        const werr = new Promise(function (_, rej) { ws.on('error', rej); });
        const reader = r.body.getReader();
        let got = 0;
        for (;;) {
          const x = await Promise.race([reader.read(), werr]);
          if (x.done) break;
          arm(); got += x.value.length; count(x.value.length);
          await Promise.race([new Promise(function (res) { ws.write(x.value, res); }), werr]);
        }
        await new Promise(function (res, rej) { ws.end(function (e) { if (e) rej(e); else res(); }); });
        if (total && got !== total) throw new Error('файл скачан не полностью (' + got + ' из ' + total + ')');
        if (!got) throw new Error('пустой файл');
        await fsp.rename(part, dst);
        return;
      } catch (e) {
        lastErr = e; await fsp.rm(part, { force: true }).catch(function () {});
        if (signal.aborted) throw new Error('остановлено');
        await new Promise(function (r) { setTimeout(r, 1200 * (attempt + 1)); });
      } finally { clearTimeout(stall); signal.removeEventListener('abort', onAbort); }
    }
    throw lastErr || new Error('не скачалось');
  }

  async function download(files) {
    if (job) return { state: 'running' };
    const todo = [];
    let doneN = 0, bytes = 0;
    const list = files.filter(function (f) { return NAME_RE.test(f); });
    for (const f of list) {
      const st = await fsp.stat(path.join(dir, f)).catch(function () { return null; });
      if (st && st.isFile() && st.size > 0) doneN++; else todo.push(f);
    }
    const total = list.length;
    if (!todo.length) { onProgress({ state: 'done', done: doneN, total: total, bytes: 0, failed: 0 }); return { state: 'done' }; }
    const ac = new AbortController();
    job = { ac: ac };
    let failed = 0, idx = 0, cur = '';
    const emit = function (state) { onProgress({ state: state || 'running', done: doneN, total: total, bytes: bytes, failed: failed, current: cur }); };
    emit();
    const tick = setInterval(function () { emit(); }, 400);
    async function worker() {
      while (idx < todo.length && !ac.signal.aborted) {
        const f = todo[idx++]; cur = f;
        try { await fetchTo(f, ac.signal, function (n) { bytes += n; }); doneN++; }
        catch (e) { if (ac.signal.aborted) return; failed++; log.warn('музыка ' + f + ': ' + (e && e.message || e)); }
      }
    }
    Promise.all([worker(), worker(), worker()]).then(function () {
      clearInterval(tick);
      const st = ac.signal.aborted ? 'cancelled' : (failed ? 'error' : 'done');
      job = null; emit(st);
      log.info('музыка: ' + st + ', скачано ' + doneN + ' из ' + total + ', ошибок ' + failed);
    });
    return { state: 'running' };
  }
  function cancel() { if (job) job.ac.abort(); }
  return { stat: stat, download: download, cancel: cancel, dir: dir };
}

module.exports = { create: create };
