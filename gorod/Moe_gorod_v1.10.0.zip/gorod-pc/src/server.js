'use strict';
// Маленький сервер только для этого окна: отдаёт файлы игры по адресу http://127.0.0.1:<порт>/ (видит только этот компьютер).
// Зачем сервер, а не файлы напрямую: так у игры обычный адрес сайта — работает вход в аккаунт (Firebase), фоновые потоки и перемотка музыки.
// /__music/<файл> — музыка: если трек скачан на компьютер, отдаём его оттуда, иначе перенаправляем на сайт.
const http = require('http'), fs = require('fs'), path = require('path');
const log = require('./log');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8', '.glb': 'model/gltf-binary', '.wasm': 'application/wasm'
};
const MUSIC_RE = /^[A-Za-z0-9_.-]+\.(mp3|m4a)$/;

function create(opts) {
  // opts: getGameDir() → папка игры, musicDir, musicBase
  const server = http.createServer(function (req, res) {
    handle(req, res).catch(function (e) {
      log.error('сервер: ' + req.url + ' — ' + (e && e.stack || e));
      try { if (!res.headersSent) res.writeHead(500); res.end(); } catch (e2) {}
    });
  });

  async function handle(req, res) {
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }); return res.end(); }
    if (!/^(127\.0\.0\.1|localhost)(:\d+)?$/i.test(req.headers.host || '')) { res.writeHead(421); return res.end(); }   // защита от чужих сайтов, подменяющих адрес
    let p;
    try { p = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname); } catch (e) { res.writeHead(400); return res.end(); }
    if (p.indexOf('\0') >= 0) { res.writeHead(400); return res.end(); }

    if (p.indexOf('/__music/') === 0) {
      const name = p.slice(9);
      if (!MUSIC_RE.test(name)) { res.writeHead(404); return res.end(); }
      const f = path.join(opts.musicDir, name);
      const st = await fs.promises.stat(f).catch(function () { return null; });
      if (st && st.isFile() && st.size > 0) return sendFile(req, res, f, st, false);
      res.writeHead(302, { Location: opts.musicBase + encodeURIComponent(name), 'Cache-Control': 'no-store' });
      return res.end();
    }

    const base = opts.getGameDir();
    let rel = p === '/' ? '/index.html' : p;
    let abs = path.join(base, rel);
    const back = path.relative(base, abs);
    if (back.indexOf('..') === 0 || path.isAbsolute(back)) { res.writeHead(403); return res.end(); }
    let st = await fs.promises.stat(abs).catch(function () { return null; });
    if (st && st.isDirectory()) { abs = path.join(abs, 'index.html'); st = await fs.promises.stat(abs).catch(function () { return null; }); }
    if (!st || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Не найдено'); }
    return sendFile(req, res, abs, st, true);
  }

  function sendFile(req, res, file, st, revalidate) {
    const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
    const etag = 'W/"' + st.size + '-' + Math.round(st.mtimeMs) + '"';
    const head = { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'Last-Modified': st.mtime.toUTCString(), ETag: etag, 'Cache-Control': revalidate ? 'no-cache' : 'private, max-age=3600' };
    const range = req.headers.range;
    if (!range && req.headers['if-none-match'] === etag) { res.writeHead(304, head); return res.end(); }
    let start = 0, end = st.size - 1, code = 200;
    if (range) {
      const m = /^bytes=(\d*)-(\d*)$/.exec(range);
      if (!m || (m[1] === '' && m[2] === '')) { res.writeHead(416, { 'Content-Range': 'bytes */' + st.size }); return res.end(); }
      if (m[1] === '') { start = Math.max(0, st.size - Number(m[2])); }
      else { start = Number(m[1]); if (m[2] !== '') end = Math.min(end, Number(m[2])); }
      if (start > end || start >= st.size) { res.writeHead(416, { 'Content-Range': 'bytes */' + st.size }); return res.end(); }
      code = 206; head['Content-Range'] = 'bytes ' + start + '-' + end + '/' + st.size;
    }
    head['Content-Length'] = end - start + 1;
    res.writeHead(code, head);
    if (req.method === 'HEAD' || st.size === 0) return res.end();
    const rs = fs.createReadStream(file, { start: start, end: end });
    rs.on('error', function () { try { res.destroy(); } catch (e) {} });
    res.on('close', function () { rs.destroy(); });
    rs.pipe(res);
  }

  function listen(port) {
    return new Promise(function (resolve, reject) {
      const onErr = function (e) { reject(e); };
      server.once('error', onErr);
      server.listen(port, '127.0.0.1', function () { server.removeListener('error', onErr); resolve(server.address().port); });
    });
  }
  // Привычный порт нужен, чтобы адрес игры не менялся (иначе браузерное хранилище — вход в аккаунт — «забывалось» бы). Занят — берём любой свободный.
  async function start(preferred) {
    try { return await listen(preferred); }
    catch (e) {
      if (e.code === 'EADDRINUSE' || e.code === 'EACCES') { log.warn('порт ' + preferred + ' занят, беру другой'); return listen(0); }
      throw e;
    }
  }
  return { start: start, close: function () { try { server.close(); } catch (e) {} } };
}

module.exports = { create: create };
