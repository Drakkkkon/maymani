'use strict';
// Обновления. Описание последней версии лежит на сайте (updates/gorod.json — как у «Мое_граббер» и «Мое_лимиты»):
//   { version, date, notes[], shellMin, game_zip:{url,size,sha256}, setup:{url,size,sha256,shell,version} }
// Два вида обновления:
//  • «game» — маленький архив с самой игрой (несколько МБ). Скачивается сам, проверяется по SHA-256, кладётся в %APPDATA%\Moe_gorod\updates
//    и начинает работать после перезапуска. Оболочка (окно, установщик) при этом не меняется.
//  • «setup» — полный установщик (≈100 МБ). Нужен редко: когда сама оболочка стала новее (shellMin больше версии оболочки). Ставится тихо поверх.
const { net } = require('electron');
const fs = require('fs'), fsp = fs.promises, path = require('path'), crypto = require('crypto');
const { spawn } = require('child_process');
const { unzipSync } = require('fflate');
const cfg = require('./config'), sv = require('./semver'), log = require('./log');

function create(o) {
  // o: userData, running() → версия, которая сейчас запущена, getAuto() → bool, emit(state), prepareExit(after) → завершает программу
  const root = path.join(o.userData, 'updates');
  const dl = path.join(root, 'download');
  let st = { status: 'idle', running: o.running(), latest: '', date: '', notes: [], kind: '', size: 0, progress: 0, error: '', checkedAt: 0, auto: o.getAuto() };
  let busy = false, timer = null, first = null, ready = null, lastM = null;   // ready: { kind, version, file? }; lastM — последнее описание с сайта

  function set(p) { Object.assign(st, p); o.emit(Object.assign({}, st)); }
  function snapshot() { st.auto = o.getAuto(); return Object.assign({}, st); }
  function friendly(e) {
    const m = String((e && e.message) || e);
    if (/ENOTFOUND|ECONNREFUSED|ERR_INTERNET|ERR_NAME|ERR_CONNECTION|ERR_NETWORK|ERR_TIMED_OUT|Failed to fetch|fetch failed|aborted/i.test(m)) return 'Нет связи с сервером обновлений. Проверьте интернет.';
    if (/HTTP 404/.test(m)) return 'Файл обновления не найден на сервере (404).';
    return m;
  }

  async function fetchManifest() {
    const r = await net.fetch(cfg.MANIFEST_URL + (cfg.MANIFEST_URL.indexOf('?') < 0 ? '?t=' + Date.now() : ''), { redirect: 'follow' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const m = await r.json();
    if (!m || typeof m.version !== 'string' || !/^\d+\.\d+\.\d+/.test(m.version)) throw new Error('Описание обновления непонятно');
    return m;
  }

  function sha256File(file) {
    return new Promise(function (resolve, reject) {
      const h = crypto.createHash('sha256'), s = fs.createReadStream(file);
      s.on('error', reject); s.on('data', function (d) { h.update(d); }); s.on('end', function () { resolve(h.digest('hex')); });
    });
  }

  async function downloadFile(url, dest, want, progress) {
    await fsp.mkdir(path.dirname(dest), { recursive: true });
    const part = dest + '.part';
    const ac = new AbortController();
    let stall = null;
    const arm = function () { clearTimeout(stall); stall = setTimeout(function () { ac.abort(); }, 60000); };
    try {
      arm();
      const r = await net.fetch(url, { signal: ac.signal, redirect: 'follow' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const total = Number(r.headers.get('content-length')) || (want && want.size) || 0;
      const ws = fs.createWriteStream(part);
      const werr = new Promise(function (_, rej) { ws.on('error', rej); });
      const h = crypto.createHash('sha256');
      const reader = r.body.getReader();
      let got = 0;
      for (;;) {
        const x = await Promise.race([reader.read(), werr]);
        if (x.done) break;
        arm(); got += x.value.length; h.update(x.value);
        await Promise.race([new Promise(function (res) { ws.write(x.value, res); }), werr]);
        progress(total ? got / total : 0);
      }
      await new Promise(function (res, rej) { ws.end(function (e) { if (e) rej(e); else res(); }); });
      const sum = h.digest('hex');
      if (want && want.size && got !== want.size) throw new Error('Файл скачался не полностью');
      if (want && want.sha256 && sum.toLowerCase() !== String(want.sha256).toLowerCase()) throw new Error('Файл повреждён (не совпала контрольная сумма)');
      await fsp.rename(part, dest);
    } catch (e) {
      await fsp.rm(part, { force: true }).catch(function () {});
      throw e;
    } finally { clearTimeout(stall); }
  }

  async function extractGame(zipFile, version) {
    const files = unzipSync(new Uint8Array(await fsp.readFile(zipFile)));
    const tmp = path.join(root, 'game-' + version + '.tmp'), dst = path.join(root, 'game-' + version);
    await fsp.rm(tmp, { recursive: true, force: true });
    await fsp.mkdir(tmp, { recursive: true });
    let n = 0;
    for (const name of Object.keys(files)) {
      if (/\/$/.test(name)) continue;
      const abs = path.join(tmp, name.replace(/\\/g, '/'));
      const back = path.relative(tmp, abs);
      if (!back || back.indexOf('..') === 0 || path.isAbsolute(back)) throw new Error('Неверный путь в архиве: ' + name);
      await fsp.mkdir(path.dirname(abs), { recursive: true });
      await fsp.writeFile(abs, files[name]); n++;
    }
    const vj = JSON.parse(await fsp.readFile(path.join(tmp, 'version.json'), 'utf8'));
    if (vj.version !== version) throw new Error('В архиве другая версия игры (' + vj.version + ')');
    await fsp.access(path.join(tmp, 'index.html'));
    await fsp.writeFile(path.join(tmp, '.ok'), String(Date.now()));
    await fsp.rm(dst, { recursive: true, force: true });
    await fsp.rename(tmp, dst);
    log.info('обновление игры ' + version + ' распаковано (' + n + ' файлов)');
  }

  async function downloadGame(m) {
    const z = m.game_zip;
    set({ status: 'downloading', kind: 'game', progress: 0, error: '' });
    const f = path.join(dl, 'Moe_gorod_game_' + m.version + '.zip');
    await downloadFile(z.url, f, z, function (p) { set({ progress: p }); });
    set({ progress: 1 });
    await extractGame(f, m.version);
    await fsp.rm(f, { force: true }).catch(function () {});
    ready = { kind: 'game', version: m.version };
    set({ status: 'ready', kind: 'game', progress: 1 });
  }

  async function downloadSetup(m) {
    const z = m.setup;
    set({ status: 'downloading', kind: 'setup', progress: 0, error: '' });
    const f = path.join(dl, 'Moe_gorod_Setup_' + (z.version || m.version) + '.exe');
    let have = false;
    try { const s = await fsp.stat(f); have = z.size ? s.size === z.size : s.size > 0; if (have && z.sha256) have = (await sha256File(f)).toLowerCase() === String(z.sha256).toLowerCase(); } catch (e) { have = false; }
    if (!have) await downloadFile(z.url, f, z, function (p) { set({ progress: p }); });
    ready = { kind: 'setup', version: m.version, file: f };
    set({ status: 'ready', kind: 'setup', progress: 1 });
  }

  async function check(manual) {
    if (busy) return snapshot();
    busy = true;
    set({ status: 'checking', error: '', running: o.running() });
    try {
      const m = await fetchManifest();
      lastM = m;
      const notes = Array.isArray(m.notes) ? m.notes.map(String) : [];
      const have = ready && sv.cmp(ready.version, o.running()) > 0 ? ready.version : o.running();
      if (sv.cmp(m.version, have) <= 0) {
        set({ status: ready ? 'ready' : 'uptodate', latest: m.version, date: m.date || '', notes: ready ? st.notes : [], checkedAt: Date.now(), running: o.running() });
        return snapshot();
      }
      const needShell = m.shellMin && sv.cmp(cfg.SHELL_VERSION, m.shellMin) < 0;
      let kind = '';
      if (!needShell && m.game_zip && m.game_zip.url) kind = 'game';
      else if (m.setup && m.setup.url) kind = 'setup';
      if (!kind) throw new Error('Для версии ' + m.version + ' нет файла обновления');
      set({ status: 'available', kind: kind, latest: m.version, date: m.date || '', notes: notes, size: (kind === 'game' ? m.game_zip : m.setup).size || 0, progress: 0, checkedAt: Date.now(), running: o.running() });
      log.info('найдена версия ' + m.version + ' (' + kind + ')');
      if (kind === 'game' && o.getAuto()) await downloadGame(m);     // маленькое обновление качаем сами; большой установщик — только по нажатию
    } catch (e) {
      log.warn('проверка обновлений: ' + (e && e.message || e));
      const loud = manual || st.status === 'downloading';          // тихая проверка без интернета ничего не показывает
      set({ status: loud ? 'error' : (ready ? 'ready' : 'idle'), error: friendly(e), checkedAt: Date.now() });
    } finally { busy = false; }
    return snapshot();
  }

  // Нажали «Скачать» (или «Скачать и установить» для установщика)
  async function fetchNow() {
    if (busy) return snapshot();
    const m = lastM;
    if (!m) return check(true);
    busy = true;
    try { if (st.kind === 'setup') await downloadSetup(m); else await downloadGame(m); }
    catch (e) { log.warn('скачивание обновления: ' + (e && e.message || e)); set({ status: 'error', error: friendly(e) }); }
    finally { busy = false; }
    return snapshot();
  }

  // Нажали «Установить и перезапустить»
  async function install() {
    if (!ready) return snapshot();
    if (ready.kind === 'game') {
      log.info('перезапуск для обновления игры до ' + ready.version);
      o.prepareExit(async function () {
        const { app } = require('electron');
        app.releaseSingleInstanceLock();   // иначе новая копия, запущенная до полного выхода этой, увидит «уже запущено» и закроется
        app.relaunch();
      });
    } else {
      const file = ready.file;
      log.info('запуск установщика ' + file);
      o.prepareExit(async function () {
        // /S — тихо, --updated — это обновление (ярлыки не пересоздаются), --force-run — запустить игру после установки
        const child = spawn(file, ['/S', '--updated', '--force-run'], { detached: true, stdio: 'ignore', windowsHide: true });
        child.on('error', function (e) { log.error('установщик не запустился: ' + e.message); });
        child.unref();
      });
    }
    return snapshot();
  }

  function start() {
    try { fs.mkdirSync(root, { recursive: true }); } catch (e) {}
    // недокачанные остатки прошлого запуска
    fsp.readdir(dl).then(function (ns) { ns.forEach(function (n) { if (/\.part$/.test(n)) fsp.rm(path.join(dl, n), { force: true }).catch(function () {}); }); }).catch(function () {});
    first = setTimeout(function () { check(false); }, cfg.CHECK_FIRST_MS);
    timer = setInterval(function () { check(false); }, cfg.CHECK_EVERY_MS);
  }
  function stop() { clearTimeout(first); clearInterval(timer); }

  return { start: start, stop: stop, check: check, fetchNow: fetchNow, install: install, state: snapshot };
}

module.exports = { create: create };
