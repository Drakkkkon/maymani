'use strict';
// Журнал программы: %APPDATA%\Moe_gorod\logs\main.log (если что-то сломалось — пришлите этот файл).
const fs = require('fs'), path = require('path');
let file = null;
function init(dir) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    file = path.join(dir, 'main.log');
    try { if (fs.statSync(file).size > 2 * 1024 * 1024) fs.renameSync(file, path.join(dir, 'main.old.log')); } catch (e) {}
  } catch (e) { file = null; }
}
function fmt(m) { return m instanceof Error ? (m.stack || String(m)) : (typeof m === 'string' ? m : JSON.stringify(m)); }
function write(level, m) {
  const line = '[' + new Date().toISOString() + '] ' + level + ' ' + fmt(m) + '\n';
  try { if (file) fs.appendFileSync(file, line); } catch (e) {}
  if (process.env.MOE_DEBUG) process.stdout.write(line);
}
module.exports = { init: init, info: function (m) { write('INFO', m); }, warn: function (m) { write('WARN', m); }, error: function (m) { write('ERROR', m); } };
