'use strict';
// «Мое_город» для Windows — главный процесс: окно, сохранения в папку на компьютере, обновления, музыка.
const { app, BrowserWindow, Menu, shell, ipcMain, session, dialog, screen } = require('electron');
const path = require('path'), fs = require('fs');
const cfg = require('./config'), log = require('./log'), sv = require('./semver');
const gamedir = require('./gamedir'), storeMod = require('./store'), serverMod = require('./server');
const musicMod = require('./music'), updaterMod = require('./updater');

// ---- пути ----
// Данные программы (журнал, обновления, музыка, настройки окна): %APPDATA%\Moe_gorod. Имя без русских букв — так надёжнее.
const userData = process.env.MOE_USERDATA || path.join(app.getPath('appData'), 'Moe_gorod');
app.setPath('userData', userData);
app.setAppUserModelId(cfg.APP_ID);

// Свои параметры Chromium: видеокарта побольше, музыка сама после запуска
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('force_high_performance_gpu');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

if (!process.env.MOE_ALLOW_MULTI && !app.requestSingleInstanceLock()) { app.exit(0); return; }   // вторая копия не нужна: две копии писали бы в одни и те же файлы

let win = null, server = null, origin = '', store = null, music = null, updater = null, game = null;
let quitting = false;
const files = { settings: path.join(userData, 'settings.json'), window: path.join(userData, 'window.json') };

function readJson(f, dflt) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return dflt; } }
function writeJson(f, v) { try { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(v)); } catch (e) { log.warn('не записалось ' + f + ': ' + e.message); } }
let settings = Object.assign({ autoUpdate: true }, readJson(files.settings, {}));

function bundledGameDir() { return app.isPackaged ? path.join(process.resourcesPath, 'game') : path.join(__dirname, '..', 'game'); }
function savesDir() {
  if (process.env.MOE_SAVES_DIR) return process.env.MOE_SAVES_DIR;
  try { return path.join(app.getPath('documents'), 'Мое_город', 'Сохранения'); }
  catch (e) { return path.join(userData, 'Сохранения'); }
}
const dirs = function () { return { saves: savesDir(), logs: path.join(userData, 'logs'), music: path.join(userData, 'music'), data: userData }; };

process.on('uncaughtException', function (e) { log.error('uncaughtException: ' + (e && e.stack || e)); });
process.on('unhandledRejection', function (e) { log.error('unhandledRejection: ' + (e && e.stack || e)); });

// ---- выход: сначала игра дописывает мир и отправляет в облако, потом закрываемся ----
function requestQuit(after) {
  if (quitting) return;
  quitting = true;
  let finished = false, timer = null;
  const fin = async function () {
    if (finished) return; finished = true; clearTimeout(timer); ipcMain.removeListener('app:quit-ready', fin);
    try { if (updater) updater.stop(); } catch (e) {}
    try { if (store) await store.flush(); } catch (e) { log.error('запись при выходе: ' + e.message); }
    try { if (after) await after(); } catch (e) { log.error('при выходе: ' + (e && e.stack || e)); }
    app.exit(0);
  };
  if (!win || win.isDestroyed() || win.webContents.isLoading()) return fin();
  timer = setTimeout(fin, 6000);
  ipcMain.once('app:quit-ready', fin);
  win.webContents.send('app:before-quit');
}

// ---- окно ----
function winState() {
  const s = readJson(files.window, null);
  if (!s || !isFinite(s.width) || !isFinite(s.height)) return { first: true };
  try {   // окно должно оказаться на каком-нибудь из мониторов (мог отключиться)
    if (isFinite(s.x) && isFinite(s.y)) {
      const ok = screen.getAllDisplays().some(function (d) { const b = d.workArea; return s.x + 100 > b.x && s.x + 100 < b.x + b.width && s.y + 50 > b.y && s.y + 50 < b.y + b.height; });
      if (!ok) { delete s.x; delete s.y; }
    }
  } catch (e) {}
  return s;
}
function saveWinState() {
  if (!win || win.isDestroyed()) return;
  const full = win.isFullScreen(), max = win.isMaximized();
  const b = (full || max) ? (readJson(files.window, {}) || {}) : win.getBounds();
  writeJson(files.window, Object.assign({}, b, { maximized: max, width: b.width || 1440, height: b.height || 880 }));
}

function createWindow() {
  const st = winState();
  win = new BrowserWindow({
    width: st.width || 1440, height: st.height || 880, x: st.x, y: st.y, minWidth: 960, minHeight: 600,
    show: false, backgroundColor: '#20324a', title: 'Мое_город',
    icon: path.join(__dirname, 'assets', 'icon.png'), autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false, webSecurity: true }
  });
  win.once('ready-to-show', function () { if (st.first || st.maximized) win.maximize(); win.show(); });
  win.on('resize', debounce(saveWinState, 500)); win.on('move', debounce(saveWinState, 500));
  win.on('close', function (e) { if (!quitting) { e.preventDefault(); saveWinState(); requestQuit(); } });
  win.webContents.on('before-input-event', function (e, input) {
    if (input.type !== 'keyDown') return;
    if (input.key === 'F11' || (input.alt && input.key === 'Enter')) { e.preventDefault(); win.setFullScreen(!win.isFullScreen()); }
    else if (input.key === 'F12' || (input.control && input.shift && (input.key === 'I' || input.key === 'i'))) { e.preventDefault(); win.webContents.toggleDevTools(); }
  });
  win.webContents.setWindowOpenHandler(function (d) { if (/^https?:\/\//i.test(d.url)) shell.openExternal(d.url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', function (e, url) { if (url.indexOf(origin) !== 0) { e.preventDefault(); if (/^https?:\/\//i.test(url)) shell.openExternal(url); } });
  win.webContents.on('render-process-gone', function (e, d) {
    log.error('страница игры упала: ' + (d && d.reason));
    if (quitting) return;
    dialog.showMessageBox(win, { type: 'error', title: 'Мое_город', message: 'Игра неожиданно остановилась (' + (d && d.reason) + ').', detail: 'Сохранения целы. Перезапустить окно игры?', buttons: ['Перезапустить', 'Закрыть'], defaultId: 0 })
      .then(function (r) { if (r.response === 0) win.loadURL(origin + '/index.html'); else requestQuit(); });
  });
  win.webContents.on('console-message', function () {
    const a = arguments, ev = a[0];
    const lvl = ev && ev.message !== undefined ? ev.level : a[1], msg = ev && ev.message !== undefined ? ev.message : a[2], line = ev && ev.message !== undefined ? ev.lineNumber : a[3], src = ev && ev.message !== undefined ? ev.sourceId : a[4];
    if (lvl === 'error' || lvl === 3) log.warn('страница: ' + msg + ' (' + String(src || '').split('/').pop() + ':' + line + ')');
  });
  win.loadURL(origin + '/index.html');
}
function debounce(fn, ms) { let t = null; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }

// ---- связь со страницей ----
function trusted(e) { try { return e.senderFrame && String(e.senderFrame.url).indexOf(origin + '/') === 0; } catch (err) { return false; } }
function handle(ch, fn) { ipcMain.handle(ch, function (e) { if (!trusted(e)) throw new Error('нет доступа'); return fn.apply(null, Array.prototype.slice.call(arguments, 1)); }); }
const STORES = { worlds: 1, chunks: 1, dirty: 1 };
const okStore = function (s) { if (!STORES[s]) throw new Error('store'); return s; };

function wire() {
  ipcMain.on('app:info', function (e) {
    if (!trusted(e)) { e.returnValue = {}; return; }
    e.returnValue = { platform: process.platform, shellVersion: cfg.SHELL_VERSION, gameVersion: game.version, gameKind: game.kind, paths: dirs() };
  });
  ipcMain.on('app:log', function (e, level, msg) { if (trusted(e)) (log[level] || log.info)('страница: ' + msg); });
  handle('fs:get', function (s, k) { return store.get(okStore(s), String(k)); });
  handle('fs:put', function (s, k, v) { return store.put(okStore(s), String(k), v); });
  handle('fs:del', function (s, k) { return store.del(okStore(s), String(k)); });
  handle('fs:all', function (s) { return store.all(okStore(s)); });
  handle('fs:keys', function (s, p) { return store.keys(okStore(s), String(p)); });
  handle('fs:trash', function (id) { return store.trashWorld(String(id)); });
  handle('app:open', function (what) {
    const d = dirs(), dir = { saves: d.saves, logs: d.logs, music: d.music, data: d.data }[what];
    if (!dir) return false;
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
    return shell.openPath(dir).then(function (err) { return !err; });
  });
  handle('win:fs', function () { win.setFullScreen(!win.isFullScreen()); return win.isFullScreen(); });
  handle('upd:state', function () { return updater.state(); });
  handle('upd:check', function () { return updater.check(true); });
  handle('upd:fetch', function () { return updater.fetchNow(); });
  handle('upd:install', function () { return updater.install(); });
  handle('upd:auto', function (on) { settings.autoUpdate = !!on; writeJson(files.settings, settings); return settings.autoUpdate; });
  handle('mus:stat', function (list) { return music.stat(Array.isArray(list) ? list.map(String) : []); });
  handle('mus:dl', function (list) { return music.download(Array.isArray(list) ? list.map(String) : []); });
  handle('mus:cancel', function () { music.cancel(); return true; });
}

function send(ch, payload) { try { if (win && !win.isDestroyed()) win.webContents.send(ch, payload); } catch (e) {} }

app.on('second-instance', function () { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('before-quit', function (e) { if (!quitting) { e.preventDefault(); requestQuit(); } });
app.on('window-all-closed', function () { if (!quitting) requestQuit(); });
app.on('child-process-gone', function (e, d) { log.warn('процесс ' + d.type + ' завершился: ' + d.reason); });

app.whenReady().then(async function () {
  log.init(path.join(userData, 'logs'));
  log.info('запуск, оболочка ' + cfg.SHELL_VERSION + ', electron ' + process.versions.electron + ', ' + process.platform);
  Menu.setApplicationMenu(null);
  session.defaultSession.setPermissionRequestHandler(function (wc, perm, cb) { cb(perm === 'fullscreen'); });
  session.defaultSession.setPermissionCheckHandler(function (wc, perm) { return perm === 'fullscreen'; });
  app.on('web-contents-created', function (e, c) { c.on('will-attach-webview', function (ev) { ev.preventDefault(); }); });

  try {
    store = storeMod.create(savesDir());
    store.pruneTrash().catch(function () {});
    music = musicMod.create(dirs().music, cfg.MUSIC_BASE, function (p) { send('mus:progress', p); });
    const upd = path.join(userData, 'updates');
    game = gamedir.pick(bundledGameDir(), upd);
    gamedir.prune(upd, game.dir);
    log.info('игра ' + game.version + ' (' + game.kind + '), папка ' + game.dir + ', сохранения ' + store.root);
    const srv = serverMod.create({ getGameDir: function () { return game.dir; }, musicDir: dirs().music, musicBase: cfg.MUSIC_BASE });
    const port = await srv.start(cfg.PORT);
    server = srv; origin = 'http://127.0.0.1:' + port;
    updater = updaterMod.create({
      userData: userData,
      running: function () { return game.version; },
      getAuto: function () { return settings.autoUpdate; },
      emit: function (s) { send('upd:state', s); },
      prepareExit: requestQuit
    });
    wire();
    createWindow();
    if (!process.env.MOE_NO_UPDATES) updater.start();
  } catch (e) {
    log.error('не удалось запустить: ' + (e && e.stack || e));
    dialog.showErrorBox('Мое_город', 'Не удалось запустить игру:\n' + (e && e.message || e) + '\n\nЖурнал: ' + path.join(userData, 'logs', 'main.log'));
    app.exit(1);
  }
});
