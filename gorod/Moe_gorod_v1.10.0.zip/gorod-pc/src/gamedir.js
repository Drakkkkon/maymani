'use strict';
// Какую папку с игрой запускать. Их может быть две:
//  1) встроенная — resources/game внутри установленной программы (версия, с которой ставили);
//  2) обновление — %APPDATA%\Moe_gorod\updates\game-<версия> (маленький архив с игрой, скачанный автоматически).
// Берётся самая новая из тех, что подходят к этой оболочке (shellMin в game/version.json).
const fs = require('fs'), path = require('path');
const sv = require('./semver'), cfg = require('./config'), log = require('./log');

function readInfo(dir) {
  try {
    const j = JSON.parse(fs.readFileSync(path.join(dir, 'version.json'), 'utf8'));
    if (!j || typeof j.version !== 'string' || !fs.existsSync(path.join(dir, 'index.html'))) return null;
    return { dir: dir, version: j.version, shellMin: typeof j.shellMin === 'string' ? j.shellMin : '1.0.0' };
  } catch (e) { return null; }
}

function overlayDirs(root) {
  let names = [];
  try { names = fs.readdirSync(root); } catch (e) { return []; }
  const out = [];
  names.forEach(function (n) {
    const m = /^game-(\d+\.\d+\.\d+)$/.exec(n);
    if (!m) return;
    const dir = path.join(root, n);
    if (!fs.existsSync(path.join(dir, '.ok'))) return;       // распаковка не закончилась — не трогаем
    const info = readInfo(dir);
    if (info && info.version === m[1]) out.push(info);
  });
  return out;
}

// → { dir, version, kind: 'bundled' | 'update' }
function pick(bundledDir, updatesRoot) {
  const cands = [];
  const b = readInfo(bundledDir);
  if (b) { b.kind = 'bundled'; cands.push(b); }
  overlayDirs(updatesRoot).forEach(function (o) { o.kind = 'update'; cands.push(o); });
  const ok = cands.filter(function (c) { return sv.cmp(cfg.SHELL_VERSION, c.shellMin) >= 0; });
  ok.sort(function (x, y) { return sv.cmp(y.version, x.version); });
  if (!ok.length) throw new Error('Не найдена папка с игрой (' + bundledDir + ')');
  return ok[0];
}

// Старые обновления и недокачанные остатки убираем, чтобы не копились.
function prune(updatesRoot, keepDir) {
  let names = [];
  try { names = fs.readdirSync(updatesRoot); } catch (e) { return; }
  names.forEach(function (n) {
    const full = path.join(updatesRoot, n);
    if (full === keepDir) return;
    if (/^game-\d+\.\d+\.\d+$/.test(n)) {
      // более новое обновление, которое пока не подошло (например, нужна новая оболочка), оставляем
      const info = readInfo(full);
      if (info && keepDir && sv.cmp(info.version, (readInfo(keepDir) || { version: '0.0.0' }).version) > 0) return;
      try { fs.rmSync(full, { recursive: true, force: true }); log.info('убрана старая версия игры ' + n); } catch (e) {}
    } else if (/\.tmp$/.test(n)) {
      try { fs.rmSync(full, { recursive: true, force: true }); } catch (e) {}
    }
  });
}

module.exports = { pick: pick, prune: prune, readInfo: readInfo };
