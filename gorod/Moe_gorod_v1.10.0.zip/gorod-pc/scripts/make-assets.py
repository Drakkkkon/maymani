#!/usr/bin/env python3
# Значки и картинки для установщика из ../gorod/icon.svg. Запуск: python3 -I scripts/make-assets.py
# Нужны: rsvg-convert (librsvg) и Pillow.
import os, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SVG = os.path.join(ROOT, '..', 'gorod', 'icon.svg')
BUILD = os.path.join(ROOT, 'build')
ASSETS = os.path.join(ROOT, 'src', 'assets')
os.makedirs(BUILD, exist_ok=True); os.makedirs(ASSETS, exist_ok=True)

def render(px):
    out = os.path.join(BUILD, '_icon_%d.png' % px)
    subprocess.check_call(['rsvg-convert', '-w', str(px), '-h', str(px), SVG, '-o', out])
    im = Image.open(out).convert('RGBA'); os.remove(out); return im

big = render(1024)
big.resize((512, 512), Image.LANCZOS).save(os.path.join(BUILD, 'icon.png'))
big.resize((256, 256), Image.LANCZOS).save(os.path.join(ASSETS, 'icon.png'))
sizes = [256, 128, 64, 48, 32, 24, 16]
# значок .ico собираем сами: у каждого размера своя картинка (маленькие рисуются отдельно, а не сжимаются из большой);
# маленькие — в обычном для Windows виде (BMP 32 бита + маска), 256 — PNG. Так значок одинаково хорошо виден везде, в том числе на ярлыке.
import struct, io
def dib(im):
    w, h = im.size; px = im.convert('RGBA').load()
    xor = bytearray(); and_ = bytearray()
    row_and = ((w + 31) // 32) * 4
    for y in range(h - 1, -1, -1):
        mask = bytearray(row_and)
        for x in range(w):
            r, g, b, a = px[x, y]
            xor += bytes((b, g, r, a))
            if a < 128: mask[x // 8] |= 0x80 >> (x % 8)
        and_ += mask
    hdr = struct.pack('<IiiHHIIiiII', 40, w, h * 2, 1, 32, 0, len(xor) + len(and_), 0, 0, 0, 0)
    return hdr + bytes(xor) + bytes(and_)
blobs = []
for sz in sizes:
    im = render(sz)
    if sz >= 256:
        b = io.BytesIO(); im.save(b, format='PNG'); blobs.append((sz, b.getvalue()))
    else:
        blobs.append((sz, dib(im)))
head = struct.pack('<HHH', 0, 1, len(blobs)); entries = b''; data = b''; off = 6 + 16 * len(blobs)
for sz, blob in blobs:
    entries += struct.pack('<BBBBHHII', sz % 256, sz % 256, 0, 0, 1, 32, len(blob), off + len(data)); data += blob
open(os.path.join(BUILD, 'icon.ico'), 'wb').write(head + entries + data)

def font(sz, bold=True):
    for f in ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
              '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf']:
        if os.path.exists(f): return ImageFont.truetype(f, sz)
    return ImageFont.load_default()

NAVY1, NAVY2 = (21, 33, 52), (44, 72, 108)
def gradient(w, h):
    im = Image.new('RGB', (w, h)); d = ImageDraw.Draw(im)
    for y in range(h):
        t = y / (h - 1)
        d.line([(0, y), (w, y)], fill=tuple(int(NAVY1[i] + (NAVY2[i] - NAVY1[i]) * t) for i in range(3)))
    return im

def skyline(d, w, base, seed=3):
    # силуэты домов внизу картинки
    import random; r = random.Random(seed)
    x = 0
    cols = [(34, 54, 82), (40, 64, 96), (30, 48, 74)]
    while x < w:
        bw = r.randint(14, 28); bh = r.randint(24, 80)
        c = cols[r.randint(0, 2)]
        d.rectangle([x, base - bh, x + bw, base], fill=c)
        for wy in range(base - bh + 6, base - 4, 9):
            for wx in range(x + 4, x + bw - 3, 7):
                if r.random() < 0.45: d.rectangle([wx, wy, wx + 2, wy + 3], fill=(242, 200, 110))
        x += bw + r.randint(0, 3)

# боковая картинка мастера (164×314) — приветствие и завершение
def sidebar(path, sub):
    W, H = 164, 314
    im = gradient(W, H); d = ImageDraw.Draw(im)
    skyline(d, W, H - 26)
    d.rectangle([0, H - 26, W, H], fill=(60, 64, 71)); d.rectangle([0, H - 30, W, H - 26], fill=(140, 192, 104))
    ic = render(96); im.paste(ic, ((W - 96) // 2, 28), ic)
    d.text((W // 2, 142), 'Мое_город', font=font(21), fill=(255, 255, 255), anchor='mm')
    d.text((W // 2, 166), sub, font=font(11, False), fill=(190, 210, 235), anchor='mm')
    im.save(path, format='BMP')
sidebar(os.path.join(BUILD, 'installerSidebar.bmp'), 'градостроитель')
sidebar(os.path.join(BUILD, 'uninstallerSidebar.bmp'), 'до новых встреч')

# шапка страниц мастера (150×57)
hd = Image.new('RGB', (150, 57), (255, 255, 255)); d = ImageDraw.Draw(hd)
ic = render(44); hd.paste(ic, (100, 6), ic)
d.text((8, 18), 'Мое_город', font=font(13), fill=(32, 50, 74))
d.text((8, 36), 'градостроитель', font=font(9, False), fill=(100, 110, 125))
hd.save(os.path.join(BUILD, 'installerHeader.bmp'), format='BMP')
print('ok')
