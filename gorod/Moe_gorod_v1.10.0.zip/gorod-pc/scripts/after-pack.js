'use strict';
// Вызывается electron-builder после упаковки (до создания установщика).
// Прописывает значок и сведения о версии в Moe_gorod.exe «чистым JS» (resedit), чтобы сборка не требовала wine/rcedit.
const fs = require('fs'), path = require('path');
const ResEdit = require('resedit');

module.exports = async function afterPack(ctx) {
  if (ctx.electronPlatformName !== 'win32') return;
  const pkg = require('../package.json');
  const exe = path.join(ctx.appOutDir, ctx.packager.appInfo.productFilename + '.exe');
  const ico = path.join(__dirname, '..', 'build', 'icon.ico');

  const exeObj = ResEdit.NtExecutable.from(fs.readFileSync(exe));
  const res = ResEdit.NtExecutableResource.from(exeObj);

  // значок: заменяем первую группу значков Electron на наш набор размеров
  const iconFile = ResEdit.Data.IconFile.from(fs.readFileSync(ico));
  const groups = ResEdit.Resource.IconGroupEntry.fromEntries(res.entries);
  const g = groups[0] || { id: 1, lang: 1033 };
  ResEdit.Resource.IconGroupEntry.replaceIconsForResource(res.entries, g.id, g.lang, iconFile.icons.map(function (i) { return i.data; }));

  // сведения о версии (вкладка «Подробно» в свойствах файла)
  const vis = ResEdit.Resource.VersionInfo.fromEntries(res.entries);
  const vi = vis[0] || ResEdit.Resource.VersionInfo.createEmpty();
  const parts = pkg.version.split('.').map(Number);
  vi.setFileVersion(parts[0] || 0, parts[1] || 0, parts[2] || 0, 0, 1033);
  vi.setProductVersion(parts[0] || 0, parts[1] || 0, parts[2] || 0, 0, 1033);
  vi.setStringValues({ lang: 1033, codepage: 1200 }, {
    ProductName: 'Moe_gorod',
    FileDescription: 'Moe_gorod — gradostroitel dlya Windows',
    CompanyName: 'Drakkkkon',
    LegalCopyright: 'Drakkkkon',
    OriginalFilename: 'Moe_gorod.exe',
    InternalName: 'Moe_gorod',
    ProductVersion: pkg.version,
    FileVersion: pkg.version
  });
  vi.outputToResourceEntries(res.entries);

  res.outputResource(exeObj);
  fs.writeFileSync(exe, Buffer.from(exeObj.generate()));
  console.log('  • afterPack: значок и версия ' + pkg.version + ' записаны в ' + path.basename(exe));
};
