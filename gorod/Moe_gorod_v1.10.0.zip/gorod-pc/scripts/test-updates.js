'use strict';
// Проверка обновлений на локальном тестовом сервере (нужны Xvfb и папка game/): node scripts/test-updates.js .   (из папки gorod-pc)
const { spawn, execSync } = require('child_process');
const fs = require('fs'), path = require('path'), http = require('http'), crypto = require('crypto');
const pc = path.resolve(process.argv[2] || '.');
const { zipSync } = require(path.join(pc, 'node_modules', 'fflate'));
const  T = '/tmp/updtest', PORT = 9334, SRV = 9444, DISP = ':98';
let failed = 0;
function ok(name, cond, extra) { const l = (cond ? 'OK   ' : 'FAIL ') + name + (extra !== undefined ? '  → ' + (typeof extra === 'string' ? extra : JSON.stringify(extra)) : ''); console.log(l); if (!cond) failed++; }
const sleep = ms => new Promise(r => setTimeout(r, ms));
function getJson(url) { return new Promise((res, rej) => { http.get(url, r => { let d = ''; r.on('data', c => d += c); r.on('end', () => { try { res(JSON.parse(d)); } catch (e) { rej(e); } }); }).on('error', rej); }); }

execSync('rm -rf ' + T + ' && mkdir -p ' + T + '/srv');
// --- тестовая «новая версия» игры 1.6.1 ---
const stage = path.join(pc, 'game');
const files = {};
(function walk(d, b) { for (const n of fs.readdirSync(d)) { const p = path.join(d, n), r = b ? b + '/' + n : n; if (fs.statSync(p).isDirectory()) walk(p, r); else files[r] = new Uint8Array(fs.readFileSync(p)); } })(stage, '');
files['version.json'] = new Uint8Array(Buffer.from(JSON.stringify({ version: '1.6.1', date: 'тест', shellMin: '1.0.0' })));
fs.writeFileSync(T + '/srv/game.zip', zipSync(files, { level: 6 }));
const gz = fs.readFileSync(T + '/srv/game.zip');
const sha = crypto.createHash('sha256').update(gz).digest('hex');
let manifest = { version: '1.6.1', date: 'тест', shellMin: '1.0.0', notes: ['тестовое обновление'], game_zip: { url: 'http://127.0.0.1:' + SRV + '/game.zip', size: gz.length, sha256: sha }, setup: { url: 'http://127.0.0.1:' + SRV + '/setup.exe', size: 5, sha256: 'x', shell: '1.0.0', version: '1.6.1' } };
const srv = http.createServer((q, r) => {
  if (q.url.startsWith('/gorod.json')) { const b = Buffer.from(JSON.stringify(manifest)); r.writeHead(200, { 'content-type': 'application/json', 'content-length': b.length }); return r.end(b); }
  if (q.url === '/game.zip') { r.writeHead(200, { 'content-length': gz.length }); return r.end(gz); }
  r.writeHead(404); r.end();
}).listen(SRV);

const xvfb = spawn('Xvfb', [DISP, '-screen', '0', '1400x900x24'], { stdio: 'ignore' });
function launch() {
  const p = spawn(path.join(pc, 'node_modules/.bin/electron'), ['--no-sandbox', '--disable-gpu-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--remote-debugging-port=' + PORT, pc],
    { env: Object.assign({}, process.env, { DISPLAY: DISP, MOE_USERDATA: T + '/userdata', MOE_SAVES_DIR: T + '/saves', MOE_DEBUG: '1', MOE_MANIFEST_URL: 'http://127.0.0.1:' + SRV + '/gorod.json' }), stdio: ['ignore', 'pipe', 'pipe'] });
  p.out = ''; p.stdout.on('data', d => p.out += d); p.stderr.on('data', d => p.out += d); p.exited = new Promise(r => p.on('exit', c => r(c)));
  return p;
}
async function connect(wantNot) {
  for (let i = 0; i < 80; i++) {
    try {
      const l = await getJson('http://127.0.0.1:' + PORT + '/json');
      const pg = l.find(x => x.type === 'page' && /127\.0\.0\.1:\d+\/index/.test(x.url));
      if (pg) { const ws = new WebSocket(pg.webSocketDebuggerUrl); await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
        let id = 0; const pend = {}; ws.onmessage = m => { const o = JSON.parse(m.data); if (o.id && pend[o.id]) { pend[o.id](o); delete pend[o.id]; } };
        const call = (method, params) => new Promise(r => { const i = ++id; pend[i] = r; ws.send(JSON.stringify({ id: i, method, params })); });
        const ev = async (expr) => { const r = await call('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }); if (r.result.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 300)); return r.result.result.value; };
        return { ws, call, ev };
      }
    } catch (e) {}
    await sleep(500);
  }
  throw new Error('окно не появилось');
}
async function waitFor(c, expr, ms) { const t = Date.now(); while (Date.now() - t < ms) { const v = await c.ev(expr).catch(() => null); if (v) return v; await sleep(400); } return null; }

(async () => {
  await sleep(1500);
  let p = launch(); let c = await connect();
  await waitFor(c, '!!(window.MoeDesktop && window.__gorod)', 40000);
  ok('старт: игра 1.6.0 из установки', await c.ev("MoeDesktop.gameVersion === '1.6.0' && MoeDesktop.gameKind === 'bundled'"));

  // 1. обновление игры: найти → скачать само → готово
  const s1 = await c.ev('MoeDesktop.update.check().then(s=>({status:s.status,kind:s.kind,latest:s.latest}))');
  ok('проверка: найдена 1.6.1 (game)', s1.latest === '1.6.1' && s1.kind === 'game', s1);
  const st = await waitFor(c, "MoeDesktop.update.state().then(s=>s.status==='ready'||s.status==='error'?s:null)", 30000);
  ok('игра скачалась и распаковалась (ready)', st && st.status === 'ready' && st.kind === 'game', st && { status: st.status, error: st.error });
  const upd = path.join(T, 'userdata', 'updates', 'game-1.6.1');
  ok('папка обновления с маркером .ok', fs.existsSync(path.join(upd, '.ok')) && fs.existsSync(path.join(upd, 'index.html')), fs.existsSync(upd) ? fs.readdirSync(upd) : 'нет');
  ok('manifest не утекает в состояние', !JSON.stringify(st).includes('sha256') && !('_m' in st));

  // 2. перезапуск → стартует новая версия
  await c.ev('MoeDesktop.update.install()').catch(() => {});
  const code = await Promise.race([p.exited, sleep(20000).then(() => 'timeout')]);
  ok('старая копия закрылась после «Обновить»', code !== 'timeout', code);
  await sleep(2500);
  c = await connect(); await waitFor(c, '!!(window.MoeDesktop && window.__gorod)', 40000);
  const v2 = await c.ev('({gv: MoeDesktop.gameVersion, kind: MoeDesktop.gameKind})');
  ok('после перезапуска работает игра 1.6.1 (update)', v2.gv === '1.6.1' && v2.kind === 'update', v2);
  const s2 = await c.ev('MoeDesktop.update.check().then(s=>s.status)');
  ok('после обновления: «версия актуальна»', s2 === 'uptodate', s2);

  // 3. испорченный файл → ошибка, не ставится
  manifest = Object.assign({}, manifest, { version: '1.6.2', game_zip: Object.assign({}, manifest.game_zip, { sha256: '0'.repeat(64) }) });
  const s3 = await c.ev('MoeDesktop.update.check().then(s=>s.status)');
  const e3 = await waitFor(c, "MoeDesktop.update.state().then(s=>s.status==='error'||s.status==='ready'?s:null)", 20000);
  ok('неверная контрольная сумма → ошибка', e3 && e3.status === 'error' && /поврежд|контрол/i.test(e3.error), e3 && e3.error);
  ok('испорченное не оставлено на диске', !fs.existsSync(path.join(T, 'userdata', 'updates', 'game-1.6.2')) && !fs.existsSync(path.join(T, 'userdata', 'updates', 'download', 'Moe_gorod_game_1.6.2.zip')));

  // 4. нужна новая оболочка → предлагается установщик, сам не качается
  manifest = Object.assign({}, manifest, { version: '1.7.0', shellMin: '9.0.0' });
  const s4 = await c.ev('MoeDesktop.update.check().then(s=>({status:s.status,kind:s.kind}))');
  ok('shellMin выше → тип «setup», сам не качает', s4.status === 'available' && s4.kind === 'setup', s4);

  // 5. выключить автоскачивание
  await c.ev('MoeDesktop.update.setAuto(false)');
  manifest = Object.assign({}, manifest, { version: '1.6.3', shellMin: '1.0.0', game_zip: Object.assign({}, manifest.game_zip, { sha256: sha }) });
  const s5 = await c.ev('MoeDesktop.update.check().then(s=>({status:s.status,kind:s.kind}))');
  ok('автоскачивание выключено → ждёт нажатия', s5.status === 'available' && s5.kind === 'game', s5);

  const log = fs.readFileSync(T + '/userdata/logs/main.log', 'utf8');
  ok('в журнале нет ERROR', !/ ERROR /.test(log), (log.match(/.* ERROR .*/g) || []).slice(0, 3));
  c.call('Browser.close'); await sleep(4000);
  try { execSync('pkill -f "remote-debugging-port=' + PORT + '"'); } catch (e) {}
  console.log(failed ? '\nПРОВАЛЕНО: ' + failed : '\nВсе проверки обновлений пройдены');
  srv.close(); xvfb.kill(); process.exit(failed ? 1 : 0);
})().catch(e => { console.error('СБОЙ ТЕСТА', e); try { execSync('pkill -f "remote-debugging-port=' + PORT + '"'); } catch (x) {} xvfb.kill(); process.exit(2); });
