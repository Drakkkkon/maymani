'use strict';
// Проверка оболочки «Мое_город» на Linux (нужны xvfb-run и папка game/ — её создаёт сборка: dist/stage/game).
// Запуск: node scripts/test-shell.js .   (из папки gorod-pc)
const { spawn, execSync } = require('child_process');
const fs = require('fs'), path = require('path'), http = require('http');
const pc = path.resolve(process.argv[2] || '.'), T = '/tmp/smoke';
const PORT = 9333;
const results = []; let failed = 0;
function ok(name, cond, extra) { results.push((cond ? 'OK   ' : 'FAIL ') + name + (extra !== undefined ? '  → ' + (typeof extra === 'string' ? extra : JSON.stringify(extra)) : '')); if (!cond) failed++; console.log(results[results.length-1]); }
const sleep = ms => new Promise(r => setTimeout(r, ms));
function getJson(url) { return new Promise((res, rej) => { http.get(url, r => { let d = ''; r.on('data', c => d += c); r.on('end', () => { try { res(JSON.parse(d)); } catch (e) { rej(e); } }); }).on('error', rej); }); }

function launch(env) {
  const p = spawn('xvfb-run', ['-a', '-s', '-screen 0 1400x900x24', path.join(pc, 'node_modules/.bin/electron'), '--no-sandbox', '--disable-gpu-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--remote-debugging-port=' + PORT, pc],
    { env: Object.assign({}, process.env, { MOE_USERDATA: T + '/userdata', MOE_SAVES_DIR: T + '/saves', MOE_NO_UPDATES: '1', MOE_DEBUG: '1', MOE_ALLOW_MULTI: '1' }, env || {}), stdio: ['ignore', 'pipe', 'pipe'] });
  p.out = ''; p.stdout.on('data', d => p.out += d); p.stderr.on('data', d => p.out += d);
  p.exited = new Promise(r => p.on('exit', c => r(c)));
  return p;
}
async function connect() {
  for (let i = 0; i < 80; i++) {
    try {
      const l = await getJson('http://127.0.0.1:' + PORT + '/json');
      const pg = l.find(x => x.type === 'page' && /127\.0\.0\.1/.test(x.url));
      if (pg) { const ws = new WebSocket(pg.webSocketDebuggerUrl); await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
        let id = 0; const pend = {}; ws.onmessage = m => { const o = JSON.parse(m.data); if (o.id && pend[o.id]) { pend[o.id](o); delete pend[o.id]; } };
        const call = (method, params) => new Promise(r => { const i = ++id; pend[i] = r; ws.send(JSON.stringify({ id: i, method, params })); });
        const ev = async (expr) => { const r = await call('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }); if (r.result.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 400)); return r.result.result.value; };
        return { ws, call, ev, url: pg.url };
      }
    } catch (e) {}
    await sleep(500);
  }
  throw new Error('окно не появилось');
}

(async () => {
  execSync('rm -rf ' + T + ' && mkdir -p ' + T);
  // ===== запуск 1 =====
  let p = launch(); let c = await connect();
  ok('окно открылось, адрес локальный', /^http:\/\/127\.0\.0\.1:\d+\//.test(c.url), c.url);
  for (let i = 0; i < 60; i++) { if (await c.ev('!!(window.__gorod && window.WORLD)').catch(() => false)) break; await sleep(500); }
  ok('игра загрузилась (__gorod и WORLD есть)', await c.ev('!!(window.__gorod && window.WORLD)'));
  const info = await c.ev('({d: window.MoeDesktop && window.MoeDesktop.isDesktop, sv: window.MoeDesktop.shellVersion, gv: window.MoeDesktop.gameVersion, kind: window.MoeDesktop.gameKind, plat: window.MoeDesktop.platform, g: window.GAME.version, ui: !!window.MoeDesktopUI, persistent: WORLD.persistent()})');
  ok('MoeDesktop: версии, тип игры', info.d === true && info.gv === '1.6.0' && info.g === '1.6.0' && info.kind === 'bundled', info);
  ok('мир хранится на диске (persistent)', info.persistent === true);
  const paths = await c.ev('window.MoeDesktop.paths');
  ok('пути к папкам отдаются', !!(paths && paths.saves), paths);

  // создаём мир с демо-застройкой, ставим здания, сохраняем
  const id = await c.ev("(async()=>{ const id = await __gorod.createWorld('Тестовый мир', 200, true, true, 0); await __gorod.openWorld(id); __gorod.place('house','2x2',10,10); await __gorod.saveNow(); await WORLD.cloud.flush && 0; return id; })()");
  ok('мир создан', typeof id === 'string' && id.length > 3, id);
  await sleep(1500);
  const wdir = path.join(T, 'saves', id);
  const exists = fs.existsSync(wdir);
  ok('папка мира есть в «Сохранения»', exists, exists ? fs.readdirSync(wdir) : 'нет ' + wdir);
  if (exists) {
    ok('world.json валидный JSON', (() => { try { const j = JSON.parse(fs.readFileSync(path.join(wdir, 'world.json'), 'utf8')); return !!j; } catch (e) { return false; } })());
    const cdir = path.join(wdir, 'chunks');
    const chunks = fs.existsSync(cdir) ? fs.readdirSync(cdir).filter(n => /^\d+_\d+\.json$/.test(n)) : [];
    ok('куски карты записаны файлами', chunks.length > 0, chunks.length + ' шт.');
    ok('«Название мира.txt» лежит рядом', fs.readdirSync(wdir).some(n => /\.txt$/.test(n)), fs.readdirSync(wdir).filter(n => /\.txt$/.test(n)));
    ok('нет хвостов .tmp', !fs.readdirSync(wdir, { recursive: true }).some(n => /\.tmp$/.test(String(n))));
  }
  // переименование и удаление мира через API
  await c.ev("WORLD.rename('" + id + "', 'Переименованный')"); await sleep(600);
  const nm = await c.ev("WORLD.get('" + id + "').name");
  ok('мир переименован', nm === 'Переименованный', nm);

  // HTTP-сервер: Range, музыка (редирект), чужой Host
  const base = new URL(c.url).origin;
  const rg = await c.ev("fetch('/js/game.js',{headers:{Range:'bytes=0-99'}}).then(r=>({s:r.status,cr:r.headers.get('content-range'),n:0}))");
  ok('сервер: Range → 206', rg.s === 206 && /^bytes 0-99\//.test(rg.cr || ''), rg);
  const nf = await c.ev("fetch('/nope.html').then(r=>r.status)");
  ok('сервер: нет файла → 404', nf === 404, nf);
  const tr = await c.ev("fetch('/%2e%2e/%2e%2e/etc/passwd').then(r=>r.status)");
  ok('сервер: выход из папки закрыт', tr === 404 || tr === 403 || tr === 400, tr);
  const mus = await c.ev("fetch('/__music/01_grieg_morning.mp3',{method:'HEAD',redirect:'manual'}).then(r=>({s:r.status,t:r.type}))");
  ok('музыка: нет локального файла → редирект на сайт', mus.s === 302 || mus.t === 'opaqueredirect', mus);
  const badm = await c.ev("fetch('/__music/..%2f..%2fpasswd').then(r=>r.status)");
  ok('музыка: странное имя отклонено', badm === 404 || badm === 400 || badm === 403, badm);
  const hostBad = await new Promise(res => { const rq = http.request({ host: '127.0.0.1', port: new URL(c.url).port, path: '/', headers: { Host: 'evil.example.com' } }, r => res(r.statusCode)); rq.on('error', () => res(-1)); rq.end(); });
  ok('сервер: чужой Host отклонён', hostBad === 403 || hostBad === 400 || hostBad === 421, hostBad);
  const ms = await c.ev('window.MoeDesktop.music.stat()');
  ok('music.stat отвечает', !!ms, ms);

  // обновления (без сети: просто состояние)
  const us = await c.ev('window.MoeDesktop.update.state()');
  ok('update.state отвечает', us && us.running === '1.6.0', us && { running: us.running, status: us.status });

  // консоль: ошибки
  const errs = (fs.readFileSync(T + '/userdata/logs/main.log', 'utf8').match(/.* ERROR .*/g) || []);   // журнал самой программы (системный шум Linux не считаем)
  ok('в журнале нет ERROR', errs.length === 0, errs.slice(0, 5));

  // закрытие окна → корректное завершение с записью
  c.call('Browser.close');
  const code = await Promise.race([p.exited, sleep(15000).then(() => 'timeout')]);
  ok('программа закрылась сама', code !== 'timeout', code);
  if (code === 'timeout') { try { execSync('pkill -f "electron.*gorod-pc"'); } catch (e) {} }
  fs.writeFileSync(T + '/run1.log', p.out);

  // ===== запуск 2: миры читаются из файлов =====
  p = launch(); c = await connect();
  for (let i = 0; i < 60; i++) { if (await c.ev('!!(window.__gorod && window.WORLD)').catch(() => false)) break; await sleep(500); }
  const list = await c.ev('WORLD.ready.then(()=>WORLD.list())');
  const found = (list || []).find(w => w.id === id);
  ok('после перезапуска мир на месте', !!found, (list || []).map(w => w.id + ':' + w.name));
  ok('имя мира сохранилось', found && found.name === 'Переименованный', found && found.name);
  const op = await c.ev("(async()=>{ await __gorod.openWorld('" + id + "'); return { b: __gorod.state().buildings.length, w: __gorod.world() }; })()");
  ok('мир открывается, здания на месте', op.w === id && op.b > 0, op);
  // удаление → корзина
  await c.ev("WORLD.remove('" + id + "')"); await sleep(1500);
  const trashDir = path.join(T, 'saves', '_Удалённые');
  ok('удалённый мир ушёл в «_Удалённые»', fs.existsSync(trashDir) && fs.readdirSync(trashDir).length > 0 && !fs.existsSync(path.join(T, 'saves', id)), fs.existsSync(trashDir) ? fs.readdirSync(trashDir) : 'нет папки');
  c.call('Browser.close');
  await Promise.race([p.exited, sleep(15000)]);
  try { execSync('pkill -f "electron.*gorod-pc"'); } catch (e) {}
  fs.writeFileSync(T + '/run2.log', p.out);
  console.log(failed ? '\nПРОВАЛЕНО: ' + failed : '\nВсе проверки пройдены');
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('СБОЙ ТЕСТА', e); try { execSync('pkill -f "electron.*gorod-pc"'); } catch (x) {} process.exit(2); });
