'use strict';
// Сборка «Мое_город» для Windows. Запуск: node scripts/build.js   (работает и на Linux — wine не нужен)
// Результат в dist/release/:
//   Moe_gorod_Setup_<версия>.exe      — установщик (мастер установки, значок на рабочем столе, удаление)
//   Moe_gorod_game_v<версия>.zip      — маленькое обновление игры (скачивается программой само)
//   Moe_gorod_v<версия>.zip           — исходники игры и оболочки (без музыки и старых архивов)
//   gorod.json                        — описание обновления для сайта (updates/gorod.json)
const fs = require('fs'), path = require('path'), vm = require('vm'), crypto = require('crypto');
const { zipSync } = require('fflate');

const root = path.join(__dirname, '..');
const gameSrc = path.join(root, '..', 'gorod');
const dist = path.join(root, 'dist');
const stage = path.join(dist, 'stage');
const release = path.join(dist, 'release');
const pkg = require('../package.json');
const cfg = require('../src/config.js');
const BASE = 'https://github.com/Drakkkkon/maymani/raw/archives/gorod/';

function rm(p) { fs.rmSync(p, { recursive: true, force: true }); }
function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }

// 1. Описание игры из js/data.js
const ctx = { window: {}, console }; ctx.window.window = ctx.window; vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(gameSrc, 'js', 'data.js'), 'utf8'), ctx, { filename: 'data.js' });
const G = ctx.window.GAME;
if (G.version !== pkg.version) throw new Error('Версия игры (' + G.version + ') и package.json (' + pkg.version + ') не совпадают');
const entry = (G.changelog || []).find(function (c) { return c.v === G.version; });
if (!entry) throw new Error('В журнале изменений нет записи для ' + G.version);
console.log('Мое_город ' + G.version + ' (' + G.date + '), оболочка ' + cfg.SHELL_VERSION);

// 2. Папка game/ — только то, что нужно игре (без музыки, старых архивов и текстов)
rm(dist); fs.mkdirSync(path.join(stage, 'game'), { recursive: true }); fs.mkdirSync(release, { recursive: true });
const gameDst = path.join(stage, 'game');
function copyDir(a, b) {
  fs.mkdirSync(b, { recursive: true });
  for (const n of fs.readdirSync(a)) {
    const s = path.join(a, n), d = path.join(b, n);
    if (fs.statSync(s).isDirectory()) copyDir(s, d); else fs.copyFileSync(s, d);
  }
}
['index.html', 'icon.svg', 'GUIDE.txt', 'README.txt'].forEach(function (f) { fs.copyFileSync(path.join(gameSrc, f), path.join(gameDst, f)); });
copyDir(path.join(gameSrc, 'css'), path.join(gameDst, 'css'));
copyDir(path.join(gameSrc, 'js'), path.join(gameDst, 'js'));
fs.writeFileSync(path.join(gameDst, 'version.json'), JSON.stringify({ version: G.version, date: G.date, shellMin: '1.0.0' }, null, 1));

// 3. Zip-обновление игры (файлы лежат в корне архива)
function listFiles(dir, base, out) {
  for (const n of fs.readdirSync(dir)) {
    const p = path.join(dir, n), rel = base ? base + '/' + n : n;
    if (fs.statSync(p).isDirectory()) listFiles(p, rel, out); else out[rel] = new Uint8Array(fs.readFileSync(p));
  }
  return out;
}
const gameZip = path.join(release, 'Moe_gorod_game_v' + G.version + '.zip');
fs.writeFileSync(gameZip, zipSync(listFiles(gameDst, '', {}), { level: 9 }));
console.log('  game zip: ' + (fs.statSync(gameZip).size / 1024).toFixed(0) + ' КБ');

// 4. Установщик (electron-builder; без wine: подменяем проверку, чтобы деактив uninstaller читался чистым JS)
const mac = require(path.join(root, 'node_modules', 'app-builder-lib', 'out', 'util', 'macosVersion'));
mac.isMacOsCatalina = function () { return true; };
const { build, Platform, Arch } = require('electron-builder');
const name = 'Moe_gorod_Setup_' + G.version + '.exe';
build({
  targets: Platform.WINDOWS.createTarget(['nsis'], Arch.x64),
  projectDir: root,
  config: {
    appId: cfg.APP_ID,
    productName: 'Moe_gorod',
    copyright: 'Drakkkkon',
    electronVersion: require('../node_modules/electron/package.json').version,
    directories: { output: path.join(dist, 'out'), buildResources: path.join(root, 'build') },
    files: ['package.json', 'src/**/*', '!src/**/*.md'],
    extraResources: [{ from: gameDst, to: 'game' }],
    asar: true,
    compression: 'maximum',
    afterPack: path.join(__dirname, 'after-pack.js'),
    publish: null,
    win: { target: [{ target: 'nsis', arch: ['x64'] }], icon: path.join(root, 'build', 'icon.ico'), signAndEditExecutable: false },
    nsis: {
      oneClick: false, perMachine: false, allowToChangeInstallationDirectory: true, allowElevation: false,
      createDesktopShortcut: true, createStartMenuShortcut: true, shortcutName: 'Мое_город',
      runAfterFinish: true, deleteAppDataOnUninstall: false, differentialPackage: false,
      installerLanguages: ['ru_RU'], language: '1049',
      installerIcon: path.join(root, 'build', 'icon.ico'), uninstallerIcon: path.join(root, 'build', 'icon.ico'),
      installerHeaderIcon: path.join(root, 'build', 'icon.ico'),
      installerHeader: path.join(root, 'build', 'installerHeader.bmp'),
      installerSidebar: path.join(root, 'build', 'installerSidebar.bmp'),
      uninstallerSidebar: path.join(root, 'build', 'uninstallerSidebar.bmp'),
      uninstallDisplayName: 'Мое_город',
      include: path.join(root, 'build', 'installer.nsh'),
      artifactName: 'Moe_gorod_Setup_${version}.${ext}'
    }
  }
}).then(function () {
  const setup = path.join(release, name);
  fs.copyFileSync(path.join(dist, 'out', name), setup);
  console.log('  установщик: ' + (fs.statSync(setup).size / 1048576).toFixed(1) + ' МБ');

  // 5. Исходники (без node_modules, dist, музыки и старых архивов)
  const src = {};
  function addDir(dir, base, skip) {
    for (const n of fs.readdirSync(dir)) {
      if (skip && skip(n, base)) continue;
      const p = path.join(dir, n), rel = base + '/' + n;
      if (fs.statSync(p).isDirectory()) addDir(p, rel, skip); else src[rel] = new Uint8Array(fs.readFileSync(p));
    }
  }
  addDir(gameSrc, 'gorod', function (n, base) { return (base === 'gorod' && n === 'music') || /^Moe_gorod_v.*\.zip$/.test(n); });
  addDir(root, 'gorod-pc', function (n) { return n === 'node_modules' || n === 'dist' || n === 'game' || /\.log$/.test(n); });
  const srcZip = path.join(release, 'Moe_gorod_v' + G.version + '.zip');
  fs.writeFileSync(srcZip, zipSync(src, { level: 9 }));
  console.log('  исходники: ' + (fs.statSync(srcZip).size / 1024).toFixed(0) + ' КБ');

  // 6. Описание обновления для сайта
  const manifest = {
    app: 'Мое_город', version: G.version, date: G.date, shellMin: '1.0.0', shell: cfg.SHELL_VERSION,
    notes: entry.items,
    game_zip: { url: BASE + path.basename(gameZip), size: fs.statSync(gameZip).size, sha256: sha256(gameZip) },
    setup: { url: BASE + name, size: fs.statSync(setup).size, sha256: sha256(setup), shell: cfg.SHELL_VERSION, version: G.version }
  };
  fs.writeFileSync(path.join(release, 'gorod.json'), JSON.stringify(manifest, null, 1));
  console.log('Готово: ' + release);
}).catch(function (e) { console.error('СБОРКА НЕ УДАЛАСЬ:', (e && e.stack) || e); process.exit(1); });
