'use strict';
// =====================================================================================================
// iLife 2.14.0 — «СЕГОДНЯ», РАЗДЕЛЫ МЕНЮ («Ещё» и скрытие), КОРЗИНА, НЕДЕЛЬНАЯ КОПИЯ НА ДИСК,
// ПЕРЕНОС «ЗАМЕТКИ → ДЕЛА» В «МОЙ ДЕНЬ», настроение в «Дневнике».
// =====================================================================================================

(function () {
    if (!window.ICONS) return;
    Object.assign(window.ICONS, {
        more_horiz: '<path d="M6 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2m12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2m-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2"/>',
        fingerprint: '<path d="M17.81 4.47c-.08 0-.16-.02-.23-.06C15.66 3.42 14 3 12.01 3c-1.98 0-3.86.47-5.57 1.41-.24.13-.54.04-.68-.2s-.04-.55.2-.68C7.82 2.52 9.86 2 12.01 2c2.13 0 3.99.47 6.03 1.52.25.13.34.43.21.67-.09.18-.26.28-.44.28M3.5 9.72a.499.499 0 0 1-.41-.79c.99-1.4 2.25-2.5 3.75-3.27C9.98 4.04 14 4.03 17.15 5.65c1.5.77 2.76 1.86 3.75 3.25.16.22.11.54-.12.7s-.54.11-.7-.12a9.4 9.4 0 0 0-3.39-2.94c-2.87-1.47-6.54-1.47-9.4.01-1.36.7-2.5 1.7-3.4 2.96-.08.14-.23.21-.39.21m6.25 12.07a.47.47 0 0 1-.35-.15c-.87-.87-1.34-1.43-2.01-2.64-.69-1.23-1.05-2.73-1.05-4.34 0-2.97 2.54-5.39 5.66-5.39s5.66 2.42 5.66 5.39c0 .28-.22.5-.5.5s-.5-.22-.5-.5c0-2.42-2.09-4.39-4.66-4.39s-4.66 1.97-4.66 4.39c0 1.44.32 2.77.93 3.85.64 1.15 1.08 1.64 1.85 2.42.19.2.19.51 0 .71-.11.1-.24.15-.37.15m7.17-1.85c-1.19 0-2.24-.3-3.1-.89-1.49-1.01-2.38-2.65-2.38-4.39 0-.28.22-.5.5-.5s.5.22.5.5c0 1.41.72 2.74 1.94 3.56.71.48 1.54.71 2.54.71.24 0 .64-.03 1.04-.1.27-.05.53.13.58.41s-.13.53-.41.58c-.57.11-1.07.12-1.21.12M14.91 22c-.04 0-.09-.01-.13-.02-1.59-.44-2.63-1.03-3.72-2.1a7.3 7.3 0 0 1-2.17-5.22c0-1.62 1.38-2.94 3.08-2.94s3.08 1.32 3.08 2.94c0 1.07.93 1.94 2.08 1.94s2.08-.87 2.08-1.94c0-3.77-3.25-6.83-7.25-6.83-2.84 0-5.44 1.58-6.61 4.03-.39.81-.59 1.76-.59 2.8 0 .78.07 2.01.67 3.61.1.26-.03.55-.29.64s-.55-.04-.64-.29a11.1 11.1 0 0 1-.73-3.96c0-1.2.23-2.29.68-3.24 1.33-2.79 4.28-4.6 7.51-4.6 4.55 0 8.25 3.51 8.25 7.83 0 1.62-1.38 2.94-3.08 2.94s-3.08-1.32-3.08-2.94c0-1.07-.93-1.94-2.08-1.94s-2.08.87-2.08 1.94c0 1.71.66 3.31 1.87 4.51.95.94 1.86 1.46 3.27 1.85.27.07.42.35.35.61-.05.23-.26.38-.47.38"/>'
    });
})();

// =====================================================================================================
// ПЕРЕНОС ДЕЛ из «Заметок» в «Мой день». Номер новой записи зависит только от номера старой, поэтому два
// устройства получают одно и то же дело, а не два. Исходные записи сохраняются на устройстве в ilife_todos_before_214.
// =====================================================================================================
function taskFromTodo(t) {
    const day = t.due || '', time = /^\d{2}:\d{2}$/.test(t.time || '') ? t.time : (day ? '09:00' : '');   // дела со сроком без времени напоминали в 09:00
    const date = day || (time ? dayKey(t.addedAt || Date.now()) : '');
    const rec = { id: 'wtm_' + t.id, kind: 'task', text: t.name || '', note: '', times: time ? [time] : [], mode: date ? 'once' : 'someday',
        date, from: date, to: date, wd: [], every: 2, notify: true, rateId: '', done: {}, createdAt: t.addedAt || Date.now(), author: t.author || authorName() };
    if (t.done) { if (date) rec.done[date] = [time || '*']; else rec.doneAt = t.doneAt || Date.now(); }
    return rec;
}
function migrateTodoTasks() {
    const old = todos.filter(t => t && t.type === 'task');
    if (!old.length) return 0;
    const keep = LS.get('todos_before_214', []), seen = new Set(keep.map(t => t.id));
    if (!LS.set('todos_before_214', keep.concat(old.filter(t => !seen.has(t.id))).slice(-2000))) return 0;
    const added = [];
    old.forEach(t => { if (!wkById('wtm_' + t.id)) { const rec = taskFromTodo(t); dayplan.push(rec); added.push([rec, Number(t.updatedAt) || Number(t.addedAt) || 1]); } });
    if (!LS.set('dayplan', dayplan)) return 0;   // старые записи убираем только когда новые уже сохранены
    todos = todos.filter(t => !t || t.type !== 'task');
    saveDayPlan(); saveTodos();
    added.forEach(([rec, at]) => { rec.updatedAt = at; });
    LS.set('dayplan', dayplan);
    renderTodo();
    return old.length;
}

// =====================================================================================================
// «СЕГОДНЯ»
// =====================================================================================================
// Невыполненные разовые дела прошлых дней
function tdOverdue(today) {
    const out = [];
    wkList('task').forEach(t => {
        if (t.mode !== 'once' || !(t.date < today)) return;
        wkSlots(t).forEach(tm => { if (!wkIsDone(t, t.date, tm)) out.push({ task: t, time: tm, date: t.date }); });
    });
    return out.sort((a, b) => a.date.localeCompare(b.date));
}
// Записи этого числа месяц назад и в прошлые годы
function tdMemories(today) {
    const md = today.slice(5), p = almatyParts(), last = new Date(Date.UTC(p.y, p.mo, 0)), ago = new Date(Date.UTC(p.y, p.mo - 1, p.d));
    const monthKey = ago.getUTCMonth() === last.getUTCMonth() ? ago.toISOString().slice(0, 10) : '';
    const hit = k => k === monthKey || (k.slice(5) === md && k < today);
    const out = [];
    if (!lkLocked('diary')) diary.forEach(e => { if (e.text && hit(e.date)) out.push({ date: e.date, icon: 'auto_stories', text: e.text, go: 'diary' }); });
    ideas.forEach(i => { const k = dayKey(i.createdAt); if (i.text && hit(k)) out.push({ date: k, icon: 'lightbulb', text: i.text, go: 'ideas' }); });
    return out.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8);
}
function tdRow(on, data, title, sub) {
    return '<label class="td-row' + (on ? ' is-done' : '') + '"><input type="checkbox" class="check" ' + data + (on ? ' checked' : '') + '><span><b>' + esc(title) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span></label>';
}
function tdCard(icon, title, body, tab) {
    return '<div class="card td-card"><h3 class="card-title"><span class="ico">' + ic(icon) + '</span><span class="ttl">' + title + '</span>' +
        (tab ? '<button type="button" class="icon-btn" data-go="' + tab + '" aria-label="Открыть раздел «' + title + '»">' + ic('chevron_right') + '</button>' : '') + '</h3><div class="card-body">' + body + '</div></div>';
}
function renderToday() {
    const host = $('#td-body'); if (!host) return;
    const today = todayKey();
    $('#td-date').textContent = capitalizeFirst(medDayFull(today));
    let html = '';
    const task = (d, key, sub) => tdRow(d.done, 'data-task="' + esc(d.task.id + '|' + key + '|' + d.time) + '"', d.task.text, sub);
    const late = tdOverdue(today).map(d => task(d, d.date, 'срок ' + fmtDayKey(d.date)));
    const mine = wkItemsOn(today).map(d => task(d, today, d.time === '*' ? '' : d.time));
    const some = wkList('task').filter(t => t.mode === 'someday' && (!t.doneAt || dayKey(t.doneAt) === today))
        .map(t => tdRow(!!t.doneAt, 'data-some="' + esc(t.id) + '"', t.text, 'без срока'));
    const rows = late.concat(mine, some);
    html += tdCard('task_alt', 'Дела', rows.join('') || '<p class="hint">На сегодня дел нет.</p>', 'day-plan') + '<button type="button" class="btn" id="td-add">' + ic('add') + 'Добавить дело</button>';
    const doses = medDosesOn(today);
    if (doses.length) html += tdCard('medication', 'Лекарства', doses.map(d => tdRow(d.taken, 'data-med="' + esc(d.key) + '"', d.plan.drug, [d.time, d.plan.dose, d.plan.note].filter(Boolean).join(' · '))).join(''), 'med-schedule');
    const habits = exList('habit');
    if (habits.length) html += tdCard('repeat_habit', 'Привычки', habits.map(h => tdRow(hbMarks(h.id).has(today), 'data-habit="' + esc(h.id) + '"', h.name, '')).join(''), 'day-habits');
    const dates = exList('person').map(p => ({ p, next: ppNext(p, today) })).filter(x => medDaysBetween(today, x.next) <= 7).sort((a, b) => a.next.localeCompare(b.next));
    if (dates.length) html += tdCard('cake', 'Ближайшие даты', dates.map(x => '<p class="td-line"><b>' + esc(x.p.name) + '</b> — ' + esc(ppWhat(x.p, x.next)) + ', ' + ppIn(medDaysBetween(today, x.next)) + '</p>').join(''), 'day-people');
    const mem = tdMemories(today);
    if (mem.length) html += tdCard('history', 'В этот день', mem.map(m => '<button type="button" class="chat-pick" data-mem="' + m.go + '|' + m.date + '">' + ic(m.icon) + '<span><b>' + esc(fmtDayKey(m.date, true)) + '</b><small>' + esc(m.text.slice(0, 140)) + '</small></span></button>').join(''), '');
    host.innerHTML = html;
}
function initToday() {
    const host = $('#td-body'); if (!host) return;
    host.addEventListener('change', e => {
        const d = e.target.dataset, on = e.target.checked;
        if (d.task) { const [id, day, time] = d.task.split('|'); const t = wkById(id); if (t) { wkSetDone(t, day, time, on); saveDayPlan(); } }
        else if (d.some) { const t = wkById(d.some); if (t) { if (on) t.doneAt = Date.now(); else delete t.doneAt; saveDayPlan(); } }
        else if (d.med) { const [id, day, time] = d.med.split('|'); const p = medById(id); if (p) { medSetTaken(p, day, time, on); saveMeds(); medScheduleChanged(); } }
        else if (d.habit) hbToggle(d.habit, todayKey());
        renderToday();
    });
    host.addEventListener('click', e => {
        const go = e.target.closest('[data-go]'), mem = e.target.closest('[data-mem]');
        if (e.target.closest('#td-add')) wkTaskSheet(null, { date: todayKey(), onSave: renderToday });
        else if (go) showTab(go.dataset.go);
        else if (mem) { const [tab, date] = mem.dataset.mem.split('|'); if (tab === 'diary') { dyDay = date; showTab('diary'); } else { showTab('ideas'); const q = $('#idea-search'); q.value = fmtDateShort(keyToMs(date)); q.dispatchEvent(new Event('input')); } }
    });
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && settings.lastTab === 'today') renderToday(); });
}

// =====================================================================================================
// РАЗДЕЛЫ МЕНЮ: каждый можно оставить в меню, убрать в «Ещё» или скрыть. Настройка своя на каждом устройстве.
// =====================================================================================================
const MN_SECTIONS = [['messages', 'Сообщения'], ['notes', 'Заметки'], ['media', 'Медиа'], ['day', 'Мой день'], ['diary', 'Дневник'], ['comics', 'Комиксы'], ['dnd', 'ДНД'], ['med', 'Лекарства']];
const MN_DEFAULT = { comics: 'more', dnd: 'more' };
const MN_PLACES = { menu: 'в меню', more: 'в «Ещё»', hidden: 'скрыт' };
function mnPlace(k) { const v = LS.get('menu', {})[k]; return MN_PLACES[v] ? v : MN_DEFAULT[k] || 'menu'; }
function mnSelector(k) { return k === 'messages' ? '[data-tab="messages"]' : '[data-group-open="' + k + '"]'; }
function mnApply() {
    MN_SECTIONS.forEach(([k]) => $$('.main-nav ' + mnSelector(k)).forEach(b => { b.hidden = mnPlace(k) !== 'menu'; }));
    const anyMore = MN_SECTIONS.some(([k]) => mnPlace(k) === 'more');
    $$('.main-nav [data-more]').forEach(b => { b.hidden = !anyMore; });
    const bar = $('.mobile-nav.main-nav'); if (!bar) return;
    const shown = $$('button', bar).filter(b => !b.hidden), n = shown.length;
    const top = n > 5 ? Math.ceil(n / 2) : n, low = n - top;
    bar.style.gridTemplateColumns = 'repeat(' + top * (low || 1) + ', minmax(0, 1fr))';
    shown.forEach((b, i) => { b.style.gridColumn = 'span ' + (i < top ? low || 1 : top); });
}
function mnMore() {
    const node = document.createElement('div');
    node.innerHTML = MN_SECTIONS.filter(([k]) => mnPlace(k) === 'more').map(([k, name]) => '<button type="button" class="chat-pick" data-sec="' + k + '"><span><b>' + name + '</b></span></button>').join('');
    const sheet = openSheet({ title: 'Ещё', node });
    node.addEventListener('click', e => { const b = e.target.closest('[data-sec]'); if (!b) return; sheet.close(); setTimeout(() => $('.sidebar-nav.main-nav ' + mnSelector(b.dataset.sec)).click(), 220); });
}
function renderMenuCard() {
    const box = $('#menu-body'); if (!box) return;
    box.innerHTML = '<p class="hint">Что держать в меню, что убрать под «Ещё», а что скрыть. Записи не удаляются. Настройка действует на этом устройстве.</p>' +
        MN_SECTIONS.map(([k, name]) => '<label class="mn-row"><b>' + name + '</b><select data-mn="' + k + '">' + Object.entries(MN_PLACES).map(([v, label]) => '<option value="' + v + '"' + (mnPlace(k) === v ? ' selected' : '') + '>' + label + '</option>').join('') + '</select></label>').join('');
}

// =====================================================================================================
// КОРЗИНА: удалённое хранится 30 дней. Список trash синхронизируется, чтобы вложения не пропали.
// { id:'tr_список_номер', list, item, at, updatedAt }
// =====================================================================================================
const TRASH_TTL = 30 * 86400000;
let trash = LS.get('trash', []);
if (!Array.isArray(trash)) trash = [];
const TRASH_NAMES = { ideas: 'Идея', todos: 'Покупка', movies: 'Кино', scripts: 'Сценарий', dnd: 'Игра ДНД', meds: 'Лекарства', diary: 'Дневник', dayplan: 'Мой день', extra: 'Привычки и даты' };
function trashSave() { LS.set('trash', trash); }
// Вызывается из gStamp, когда запись пропала из списка (js/gdrive.js)
function trashPut(list, json) {
    if (!TRASH_NAMES[list]) return;
    const item = JSON.parse(json);
    if (list === 'todos' && wkById('wtm_' + item.id)) return;   // перенос в «Мой день», а не удаление
    if (list === 'dayplan' && !['task', 'rate', 'log'].includes(item.kind)) return;
    if (list === 'extra' && item.kind === 'mark' && extra.some(x => x.id === item.habit)) return;   // просто сняли отметку
    const id = 'tr_' + list + '_' + item.id;
    trash = trash.filter(x => x.id !== id);
    trash.push({ id, list, item, at: Date.now() });
    trashSave();
}
function trashList(key) { const l = G_LISTS.find(x => x.key === key); return l ? l.get() : null; }
function trashRefs() {
    const out = new Set();
    trash.forEach(t => {
        const items = [t.item];
        mediaRefs(items).forEach(id => out.add(id));
        if (t.list === 'dnd' && typeof dndMediaRefs === 'function') dndMediaRefs(items).forEach(id => out.add(id));
    });
    return out;
}
function trashRestore(id) {
    const t = trash.find(x => x.id === id); if (!t) return;
    const list = trashList(t.list); if (!list) return;
    const back = x => { if (list.some(i => i.id === x.item.id)) return; delete x.item.updatedAt; list.push(x.item); };
    // вместе с привычкой возвращаются её отметки
    const group = t.list === 'extra' && t.item.kind === 'habit' ? trash.filter(x => x === t || (x.list === 'extra' && x.item.habit === t.item.id)) : [t];
    if (t.list === 'diary' && list.some(e => e.date === t.item.date)) { toast('За этот день уже есть новая запись — сначала удалите её'); return; }
    group.forEach(back);
    trash = trash.filter(x => !group.includes(x)); trashSave();
    cloudLocalChanged();
    const g = G_LISTS.find(x => x.key === t.list); if (g) LS.set(t.list === 'dnd' ? 'dnd_games' : t.list, g.get());
    renderIdeas(); renderTodo(); renderMovies(); renderScripts(); renderDayPlan(); renderStorageInfo(); extraAfterSync(); medsAfterSync(); dyAfterSync(); if (typeof dndAfterSync === 'function') dndAfterSync();
    toast('Восстановлено');
}
// Убирает записи из корзины навсегда вместе с их вложениями
async function trashDrop(items) {
    if (!items.length) return;
    const gone = new Set(items);
    const refs = new Set();
    items.forEach(t => { mediaRefs([t.item]).forEach(id => refs.add(id)); if (t.list === 'dnd' && typeof dndMediaRefs === 'function') dndMediaRefs([t.item]).forEach(id => refs.add(id)); });
    trash = trash.filter(x => !gone.has(x)); trashSave();
    cloudLocalChanged();
    const used = gAllMediaRefs();
    for (const id of refs) if (!used.has(id)) await BlobDB.del(id);
}
function trashTitle(t) {
    const i = t.item;
    return String(i.title || i.name || i.text || i.drug || i.diagnosis || i.date || 'Запись').split('\n')[0].slice(0, 80);
}
function renderTrashCard() {
    const box = $('#trash-body'); if (!box) return;
    const list = trash.filter(t => !(t.list === 'extra' && t.item.kind === 'mark') && !(t.list === 'diary' && lkLocked('diary'))).sort((a, b) => b.at - a.at);
    $('#trash-badge').textContent = list.length ? String(list.length) : '';
    box.innerHTML = '<p class="hint">Удалённое хранится 30 дней. Песни, фото и видео «Мое_совсек», сообщения и отдельные вложения, убранные из записи, в корзину не попадают.</p>' +
        (list.length ? list.slice(0, 100).map(t => '<div class="tr-row" data-id="' + esc(t.id) + '"><span><b>' + esc(trashTitle(t)) + '</b><small>' + TRASH_NAMES[t.list] + ' · удалено ' + esc(fmtDate(t.at)) + '</small></span>' +
            '<button type="button" class="btn" data-tr="back">Вернуть</button><button type="button" class="icon-btn is-danger" data-tr="drop" aria-label="Удалить навсегда">' + ic('delete') + '</button></div>').join('') +
            '<div class="btn-group"><button type="button" class="btn" data-tr="empty">' + ic('delete_sweep') + 'Очистить корзину</button></div>' : '<p class="hint">Корзина пуста.</p>');
}

// =====================================================================================================
// НЕДЕЛЬНАЯ КОПИЯ на Google Диске: iLife/Копии/iLife_копия_ДАТА.json — только записи, без вложений и ключей.
// =====================================================================================================
const WEEK_BK_EVERY = 7 * 86400000, WEEK_BK_KEEP = 8;
let weekBkRunning = false;
function weekBkData() {
    const s = gLocalSnapshot();
    delete s.keys; delete s.keysAt; delete s.deleted; delete s.scalars; delete s.scalarsAt;
    return Object.assign(s, { app: 'iLife', version: APP_VERSION, exportedAt: new Date().toISOString(), settings, noMedia: true });
}
async function weekBkFolder() { return gEnsureFolder('Копии', await gRootFolder(), 'g_bk_folder'); }
async function weekBkList() { return gList("'" + (await weekBkFolder()) + "' in parents and trashed=false", 'id,name,createdTime', 100); }
async function weekBackup(force) {
    if (weekBkRunning || !gUser || !hasValidToken() || (!force && Date.now() - LS.get('g_bk_at', 0) < WEEK_BK_EVERY)) return false;
    weekBkRunning = true;
    try {
        const folder = await weekBkFolder(), name = 'iLife_копия_' + todayKey() + '.json';
        await gUploadBlob(folder, name, name, new Blob([JSON.stringify(weekBkData())], { type: 'application/json' }), 'application/json');
        LS.set('g_bk_at', Date.now());
        const old = (await weekBkList()).sort((a, b) => String(b.createdTime).localeCompare(String(a.createdTime))).slice(WEEK_BK_KEEP);
        for (const f of old) await gFetch(G_DRIVE_API + '/files/' + encodeURIComponent(f.id) + '?fields=id', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ trashed: true }) });
        renderStorageInfo();
        return true;
    } catch (e) { console.warn('Недельная копия не сохранилась', e); return false; }
    finally { weekBkRunning = false; }
}
async function weekBkRestore() {
    if (!gUser || !hasValidToken()) { toast('Сначала подключите Google Диск'); return; }
    let files;
    try { files = (await weekBkList()).sort((a, b) => String(b.name).localeCompare(String(a.name))); } catch (e) { toast('Не удалось получить список копий'); return; }
    if (!files.length) { toast('Копий на Диске ещё нет'); return; }
    const node = document.createElement('div');
    node.innerHTML = files.map(f => '<button type="button" class="chat-pick" data-f="' + esc(f.id) + '">' + ic('restore') + '<span><b>' + esc(f.name.replace(/^iLife_копия_|\.json$/g, '')) + '</b></span></button>').join('');
    const sheet = openSheet({ title: 'Копии на Google Диске', node });
    node.addEventListener('click', async e => {
        const b = e.target.closest('[data-f]'); if (!b) return;
        sheet.close();
        try { const blob = await (await gFetch(G_DRIVE_API + '/files/' + encodeURIComponent(b.dataset.f) + '?alt=media')).blob(); if (await lkAsk()) restoreData(blob); }
        catch (err) { toast('Не удалось скачать копию'); }
    });
}

// ---------- Настроение прямо в «Записи дня» ----------
function renderDyMood() {
    const host = $('#dy-mood'); if (!host) return;
    const rec = moodRec(dyDay), cur = rec ? rec.mood : '';
    host.innerHTML = dyDay > todayKey() ? '' : MOODS.map(m => '<button type="button" class="chip' + (m.k === cur ? ' is-on' : '') + '" data-mood="' + m.k + '" aria-pressed="' + (m.k === cur) + '">' + m.e + ' ' + esc(m.n) + '</button>').join('');
}

function initHome() {
    initToday();
    document.addEventListener('click', e => { if (e.target.closest('[data-more]')) mnMore(); });
    $('#menu-body').addEventListener('change', e => { const s = e.target.closest('[data-mn]'); if (!s) return; LS.set('menu', Object.assign(LS.get('menu', {}), { [s.dataset.mn]: s.value })); mnApply(); });
    renderMenuCard(); mnApply();
    $('#trash-body').addEventListener('click', async e => {
        const b = e.target.closest('[data-tr]'); if (!b) return;
        const row = b.closest('[data-id]');
        if (b.dataset.tr === 'back') trashRestore(row.dataset.id);
        else if (b.dataset.tr === 'drop') { if (await confirmSheet('Удалить навсегда?', 'Вернуть эту запись будет нельзя.', 'Удалить', true)) await trashDrop(trash.filter(t => t.id === row.dataset.id)); }
        else if (await confirmSheet('Очистить корзину?', 'Всё из корзины будет удалено навсегда.', 'Очистить', true)) await trashDrop(trash.slice());
        renderTrashCard();
    });
    $('#week-bk-now').addEventListener('click', async () => { if (!gUser || !hasValidToken()) toast('Сначала подключите Google Диск'); else toast((await weekBackup(true)) ? 'Копия сохранена на Диск' : 'Не удалось сохранить копию'); });
    $('#week-bk-restore').addEventListener('click', weekBkRestore);
    $('#dy-mood').addEventListener('click', e => { const b = e.target.closest('[data-mood]'); if (!b) return; const rec = moodRec(dyDay), same = rec && rec.mood === b.dataset.mood; moodSet(dyDay, { mood: same ? '' : b.dataset.mood, color: '' }); renderDyMood(); });
}
// После запуска и после каждой синхронизации
function homeAfterData() {
    const n = migrateTodoTasks();
    renderDayPlan();
    if (n && !LS.get('moved_told', false)) { LS.set('moved_told', true); toast('Дела из «Заметок» перенесены в «Мой день»', { ms: 8000 }); }
    trashDrop(trash.filter(t => Date.now() - t.at > TRASH_TTL));
    const tab = settings.lastTab;
    if (tab === 'today') renderToday();
    if (tab === 'settings') renderTrashCard();
}
