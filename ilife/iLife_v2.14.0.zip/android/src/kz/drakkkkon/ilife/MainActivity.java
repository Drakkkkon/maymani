package kz.drakkkkon.ilife;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.annotation.TargetApi;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.OutputStream;
import org.json.JSONObject;

/** Оболочка сайта iLife: новые версии сайта появляются в приложении сами. */
public class MainActivity extends Activity {
    private static final String HOME = "https://drakkkkon.github.io/ilife/";
    private static final String NOTIFICATIONS = "android.permission.POST_NOTIFICATIONS";
    private static final String MIC = "android.permission.RECORD_AUDIO";
    private static final int PICK = 1, SAVE = 2, ASK = 3, ASK_MIC = 4;
    private WebView web;
    private ValueCallback<Uri[]> picker;
    private PermissionRequest micRequest;
    private byte[] saveData;
    private volatile String open = "";
    private GoogleAuth google;
    private volatile Updater.Release update;
    private volatile String updateText = "";
    private long lastUpdateCheck;
    private boolean checking, waitingPermission;
    private int offered;
    private AlertDialog offer;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        FrameLayout root = new FrameLayout(this);
        root.addView(web);
        // не залезаем под строку состояния, кнопки навигации и клавиатуру
        root.setOnApplyWindowInsetsListener((View v, WindowInsets in) -> {
            v.setPadding(in.getSystemWindowInsetLeft(), in.getSystemWindowInsetTop(),
                    in.getSystemWindowInsetRight(), in.getSystemWindowInsetBottom());
            return in.consumeSystemWindowInsets();
        });
        setContentView(root);
        google = new GoogleAuth(this, json -> js("window.ilGoogle&&ilGoogle(" + json + ")"));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        web.addJavascriptInterface(new Bridge(), "iLifeNative");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                if (request.getUrl().toString().startsWith(HOME)) return false;
                // всё чужое открываем в браузере
                String scheme = request.getUrl().getScheme();
                if ("https".equals(scheme) || "http".equals(scheme) || "mailto".equals(scheme) || "tg".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl()));
                    } catch (ActivityNotFoundException e) {
                        say("Нечем открыть ссылку");
                    }
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (!request.isForMainFrame()) return;
                view.loadDataWithBaseURL(null, "<meta charset=utf-8><meta name=viewport content='width=device-width'>"
                        + "<body style='font:18px sans-serif;text-align:center;padding:40px'>Нет связи с сайтом."
                        + "<p><a href='" + HOME + "'>Повторить</a></p>", "text/html", "utf-8", null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (picker != null) picker.onReceiveValue(null);
                picker = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                        .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(i, PICK);
                } catch (ActivityNotFoundException e) {
                    picker = null;
                    return false;
                }
                return true;
            }

            // диктофон: микрофон только для самого iLife
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean audio = false;
                    for (String r : request.getResources()) audio |= PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r);
                    if (!audio || !HOME.startsWith(request.getOrigin().toString())) {
                        request.deny();
                    } else if (checkSelfPermission(MIC) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        micRequest = request;
                        requestPermissions(new String[]{MIC}, ASK_MIC);
                    }
                });
            }
        });

        readIntent(getIntent());
        if (state == null || web.restoreState(state) == null) web.loadUrl(HOME);
        Notify.arm(getApplicationContext());
        if (state == null && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !getPreferences(MODE_PRIVATE).getBoolean("asked", false)) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("asked", true).apply();
            requestPermissions(new String[]{NOTIFICATIONS}, ASK);
        }
    }

    private void readIntent(Intent intent) {
        String value = intent == null ? null : intent.getStringExtra("open");
        if (value != null) open = value;
    }

    private void js(String code) {
        web.evaluateJavascript(code, null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        readIntent(intent);
        js("window.ilResume&&ilResume()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        js("window.ilResume&&ilResume()");
        if (waitingPermission) {
            waitingPermission = false;
            if (getPackageManager().canRequestPackageInstalls()) installUpdate();
        } else if (System.currentTimeMillis() - lastUpdateCheck > 3 * 3600_000L) {
            checkUpdate(false);
        }
    }

    private void checkUpdate(boolean asked) {
        if (checking) return;
        checking = true;
        lastUpdateCheck = System.currentTimeMillis();
        new Thread(() -> {
            Updater.Release found = null;
            String text;
            try {
                found = Updater.fetch(getApplicationContext());
                text = found == null ? "Установлена последняя версия." : "Версия " + found.version + " скачана.";
            } catch (Exception e) {
                text = "Не получилось проверить обновление. Проверьте интернет и попробуйте ещё раз.";
                lastUpdateCheck = 0;
            }
            final Updater.Release result = found;
            final String message = text;
            runOnUiThread(() -> {
                checking = false;
                if (isDestroyed()) return;
                update = result;
                updateText = message;
                js("window.ilUpdate&&ilUpdate()");
                if (result != null && !isFinishing() && (asked || offered != result.code)) offerUpdate(result);
            });
        }).start();
    }

    private void offerUpdate(Updater.Release r) {
        if (offer != null && offer.isShowing()) return;
        offered = r.code;
        offer = new AlertDialog.Builder(this, android.R.style.Theme_Material_Light_Dialog_Alert)
                .setTitle("Доступна версия " + r.version)
                .setMessage(r.notes)
                .setPositiveButton("Обновить", (d, w) -> installUpdate())
                .setNegativeButton("Позже", null)
                .show();
    }

    private void installUpdate() {
        Updater.Release r = update;
        if (r == null) {
            checkUpdate(true);
            return;
        }
        if (!getPackageManager().canRequestPackageInstalls()) {
            say("Разрешите установку для «iLife» и вернитесь назад");
            waitingPermission = true;
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException e) {
                waitingPermission = false;
                say("Разрешите установку из этого источника в настройках Android");
            }
            return;
        }
        new Thread(() -> {
            try {
                Updater.install(getApplicationContext(), r.file);
            } catch (Exception e) {
                // файл мог пропасть из кэша: при следующей попытке скачаем заново
                runOnUiThread(() -> {
                    update = null;
                    say("Не получилось начать установку. Нажмите «Проверить обновление».");
                });
            }
        }).start();
    }

    private void say(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    @TargetApi(28)
    private void askFingerprint() {
        new BiometricPrompt.Builder(this)
                .setTitle("iLife")
                .setNegativeButton("Ввести код", getMainExecutor(), (d, w) -> js("window.ilBio&&ilBio(false)"))
                .build()
                .authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        js("window.ilBio&&ilBio(true)");
                    }

                    @Override
                    public void onAuthenticationError(int code, CharSequence message) {
                        js("window.ilBio&&ilBio(false)");
                    }
                });
    }

    private class Bridge {
        // Отпечаток пальца для «Замка на личное»: сам отпечаток приложение не видит, Android отвечает только «да» или «нет»
        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public boolean bioAvailable() {
            if (Build.VERSION.SDK_INT >= 29) {
                BiometricManager manager = getSystemService(BiometricManager.class);
                return manager != null && manager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
            }
            return Build.VERSION.SDK_INT == 28 && getPackageManager().hasSystemFeature(PackageManager.FEATURE_FINGERPRINT);
        }

        @JavascriptInterface
        public void bioAsk() {
            if (Build.VERSION.SDK_INT >= 28) runOnUiThread(MainActivity.this::askFingerprint);
        }

        @JavascriptInterface
        public void notifySchedule(String json) {
            Notify.schedule(getApplicationContext(), json);
        }

        @JavascriptInterface
        public boolean notifyAllowed() {
            return Notify.allowed(getApplicationContext());
        }

        @JavascriptInterface
        public void notifyAllow() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        && (!getPreferences(MODE_PRIVATE).getBoolean("asked", false) || shouldShowRequestPermissionRationale(NOTIFICATIONS))) {
                    getPreferences(MODE_PRIVATE).edit().putBoolean("asked", true).apply();
                    requestPermissions(new String[]{NOTIFICATIONS}, ASK);
                } else if (!Notify.allowed(MainActivity.this)) {
                    notifySettings(); // Android больше не спросит сам
                    js("window.ilAllowed&&ilAllowed(false)");
                } else {
                    js("window.ilAllowed&&ilAllowed(true)");
                }
            });
        }

        @JavascriptInterface
        public void notifyTest() {
            Notify.test(getApplicationContext());
        }

        @JavascriptInterface
        public void notifySettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())));
        }

        @JavascriptInterface
        public String takeDone() {
            return Notify.takeDone(getApplicationContext());
        }

        @JavascriptInterface
        public String takeOpen() {
            String value = open;
            open = "";
            return value;
        }

        @JavascriptInterface
        public void googleToken(String id, String scope, boolean silent) {
            runOnUiThread(() -> google.token(id, scope, silent));
        }

        @JavascriptInterface
        public void googleSignOut(String token) {
            runOnUiThread(() -> google.signOut(token));
        }

        @JavascriptInterface
        public String updateStatus() {
            try {
                Updater.Release r = update;
                return new JSONObject().put("installed", Updater.installedName(MainActivity.this))
                        .put("available", r == null ? "" : r.version).put("text", updateText).toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void updateCheck() {
            runOnUiThread(() -> checkUpdate(true));
        }

        @JavascriptInterface
        public void updateInstall() {
            runOnUiThread(MainActivity.this::installUpdate);
        }

        @JavascriptInterface
        public boolean saveFile(String base64, String name, String mime) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                runOnUiThread(() -> {
                    saveData = data;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                            .setType(mime).putExtra(Intent.EXTRA_TITLE, name);
                    try {
                        startActivityForResult(i, SAVE);
                    } catch (ActivityNotFoundException e) {
                        say("Нечем сохранить файл");
                    }
                });
                return true;
            } catch (Exception | OutOfMemoryError e) {
                return false;
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (request == ASK) {
            if (ok) Notify.arm(getApplicationContext());
            js("window.ilAllowed?ilAllowed(" + ok + "):window.ilResume&&ilResume()");
        }
        if (request == ASK_MIC && micRequest != null) {
            if (ok) micRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else micRequest.deny();
            micRequest = null;
        }
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        if (request == GoogleAuth.CHOOSE) google.chosen(result, data);
        boolean ok = result == RESULT_OK && data != null;
        if (request == PICK && picker != null) {
            Uri[] uris = null;
            if (ok && data.getClipData() != null) {
                uris = new Uri[data.getClipData().getItemCount()];
                for (int i = 0; i < uris.length; i++) uris[i] = data.getClipData().getItemAt(i).getUri();
            } else if (ok && data.getData() != null) {
                uris = new Uri[]{data.getData()};
            }
            picker.onReceiveValue(uris);
            picker = null;
        }
        if (request == SAVE && ok && data.getData() != null && saveData != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                out.write(saveData);
                say("Файл сохранён");
            } catch (Exception e) {
                say("Не получилось сохранить файл");
            }
            saveData = null;
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.ilBack?ilBack():false", handled -> {
            if (!"true".equals(handled)) moveTaskToBack(true);
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
