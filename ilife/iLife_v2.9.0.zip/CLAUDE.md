# iLife — памятка для разработки

- Сайт — GitHub Pages из корня ветки `main`. Личное некоммерческое приложение, язык интерфейса и комментариев — русский.
- **Код правится только в `src/`** (`src/js`, `src/css`, `src/sw.js`). Файлы `js/`, `css/`, `sw.js` в корне — сжатые, их создаёт сборка; руками не править.
- После правок: `node build.cjs` (нужен esbuild: `npm install`; в облачной среде без сети — `NODE_PATH=/opt/npm-tools/node_modules node build.cjs`). Проверка: `node build.cjs --check`.
- `index.html`, `manifest.webmanifest`, `images/`, `README_RU.txt` лежат в корне и не сжимаются.
- `js/config.js` — файл владельца сайта: не трогать, не удалять, в архивы версий не класть. `js/config.example.js` — образец, тоже вне сборки.
- Все файлы — обычные скрипты без модулей, функции и переменные общие; порядок подключения задан в `index.html`. Сборка сжимает файлы по одному и имена верхнего уровня не меняет.
- Новая версия: `APP_VERSION` в `src/js/core.js`, `CACHE` в `src/sw.js`, запись в журнале изменений в `index.html` (блок `#changelog`), «История версий» и номер в `README_RU.txt`. Новый файл — ещё и в список `CORE` в `src/sw.js` и в `index.html`.
- `assets/3d/` (движок three.js, модели `town.bin`/`town.json`, тексты лицензий) и `tools/` (сборка этих ресурсов) лежат в корне и сборкой не сжимаются; файлы из `assets/3d/` грузятся лениво при открытии 3D-режима (`?v=APP_VERSION`), в `CORE` в `src/sw.js` их нет. Скрипты 3D — `src/js/dnd-city3d-world.js` и `src/js/dnd-city3d.js`.
- Генератор карт ДНД — `src/js/dnd-citygen.js` (чистые функции, без интерфейса; `dndCityGenerate`, `DND_GEN_PRESETS`); окно генератора и `applyGen` — в `src/js/dnd-city.js`. Местность рисуется из живого массива `this.tiles` (не из строки `city.tiles`, она обновляется только при `save()`/`snap()`).
- Инструкции и ссылки на сайты — только в блоке «Сайты и инструкции» внизу «Настроек» (свёрнуты); в блоках ключей — одна ссылка на инструкцию.
- Архивы версий (`iLife_vX.Y.Z.zip`) в этот репозиторий не кладутся — они лежат в ветке `archives` репозитория Drakkkkon/maymani (папка `ilife/`).
- «Комиксы» (2.9.0): `comics/index.html` — копия index.html из Drakkkkon/topsecret (встроенный режим `?embed=ilife`), не сжимается; правки — сначала в topsecret, затем копия сюда. Связь — `src/js/comics.js`.
