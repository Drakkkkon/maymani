document.addEventListener("DOMContentLoaded", () => {
    const buttons = document.querySelectorAll('.btn, .title-bar-controls button');
    buttons.forEach(btn => {
        btn.addEventListener('mousedown', () => btn.classList.add('active'));
        btn.addEventListener('mouseup', () => btn.classList.remove('active'));
        btn.addEventListener('mouseleave', () => btn.classList.remove('active'));
    });

    const folders = document.querySelectorAll('.tree-item');
    const editor = document.querySelector('.note-editor');
    const statusPanel = document.querySelectorAll('.status-panel')[0];

    folders.forEach(folder => {
        folder.addEventListener('click', (e) => {
            const folderName = e.target.textContent.replace('📁 ', '').replace('🗑️ ', '').trim();
            statusPanel.textContent = `Открыта папка: ${folderName}`;
            editor.value = `--- ${folderName} ---\n\n`;
        });
    });
});
