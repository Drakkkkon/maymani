'use strict';
// =====================================================================================================
// iLife 2.13.0 — ОБЩИЙ ПОИСК, «МОЙ ДЕНЬ → ПРИВЫЧКИ / ЛЮДИ И ДАТЫ / ИТОГИ», ЗАМОК НА ЛИЧНОЕ.
// Данные — список extra (ключ ilife_extra, синхронизируется через Google Диск и аккаунт, входит в копию):
//   habit  — { id, kind:'habit', name, createdAt }
//   mark   — { id:'hm'+привычка+'_'+дата, kind:'mark', habit, date, createdAt }   (отметка — отдельной записью,
//            чтобы отметки с разных устройств не затирали друг друга)
//   person — { id, kind:'person', name, type:'birthday'|'anniversary'|'other', date:'ГГГГ-ММ-ДД', noYear, remind (дней), gifts, createdAt }
// Замок (ключ ilife_pin) — только на этом устройстве, не синхронизируется.
// =====================================================================================================

(function () {
    if (!window.ICONS) return;
    Object.assign(window.ICONS, {
        cake: '<path d="M12 6c1.11 0 2-.9 2-2 0-.38-.1-.73-.29-1.03L12 0l-1.71 2.97c-.19.3-.29.65-.29 1.03 0 1.1.9 2 2 2m6 3h-5V7h-2v2H6c-1.66 0-3 1.34-3 3v9c0 .55.45 1 1 1h16c.55 0 1-.45 1-1v-9c0-1.66-1.34-3-3-3m1 7c-1.2 0-2-1-3.5-1S13.5 16 12 16s-2-1-3.5-1S6.200 16 5 16v-4c0-.55.45-1 1-1h12c.55 0 1 .45 1 1z"/>',
        repeat_habit: '<path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8"/>'
    });
})();

let extra = LS.get('extra', []);
if (!Array.isArray(extra)) extra = [];
function saveExtra() { if (typeof cloudLocalChanged === 'function') cloudLocalChanged(); LS.set('extra', extra); }
function exList(kind) { return extra.filter(x => x && x.kind === kind); }

// =====================================================================================================
// ПРИВЫЧКИ
// =====================================================================================================
function hbMarks(id) { return new Set(exList('mark').filter(m => m.habit === id).map(m => m.date)); }
function hbToggle(id, date) {
    const mid = 'hm' + id + '_' + date;
    if (extra.some(x => x.id === mid)) extra = extra.filter(x => x.id !== mid);
    else extra.push({ id: mid, kind: 'mark', habit: id, date, createdAt: Date.now() });
    saveExtra(); renderHabits();
}
// Дней подряд по сегодня; пока сегодня не отмечено, серия считается по вчера
function hbStreak(marks) {
    let shift = marks.has(todayKey()) ? 0 : -1, n = 0;
    while (marks.has(todayKey(shift))) { n++; shift--; }
    return n;
}
function renderHabits() {
    const host = $('#hb-list'); if (!host) return;
    const list = exList('habit').sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
    if (!list.length) { host.innerHTML = '<div class="empty"><div class="ico-big">' + ic('repeat_habit') + '</div><b>Привычек пока нет</b>Добавьте, например, «Вода», «Зарядка» или «Чтение».</div>'; return; }
    const today = todayKey(), month = today.slice(0, 7);
    host.innerHTML = list.map(h => {
        const marks = hbMarks(h.id), streak = hbStreak(marks), inMonth = Array.from(marks).filter(d => d.slice(0, 7) === month).length;
        let days = '';
        for (let i = -6; i <= 0; i++) {
            const k = todayKey(i), on = marks.has(k);
            days += '<button type="button" class="hb-day' + (on ? ' is-on' : '') + (i === 0 ? ' is-today' : '') + '" data-d="' + k + '" aria-pressed="' + on + '" aria-label="' + esc(medDayFull(k)) + '"><small>' + MED_WD[medWd(k)] + '</small><b>' + (on ? ic('check') : +k.slice(8)) + '</b></button>';
        }
        return '<div class="card hb-card" data-id="' + esc(h.id) + '"><div class="hb-head"><div><b>' + esc(h.name) + '</b><small>' + (streak ? 'подряд: ' + medFmtN(streak, 'день', 'дня', 'дней') : 'серия не начата') + ' · в этом месяце: ' + inMonth + '</small></div>' +
            '<button type="button" class="icon-btn" data-edit aria-label="Изменить привычку">' + ic('edit') + '</button></div><div class="hb-week">' + days + '</div></div>';
    }).join('');
}
function hbSheet(habit) {
    const node = document.createElement('div'); node.className = 'med-form';
    node.innerHTML = '<label class="field-label" for="hb-name">Что отмечать каждый день</label><input type="text" id="hb-name" maxlength="60" placeholder="Вода, зарядка, чтение…" value="' + esc(habit ? habit.name : '') + '">';
    const actions = [{ label: 'Отмена' }];
    if (habit) actions.unshift({ label: 'Удалить', kind: 'danger', icon: 'delete', onClick: async () => {
        if (!(await confirmSheet('Удалить привычку?', '«' + habit.name + '» и все её отметки будут удалены.', 'Удалить', true))) return false;
        extra = extra.filter(x => x !== habit && !(x.kind === 'mark' && x.habit === habit.id)); saveExtra(); renderHabits();
    } });
    actions.push({ label: 'Сохранить', kind: 'primary', icon: 'check', onClick: () => {
        const name = $('#hb-name', node).value.trim();
        if (!name) { toast('Впишите название'); return false; }
        if (habit) habit.name = name; else extra.push({ id: uid('hb'), kind: 'habit', name, createdAt: Date.now() });
        saveExtra(); renderHabits();
    } });
    openSheet({ title: habit ? 'Привычка' : 'Новая привычка', node, actions });
}

// =====================================================================================================
// ЛЮДИ И ДАТЫ
// =====================================================================================================
const PP_TYPES = { birthday: 'День рождения', anniversary: 'Годовщина', other: 'Другая дата' };
// Ближайшее наступление даты начиная с дня from; 29 февраля в обычный год — 28-го
function ppNext(p, from) {
    const mo = +p.date.slice(5, 7), d = +p.date.slice(8, 10);
    let y = +from.slice(0, 4);
    for (;;) {
        const last = new Date(Date.UTC(y, mo, 0)).getUTCDate(), key = y + '-' + pad2(mo) + '-' + pad2(Math.min(d, last));
        if (key >= from) return key;
        y++;
    }
}
function ppYears(p, key) { return p.noYear ? 0 : Math.max(0, +key.slice(0, 4) - +p.date.slice(0, 4)); }
function ppWhat(p, key) {
    const n = ppYears(p, key);
    return PP_TYPES[p.type] + (n ? ' · ' + (p.type === 'birthday' ? 'исполнится ' : '') + medFmtN(n, 'год', 'года', 'лет') : '');
}
function ppIn(days) { return days === 0 ? 'сегодня' : days === 1 ? 'завтра' : 'через ' + medFmtN(days, 'день', 'дня', 'дней'); }
// Напоминания этого дня (js/chat.js → chatDue): в сам день и за remind дней до него, в 09:00
function ppDue(day) {
    const out = [];
    exList('person').forEach(p => {
        if (p.remind < 0) return;
        const next = ppNext(p, day), days = medDaysBetween(day, next);
        if (days !== 0 && days !== p.remind) return;
        out.push({ type: 'date', key: p.id + '|' + day + '|09:00', time: '09:00', title: days ? 'Скоро дата' : 'Сегодня дата', line: p.name + ' — ' + ppWhat(p, next) + ' (' + ppIn(days) + ')', done: false });
    });
    return out;
}
function renderPeople() {
    const host = $('#pp-list'); if (!host) return;
    const today = todayKey();
    const list = exList('person').map(p => ({ p, next: ppNext(p, today) })).sort((a, b) => a.next.localeCompare(b.next));
    if (!list.length) { host.innerHTML = '<div class="empty"><div class="ico-big">' + ic('cake') + '</div><b>Дат пока нет</b>Добавьте дни рождения и годовщины — iLife напомнит о них в «Сообщениях».</div>'; return; }
    host.innerHTML = list.map(({ p, next }) => {
        const days = medDaysBetween(today, next);
        return '<div class="card pp-card' + (days <= 7 ? ' is-soon' : '') + '" data-id="' + esc(p.id) + '"><div class="hb-head"><div><b>' + esc(p.name) + '</b><small>' + esc(fmtDayKey(next, false) + ' · ' + ppWhat(p, next)) + '</small></div>' +
            '<span class="chip' + (days <= 7 ? ' is-ok' : '') + '">' + ppIn(days) + '</span><button type="button" class="icon-btn" data-edit aria-label="Изменить">' + ic('edit') + '</button></div>' +
            (p.gifts ? '<p class="hint pp-gifts"><b>Идеи подарков:</b> ' + esc(p.gifts) + '</p>' : '') + '</div>';
    }).join('');
}
function ppSheet(person) {
    const p = person || { name: '', type: 'birthday', date: '', noYear: false, remind: 3, gifts: '' };
    const node = document.createElement('div'); node.className = 'med-form';
    const opt = (v, label, cur) => '<option value="' + v + '"' + (String(v) === String(cur) ? ' selected' : '') + '>' + label + '</option>';
    node.innerHTML = '<label class="field-label" for="pp-name">Кто или что</label><input type="text" id="pp-name" maxlength="60" placeholder="Мама, друг, годовщина свадьбы…" value="' + esc(p.name) + '">' +
        '<label class="field-label" for="pp-type">Что за дата</label><select id="pp-type">' + Object.entries(PP_TYPES).map(([k, v]) => opt(k, v, p.type)).join('') + '</select>' +
        '<label class="field-label" for="pp-date">Дата</label><input type="date" id="pp-date" value="' + esc(p.date) + '">' +
        '<label class="opt-row" style="margin-top:0.5rem"><span style="flex:1"><b>Год неизвестен</b><span class="sub">не считать, сколько лет</span></span><input type="checkbox" class="switch" id="pp-noyear"' + (p.noYear ? ' checked' : '') + '></label>' +
        '<label class="field-label" for="pp-remind">Напомнить</label><select id="pp-remind">' + opt(-1, 'не напоминать', p.remind) + opt(0, 'в сам день', p.remind) + opt(1, 'за 1 день и в сам день', p.remind) + opt(3, 'за 3 дня и в сам день', p.remind) + opt(7, 'за неделю и в сам день', p.remind) + opt(14, 'за 2 недели и в сам день', p.remind) + '</select>' +
        '<label class="field-label" for="pp-gifts">Идеи подарков</label><textarea id="pp-gifts" rows="3" maxlength="600">' + esc(p.gifts || '') + '</textarea>';
    const actions = [{ label: 'Отмена' }];
    if (person) actions.unshift({ label: 'Удалить', kind: 'danger', icon: 'delete', onClick: async () => {
        if (!(await confirmSheet('Удалить дату?', '«' + person.name + '» будет удалено.', 'Удалить', true))) return false;
        extra = extra.filter(x => x !== person); saveExtra(); renderPeople();
    } });
    actions.push({ label: 'Сохранить', kind: 'primary', icon: 'check', onClick: () => {
        const name = $('#pp-name', node).value.trim(), date = $('#pp-date', node).value;
        if (!name) { toast('Впишите имя'); return false; }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) { toast('Укажите дату'); return false; }
        const rec = { name, date, type: $('#pp-type', node).value, noYear: $('#pp-noyear', node).checked, remind: +$('#pp-remind', node).value, gifts: $('#pp-gifts', node).value.trim() };
        if (person) Object.assign(person, rec); else extra.push(Object.assign({ id: uid('pp'), kind: 'person', createdAt: Date.now() }, rec));
        saveExtra(); renderPeople();
    } });
    openSheet({ title: person ? 'Дата' : 'Новая дата', node, actions });
}

// =====================================================================================================
// ИТОГИ НЕДЕЛИ И МЕСЯЦА
// =====================================================================================================
let stMode = 'week', stShift = 0;
// Дни выбранной недели (пн–вс) или месяца
function stKeys(mode, shift) {
    if (mode === 'week') {
        const start = shift * 7 - medWd(todayKey());
        return Array.from({ length: 7 }, (_, i) => todayKey(start + i));
    }
    const p = almatyParts(), d = new Date(Date.UTC(p.y, p.mo + shift, 1));
    return medMonthKeys(d.getUTCFullYear(), d.getUTCMonth());
}
function stCollect(keys) {
    const today = todayKey(), set = new Set(keys), past = keys.filter(k => k <= today), inside = ms => !!ms && set.has(dayKey(ms));
    const r = { hours: 0, workDays: 0, earned: 0, done: 0, total: 0, byRate: new Map() };
    past.forEach(k => {
        const w = wkWorkTime(k); if (!w.off) { r.hours += w.hours; r.workDays++; }
        const st = wkDayState(k); r.done += st.done; r.total += st.total;
    });
    keys.forEach(k => wkLogsOn(k).forEach(l => {
        const sum = (+l.qty || 0) * (+l.price || 0); r.earned += sum;
        const v = r.byRate.get(l.name) || { qty: 0, sum: 0, unit: l.per === 'hour' ? 'ч' : l.unit };
        v.qty += +l.qty || 0; v.sum += sum; r.byRate.set(l.name, v);
    }));
    r.todos = todos.filter(t => t.type === 'task' && t.done && inside(t.doneAt)).length;
    r.buys = todos.filter(t => t.type !== 'task' && t.done && inside(t.doneAt)).length;
    r.movies = movies.filter(m => m.status === 'watched' && inside(m.watchedAt));
    r.ideas = ideas.filter(i => inside(i.createdAt)).length;
    r.diary = diary.filter(e => set.has(e.date)).length;
    r.habits = exList('habit').map(h => { const marks = hbMarks(h.id); return { name: h.name, n: past.filter(k => marks.has(k)).length, of: past.length }; });
    return r;
}
function renderStats() {
    const host = $('#st-body'); if (!host) return;
    const keys = stKeys(stMode, stShift), r = stCollect(keys);
    $$('#st-mode button').forEach(b => b.classList.toggle('is-on', b.dataset.m === stMode));
    $('#st-title').textContent = stMode === 'week' ? fmtDayKey(keys[0], false) + ' — ' + fmtDayKey(keys[6], true) : medMonthTitle(+keys[0].slice(0, 4), +keys[0].slice(5, 7) - 1);
    $('#st-next').disabled = stShift >= 0;
    const tile = (label, value) => '<div><small>' + label + '</small><b>' + value + '</b></div>';
    const rows = list => '<ul class="wk-byrate">' + list.join('') + '</ul>';
    host.innerHTML = '<div class="wk-tiles">' +
        tile('Заработано', wkMoney(r.earned)) + tile('Рабочее время', wkNum(r.hours) + ' ч') + tile('Рабочих дней', r.workDays) +
        tile('Дела «Моего дня»', r.done + ' из ' + r.total) + tile('Дела из списка', r.todos) + tile('Покупки', r.buys) +
        tile('Посмотрено', r.movies.length) + tile('Новых идей', r.ideas) + tile('Дней в дневнике', r.diary) + '</div>' +
        (r.byRate.size ? '<h3 class="st-h">Заработок по работам</h3>' + rows(Array.from(r.byRate).sort((a, b) => b[1].sum - a[1].sum).map(([n, v]) => '<li><span>' + esc(n) + '</span><span>' + wkNum(v.qty) + ' ' + esc(v.unit) + '</span><b>' + wkMoney(v.sum) + '</b></li>')) : '') +
        (r.habits.length ? '<h3 class="st-h">Привычки</h3>' + rows(r.habits.map(h => '<li><span>' + esc(h.name) + '</span><span></span><b>' + h.n + ' из ' + h.of + '</b></li>')) : '') +
        (r.movies.length ? '<h3 class="st-h">Кино</h3>' + rows(r.movies.map(m => '<li><span>' + esc(m.title) + '</span></li>')) : '');
}

// =====================================================================================================
// ОБЩИЙ ПОИСК
// =====================================================================================================
// Все записи, по которым ищем: { sec, icon, title, text, open() }
function gsItems() {
    const out = [];
    const add = (sec, icon, title, text, open) => out.push({ sec, icon, title: String(title || '').trim(), text: String(text || ''), open });
    const read = (title, text, tab, after) => () => openSheet({ title, html: '<p class="gs-full">' + esc(text) + '</p>', actions: [{ label: 'Закрыть' }, { label: 'Открыть раздел', kind: 'primary', onClick: () => { showTab(tab); if (after) after(); } }] });
    const first = s => String(s || '').split('\n')[0].slice(0, 90);
    ideas.forEach(i => {
        const text = [i.text, (i.tags || []).filter(t => !extractTags(i.text).includes(t)).map(t => '#' + t).join(' '), i.track ? i.track.title + ' ' + i.track.artist : '', (i.files || []).map(f => f.name).join(' ')].filter(Boolean).join('\n');
        add('Идеи', 'lightbulb', first(i.text) || (i.track && i.track.title) || 'Вложение', text, () => openSheet({ title: 'Идея · ' + fmtDate(i.createdAt, true), html: '<p class="gs-full">' + esc(text) + '</p>', actions: [{ label: 'Закрыть' }, { label: 'Изменить', kind: 'primary', onClick: () => { showTab('ideas'); setTimeout(() => editIdea(i.id), 220); } }] }));
    });
    todos.forEach(t => add('Дела и покупки', t.type === 'task' ? 'task_alt' : 'shopping_cart', t.name, [t.name, t.store, t.done ? 'выполнено' : ''].join(' '), () => showTab('todo')));
    wkList('task').forEach(t => add('Мой день', 'today', t.text, t.text + ' ' + (t.note || ''), () => { showTab('day-plan'); setTimeout(() => wkTaskSheet(t), 220); }));
    wkList('log').forEach(l => add('Сделанная работа', 'payments', l.name + ' · ' + fmtDayKey(l.date, true), l.name + ' ' + (l.note || ''), () => { wkSel = l.date; wkCal = { y: +l.date.slice(0, 4), mo: +l.date.slice(5, 7) - 1 }; showTab('day-cal'); }));
    exList('habit').forEach(h => add('Привычки', 'repeat_habit', h.name, h.name, () => showTab('day-habits')));
    exList('person').forEach(p => add('Люди и даты', 'cake', p.name, p.name + ' ' + PP_TYPES[p.type] + ' ' + (p.gifts || ''), () => { showTab('day-people'); setTimeout(() => ppSheet(p), 220); }));
    if (!lkLocked('diary')) diary.forEach(e => add('Дневник', 'auto_stories', fmtDayKey(e.date, true), e.text, () => { dyDay = e.date; showTab('diary'); }));
    movies.forEach(m => add('Кино', 'movie', m.title + (m.year ? ' (' + m.year + ')' : ''), [m.title, m.origTitle, mvJoin(m.directors, 5), mvJoin(m.cast, 20)].join(' '), () => { showTab('movies'); setTimeout(() => openMovieInfo(m.id), 220); }));
    songs.forEach(s => add('Песни', 'library_music', songTitleOf(s), [s.title, s.artist, s.noteTitle].concat((s.blocks || []).map(b => b.label + ' ' + b.note)).join(' '), () => { showTab('ideas'); setTimeout(() => openSongStudio(s.id), 220); }));
    scripts.forEach(s => add('Сценарии', 'edit_note', s.title || 'Без названия', [s.title, s.logline, s.notes].concat((s.els || []).map(e => e.x)).join('\n'), () => { showTab('scripts'); setTimeout(() => openScript(s.id), 220); }));
    meds.forEach(m => {
        const text = [m.drug, m.title, m.doctor, m.dose, m.note, m.text].concat((m.drugs || []).map(d => d.name || d.drug)).filter(Boolean).join(' · ');
        if (text) add('Лекарства', 'medication', first(text), text, read('Лекарства', text, m.kind === 'plan' ? 'med-schedule' : 'med-rx'));
    });
    dndGames.forEach(g => add('ДНД', 'd20', g.title, g.title, () => showTab('dnd-games')));
    chatLog.forEach(m => { if (m.kind === 'me') add('Сообщения', 'forum', first(m.text), m.text, read('Сообщение', m.text, 'messages')); });
    return out;
}
// Все слова запроса должны найтись в записи; регистр и «ё» не важны
function gsFind(query, items) {
    const words = normText(query).split(/\s+/).filter(Boolean);
    if (!words.length) return [];
    return items.filter(x => { const hay = normText(x.title + '\n' + x.text); return words.every(w => hay.includes(w)); });
}
function openGlobalSearch() {
    if ($('#gs-input')) { $('#gs-input').focus(); return; }
    const items = gsItems(), node = document.createElement('div');
    node.innerHTML = '<div class="searchbar">' + ic('search') + '<input type="search" id="gs-input" placeholder="Искать везде" autocomplete="off" aria-label="Искать во всех разделах"></div><div id="gs-out" aria-live="polite"></div>';
    let found = [];
    const sheet = openSheet({ title: 'Поиск по iLife', node });
    const out = $('#gs-out', node), input = $('#gs-input', node);
    const draw = () => {
        const q = input.value.trim(), all = gsFind(q, items);
        const groups = new Map();
        all.forEach(x => { if (!groups.has(x.sec)) groups.set(x.sec, []); groups.get(x.sec).push(x); });
        found = [];
        let html = '';
        groups.forEach((list, sec) => {
            html += '<h4 class="gs-sec">' + esc(sec) + ' · ' + list.length + '</h4>' + list.slice(0, 20).map(x => {
                found.push(x);
                const pos = normText(x.text).indexOf(normText(q.split(/\s+/)[0])), snip = x.text.slice(Math.max(0, pos - 30), Math.max(0, pos - 30) + 100).replace(/\s+/g, ' ');
                return '<button type="button" class="chat-pick" data-n="' + (found.length - 1) + '">' + ic(x.icon) + '<span><b>' + esc(x.title) + '</b><small>' + esc(snip) + '</small></span></button>';
            }).join('') + (list.length > 20 ? '<p class="hint">Показаны первые 20 — уточните запрос.</p>' : '');
        });
        out.innerHTML = html || '<p class="hint gs-empty">' + (q ? 'Ничего не найдено.' : 'Введите слово: ищу в заметках, делах, дневнике, кино, сценариях, песнях, лекарствах, датах и сообщениях.') + (lkLocked('diary') ? ' Дневник закрыт замком и в поиске не участвует.' : '') + '</p>';
    };
    input.addEventListener('input', debounce(draw, 150));
    out.addEventListener('click', e => { const b = e.target.closest('[data-n]'); if (!b) return; const x = found[+b.dataset.n]; sheet.close(); setTimeout(x.open, 220); });
    draw(); setTimeout(() => input.focus(), 250);
}

// =====================================================================================================
// ЗАМОК НА ЛИЧНОЕ. Закрывает вход в раздел (это замок на экран, а не шифрование данных).
// ilife_pin = { salt, hash, recovery (хеш запасного кода), diary: true, sovsek: true }
// =====================================================================================================
const LK_AWAY_MS = 60000;   // столько можно отсутствовать, не вводя код заново (выбор фото, ответ на звонок)
const LK_TABS = { diary: 'diary', 'diary-shelf': 'diary', sovsek: 'sovsek' };
const LK_NAMES = { diary: 'Дневник', sovsek: 'Мое_совсек' };
let lkOpen = false, lkHiddenAt = 0;
function lkCfg() { return LS.get('pin', null); }
function lkLocked(section) { const c = lkCfg(); return !!c && c[section] !== false && !lkOpen; }
async function lkHash(code, salt) {
    const text = salt + ':' + code;
    if (window.crypto && crypto.subtle) return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))), b => b.toString(16).padStart(2, '0')).join('');
    let h = 2166136261; for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619) >>> 0;
    return 'f' + h.toString(16);
}
async function lkCheck(code) {
    const c = lkCfg(); if (!c) return true;
    const h = await lkHash(code, c.salt);
    return h === c.hash;
}
// Ставит или снимает заслонку на открытой странице (js/app.js → showTab)
function lkGate(id) {
    $$('.pin-gate').forEach(e => e.remove());
    $$('.tab.pin-on').forEach(e => e.classList.remove('pin-on'));
    const section = LK_TABS[id], tab = document.getElementById(id);
    if (!section || !tab || !lkLocked(section)) return;
    tab.classList.add('pin-on');
    const gate = document.createElement('form'); gate.className = 'pin-gate';
    gate.innerHTML = '<div class="ico-big">' + ic('lock') + '</div><b>«' + LK_NAMES[section] + '» под замком</b>' +
        '<input type="password" class="pin-input" inputmode="numeric" autocomplete="off" maxlength="12" placeholder="Код" aria-label="Код замка">' +
        '<button type="submit" class="btn btn-primary">' + ic('lock_open') + 'Открыть</button>' +
        '<button type="button" class="linkbtn" data-forgot>Забыл код</button>';
    gate.addEventListener('submit', async e => {
        e.preventDefault();
        const input = gate.querySelector('.pin-input');
        if (await lkCheck(input.value)) { lkOpen = true; showTab(id); } else { input.value = ''; toast('Неверный код'); }
    });
    gate.querySelector('[data-forgot]').addEventListener('click', lkForgot);
    tab.appendChild(gate);
}
function lkForgot() {
    const node = document.createElement('div'); node.className = 'med-form';
    node.innerHTML = '<p class="hint">Введите запасной код из 8 цифр, который iLife показал при включении замка. Замок снимется, записи останутся.</p><input type="text" id="lk-rec" inputmode="numeric" maxlength="8" aria-label="Запасной код">';
    openSheet({ title: 'Забыли код?', node, actions: [{ label: 'Отмена' }, { label: 'Снять замок', kind: 'primary', onClick: async () => {
        const c = lkCfg();
        if (!c || (await lkHash($('#lk-rec', node).value.trim(), c.salt)) !== c.recovery) { toast('Запасной код не подходит'); return false; }
        LS.del('pin'); renderLockCard(); showTab(settings.lastTab); toast('Замок снят');
    } }] });
}
// Спросить код перед действием (копия данных содержит дневник)
function lkAsk() {
    if (!lkCfg() || lkOpen) return Promise.resolve(true);
    return new Promise(resolve => {
        const node = document.createElement('div'); node.className = 'med-form';
        node.innerHTML = '<input type="password" id="lk-ask" inputmode="numeric" autocomplete="off" maxlength="12" placeholder="Код замка" aria-label="Код замка">';
        openSheet({ title: 'Введите код', node, onClose: r => resolve(r === true), actions: [{ label: 'Отмена', value: false }, { label: 'Дальше', kind: 'primary', value: true, onClick: async () => { if (!(await lkCheck($('#lk-ask', node).value))) { toast('Неверный код'); return false; } } }] });
    });
}
function lkSet() {
    const old = lkCfg(), node = document.createElement('div'); node.className = 'med-form';
    node.innerHTML = (old ? '<label class="field-label" for="lk-old">Нынешний код</label><input type="password" id="lk-old" inputmode="numeric" autocomplete="off" maxlength="12">' : '') +
        '<label class="field-label" for="lk-new">Новый код (от 4 цифр)</label><input type="password" id="lk-new" inputmode="numeric" autocomplete="new-password" maxlength="12">' +
        '<label class="field-label" for="lk-new2">Ещё раз</label><input type="password" id="lk-new2" inputmode="numeric" autocomplete="new-password" maxlength="12">';
    openSheet({ title: old ? 'Сменить код' : 'Включить замок', node, actions: [{ label: 'Отмена' }, { label: 'Сохранить', kind: 'primary', onClick: async () => {
        if (old && !(await lkCheck($('#lk-old', node).value))) { toast('Нынешний код неверный'); return false; }
        const code = $('#lk-new', node).value;
        if (!/^\d{4,12}$/.test(code)) { toast('Нужно от 4 до 12 цифр'); return false; }
        if (code !== $('#lk-new2', node).value) { toast('Коды не совпали'); return false; }
        const salt = uid('s'), rnd = new Uint32Array(1); crypto.getRandomValues(rnd);
        const recovery = String(rnd[0] % 100000000).padStart(8, '0');
        LS.set('pin', { salt, hash: await lkHash(code, salt), recovery: await lkHash(recovery, salt), diary: old ? old.diary !== false : true, sovsek: old ? old.sovsek !== false : true });
        lkOpen = false; renderLockCard();
        setTimeout(() => openSheet({ title: 'Запишите запасной код', html: '<p class="lk-code">' + recovery + '</p><p class="hint">Он снимет замок, если вы забудете свой код. Второй раз iLife его не покажет.</p>', actions: [{ label: 'Записал', kind: 'primary' }] }), 220);
    } }] });
}
function renderLockCard() {
    const box = $('#lock-body'); if (!box) return;
    const c = lkCfg();
    $('#lock-badge').textContent = c ? 'Включён' : 'Выключен';
    const row = (k) => '<label class="switch-row"><span class="tx"><b>' + LK_NAMES[k] + '</b></span><input type="checkbox" class="switch" data-lk="' + k + '"' + (c[k] !== false ? ' checked' : '') + '></label>';
    box.innerHTML = '<p class="hint">Код спрашивается при входе в раздел и снова, если iLife был свёрнут дольше минуты. Замок действует только на этом устройстве и не шифрует данные и файлы на Google Диске.</p>' +
        (c ? row('diary') + row('sovsek') + '<div class="btn-group"><button type="button" class="btn" data-lock="now">' + ic('lock') + 'Закрыть сейчас</button><button type="button" class="btn" data-lock="set">Сменить код</button><button type="button" class="btn" data-lock="off">Выключить</button></div>'
           : '<div class="btn-group"><button type="button" class="btn btn-primary" data-lock="set">' + ic('lock') + 'Включить замок</button></div>');
}
function lkRelock() {
    if (!lkCfg() || !lkOpen) return;
    lkOpen = false;
    if (LK_TABS[settings.lastTab]) {
        sheetStack.slice().reverse().forEach(s => s.close());
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));   // закрыть просмотр фото
        if (typeof dySaveNow === 'function') dySaveNow();
        lkGate(settings.lastTab);
    }
}

// ---------- Вкладки и запуск ----------
function extraTabOpened(id) {
    if (id === 'day-habits') renderHabits();
    if (id === 'day-people') renderPeople();
    if (id === 'day-stats') { stShift = 0; renderStats(); }
}
function extraAfterSync() { renderHabits(); renderPeople(); renderStats(); }
function initExtra() {
    $('#hb-new').addEventListener('click', () => hbSheet(null));
    $('#hb-list').addEventListener('click', e => {
        const card = e.target.closest('[data-id]'); if (!card) return;
        const day = e.target.closest('[data-d]');
        if (day) hbToggle(card.dataset.id, day.dataset.d);
        else if (e.target.closest('[data-edit]')) hbSheet(extra.find(x => x.id === card.dataset.id));
    });
    $('#pp-new').addEventListener('click', () => ppSheet(null));
    $('#pp-list').addEventListener('click', e => { const card = e.target.closest('[data-id]'); if (card && e.target.closest('[data-edit]')) ppSheet(extra.find(x => x.id === card.dataset.id)); });
    $('#st-mode').addEventListener('click', e => { const b = e.target.closest('[data-m]'); if (!b) return; stMode = b.dataset.m; stShift = 0; renderStats(); });
    $('#st-prev').addEventListener('click', () => { stShift--; renderStats(); });
    $('#st-next').addEventListener('click', () => { if (stShift < 0) { stShift++; renderStats(); } });
    document.addEventListener('click', e => { if (e.target.closest('[data-search-open]')) openGlobalSearch(); });
    document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.code === 'KeyK') { e.preventDefault(); openGlobalSearch(); } });
    $('#lock-body').addEventListener('click', async e => {
        const b = e.target.closest('[data-lock]'); if (!b) return;
        if (b.dataset.lock === 'set') lkSet();
        else if (b.dataset.lock === 'now') { lkOpen = false; toast('Закрыто'); }
        else { lkOpen = false; if (await lkAsk()) { LS.del('pin'); renderLockCard(); toast('Замок выключен'); } }
    });
    $('#lock-body').addEventListener('change', async e => {
        const box = e.target.closest('[data-lk]'); if (!box) return;
        // снять защиту с раздела можно только зная код
        if (!box.checked && !(await lkAsk())) { box.checked = true; return; }
        LS.set('pin', Object.assign(lkCfg(), { [box.dataset.lk]: box.checked }));
    });
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') lkHiddenAt = Date.now();
        else if (lkHiddenAt && Date.now() - lkHiddenAt > LK_AWAY_MS) lkRelock();
    });
    renderLockCard();
}
