package kz.drakkkkon.ilife;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.OperationCanceledException;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;

/**
 * Вход Google через аккаунт самого телефона: в WebView окно входа Google запрещено.
 * Google узнаёт приложение по имени пакета и отпечатку подписи (клиент OAuth типа Android).
 * Все методы вызывать из главного потока.
 */
final class GoogleAuth {
    static final int CHOOSE = 10;
    private static final String TYPE = "com.google";

    interface Done {
        void send(String json);
    }

    private final Activity activity;
    private final Done done;
    private String waitingId, waitingScope;

    GoogleAuth(Activity activity, Done done) {
        this.activity = activity;
        this.done = done;
    }

    private SharedPreferences prefs() {
        return activity.getSharedPreferences("google", Context.MODE_PRIVATE);
    }

    private Account account() {
        String name = prefs().getString("account", "");
        for (Account a : AccountManager.get(activity).getAccountsByType(TYPE))
            if (a.name.equals(name)) return a;
        return null;
    }

    /** scope — права через пробел; silent — без каких-либо окон. */
    @SuppressWarnings("deprecation")
    void token(String id, String scope, boolean silent) {
        Account a = account();
        if (a != null) {
            request(id, scope, a, silent, true);
        } else if (silent) {
            answer(id, null, "needs_user");
        } else {
            if (waitingId != null) answer(waitingId, null, "cancel");
            waitingId = id;
            waitingScope = scope;
            try {
                activity.startActivityForResult(AccountManager.newChooseAccountIntent(
                        null, null, new String[]{TYPE}, null, null, null, null), CHOOSE);
            } catch (Exception e) {
                waitingId = null;
                answer(id, null, "no_google");
            }
        }
    }

    void chosen(int result, Intent data) {
        String id = waitingId;
        waitingId = null;
        if (id == null) return;
        String name = result == Activity.RESULT_OK && data != null ? data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME) : null;
        if (name == null) {
            answer(id, null, "cancel");
            return;
        }
        prefs().edit().putString("account", name).apply();
        Account a = account();
        if (a == null) answer(id, null, "no_account");
        else request(id, waitingScope, a, false, true);
    }

    /** fresh — телефон кэширует токены, поэтому прежний сначала выбрасываем и просим новый. */
    private void request(String id, String scope, Account a, boolean silent, boolean fresh) {
        AccountManager manager = AccountManager.get(activity);
        AccountManagerCallback<Bundle> callback = future -> {
            try {
                Bundle b = future.getResult();
                String token = b.getString(AccountManager.KEY_AUTHTOKEN);
                if (token == null) {
                    answer(id, null, "needs_user");
                } else if (fresh) {
                    manager.invalidateAuthToken(TYPE, token);
                    request(id, scope, a, silent, false);
                } else {
                    answer(id, token, null);
                }
            } catch (OperationCanceledException e) {
                answer(id, null, "cancel");
            } catch (Exception e) {
                answer(id, null, String.valueOf(e.getMessage()));
            }
        };
        Handler main = new Handler(Looper.getMainLooper());
        if (silent) manager.getAuthToken(a, "oauth2:" + scope, null, false, callback, main);
        else manager.getAuthToken(a, "oauth2:" + scope, null, activity, callback, main);
    }

    private void answer(String id, String token, String error) {
        try {
            JSONObject o = new JSONObject().put("id", id);
            if (token != null) o.put("access_token", token).put("expires_in", 3000);
            else o.put("error", error);
            done.send(o.toString());
        } catch (Exception ignored) {
            // страница сама прервёт ожидание
        }
    }

    void signOut(String token) {
        if (token != null && !token.isEmpty()) AccountManager.get(activity).invalidateAuthToken(TYPE, token);
        prefs().edit().remove("account").apply();
    }
}
