package kz.drakkkkon.ilife;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Будильник, кнопка в уведомлении, перезагрузка телефона и смена времени. */
public class Alarms extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Notify.DONE.equals(intent.getAction())) {
            Notify.done(context, intent.getStringExtra("id"), intent.getStringExtra("type"), intent.getStringExtra("keys"));
        } else {
            Notify.arm(context);
        }
    }
}
