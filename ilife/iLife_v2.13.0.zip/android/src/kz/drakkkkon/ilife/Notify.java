package kz.drakkkkon.ilife;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Напоминания. Страница присылает расписание [{id, at, type, title, body, keys, action}];
 * приложение держит один будильник на ближайшее напоминание и после него ставит следующий.
 */
final class Notify {
    private static final String CHANNEL = "reminders";
    static final String ALARM = "kz.drakkkkon.ilife.ALARM", DONE = "kz.drakkkkon.ilife.DONE";
    private static final long LATE = 2 * 3600 * 1000L;

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("notify", Context.MODE_PRIVATE);
    }

    private static NotificationManager manager(Context c) {
        return c.getSystemService(NotificationManager.class);
    }

    static boolean allowed(Context c) {
        return manager(c).areNotificationsEnabled();
    }

    private static JSONArray array(Context c, String name) {
        try {
            return new JSONArray(prefs(c).getString(name, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static synchronized void schedule(Context c, String json) {
        try {
            JSONArray next = new JSONArray(json);
            Set<String> ids = new HashSet<>();
            for (int i = 0; i < next.length(); i++) ids.add(next.getJSONObject(i).getString("id"));
            // выполненное или удалённое убираем и из шторки
            JSONArray old = array(c, "schedule");
            for (int i = 0; i < old.length(); i++) {
                String id = old.getJSONObject(i).getString("id");
                if (!ids.contains(id)) manager(c).cancel(id.hashCode());
            }
            prefs(c).edit().putString("schedule", next.toString()).apply();
            arm(c);
        } catch (Exception ignored) {
            // испорченное расписание не должно ронять приложение
        }
    }

    /** Показывает наступившее и ставит будильник на следующее. */
    static synchronized void arm(Context c) {
        try {
            JSONArray list = array(c, "schedule");
            JSONObject shown = new JSONObject(prefs(c).getString("shown", "{}"));
            JSONObject keep = new JSONObject();
            long now = System.currentTimeMillis(), next = 0;
            for (int i = 0; i < list.length(); i++) {
                JSONObject r = list.getJSONObject(i);
                long at = r.getLong("at");
                String mark = r.getString("id") + "|" + r.getString("body");
                if (at > now) {
                    if (next == 0 || at < next) next = at;
                } else if (at > now - LATE) {
                    if (!shown.has(mark) && allowed(c)) show(c, r);
                    if (shown.has(mark) || allowed(c)) keep.put(mark, at);
                }
            }
            prefs(c).edit().putString("shown", keep.toString()).apply();
            AlarmManager alarms = c.getSystemService(AlarmManager.class);
            PendingIntent pi = PendingIntent.getBroadcast(c, 0, new Intent(c, Alarms.class).setAction(ALARM),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            alarms.cancel(pi);
            if (next == 0) return;
            if (Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms()) alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
            else alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
        } catch (Exception ignored) {
            // без будильника напоминание всё равно появится в чате при открытии
        }
    }

    private static void show(Context c, JSONObject r) throws Exception {
        String id = r.getString("id");
        Intent done = new Intent(c, Alarms.class).setAction(DONE).setData(Uri.parse("ilife:" + id))
                .putExtra("id", id).putExtra("type", r.getString("type")).putExtra("keys", r.getJSONArray("keys").toString());
        PendingIntent pi = PendingIntent.getBroadcast(c, id.hashCode(), done, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = builder(c, r.getString("title"), r.getString("body"), id.hashCode());
        b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_notify), r.getString("action"), pi).build());
        manager(c).notify(id.hashCode(), b.build());
    }

    private static Notification.Builder builder(Context c, String title, String body, int request) {
        manager(c).createNotificationChannel(new NotificationChannel(CHANNEL, "Напоминания", NotificationManager.IMPORTANCE_HIGH));
        Intent open = new Intent(c, MainActivity.class).putExtra("open", "messages")
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setColor(0xFF6750A4)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(PendingIntent.getActivity(c, request, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE))
                .setAutoCancel(true);
    }

    static void test(Context c) {
        manager(c).notify(1, builder(c, "iLife", "Уведомления включены ✅", 1).build());
    }

    /** Нажата кнопка «Принял» / «Сделано»: запоминаем, страница отметит при следующем открытии. */
    static synchronized void done(Context c, String id, String type, String keys) {
        try {
            JSONArray done = array(c, "done");
            done.put(new JSONObject().put("type", type).put("keys", new JSONArray(keys)));
            // из расписания не убираем: пометка «уже показано» не даст уведомить второй раз, пока страница не отметит
            prefs(c).edit().putString("done", done.toString()).apply();
            manager(c).cancel(id.hashCode());
        } catch (Exception ignored) {
            // отметить можно будет в самом приложении
        }
    }

    static synchronized String takeDone(Context c) {
        String out = prefs(c).getString("done", "[]");
        prefs(c).edit().remove("done").apply();
        return out;
    }
}
