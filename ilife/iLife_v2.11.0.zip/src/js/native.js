'use strict';
// =====================================================================================================
// iLife 2.11.0 — ПРИЛОЖЕНИЕ ANDROID (android/): внутри него есть window.iLifeNative.
// Системные уведомления показывает само приложение, даже когда оно закрыто: страница передаёт ему расписание
// напоминаний на две недели вперёд. В обычном браузере этот файл ничего не делает.
// =====================================================================================================
const NATIVE = window.iLifeNative && typeof window.iLifeNative.notifySchedule === 'function' ? window.iLifeNative : null;
if (NATIVE) {
    // в WebView нет Notification: подставляем свой, чтобы переключатели «Напоминать» работали как в браузере
    const N = function () { this.close = () => {}; };
    Object.defineProperty(N, 'permission', { get: () => NATIVE.notifyAllowed() ? 'granted' : 'default' });
    N.requestPermission = () => new Promise(resolve => { window.ilAllowed = ok => { resolve(ok ? 'granted' : 'denied'); nativeCard(); nativeSync(); }; NATIVE.notifyAllow(); });
    Object.defineProperty(window, 'Notification', { value: N, configurable: true, writable: true });
}
let nativeLast = '';
function nativeTakeDone() {
    try { JSON.parse(NATIVE.takeDone() || '[]').forEach(d => chatMarkDone(d.type, d.keys)); } catch (e) { console.warn(e); }
}
function nativeSync() {
    if (!NATIVE) return;
    nativeTakeDone();
    const on = { med: LS.get('med_notify', true) !== false, plan: LS.get('dp_notify', true) !== false, todo: true };
    const list = [], now = Date.now();
    for (let i = -1; i < 14; i++) {
        const day = todayKey(i), groups = new Map();
        chatDue(day).forEach(x => {
            if (x.done || !on[x.type]) return;
            const at = keyToMs(day) + (medMin(x.time) - 720) * 60000;   // keyToMs — полдень по Алматы
            if (at < now - 7200000) return;
            const id = x.type + '-' + day + '-' + x.time;
            if (!groups.has(id)) groups.set(id, { id, at, type: x.type, title: x.title + ' · ' + x.time, body: [], keys: [], action: x.type === 'med' ? 'Принял' : 'Сделано' });
            const g = groups.get(id); g.body.push(x.line); g.keys.push(x.key);
        });
        groups.forEach(g => { g.body = g.body.join('\n'); list.push(g); });
    }
    const json = JSON.stringify(list.sort((a, b) => a.at - b.at).slice(0, 300));
    if (json !== nativeLast) { nativeLast = json; NATIVE.notifySchedule(json); }
}
// Кнопки «Принял» / «Сделано» прямо в уведомлении и нажатие на само уведомление
function nativeResume() {
    if (!NATIVE) return;
    nativeTakeDone();
    if (NATIVE.takeOpen() === 'messages') showTab('messages');
    chatScan(); nativeSync(); nativeCard();
}
function nativeCard() {
    if (!NATIVE) return;
    const ok = NATIVE.notifyAllowed(), b = $('#apk-badge');
    if (b) b.textContent = ok ? 'Включены' : 'Выключены';
    const a = $('#apk-allow'); if (a) a.hidden = ok;
    const t = $('#apk-state');
    if (t) t.textContent = ok ? 'Напоминания приходят в системные уведомления, даже когда iLife закрыт.' : 'Разрешите уведомления, чтобы не пропустить лекарства и дела.';
}
// Системная кнопка «Назад»: сначала закрыть окно, потом выйти из подменю
window.ilBack = () => {
    if (sheetStack.length) { sheetStack[sheetStack.length - 1].close(); return true; }
    if ((document.documentElement.dataset.nav || 'main') !== 'main') { navShowMain(); return true; }
    return false;
};
function initNative() {
    const card = $('#apk-card');
    if (!NATIVE) return;
    document.documentElement.classList.add('is-apk');
    if (card) card.hidden = false;
    $('#apk-allow').addEventListener('click', () => Notification.requestPermission());
    $('#apk-test').addEventListener('click', () => { if (NATIVE.notifyAllowed()) NATIVE.notifyTest(); else Notification.requestPermission(); });
    $('#apk-settings').addEventListener('click', () => NATIVE.notifySettings());
    window.ilResume = nativeResume;
    setTimeout(nativeResume, 900);
    setInterval(nativeSync, 5000);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') nativeResume(); else nativeSync(); });
}
