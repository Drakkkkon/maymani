'use strict';
// =====================================================================================================
// iLife 2.11.0 — РАЗДЕЛ «СООБЩЕНИЯ»: чат в духе Telegram.
//   • пользователь пишет сообщение — iLife подсказывает, в какой пункт меню его добавить (или выбрать вручную);
//   • сюда же приходят напоминания: лекарства, дела «Моего дня», дела со сроком из «Дел».
// Сообщения: { id, kind:'me'|'rem', text, at, added:[{sec,at}], skip, rem:{type,day,time,keys:[]} } — ключ ilife_chat.
// =====================================================================================================

(function () {
    if (!window.ICONS) return;
    Object.assign(window.ICONS, {
        forum: '<path d="M21 6h-2v9H6v2c0 .55.45 1 1 1h11l4 4V7c0-.55-.45-1-1-1m-4 6V3c0-.55-.45-1-1-1H3c-.55 0-1 .45-1 1v14l4-4h10c.55 0 1-.45 1-1"/>',
        send_msg: '<path d="M2.01 21 23 12 2.01 3 2 10l15 2-15 2z"/>'
    });
})();

let chatLog = LS.get('chat', []);
if (!Array.isArray(chatLog)) chatLog = [];
const CHAT_MAX = 600;

const CHAT_SECTIONS = {
    buy: { n: 'Покупки', path: 'Заметки → Дела', i: 'shopping_cart', tab: 'todo' },
    todo: { n: 'Дела', path: 'Заметки → Дела', i: 'checklist', tab: 'todo' },
    day: { n: 'Мой день', path: 'Дела с напоминанием', i: 'today', tab: 'day-plan' },
    med: { n: 'Лекарства', path: 'График приёма', i: 'medication', tab: 'med-schedule' },
    idea: { n: 'Идеи', path: 'Заметки → Идеи', i: 'lightbulb', tab: 'ideas' },
    diary: { n: 'Дневник', path: 'Запись дня', i: 'auto_stories', tab: 'diary' },
    movie: { n: 'Кино', path: 'Медиа → Кино', i: 'movie', tab: 'movies' },
    script: { n: 'Сценарии', path: 'Медиа → Сценарии', i: 'edit_note', tab: 'scripts' }
};

function saveChat() {
    if (chatLog.length > CHAT_MAX) chatLog = chatLog.slice().sort((a, b) => a.at - b.at).slice(-CHAT_MAX);
    if (typeof cloudLocalChanged === 'function') cloudLocalChanged();
    LS.set('chat', chatLog);
}

// ---------- Разбор сообщения: куда его добавить ----------
// \b в JavaScript не видит русские буквы, поэтому границы слов — через пробелы и (?![а-я])
const CHAT_PREFIX = [
    [/^(?:в\s+)?покупк[иу]\s*[:—-]\s*/i, 'buy'], [/^(?:в\s+)?дел[оа]\s*[:—-]\s*/i, 'todo'], [/^(?:в\s+)?(?:мой день|напоминани[ея])\s*[:—-]\s*/i, 'day'],
    [/^(?:в\s+)?лекарств[оа]\s*[:—-]\s*/i, 'med'], [/^(?:в\s+)?иде[яию]\s*[:—-]\s*/i, 'idea'], [/^(?:в\s+)?дневник\s*[:—-]\s*/i, 'diary'],
    [/^(?:в\s+)?(?:кино|фильм|сериал)\s*[:—-]\s*/i, 'movie'], [/^(?:в\s+)?сценари[йи]\s*[:—-]\s*/i, 'script']
];
const CHAT_REPEAT_RE = /(?:^|\s)(?:кажд(?:ый|ую|ое)\s+(?:день|утро|вечер|понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье)|ежедневно|через день|по (?:понедельникам|вторникам|средам|четвергам|пятницам|субботам|воскресеньям|будням))(?![а-я])/i;
function chatStripPrefix(text) {
    for (const [re, sec] of CHAT_PREFIX) if (re.test(text)) return { sec, text: text.replace(re, '').trim() };
    return { sec: '', text: text.trim() };
}
// «в 9:30», «в 9 утра», «в 7 вечера» → ['09:30']
function chatTimes(text) {
    const out = new Set(); let m;
    const hm = /(?:^|\s)(?:в\s+|к\s+)?([01]?\d|2[0-3]):([0-5]\d)(?!\d)/g;
    while ((m = hm.exec(text))) out.add(pad2(+m[1]) + ':' + m[2]);
    const word = /(?:^|\s)(?:в|к)\s+(\d{1,2})\s*(утра|вечера|дня|ночи|час(?:ов|а)?)(?![а-я])/gi;
    while ((m = word.exec(text))) {
        let h = +m[1]; const w = m[2].toLowerCase();
        if ((w === 'вечера' || w === 'дня') && h < 12) h += 12;
        if (w === 'ночи' && h === 12) h = 0;
        if (h < 24) out.add(pad2(h) + ':00');
    }
    return Array.from(out).sort();
}
function chatGuess(raw) {
    const p = chatStripPrefix(raw);
    if (p.sec) return p.sec;
    const s = normText(p.text);
    if (/(?:^|\s)(?:посмотреть|глянуть)(?![а-я]).*(?:фильм|сериал|кино|мульт)|^(?:фильм|сериал|мультфильм)(?![а-я])/.test(s)) return 'movie';
    if (/сценари|раскадровк|^сцена(?![а-я])/.test(s)) return 'script';
    if (/(?:^|\s)(?:купи|купить|докупить|покупки)(?![а-я])/.test(s)) return 'buy';
    if (/таблет|капсул|лекарств|укол|(?:^|\s)капли|сироп|витамин|ингаляц|\d\s*мг(?![а-я])|(?:пить|принимать|принять).*(?:раза? в день|после еды|до еды|натощак|на ночь)/.test(s)) return 'med';
    if (/(?:^|\s)напомни/.test(s) || CHAT_REPEAT_RE.test(s) || chatTimes(s).length) return 'day';
    if (/^(?:сегодня|вчера)(?![а-я]).*[а-я](?:л|ла|ли|лся|лась|лись)(?![а-я])/.test(s)) return 'diary';
    if (/^(?:позвонить|написать|оплатить|сделать|сдать|забрать|отправить|записаться|сходить|съездить|починить|проверить|убрать|помыть|приготовить|вернуть|отнести|надо|нужно|не забыть)(?![а-я])/.test(s) || extractDue(p.text).due) return 'todo';
    if (/^(?:идея|придумал|мысль|а что если)(?![а-я])|#[a-zа-я0-9_]/.test(s)) return 'idea';
    if (/^(?:сегодня|вчера)(?![а-я])|^день (?:был|прош)/.test(s)) return 'diary';
    if (p.text.includes(',') && p.text.split(/[,\n]/).every(x => x.trim() && x.trim().split(/\s+/).length <= 3)) return 'buy';
    if (/\d\s*(?:тг|тенге|₸)(?![а-я])/.test(s)) return 'buy';
    return 'idea';
}
// Текст дела без «напомни мне», времени и повторов
function chatTitle(text) {
    return capitalizeFirst(String(text)
        .replace(/(^|\s)напомни(?:ть)?(?:\s+мне)?(?![а-яё])/ig, '$1')
        .replace(new RegExp(CHAT_REPEAT_RE.source, 'ig'), ' ')
        .replace(/(^|\s)(?:в|к)\s+\d{1,2}\s*(?:утра|вечера|дня|ночи|час(?:ов|а)?)(?![а-яё])/ig, '$1')
        .replace(/(^|\s)(?:(?:в|к)\s+)?(?:[01]?\d|2[0-3]):[0-5]\d(?!\d)/g, '$1')
        .replace(/\s{2,}/g, ' ').replace(/^[\s,.:—-]+|[\s,.:—-]+$/g, ''));
}

// ---------- Добавление в пункт меню ----------
// done(true) — добавлено. Для «Моего дня» и «Лекарств» открывается заполненная форма: время и дни стоит проверить.
async function chatPut(sec, raw, done) {
    const text = chatStripPrefix(raw).text || raw.trim(), now = Date.now();
    if (sec === 'buy') {
        const items = parseShoppingText(text.replace(/(^|\s)(?:надо\s+|нужно\s+)?(?:купи|купить|докупить|покупки)(?![а-яё])\s*:?/ig, '$1').replace(/\s+и\s+/g, ', '));
        if (!items.length) { toast('Не нашёл, что купить'); return; }
        items.forEach((it, i) => { const item = { id: uid('t'), type: 'buy', name: it.name, qty: it.qty, price: it.price, currency: it.currency, done: false, store: '', addedAt: now + i, author: authorName() }; todos.push(item); if (it.price) syncShopPrice(item); });
        saveTodos(); renderTodo(); done(true);
    } else if (sec === 'todo') {
        const items = parseTaskText(text);
        if (!items.length) { toast('Не нашёл дело в тексте'); return; }
        items.forEach((it, i) => todos.push({ id: uid('t'), type: 'task', name: it.name, due: it.due, time: it.time || '', done: false, addedAt: now + i, author: authorName() }));
        saveTodos(); renderTodo(); done(true);
    } else if (sec === 'day') {
        const times = chatTimes(text), due = extractDue(chatTitle(text));
        const s = normText(text);
        const mode = /через день/.test(s) ? 'every' : /по (?:понедельник|вторник|сред|четверг|пятниц|суббот|воскресень|будн)|кажд\S+ (?:понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье)/.test(s) ? 'week' : CHAT_REPEAT_RE.test(s) ? 'daily' : 'once';
        let date = due.due || todayKey();
        if (!due.due && mode === 'once' && times.length && times[times.length - 1] <= fmtTime(now)) date = todayKey(1);   // время уже прошло — на завтра
        const names = ['понедельник', 'вторник', 'сред', 'четверг', 'пятниц', 'суббот', 'воскресень'];
        let wd = names.map((n, i) => s.includes(n) ? i : -1).filter(i => i >= 0);
        if (/будн/.test(s)) wd = [0, 1, 2, 3, 4];
        wkTaskSheet(null, { text: due.text || text, times, mode, date, wd, onSave: () => done(true) });
    } else if (sec === 'med') {
        const days = (normText(text).match(/(\d{1,3})\s*(?:дней|дня|день)(?![а-я])/) || [])[1];
        const dose = (text.match(/\d+(?:[.,]\d+)?\s*(?:мг|мл|таблет\S*|капсул\S*|капл\S*)/i) || [])[0] || '';
        const drug = chatTitle(text).replace(/(^|\s)(?:надо\s+|нужно\s+)?(?:пить|принимать|принять|выпить|лекарство)(?![а-яё])/ig, '$1').replace(dose, '')
            .replace(/(^|\s)(?:\d+\s*раза?\s+в\s+день|после еды|до еды|натощак|на ночь|утром|вечером|\d+\s*(?:дней|дня|день))(?![а-яё])/ig, '$1').replace(/\s{2,}/g, ' ').replace(/^[\s,.:—-]+|[\s,.:—-]+$/g, '');
        const note = (text.match(/после еды|до еды|во время еды|натощак|перед сном/i) || [])[0] || '';
        const times = chatTimes(text);
        medPlanFormSheet(null, { drug: capitalizeFirst(drug), dose, note, days, times: times.length ? times : medGuessTimes(text), from: todayKey(), onSave: () => done(true) });
    } else if (sec === 'idea') {
        ideas.unshift({ id: uid('i'), text, tags: extractTags(text), createdAt: now, updatedAt: now, author: authorName(), files: [], track: null });
        if (!saveIdeas()) { ideas.shift(); return; }
        renderIdeas(); done(true); if (typeof ideaAutoSoon === 'function') ideaAutoSoon();
    } else if (sec === 'diary') {
        const day = todayKey(); let e = dyGet(day);
        if (!e) { e = { id: 'dy' + day, date: day, html: '', text: '', files: [], createdAt: now, author: authorName() }; diary.push(e); }
        e.html = dyClean((e.html || '') + '<p>' + esc(text).replace(/\n/g, '<br>') + '</p>'); e.text = dyPlain(e.html).slice(0, 20000);
        saveDiary(); done(true);
    } else if (sec === 'movie') {
        const title = text.replace(/(^|\s)(?:надо\s+|нужно\s+|хочу\s+)?(?:посмотреть|глянуть)(?![а-яё])/ig, '$1').replace(/(^|\s)(?:фильм|сериал|мультфильм|кино)(?![а-яё])/ig, '$1').replace(/\s{2,}/g, ' ').replace(/^[\s"«:—-]+|[\s"»]+$/g, '').trim();
        if (!title) { toast('Не нашёл название фильма'); return; }
        done(true);   // обложка и оценки подтягиваются долго — отметку ставим сразу
        try { const r = await mvAddMovie({ title }, 'queue'); if (r.dup) toast('Этот фильм уже есть в «Кино»'); } catch (e) { toast('Не удалось добавить фильм: ' + e.message); }
    } else if (sec === 'script') {
        const sc = { id: uid('sc'), title: text.split('\n')[0].slice(0, 80), kind: 'film', status: 'idea', logline: text.slice(0, 300), genre: '', theme: '', author: authorName(), createdAt: now, updatedAt: now, els: scTemplateEls('blank'), chars: {}, beats: [], notes: text };
        scripts.unshift(sc);
        if (!saveScripts()) { scripts.shift(); return; }
        renderScripts(); done(true);
    }
}
function chatMarkAdded(msg, sec) {
    if (!chatLog.includes(msg)) return;
    msg.added = (msg.added || []).concat({ sec, at: Date.now() }); delete msg.skip;
    saveChat(); renderChat();   // отметка «В «…»» под сообщением заменяет всплывающую подсказку
}
function chatPickSheet(title, onPick) {
    const node = document.createElement('div');
    node.innerHTML = Object.entries(CHAT_SECTIONS).map(([k, v]) => '<button type="button" class="chat-pick" data-sec="' + k + '">' + ic(v.i) + '<span><b>' + v.n + '</b><small>' + v.path + '</small></span></button>').join('');
    const sheet = openSheet({ title, node });
    node.addEventListener('click', e => { const b = e.target.closest('[data-sec]'); if (!b) return; sheet.close(); setTimeout(() => onPick(b.dataset.sec), 220); });
}
function chatPost(text) {
    const msg = { id: uid('ms'), kind: 'me', text: text.slice(0, 4000), at: Date.now(), added: [] };
    chatLog.push(msg); saveChat(); renderChat(true); return msg;
}

// ---------- Напоминания ----------
// Всё, о чём напоминать в этот день: [{ type, key, time, title, line, done }]
function chatDue(day) {
    const out = [];
    medDosesOn(day).forEach(d => { if (d.plan.notify !== false) out.push({ type: 'med', key: d.key, time: d.time, title: 'Пора принять лекарство', line: d.plan.drug + (d.plan.dose ? ' — ' + d.plan.dose : '') + (d.plan.note ? ' (' + d.plan.note + ')' : ''), done: d.taken }); });
    wkItemsOn(day).forEach(d => { if (d.time !== '*' && d.task.notify !== false) out.push({ type: 'plan', key: d.key, time: d.time, title: 'Мой день', line: d.task.text, done: d.done }); });
    todos.forEach(t => { if (t.type === 'task' && t.due === day) out.push({ type: 'todo', key: t.id + '|' + day + '|' + (t.time || '09:00'), time: t.time || '09:00', title: 'Дело на сегодня', line: t.name, done: !!t.done }); });
    return out;
}
function chatItem(type, key) {
    const [id, day, time] = String(key).split('|');
    if (type === 'med') { const p = medById(id); return p ? { line: p.drug + (p.dose ? ' — ' + p.dose : '') + (p.note ? ' (' + p.note + ')' : ''), done: medIsTaken(p, day, time) } : null; }
    if (type === 'plan') { const t = wkById(id); return t ? { line: t.text, done: wkIsDone(t, day, time) } : null; }
    const t = todos.find(x => x.id === id); return t ? { line: t.name, done: !!t.done } : null;
}
function chatMarkDone(type, keys) {
    let n = 0;
    if (type === 'med') n = medMarkKeys(keys);
    else if (type === 'plan') n = wkMarkKeys(keys);
    else (keys || []).forEach(k => { const t = todos.find(x => x.id === String(k).split('|')[0]); if (t && !t.done) { toggleTodo(t.id, true); n++; } });
    renderChat();
    return n;
}
// Раз в 20 секунд: наступившие напоминания кладём в чат (за сегодня и за вчера, если iLife был закрыт)
function chatScan() {
    const today = todayKey(), now = fmtTime(Date.now());
    let seen = LS.get('chat_seen', null);
    const first = !seen;
    if (!seen) seen = {};
    let changed = false;
    (first ? [today] : [todayKey(-1), today]).forEach(day => {
        const groups = new Map();
        chatDue(day).forEach(x => {
            if (x.done || (day === today && x.time > now) || seen[x.type + ':' + x.key]) return;
            const g = x.type + '-' + day + '-' + x.time;
            if (!groups.has(g)) groups.set(g, []);
            groups.get(g).push(x);
        });
        groups.forEach((arr, g) => {
            const a = arr[0], id = 'rem-' + g;
            let msg = chatLog.find(m => m.id === id);
            if (!msg) { msg = { id, kind: 'rem', title: a.title, text: '', at: keyToMs(day) + (medMin(a.time) - 720) * 60000, rem: { type: a.type, day, time: a.time, keys: [] } }; chatLog.push(msg); }
            arr.forEach(x => { seen[x.type + ':' + x.key] = day; if (!msg.rem.keys.includes(x.key)) msg.rem.keys.push(x.key); });
            msg.text = msg.rem.keys.map(k => (chatItem(msg.rem.type, k) || {}).line).filter(Boolean).join('\n');
            changed = true;
            // лекарства и «Мой день» уведомляют сами; для дел со сроком — здесь (в приложении Android это делает само приложение)
            if (a.type === 'todo' && !window.iLifeNative && (medNotifyOn() || wkNotifyOn()) && day === today) wkShowNotification('Дело · ' + a.time, msg.text, 'ilife-' + id, []);
        });
    });
    const old = todayKey(-3);
    Object.keys(seen).forEach(k => { if (seen[k] < old) delete seen[k]; });
    LS.set('chat_seen', seen);
    if (changed) { saveChat(); renderChat(true); }
}

// ---------- Отрисовка ----------
function chatActive() { const s = $('#messages'); return !!s && s.classList.contains('is-active'); }
function chatBadge() {
    const read = LS.get('chat_read', 0);
    if (chatActive() && document.visibilityState === 'visible') LS.set('chat_read', Date.now());
    const n = chatActive() ? 0 : chatLog.filter(m => m.kind === 'rem' && m.at > read).length;
    $$('button[data-tab="messages"]').forEach(b => { if (n) b.dataset.badge = n > 99 ? '99+' : String(n); else delete b.dataset.badge; });
}
function chatBubble(m) {
    const time = '<time>' + fmtTime(m.at) + '</time>';
    if (m.kind === 'rem') {
        const type = m.rem.type, items = m.rem.keys.map(k => chatItem(type, k)).filter(Boolean);
        const all = items.length && items.every(x => x.done);
        const lines = items.length ? items.map(x => '<li' + (x.done ? ' class="is-done"' : '') + '>' + esc(x.line) + '</li>').join('') : '<li>' + esc(m.text) + '</li>';
        return '<div class="msg is-in" data-id="' + esc(m.id) + '"><div class="bubble"><b class="msg-h">' + ic(type === 'med' ? 'medication' : 'alarm') + esc(m.title) + ' · ' + esc(m.rem.time) + '</b><ul>' + lines + '</ul>' + time + '</div>' +
            '<div class="msg-acts">' + (all ? '<span class="msg-ok">' + ic('check') + (type === 'med' ? 'Принято' : 'Сделано') + '</span>' : items.length ? '<button type="button" class="chip is-on" data-done>' + ic('check') + (type === 'med' ? 'Принял' : 'Сделано') + '</button>' : '') +
            '<button type="button" class="chip" data-open="' + (type === 'med' ? 'med-schedule' : type === 'plan' ? 'day-cal' : 'todo') + '">Открыть</button></div></div>';
    }
    const added = m.added || [];
    let acts;
    if (added.length) acts = added.map(a => CHAT_SECTIONS[a.sec] ? '<button type="button" class="msg-ok" data-open="' + CHAT_SECTIONS[a.sec].tab + '">' + ic('check') + 'В «' + CHAT_SECTIONS[a.sec].n + '» · открыть</button>' : '').join('') + '<button type="button" class="chip" data-other>Ещё…</button>';
    else if (m.skip) acts = '<button type="button" class="chip" data-other>Добавить…</button>';
    else { const g = chatGuess(m.text), v = CHAT_SECTIONS[g]; acts = '<span class="msg-q">Добавить в</span><button type="button" class="chip is-on" data-add="' + g + '">' + ic(v.i) + v.n + '</button><button type="button" class="chip" data-other>Другое…</button><button type="button" class="chip" data-skip aria-label="Никуда не добавлять">Не надо</button>'; }
    return '<div class="msg is-out" data-id="' + esc(m.id) + '"><div class="bubble"><p>' + esc(m.text) + '</p>' + time + '</div><div class="msg-acts">' + acts + '</div></div>';
}
function renderChat(toEnd) {
    chatBadge();
    const list = $('#chat-list'); if (!list || !chatActive()) return;
    const atEnd = list.scrollHeight - list.scrollTop - list.clientHeight < 80, keep = list.scrollTop;
    const sorted = chatLog.slice().sort((a, b) => a.at - b.at).slice(-200);
    let day = '', html = '';
    sorted.forEach(m => { const k = dayKey(m.at); if (k !== day) { day = k; html += '<div class="chat-day"><span>' + esc(dayTitle(k)) + '</span></div>'; } html += chatBubble(m); });
    list.innerHTML = html || '<div class="empty"><div class="ico-big">' + ic('forum') + '</div><b>Напишите что угодно</b>«Купить молоко и хлеб», «Напомни в 18:00 позвонить маме», «Пить витамин D после еды» — iLife предложит, куда это добавить. Сюда же придут напоминания.</div>';
    list.scrollTop = toEnd || atEnd ? list.scrollHeight : keep;
}
function chatTabOpened() { renderChat(true); chatBadge(); }

function initChat() {
    if (!$('#messages')) return;
    const input = $('#chat-input');
    const grow = () => { input.style.height = 'auto'; if (input.scrollHeight) input.style.height = Math.min(input.scrollHeight, 140) + 'px'; $('#chat-send').disabled = !input.value.trim(); };
    const take = () => { const v = input.value.trim(); input.value = ''; grow(); return v; };
    input.addEventListener('input', grow);
    input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && !isMobileDevice()) { e.preventDefault(); $('#chat-send').click(); } });
    $('#chat-send').addEventListener('click', () => { const v = take(); if (v) chatPost(v); });
    // «+» — добавить вручную: набранный текст кладётся в выбранный пункт, без текста открывается сам пункт
    $('#chat-plus').addEventListener('click', () => chatPickSheet(input.value.trim() ? 'Куда добавить' : 'Добавить вручную', sec => {
        const v = take();
        if (v) { const msg = chatPost(v); chatPut(sec, v, () => chatMarkAdded(msg, sec)); return; }
        if (sec === 'day') { wkTaskSheet(null, { date: todayKey() }); return; }
        if (sec === 'med') { medPlanFormSheet(null); return; }
        showTab(CHAT_SECTIONS[sec].tab);
        if (sec === 'buy' || sec === 'todo') setTodoMode(sec === 'buy' ? 'buy' : 'task');
    }));
    $('#chat-list').addEventListener('click', e => {
        const row = e.target.closest('.msg'); if (!row) return;
        const msg = chatLog.find(m => m.id === row.dataset.id); if (!msg) return;
        const add = e.target.closest('[data-add]'), open = e.target.closest('[data-open]');
        if (add) chatPut(add.dataset.add, msg.text, () => chatMarkAdded(msg, add.dataset.add));
        else if (e.target.closest('[data-other]')) chatPickSheet('Куда добавить', sec => chatPut(sec, msg.text, () => chatMarkAdded(msg, sec)));
        else if (e.target.closest('[data-skip]')) { msg.skip = true; saveChat(); renderChat(); }
        else if (e.target.closest('[data-done]')) { if (chatMarkDone(msg.rem.type, msg.rem.keys)) toast(msg.rem.type === 'med' ? 'Отмечено: принято' : 'Отмечено: сделано'); }
        else if (open) showTab(open.dataset.open);
        else if (e.target.closest('.bubble')) openSheet({ title: 'Сообщение', html: '<p class="hint" style="white-space:pre-wrap">' + esc(msg.text) + '</p>', actions: [
            { label: 'Удалить', kind: 'danger', icon: 'delete', onClick: () => { chatLog = chatLog.filter(m => m !== msg); saveChat(); renderChat(); } },
            { label: 'Копировать', kind: 'primary', onClick: () => { navigator.clipboard.writeText(msg.text).then(() => toast('Скопировано'), () => toast('Не удалось скопировать')); } }] });
    });
    setTimeout(chatScan, 1800);
    setInterval(() => { chatScan(); chatBadge(); }, 20000);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { chatScan(); renderChat(); } });
    grow(); chatBadge();
}
