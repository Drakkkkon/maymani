'use strict';
// =====================================================================================================
// iLife 2.11.0 — ПРИЛОЖЕНИЕ ANDROID (android/): внутри него есть window.iLifeNative.
// Системные уведомления показывает само приложение, даже когда оно закрыто: страница передаёт ему расписание
// напоминаний на две недели вперёд. В обычном браузере этот файл ничего не делает.
// =====================================================================================================
const NATIVE = window.iLifeNative && typeof window.iLifeNative.notifySchedule === 'function' ? window.iLifeNative : null;
if (NATIVE) {
    // в WebView нет Notification: подставляем свой, чтобы переключатели «Напоминать» работали как в браузере
    const N = function () { this.close = () => {}; };
    Object.defineProperty(N, 'permission', { get: () => NATIVE.notifyAllowed() ? 'granted' : 'default' });
    N.requestPermission = () => new Promise(resolve => { window.ilAllowed = ok => { resolve(ok ? 'granted' : 'denied'); nativeCard(); nativeSync(); }; NATIVE.notifyAllow(); });
    Object.defineProperty(window, 'Notification', { value: N, configurable: true, writable: true });
}
// ---------- Вход Google через аккаунт телефона ----------
// Окно входа Google в WebView запрещено, поэтому подставляем свой google.accounts.oauth2 с тем же поведением:
// им пользуются «Google Диск», «Музыка» и «Комиксы».
const NATIVE_GOOGLE = NATIVE && typeof NATIVE.googleToken === 'function';
const nativeWait = new Map();
let nativeSeq = 0;
window.ilGoogle = r => { const done = nativeWait.get(r.id); if (done) { nativeWait.delete(r.id); done(r); } };
function nativeScopes(scope) {
    const map = { email: 'https://www.googleapis.com/auth/userinfo.email', profile: 'https://www.googleapis.com/auth/userinfo.profile', openid: '' };
    return String(scope).split(/\s+/).map(s => s in map ? map[s] : s).filter(Boolean).join(' ');
}
function nativeToken(scope, silent) {
    return new Promise(resolve => {
        const id = 'g' + (++nativeSeq);
        const timer = setTimeout(() => window.ilGoogle({ id, error: 'timeout' }), silent ? 20000 : 180000);
        nativeWait.set(id, r => { clearTimeout(timer); resolve(r); });
        NATIVE.googleToken(id, nativeScopes(scope), !!silent);
    });
}
function nativeGoogleError(code) {
    if (/UNREGISTERED|INVALID_AUDIENCE|DEVELOPER_ERROR/i.test(code)) return 'Приложение ещё не зарегистрировано в Google Cloud. Один раз создайте клиент OAuth типа Android — шаги в «Настройки» → «Сайты и инструкции» → «Приложение для Android».';
    if (/network|NetworkError/i.test(code)) return 'Нет связи с Google. Проверьте интернет.';
    if (code === 'no_google' || code === 'no_account') return 'На телефоне не найден аккаунт Google. Добавьте его в настройках Android.';
    return 'Телефон не выдал доступ Google (' + code + ').';
}
if (NATIVE_GOOGLE) {
    window.google = { accounts: { oauth2: {
        initTokenClient: cfg => ({
            requestAccessToken: o => {
                nativeToken(cfg.scope, o && o.prompt === 'none').then(r => {
                    if (r.access_token) cfg.callback({ access_token: r.access_token, expires_in: r.expires_in, scope: cfg.scope });
                    else if (r.error === 'cancel' || r.error === 'needs_user' || r.error === 'timeout') { if (cfg.error_callback) cfg.error_callback({ type: 'popup_closed' }); }
                    else cfg.callback({ error: 'apk', error_description: 'apk:' + nativeGoogleError(r.error) });
                });
            }
        }),
        initCodeClient: cfg => ({ requestCode: () => cfg.callback({ error: 'в приложении это не нужно — доступ продлевается сам, нажмите обычное «Подключить»' }) }),
        hasGrantedAllScopes: () => true,
        revoke: (token, cb) => { NATIVE.googleSignOut(token || ''); if (cb) cb(); }
    } } };
}
// Токен живёт около часа: в приложении продлеваем сами, без кнопки «Подтвердить»
let nativeRenewing = null;
function nativeRenew() {
    if (!NATIVE_GOOGLE || !gUser) return Promise.resolve(false);
    if (gTokenExpiry > Date.now() + 5 * 60000) return Promise.resolve(true);
    if (!nativeRenewing) nativeRenewing = nativeToken(G_SCOPES, true).then(r => {
        nativeRenewing = null;
        if (!r.access_token) return false;
        gStoreToken(r.access_token, r.expires_in);
        if (gCfg().auto) runCloudSync(); else setCloudStatus('off');
        return true;
    });
    return nativeRenewing;
}

// ---------- Обновление самого приложения ----------
function nativeUpdate() {
    const box = $('#apk-update'); if (!NATIVE || !box) return;
    if (!NATIVE.updateStatus) {
        box.innerHTML = '<p class="hint"><b>Эту версию приложения обновите вручную один раз</b> (скачайте новый APK, шаги — в инструкции). В новой работают вход Google и обновление изнутри.</p>';
        return;
    }
    const u = JSON.parse(NATIVE.updateStatus());
    box.innerHTML = '<p class="hint">Версия приложения: <b>' + esc(u.installed) + '</b>' + (u.text ? '. ' + esc(u.text) : '') + '</p><div class="btn-group">' +
        (u.available ? '<button type="button" class="btn btn-primary" data-upd="install">Обновить до ' + esc(u.available) + '</button>' : '') +
        '<button type="button" class="btn" data-upd="check">Проверить обновление</button></div>';
}

let nativeLast = '';
function nativeTakeDone() {
    try { JSON.parse(NATIVE.takeDone() || '[]').forEach(d => chatMarkDone(d.type, d.keys)); } catch (e) { console.warn(e); }
}
function nativeSync() {
    if (!NATIVE) return;
    nativeTakeDone();
    const on = { med: LS.get('med_notify', true) !== false, plan: LS.get('dp_notify', true) !== false, todo: true };
    const list = [], now = Date.now();
    for (let i = -1; i < 14; i++) {
        const day = todayKey(i), groups = new Map();
        chatDue(day).forEach(x => {
            if (x.done || !on[x.type]) return;
            const at = keyToMs(day) + (medMin(x.time) - 720) * 60000;   // keyToMs — полдень по Алматы
            if (at < now - 7200000) return;
            const id = x.type + '-' + day + '-' + x.time;
            if (!groups.has(id)) groups.set(id, { id, at, type: x.type, title: x.title + ' · ' + x.time, body: [], keys: [], action: x.type === 'med' ? 'Принял' : 'Сделано' });
            const g = groups.get(id); g.body.push(x.line); g.keys.push(x.key);
        });
        groups.forEach(g => { g.body = g.body.join('\n'); list.push(g); });
    }
    const json = JSON.stringify(list.sort((a, b) => a.at - b.at).slice(0, 300));
    if (json !== nativeLast) { nativeLast = json; NATIVE.notifySchedule(json); }
}
// Кнопки «Принял» / «Сделано» прямо в уведомлении и нажатие на само уведомление
function nativeResume() {
    if (!NATIVE) return;
    nativeTakeDone();
    if (NATIVE.takeOpen() === 'messages') showTab('messages');
    chatScan(); nativeSync(); nativeCard(); nativeRenew();
}
function nativeCard() {
    if (!NATIVE) return;
    const ok = NATIVE.notifyAllowed(), b = $('#apk-badge');
    if (b) b.textContent = ok ? 'Включены' : 'Выключены';
    const a = $('#apk-allow'); if (a) a.hidden = ok;
    nativeUpdate();
    const t = $('#apk-state');
    if (t) t.textContent = ok ? 'Напоминания приходят в системные уведомления, даже когда iLife закрыт.' : 'Разрешите уведомления, чтобы не пропустить лекарства и дела.';
}
// Системная кнопка «Назад»: сначала закрыть окно, потом выйти из подменю
window.ilBack = () => {
    if (sheetStack.length) { sheetStack[sheetStack.length - 1].close(); return true; }
    if ((document.documentElement.dataset.nav || 'main') !== 'main') { navShowMain(); return true; }
    return false;
};
function initNative() {
    const card = $('#apk-card');
    if (!NATIVE) return;
    document.documentElement.classList.add('is-apk');
    if (card) card.hidden = false;
    $('#apk-allow').addEventListener('click', () => Notification.requestPermission());
    $('#apk-test').addEventListener('click', () => { if (NATIVE.notifyAllowed()) NATIVE.notifyTest(); else Notification.requestPermission(); });
    $('#apk-settings').addEventListener('click', () => NATIVE.notifySettings());
    window.ilResume = nativeResume;
    window.ilUpdate = nativeUpdate;
    $('#apk-update').addEventListener('click', e => {
        const b = e.target.closest('[data-upd]'); if (!b) return;
        if (b.dataset.upd === 'check') { toast('Проверяю обновление…'); NATIVE.updateCheck(); } else NATIVE.updateInstall();
    });
    if (!NATIVE.updateStatus) setTimeout(() => toast('Вышло новое приложение iLife: вход Google и обновление изнутри', { action: 'Подробнее', ms: 9000, onAction: () => openInstruction('instr-apk') }), 2500);
    setInterval(nativeRenew, 4 * 60000);
    setTimeout(nativeResume, 900);
    setInterval(nativeSync, 5000);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') nativeResume(); else nativeSync(); });
}
