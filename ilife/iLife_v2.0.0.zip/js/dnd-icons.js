'use strict';
// =====================================================================================================
// iLife 2.0.0 — ЗНАЧКИ ДЛЯ РАЗДЕЛА «ДНД». Дополняют набор из js/icons.js (подключается в <head> сразу после него).
// Нарисованы здесь же простыми фигурами (24×24), поэтому интернет и шрифт значков не нужны.
// Обводкой нарисованы «линейные» значки (S), остальные — заливкой.
// =====================================================================================================
(function () {
    if (!window.ICONS) return;
    const S = d => '<path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="' + d + '"/>';
    const dot = (x, y, r) => 'M' + (x - r) + ' ' + y + 'a' + r + ' ' + r + ' 0 1 0 ' + (2 * r) + ' 0 ' + r + ' ' + r + ' 0 1 0 ' + (-2 * r) + ' 0z';
    const F = d => '<path fill-rule="evenodd" d="' + d + '"/>';
    const add = {
        // разделы
        d20: F('M12 1.5 21.1 6.75v10.5L12 22.5 2.9 17.25V6.75zM12 6.6 17.5 16H6.5z'),
        casino: F('M6 3h12a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3z' + dot(8.5, 8.5, 1.5) + dot(15.5, 8.5, 1.5) + dot(12, 12, 1.5) + dot(8.5, 15.5, 1.5) + dot(15.5, 15.5, 1.5)),
        dnd_board: '<path d="M3 3h8v10H3zM13 3h8v6h-8zM13 11h8v10h-8zM3 15h8v6H3z"/>',
        cube3d: F('M12 1.8 21 6.9v10.2l-9 5.1-9-5.1V6.9zM12 4.3 18.2 7.8 12 11.3 5.8 7.8zM5 9.8l6 3.4v6.4l-6-3.4zM19 9.8v6.4l-6 3.4v-6.4z'),
        account_tree: '<path d="M22 11V3h-7v3H9V3H2v8h7V8h2v10h4v3h7v-8h-7v3h-2V8h2v3z"/>',
        // инструменты доски
        cursor: '<path d="M5 3l14 8-6 1.8L11 19z"/>',
        hand: S('M8 13V5.5a1.5 1.5 0 0 1 3 0V11M11 10V4.5a1.5 1.5 0 0 1 3 0V11M14 10V6.5a1.5 1.5 0 0 1 3 0V15a6 6 0 0 1-6 6h-1a6 6 0 0 1-4.8-2.4L3.3 14.8a1.5 1.5 0 0 1 2.3-1.9L8 15.5'),
        sticky: F('M5 3h14a2 2 0 0 1 2 2v9.2L14.2 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zM14.5 19.4l4.9-4.9h-3.9a1 1 0 0 0-1 1z'),
        card: F('M5 4h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM5.5 6.5h13V9h-13zM5.5 11h8v1.6h-8zM5.5 14.2h10v1.6h-10z'),
        shapes: '<path d="M7 2 2 11h10z"/><circle cx="17" cy="7" r="4.5"/><rect x="3" y="14" width="8" height="8" rx="1.2"/><path d="M17.5 13.2 22 17.7l-4.5 4.5L13 17.7z"/>',
        frame: S('M7 3v18M17 3v18M3 7h18M3 17h18'),
        connector: S('M5 19c0-8 5-12 13-12M14 3l4.5 4L14 11'),
        pen: S('M3 17c2.5-6 4-10 6-10s0 8 3 8 3-6 5-6 2 5 4 5'),
        redo: '<g transform="matrix(-1 0 0 1 24 0)">' + (window.ICONS.undo || '') + '</g>',
        fit: S('M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5') + '<rect x="8.5" y="8.5" width="7" height="7" rx="1"/>',
        grid: S('M3.5 3.5h17v17h-17zM9.2 3.5v17M14.8 3.5v17M3.5 9.2h17M3.5 14.8h17'),
        minimap: S('M3 5h18v14H3z') + '<rect x="12" y="11" width="6" height="5" rx="1"/>',
        magnet: S('M6 4v7a6 6 0 0 0 12 0V4M6 8h4M14 8h4'),
        layers: S('M12 3 3 8l9 5 9-5zM3 12.5l9 5 9-5M3 16.5l9 5 9-5'),
        to_front: S('M4 4h16M12 20V8M7 13l5-5 5 5'),
        to_back: S('M4 20h16M12 4v12M7 11l5 5 5-5'),
        al_left: S('M4 3v18M8 7h12M8 13h7'),
        al_center: S('M12 3v18M6 7h12M8.5 13h7'),
        al_right: S('M20 3v18M4 7h12M9 13h7'),
        al_top: S('M3 4h18M7 8v12M13 8v7'),
        al_middle: S('M3 12h18M7 6v12M13 8.5v7'),
        al_bottom: S('M3 20h18M7 4v12M13 9v7'),
        dist_h: S('M4 3v18M20 3v18M10 8h4v8h-4z'),
        dist_v: S('M3 4h18M3 20h18M8 10h8v4H8z'),
        group: S('M3 3h12v12H3zM9 9h12v12H9z'),
        line_straight: S('M4 20 20 4'),
        line_curve: S('M4 20c0-10 16 4 16-16'),
        line_elbow: S('M4 20h8V4h8'),
        head_none: S('M4 12h16'),
        head_end: S('M4 12h15M14 7l5 5-5 5'),
        head_both: S('M6 12h12M10 7l-5 5 5 5M14 7l5 5-5 5'),
        dashed: S('M3 12h3M10.5 12h3M18 12h3'),
        more_horiz: '<path d="' + dot(5, 12, 1.8) + dot(12, 12, 1.8) + dot(19, 12, 1.8) + '"/>',
        text_size: S('M4 19 9.5 6 15 19M6 14.5h7M17 10v9M17 10l-2 2M17 10l2 2'),
        // предметы ДНД
        pin: F('M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zM12 6.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z'),
        skull: F('M12 2.5a8 8 0 0 0-4.5 14.6V21h9v-3.9A8 8 0 0 0 12 2.5zM8.8 9.5a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM15.2 9.5a2 2 0 1 0 0 4 2 2 0 0 0 0-4z'),
        gem: F('M6.5 3h11L22 9l-10 12L2 9zM6.2 9h11.6L15.6 5.2H8.4z'),
        swords: S('M4 20 16 8M13 5l6 6M20 20 8 8M5 11l6-6M3.5 20.5l3-3M20.5 20.5l-3-3'),
        auto_stories: S('M12 6c-2-1.5-5-2-8-2v14c3 0 6 .5 8 2 2-1.5 5-2 8-2V4c-3 0-6 .5-8 2zM12 6v14'),
        map: S('M9 4 3 6.5V20l6-2.5 6 2.5 6-2.5V4l-6 2.5zM9 4v13.5M15 6.5V20'),
        person_add: '<path d="M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>',
        checkroom: S('M12 7a2 2 0 1 0-2-2M12 7v3M12 10 3.6 16.6A1.6 1.6 0 0 0 4.6 19.5h14.8a1.6 1.6 0 0 0 1-2.9z'),
        auto_arrange: '<path d="M3 3h6v5H3zM15 9.5h6v5h-6zM3 16h6v5H3z"/>' + S('M9 5.5h3v9h3M9 18.5h3v-4'),
        shield_d: F('M12 2 4 5v6c0 5 3.4 9.4 8 11 4.6-1.6 8-6 8-11V5zM12 5.2 17.8 7.4V11c0 3.7-2.4 7-5.8 8.4z'),
        heart: '<path d="M12 21s-8-5.2-8-11a4.6 4.6 0 0 1 8-3 4.6 4.6 0 0 1 8 3c0 5.8-8 11-8 11z"/>',
        bolt_fill: '<path d="M13 2 4 14h6l-1 8 9-12h-6z"/>',
        compress: S('M4 4l6 6M4 10h6V4M20 20l-6-6M20 14h-6v6')
    };
    Object.keys(add).forEach(k => { if (!window.ICONS[k]) window.ICONS[k] = add[k]; });
})();
