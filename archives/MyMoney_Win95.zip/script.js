// Основной скрипт приложения (заглушка)
console.log("Приложение загружено");

// Демонстрация логики ПИН-кода для визуального шаблона
document.querySelectorAll('.pin-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        if (e.target.innerText === 'OK') {
            document.getElementById('pin-screen').style.display = 'none';
            document.querySelector('.app-wrapper').style.display = 'flex';
        }
    });
});
