
let transactions = [];
let subscriptions = [];
let priorityGoal = { name: '', amount: 0, icon: '🎯' };
let manualLimit = 0;
let savings = 0;

async function init() {
    loadData();
    checkDailyRollover();
    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('tx-datetime').value = now.toISOString().slice(0,16);
    
    document.querySelectorAll('.icon-btn').forEach(btn => {
        btn.onclick = (e) => {
            document.querySelectorAll('.icon-btn').forEach(b => b.classList.remove('selected'));
            e.target.classList.add('selected');
        }
    });
    updateUI(false);
    autoSyncPull();
}

function loadData() {
    if (localStorage.getItem('finance_tx')) transactions = JSON.parse(localStorage.getItem('finance_tx'));
    if (localStorage.getItem('finance_subs')) subscriptions = JSON.parse(localStorage.getItem('finance_subs'));
    if (localStorage.getItem('finance_goal')) priorityGoal = JSON.parse(localStorage.getItem('finance_goal'));
    if (localStorage.getItem('finance_limit')) manualLimit = parseFloat(localStorage.getItem('finance_limit'));
    if (localStorage.getItem('finance_savings')) savings = parseFloat(localStorage.getItem('finance_savings'));
    
    if (localStorage.getItem('finance_theme') === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
        document.getElementById('theme-icon').innerText = 'light_mode';
    }
    if (localStorage.getItem('finance_bg')) setHeaderBg(localStorage.getItem('finance_bg'));
    if (localStorage.getItem('finance_sync_url')) document.getElementById('sync-url').value = localStorage.getItem('finance_sync_url');
    if (localStorage.getItem('finance_sync_id')) document.getElementById('sync-id').value = localStorage.getItem('finance_sync_id');
    document.getElementById('manual-limit').value = manualLimit > 0 ? manualLimit : '';
}

function saveSyncConfig() {
    localStorage.setItem('finance_sync_url', document.getElementById('sync-url').value.trim());
    localStorage.setItem('finance_sync_id', document.getElementById('sync-id').value.trim());
}

function toggleTheme() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
    document.getElementById('theme-icon').innerText = isDark ? 'dark_mode' : 'light_mode';
    localStorage.setItem('finance_theme', isDark ? 'light' : 'dark');
}

function setHeaderBg(bgClass) {
    document.getElementById('main-header').className = bgClass;
    localStorage.setItem('finance_bg', bgClass);
}

function getTxDateStr(datetimeStr) {
    return datetimeStr.includes('T') ? datetimeStr.split('T')[0] : datetimeStr;
}

function checkDailyRollover() {
    const today = new Date().toISOString().split('T')[0];
    let lastDate = localStorage.getItem('finance_lastDate');
    if (!lastDate) { localStorage.setItem('finance_lastDate', today); return; }
    
    if (lastDate !== today && manualLimit > 0) {
        let dayExpenses = transactions.filter(t => getTxDateStr(t.date) === lastDate && t.type === 'expense' && !t.isSystem).reduce((sum, t) => sum + t.amount, 0);
        let saved = manualLimit - dayExpenses;
        if (saved > 0 && priorityGoal.amount > 0) {
            savings += saved;
            transactions.push({ id: Date.now().toString(), type: 'expense', amount: saved, category: 'Автоперенос в копилку (остаток лимита)', date: lastDate + 'T23:59', isSystem: true });
            updateUI(true);
        }
        localStorage.setItem('finance_lastDate', today);
    }
}

function updateUI(pushToCloud = false) {
    saveDataLocally();
    let balance = transactions.reduce((acc, tx) => tx.type === 'income' ? acc + tx.amount : acc - tx.amount, 0);
    document.getElementById('balance').innerText = `${balance.toFixed(0)} ₸`;
    document.getElementById('savings').innerText = `${savings.toFixed(0)} ₸`;
    document.getElementById('daily-limit-display').innerText = manualLimit > 0 ? `${manualLimit} ₸` : 'Не установлен';

    renderTransactions();
    renderSubscriptions();
    renderGoal();
    generateReport(); 
    if (pushToCloud) autoSyncPush();
}

function renderTransactions() {
    const txList = document.getElementById('tx-list');
    txList.innerHTML = '';
    if (transactions.length === 0) { txList.innerHTML = '<p class="hint" style="text-align:center; padding: 20px;">Записей пока нет</p>'; return; }

    let sortedAsc = [...transactions].sort((a,b) => new Date(a.date.replace('T', ' ')) - new Date(b.date.replace('T', ' ')));
    let groups = {};
    let runBalance = 0;
    
    sortedAsc.forEach(tx => {
        runBalance += (tx.type === 'income' ? tx.amount : -tx.amount);
        let dDate = getTxDateStr(tx.date);
        if(!groups[dDate]) groups[dDate] = { income: 0, expense: 0, endBalance: 0, items: [] };
        if(!tx.isSystem) {
            if(tx.type === 'income') groups[dDate].income += tx.amount;
            else groups[dDate].expense += tx.amount;
        }
        groups[dDate].endBalance = runBalance;
        groups[dDate].items.push(tx);
    });

    Object.keys(groups).sort((a,b) => new Date(b) - new Date(a)).forEach(date => {
        let g = groups[date];
        let [y, m, d] = date.split('-');
        let header = document.createElement('div');
        header.className = 'date-group-header';
        header.innerHTML = `<h4>${d}.${m}.${y}</h4><p><span style="color:var(--income)">+${g.income}</span> <span style="color:var(--expense)">-${g.expense}</span> <span>Итог: <strong>${g.endBalance} ₸</strong></span></p>`;
        txList.appendChild(header);
        
        g.items.reverse().forEach(tx => {
            let sign = tx.type === 'income' ? '+' : '-';
            let timeStr = tx.date.includes('T') ? ` <span style="font-size:12px;color:#aaa;">${tx.date.split('T')[1]}</span>` : '';
            let div = document.createElement('div');
            div.className = `tx-item ${tx.type}`;
            div.innerHTML = `<div class="tx-info"><strong>${tx.category}</strong><br>${timeStr}</div><strong style="font-size: 15px;">${sign}${tx.amount} ₸</strong>${tx.isSystem ? '' : `<div class="tx-actions"><button onclick="editTx('${tx.id}')"><span class="material-icons" style="font-size:16px;">edit</span></button><button onclick="deleteTx('${tx.id}')"><span class="material-icons" style="font-size:16px; color:#f44336;">delete</span></button></div>`}`;
            txList.appendChild(div);
        });
    });
}

function addSub() {
    let name = document.getElementById('sub-name').value.trim();
    let amount = parseFloat(document.getElementById('sub-amount').value);
    let day = parseInt(document.getElementById('sub-day').value);
    if(!name || !amount || isNaN(day)) { alert("Заполните поля подписки!"); return; }
    subscriptions.push({ id: Date.now().toString(), name, amount, day });
    document.getElementById('sub-name').value = '';
    document.getElementById('sub-amount').value = '';
    updateUI(true);
}

function deleteSub(id) {
    if(confirm("Удалить подписку?")) { subscriptions = subscriptions.filter(s => s.id !== id); updateUI(true); }
}

function paySub(id) {
    let sub = subscriptions.find(s => s.id === id);
    if(!sub) return;
    let now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    transactions.push({ id: Date.now().toString(), type: 'expense', amount: sub.amount, category: `Подписка: ${sub.name}`, date: now.toISOString().slice(0,16) });
    updateUI(true);
    alert(`Подписка «${sub.name}» списана!`);
}

function renderSubscriptions() {
    let list = document.getElementById('subs-list');
    list.innerHTML = '';
    if(subscriptions.length === 0) { list.innerHTML = '<p class="hint" style="text-align:center; padding: 15px;">Нет подписок</p>'; return; }
    subscriptions.forEach(sub => {
        let div = document.createElement('div');
        div.className = 'sub-item';
        div.innerHTML = `<div class="sub-info"><strong>${sub.name}</strong><br><span style="font-size: 12px; color: var(--text-muted);">Списание: ${sub.day}-го числа</span></div><strong style="font-size: 16px; color: var(--expense);">-${sub.amount} ₸</strong><div class="sub-actions"><button class="pay-btn" onclick="paySub('${sub.id}')">Списать</button><button onclick="deleteSub('${sub.id}')"><span class="material-icons" style="font-size:16px; color:#f44336;">delete</span></button></div>`;
        list.appendChild(div);
    });
}

function saveTx(type) {
    let amount = parseFloat(document.getElementById('amount').value);
    let category = document.getElementById('category').value;
    let datetime = document.getElementById('tx-datetime').value; 
    if (!amount || !category || !datetime) { alert('Заполните все поля!'); return; }
    transactions.push({ id: Date.now().toString(), type, amount, category, date: datetime });
    clearForm();
    updateUI(true);
}

function deleteTx(id) { if(confirm("Удалить запись?")) { transactions = transactions.filter(t => t.id !== id); updateUI(true); } }
function editTx(id) {
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        document.getElementById('edit-id').value = tx.id;
        document.getElementById('tx-datetime').value = tx.date.includes('T') ? tx.date : tx.date + 'T00:00';
        document.getElementById('amount').value = tx.amount;
        document.getElementById('category').value = tx.category;
        document.getElementById('add-btns').style.display = 'none';
        document.getElementById('save-edit-btn').style.display = 'flex';
    }
}
function saveEdit() {
    let id = document.getElementById('edit-id').value;
    let tx = transactions.find(t => t.id === id);
    if(tx) {
        tx.amount = parseFloat(document.getElementById('amount').value);
        tx.category = document.getElementById('category').value;
        tx.date = document.getElementById('tx-datetime').value;
    }
    clearForm();
    updateUI(true);
}
function clearForm() {
    document.getElementById('amount').value = '';
    document.getElementById('category').value = '';
    document.getElementById('edit-id').value = '';
    document.getElementById('add-btns').style.display = 'flex';
    document.getElementById('save-edit-btn').style.display = 'none';
}

function generateReport() {
    let type = document.getElementById('report-type').value;
    let tbody = document.getElementById('report-tbody');
    tbody.innerHTML = '';
    let groups = {};
    transactions.forEach(tx => {
        if(tx.isSystem) return; 
        let dt = tx.date.includes('T') ? tx.date : tx.date + 'T00:00';
        let key = type === 'days' ? dt.split('T')[0] : (type === 'hours' ? `${dt.split('T')[0]} ${dt.split('T')[1].split(':')[0]}:00` : dt.split('T')[0]);
        if(!groups[key]) groups[key] = { inc: 0, exp: 0 };
        if(tx.type === 'income') groups[key].inc += tx.amount; else groups[key].exp += tx.amount;
    });
    let keys = Object.keys(groups).sort((a,b) => b.localeCompare(a));
    if (keys.length === 0) { tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">Нет данных</td></tr>'; return; }
    keys.forEach(k => {
        let g = groups[k]; let total = g.inc - g.exp;
        tbody.innerHTML += `<tr><td>${k}</td><td style="color:var(--income)">${g.inc}</td><td style="color:var(--expense)">${g.exp}</td><td style="font-weight:bold;">${total}</td></tr>`;
    });
}

function exportExcel() {
    let data = [['Дата', 'Время', 'Тип', 'Категория', 'Сумма']];
    transactions.forEach(t => data.push([t.date.split('T')[0], t.date.split('T')[1]||'', t.type==='income'?'Доход':'Расход', t.category, t.amount]));
    let wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(data), "Записи");
    XLSX.writeFile(wb, `Money_Export.xlsx`);
}

function exportForPages() { exportExcel(); }
function setPriorityGoal() {
    let name = document.getElementById('goal-name').value;
    let amount = parseFloat(document.getElementById('goal-amount').value);
    let icon = document.querySelector('.icon-btn.selected').getAttribute('data-icon');
    if(!name || !amount) return;
    priorityGoal = { name, amount, icon };
    updateUI(true);
}
function renderGoal() {
    let gd = document.getElementById('current-goal-display');
    if (priorityGoal.name && priorityGoal.amount > 0) {
        let percent = Math.min(100, (savings / priorityGoal.amount) * 100);
        gd.innerHTML = `<h4>${priorityGoal.icon} ${priorityGoal.name}</h4><p>Собрано: ${savings.toFixed(0)} ₸ из ${priorityGoal.amount} ₸ (${percent.toFixed(1)}%)</p><div class="goal-progress"><div class="goal-bar" style="width: ${percent}%"></div></div>`;
    }
}
function saveSettings() {
    manualLimit = parseFloat(document.getElementById('manual-limit').value) || 0;
    saveSyncConfig();
    updateUI(true);
    alert('Настройки сохранены!');
}
function saveDataLocally() {
    localStorage.setItem('finance_tx', JSON.stringify(transactions));
    localStorage.setItem('finance_subs', JSON.stringify(subscriptions));
    localStorage.setItem('finance_savings', savings.toString());
    localStorage.setItem('finance_limit', manualLimit.toString());
    localStorage.setItem('finance_goal', JSON.stringify(priorityGoal));
}
function exportBackup() {
    let data = { tx: transactions, subs: subscriptions, savings, limit: manualLimit, goal: priorityGoal };
    let blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
    let link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `money_backup.json`;
    link.click();
}
function importBackup(e) {
    let file = e.target.files[0];
    if(!file) return;
    let reader = new FileReader();
    reader.onload = (event) => {
        try {
            let data = JSON.parse(event.target.result);
            if(data.tx) transactions = data.tx;
            if(data.subs) subscriptions = data.subs;
            if(data.savings !== undefined) savings = data.savings;
            if(data.limit !== undefined) manualLimit = data.limit;
            if(data.goal) priorityGoal = data.goal;
            updateUI(true);
            alert("Данные загружены!");
        } catch(err) { alert("Ошибка файла!"); }
    };
    reader.readAsText(file);
}
function clearAllData() {
    if(confirm("Сбросить все данные?")) {
        localStorage.clear();
        transactions = []; subscriptions = []; savings = 0; manualLimit = 0;
        updateUI(true);
    }
}
async function autoSyncPull() {
    let url = localStorage.getItem('finance_sync_url');
    let id = localStorage.getItem('finance_sync_id');
    if(!url || !id) return;
    try {
        let res = await fetch(`${url.replace(/\/g, '')}/${id}.json`);
        if(res.ok) {
            let data = await res.json();
            if(data) {
                if(data.tx) transactions = data.tx;
                if(data.subs) subscriptions = data.subs;
                if(data.savings !== undefined) savings = data.savings;
                if(data.limit !== undefined) manualLimit = data.limit;
                if(data.goal) priorityGoal = data.goal;
                updateUI(false);
            }
        }
    } catch(e) {}
}
async function autoSyncPush() {
    let url = localStorage.getItem('finance_sync_url');
    let id = localStorage.getItem('finance_sync_id');
    if(!url || !id) return;
    let data = { tx: transactions, subs: subscriptions, savings, limit: manualLimit, goal: priorityGoal };
    try {
        await fetch(`${url.replace(/\/g, '')}/${id}.json`, { method: 'PUT', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data) });
    } catch(e) {}
}
async function pushToCloud() { await autoSyncPush(); alert("Отправлено!"); }
async function pullFromCloud() { await autoSyncPull(); alert("Загружено!"); }
async function forceSyncPull() { await autoSyncPull(); alert("Обновлено!"); }

function showTab(id, btn) {
    document.querySelectorAll('.tab').forEach(t => t.style.display = 'none');
    document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
    document.getElementById(id).style.display = 'block';
    btn.classList.add('active');
}

window.onload = init;
