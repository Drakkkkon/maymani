'use strict';
// =====================================================================================================
// iLife — СТРАНИЦА «НАСТРОЙКИ»: Google (заглушка), Spotify, темы Android и шрифт, масштаб, профиль, копия данных.
// =====================================================================================================

// ---------- Google: пока заглушка ----------
function initGoogleStub() {
    const explain = () => openSheet({
        title: 'Google Диск — скоро',
        html: '<p style="font-size:15px;line-height:1.55;margin:0 0 10px">Вход через Google и синхронизация через Google Диск ещё не подключены — это заготовка в настройках.</p>' +
            '<p class="hint" style="font-size:14px">Как это будет: вход через Google (OAuth, Client ID), папка «iLife» на вашем Диске, файл с идеями и делами и отдельная папка вложений. Изменения будут отправляться автоматически и подтягиваться на другие устройства — как в My Money.</p>' +
            '<p class="hint" style="font-size:14px;margin-top:8px">Пока все данные хранятся только на этом устройстве. Чтобы не потерять их, сохраняйте копию: Настройки → «Данные» → «Сохранить копию».</p>',
        actions: [{ label: 'Понятно', kind: 'primary' }]
    });
    $('#google-signin').addEventListener('click', explain);
    $('#google-sync').addEventListener('click', explain);
    $('#google-auto').addEventListener('change', e => { e.target.checked = false; explain(); });
}

// ---------- Spotify ----------
function renderSpotifyCard() {
    const cfg = spCfg(), on = spotifyConnected();
    $('#sp-client').value = cfg.clientId || '';
    $('#sp-redirect').textContent = spotifyRedirectUri();
    const problem = spotifyRedirectProblem();
    $('#sp-problem').textContent = problem;
    $('#sp-problem').style.color = problem ? 'var(--md-error)' : '';
    $('#sp-badge').textContent = on ? 'Подключён' : 'Не подключён';
    $('#sp-badge').style.background = on ? 'color-mix(in oklab, var(--md-income) 24%, var(--md-container))' : '';
    $('#sp-badge').style.color = on ? 'var(--md-income)' : '';
    $('#sp-state-text').innerHTML = on ? '<b>' + esc(cfg.user ? 'Аккаунт: ' + cfg.user : 'Spotify подключён') + '</b><span class="hint">Кнопка Spotify на странице «Идеи» берёт трек из вашего аккаунта</span>'
        : '<b>Spotify не подключён</b><span class="hint">Вставьте Client ID и нажмите «Подключить»</span>';
    $('#sp-connect').hidden = on; $('#sp-disconnect').hidden = !on;
    $('#sp-connect').disabled = !!problem;
}
function initSpotifyCard() {
    $('#sp-client').addEventListener('change', e => { spSave({ clientId: e.target.value.trim() }); renderSpotifyCard(); });
    $('#sp-connect').addEventListener('click', () => { spSave({ clientId: $('#sp-client').value.trim() }); spotifyLogin(); });
    $('#sp-disconnect').addEventListener('click', async () => { if (await confirmSheet('Отключить Spotify?', 'Токены будут удалены с этого устройства. Сохранённые заметки с треками останутся.', 'Отключить', true)) { spotifyDisconnect(); renderSpotifyCard(); toast('Spotify отключён'); } });
    $('#sp-copy').addEventListener('click', async () => toast((await copyText(spotifyRedirectUri())) ? 'Адрес скопирован' : 'Не удалось скопировать'));
    renderSpotifyCard();
}

// ---------- Темы и шрифт ----------
function renderThemes() {
    $('#theme-grid').innerHTML = PALETTES.map(p =>
        '<button type="button" class="theme-swatch' + (p.id === settings.theme ? ' is-active' : '') + '" data-theme="' + p.id + '" aria-pressed="' + (p.id === settings.theme) + '">' +
        '<span class="sw-prev" style="background:' + p.surface + '"><span class="sw-pill" style="background:' + p.primary + '"></span>' +
        '<span class="sw-card" style="background:' + p.surfaceContainer + '"><i style="background:' + p.onSurface + '"></i><i style="background:' + p.onSurfaceVariant + '"></i></span>' +
        '<span class="sw-fab" style="background:' + p.tertiaryContainer + '"></span></span>' +
        '<span class="sw-check">' + ic('check') + '</span>' +
        '<span class="nm">' + esc(p.name) + (p.dark ? '<span class="dk">тёмная</span>' : '<span class="dk">светлая</span>') + '</span></button>').join('');
    $('#font-grid').innerHTML = FONTS.map(f => '<button type="button" class="font-card' + (f.id === settings.font ? ' is-active' : '') + '" data-font="' + f.id + '"><b>' + esc(f.name) + '</b><span style="font-family:' + f.stack.replace(/"/g, "'") + '">Аа Әә 123 ₸</span></button>').join('');
}
function initLook() {
    $('#theme-grid').addEventListener('click', e => { const b = e.target.closest('[data-theme]'); if (!b) return; applyTheme(b.dataset.theme); saveSettings(); renderThemes(); });
    $('#font-grid').addEventListener('click', e => { const b = e.target.closest('[data-font]'); if (!b) return; applyFont(b.dataset.font); saveSettings(); renderThemes(); });
    renderThemes();
}

// ---------- Масштаб ----------
function refreshScaleUI() {
    const pct = currentScale();
    const rng = $('#zoom-range'); if (!rng) return;
    if (document.activeElement !== rng) rng.value = pct;
    $('#zoom-val').textContent = pct + '%';
    $('#zoom-mode').textContent = settings.scaleMode === 'auto' ? 'подбирается под экран' : 'задан вручную';
    $('#zoom-auto').classList.toggle('btn-primary', settings.scaleMode === 'auto');
}
function initZoom() {
    const rng = $('#zoom-range');
    rng.min = SCALE_MIN; rng.max = SCALE_MAX; rng.step = 5;
    rng.addEventListener('input', () => { $('#zoom-val').textContent = rng.value + '%'; });
    rng.addEventListener('change', () => setScale(+rng.value, 'manual')); // применяется, когда ползунок отпущен — иначе он «убегает» из-под пальца
    $('#zoom-minus').addEventListener('click', () => setScale(currentScale() - 5, 'manual'));
    $('#zoom-plus').addEventListener('click', () => setScale(currentScale() + 5, 'manual'));
    $('#zoom-100').addEventListener('click', () => setScale(100, 'manual'));
    $('#zoom-auto').addEventListener('click', () => { setScale(0, 'auto'); toast('Масштаб подобран под экран: ' + currentScale() + '%'); });
    refreshScaleUI();
}

// ---------- Профиль ----------
function initProfile() {
    const a = $('#profile-author'); a.value = authorName();
    a.addEventListener('change', () => { settings.author = a.value.trim().slice(0, 30) || 'Александр'; a.value = settings.author; saveSettings(); updateSplashClock(); updateComposerMeta(); renderTodo(); toast('Имя автора: ' + settings.author); });
    const s = $('#profile-splash'); s.checked = !!settings.splash;
    s.addEventListener('change', () => { settings.splash = s.checked; saveSettings(); toast(s.checked ? 'Экран блокировки будет при запуске' : 'Экран блокировки выключен'); });
}

// ---------- Данные: копия и восстановление ----------
async function renderStorageInfo() {
    let text = 'Идей: ' + ideas.length + ' · дел и покупок: ' + todos.length;
    try { if (navigator.storage && navigator.storage.estimate) { const e = await navigator.storage.estimate(); if (e && e.usage != null) text += ' · занято на устройстве: ' + fmtBytes(e.usage); } } catch (e) {}
    $('#data-info').textContent = text;
}
async function backupData() {
    const btn = $('#data-backup'); btn.disabled = true;
    try {
        const media = [];
        for (const rec of await BlobDB.all()) media.push({ id: rec.id, name: rec.name, type: rec.type, size: rec.size, data: await blobToBase64(rec.blob), thumb: rec.thumb ? await blobToBase64(rec.thumb) : null, thumbType: rec.thumb ? rec.thumb.type : null });
        const data = { app: 'iLife', version: APP_VERSION, exportedAt: new Date().toISOString(), settings, ideas, todos, prices, media };
        const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
        const name = stampName('копия', 'json');
        const res = await deliverFile(blob, name);
        toast(res === 'unsupported' ? 'В этом приложении сохранить файл нельзя — откройте iLife в браузере' : res === 'shared' ? 'Копия готова — выберите, куда её отправить' : 'Копия сохранена: ' + name);
    } catch (e) { console.error(e); toast('Не удалось собрать копию'); } finally { btn.disabled = false; }
}
function b64ToBlob(b64, type) { const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new Blob([u], { type: type || 'application/octet-stream' }); }
async function restoreData(file) {
    let data;
    try { data = JSON.parse(await file.text()); } catch (e) { toast('Это не файл копии iLife'); return; }
    if (!data || data.app !== 'iLife' || !Array.isArray(data.ideas)) { toast('Это не файл копии iLife'); return; }
    const ok = await confirmSheet('Заменить данные копией?', 'Идей в копии: ' + data.ideas.length + ', дел и покупок: ' + (data.todos || []).length + '. Текущие идеи, дела и вложения на этом устройстве будут заменены.', 'Заменить', true);
    if (!ok) return;
    try {
        await BlobDB.clear();
        for (const m of data.media || []) await BlobDB.put({ id: m.id, name: m.name, type: m.type, size: m.size, blob: b64ToBlob(m.data, m.type), thumb: m.thumb ? b64ToBlob(m.thumb, m.thumbType) : null });
        ideas = data.ideas; todos = data.todos || []; prices = data.prices || [];
        saveIdeas(); saveTodos(); IX.clear();
        renderIdeas(); renderTodo(); renderDraft(); renderStorageInfo();
        toast('Данные восстановлены из копии');
    } catch (e) { console.error(e); toast('Не удалось восстановить данные'); }
}
function initData() {
    $('#data-backup').addEventListener('click', backupData);
    const inp = $('#data-file');
    $('#data-restore').addEventListener('click', () => { inp.value = ''; inp.click(); });
    inp.addEventListener('change', () => { if (inp.files[0]) restoreData(inp.files[0]); });
    renderStorageInfo();
}

function initSettings() { initGoogleStub(); initSpotifyCard(); initLook(); initZoom(); initProfile(); initData(); }
