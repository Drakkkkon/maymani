document.addEventListener("DOMContentLoaded", () => {
    // --- 1. ЛОГИКА ПИН-КОДА ---
    let currentPin = "";
    const dots = document.querySelectorAll('.pin-dots .dot');
    const pinScreen = document.getElementById('pin-screen');
    const appWrapper = document.querySelector('.app-wrapper');

    // Функция обновления визуальных точек
    function updateDots() {
        dots.forEach((dot, index) => {
            if (index < currentPin.length) {
                dot.classList.add('filled');
            } else {
                dot.classList.remove('filled');
            }
        });
    }

    // Изначально очищаем все точки
    updateDots();

    // Обработка нажатий кнопок калькулятора ПИН-кода
    document.querySelectorAll('.pin-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const val = e.target.innerText.trim();
            
            if (val === 'C') {
                // Очистка ПИН-кода
                currentPin = "";
                updateDots();
            } else if (val === 'OK') {
                // Подтверждение
                if (currentPin.length === 4) {
                    // В реальном приложении здесь сверка с Firebase. Сейчас просто пускаем дальше.
                    pinScreen.style.display = 'none';
                    appWrapper.style.display = 'flex';
                } else {
                    alert("ПИН-код должен содержать ровно 4 цифры.");
                }
            } else {
                // Ввод цифр (максимум 4)
                if (currentPin.length < 4) {
                    currentPin += val;
                    updateDots();
                }
            }
        });
    });

    // --- 2. ЛОГИКА МЕНЮ НАВИГАЦИИ (АКТИВНЫЕ КНОПКИ) ---
    function setupNavigation(selector) {
        const buttons = document.querySelectorAll(selector);
        buttons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                // Убираем класс active у всех кнопок в этой панели
                buttons.forEach(b => b.classList.remove('active'));
                // Добавляем нажатой
                e.currentTarget.classList.add('active');
            });
        });
    }

    // Применяем логику к боковому и нижнему мобильному меню
    setupNavigation('.sidebar-nav button');
    setupNavigation('.mobile-nav button');
    
    // Демонстрация работы кнопок Доход/Расход
    document.querySelector('.btn-income').addEventListener('click', () => alert('Доход добавлен!'));
    document.querySelector('.btn-expense').addEventListener('click', () => alert('Расход добавлен!'));
});
