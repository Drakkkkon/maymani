// --- ТЕМА «WINDOWS 95_ПУСК»: РАБОЧИЙ СТОЛ, ОКНА СТРАНИЦ, КНОПКА «СВЕРНУТЬ ВСЕ» ---
// Отдельная тема с другой логикой. После заставки и ПИН-кода — пустой рабочий стол без панели «Пуск» со значками разделов меню
// (Записи, Стена, Подписки, Зарплата, Статистика, Отчёты, Цели, Котировки, Цены, Настройки; порядок и набор — как в
// Настройки → «Пункты меню»). Нажатие на значок открывает страницу в окне с анимацией (рамка «растёт» из значка, как в Windows 95);
// страница в окне выглядит как обычно. Крестик закрывает окно, «_» сворачивает, «□» разворачивает (на ПК), заголовок окна можно
// двигать. Внизу справа квадратная кнопка «Свернуть все» (вместо круглой кнопки синхронизации): сворачивает все окна на рабочий стол;
// значок свёрнутой страницы подсвечен зелёным огоньком, нажатие на него возвращает окно.
//
// Как это устроено: раздел (div.tab) по-прежнему тот же самый элемент с теми же id и обработчиками — он только переезжает
// из <main> страницы в <main> окна и возвращается обратно при закрытии. Блок «Текущий баланс» (header) переезжает в верхнее
// окно, поэтому в окне всё как обычно. Все остальные темы этот файл не затрагивает: пока тема не выбрана, ничего не создаётся.
// Оформление — css/desk95.css (только при html[data-w95="desk95"]), значки — js/desk95-icons.js.

(function () {
    'use strict';

    const THEME = 'desk95';
    const root = document.documentElement;
    const isDesk = () => root.getAttribute('data-w95') === THEME;
    const isWide = () => window.innerWidth >= 769; // как isDesktopView() в js/layout.js
    const reduceMotion = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    const sound = (n) => { try { if (typeof playSound === 'function') playSound(n); } catch (e) {} };
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const iconSvg = (id) => (window.DESK95_ICONS && (window.DESK95_ICONS[id] || window.DESK95_ICONS.generic)) || '';

    let started = false;      // рабочий стол построен (тема выбрана)
    let desk = null;          // #desk95
    let iconsBox = null;      // контейнер значков
    let minBtn = null;        // «Свернуть все»
    let origWrap = null;      // обычная страница (.main-wrapper), скрыта темой
    let origMain = null;      // её <main>: сюда возвращаются закрытые разделы
    let header = null;        // блок «Текущий баланс»
    const wins = new Map();   // id раздела → { id, el, body, main, tab, min, max }
    let order = [];           // id окон: впереди — верхнее
    let cascade = 0;          // сдвиг каждого нового окна на ПК

    // исходные функции script.js, extras.js: их вызывает тема, остальные темы работают как раньше
    const orig = {
        showTab: typeof window.showTab === 'function' ? window.showTab : null,
        renderMenus: typeof window.renderMenus === 'function' ? window.renderMenus : null,
        swipeBlocked: typeof window.swipeBlocked === 'function' ? window.swipeBlocked : null,
        editTx: typeof window.editTx === 'function' ? window.editTx : null
    };

    // ---------- меню ----------
    function menuItems() {
        const items = typeof MENU_ITEMS !== 'undefined' ? MENU_ITEMS : [];
        let ids = items.map(i => i.id);
        try {
            if (typeof getMenuState === 'function') {
                const st = getMenuState();
                ids = st.order.filter(id => !st.hidden.includes(id));
            }
        } catch (e) {}
        return ids.map(id => items.find(i => i.id === id)).filter(Boolean);
    }
    const itemOf = (id) => (typeof MENU_ITEMS !== 'undefined' ? MENU_ITEMS : []).find(i => i.id === id);

    // ---------- построение рабочего стола ----------
    function build() {
        const wrapper = document.querySelector('.app-wrapper');
        origWrap = document.querySelector('.main-wrapper');
        origMain = origWrap ? origWrap.querySelector(':scope > main') : null;
        header = document.getElementById('main-header');
        if (!wrapper || !origMain) return false;

        desk = document.createElement('div');
        desk.id = 'desk95';
        desk.innerHTML =
            '<div class="desk-icons" role="group" aria-label="Рабочий стол"></div>' +
            '<button type="button" id="desk-min-all" class="is-idle" title="Свернуть все" aria-label="Свернуть все"></button>';
        wrapper.appendChild(desk);
        iconsBox = desk.querySelector('.desk-icons');
        minBtn = desk.querySelector('#desk-min-all');
        minBtn.innerHTML = iconSvg('minall');

        iconsBox.addEventListener('click', (e) => {
            const b = e.target.closest('.desk-icon');
            if (!b) return;
            selectIcon(b);
            open(b.dataset.id, b);
        });
        desk.addEventListener('pointerdown', (e) => {
            if (!e.target.closest('.desk-icon')) selectIcon(null);
        });
        minBtn.addEventListener('click', () => minimizeAll());

        renderIcons();
        return true;
    }

    function renderIcons() {
        if (!iconsBox) return;
        iconsBox.innerHTML = menuItems().map(it =>
            `<button type="button" class="desk-icon" data-id="${esc(it.id)}" aria-label="${esc(it.label)}">` +
            `<span class="di-img">${iconSvg(it.id)}</span><span class="di-label">${esc(it.label)}</span></button>`).join('');
        syncIconStates();
    }

    function syncIconStates() {
        if (!iconsBox) return;
        iconsBox.querySelectorAll('.desk-icon').forEach(b => {
            const w = wins.get(b.dataset.id);
            b.classList.toggle('is-open', !!w);
            b.classList.toggle('is-min', !!(w && w.min));
        });
        if (minBtn) minBtn.classList.toggle('is-idle', !frontWin());
    }

    function selectIcon(btn) {
        if (!iconsBox) return;
        iconsBox.querySelectorAll('.desk-icon.is-sel').forEach(b => b.classList.remove('is-sel'));
        if (btn) btn.classList.add('is-sel');
    }

    const iconEl = (id) => (iconsBox ? iconsBox.querySelector(`.desk-icon[data-id="${id}"]`) : null);

    // ---------- окна ----------
    function frontWin() {
        for (const id of order) {
            const w = wins.get(id);
            if (w && !w.min) return w;
        }
        return null;
    }

    function applyZ() {
        order.forEach((id, i) => {
            const w = wins.get(id);
            if (w) w.el.style.zIndex = String(10 + (order.length - i));
        });
    }

    // Блок «Текущий баланс» всегда в верхнем окне (если окон нет — возвращается на скрытую обычную страницу)
    function placeHeader() {
        if (!header) return;
        const f = frontWin();
        if (f) {
            if (header.parentNode !== f.body || f.body.firstChild !== header) f.body.insertBefore(header, f.body.firstChild);
        } else if (origWrap && header.parentNode !== origWrap) {
            origWrap.insertBefore(header, origMain);
        }
    }

    function focusWin(w) {
        order = [w.id].concat(order.filter(x => x !== w.id));
        applyZ();
        wins.forEach(x => x.el.classList.toggle('is-inactive', x !== w));
        if (typeof currentTabId === 'string') currentTabId = w.id;
        placeHeader();
        syncIconStates();
    }

    // Ширина полосы со значками (справа от неё на ПК открываются окна, чтобы значки оставались доступны)
    function iconStripWidth() {
        const icons = iconsBox ? iconsBox.querySelectorAll('.desk-icon') : [];
        if (!icons.length) return 0;
        const d = desk.getBoundingClientRect();
        let right = 0;
        icons.forEach(b => { right = Math.max(right, b.getBoundingClientRect().right - d.left); });
        return Math.round(right) + 12;
    }

    // Размер и положение нового окна: на телефоне окно на весь экран (css), на ПК — большое окно справа от значков со сдвигом «лесенкой»
    function placeWin(w) {
        if (!isWide()) return;
        const W = desk.clientWidth, H = desk.clientHeight, n = cascade++ % 5;
        const strip = iconStripWidth(), free = W - strip - 14;
        const width = Math.min(1100, Math.max(Math.min(640, W - 12), free)), height = Math.min(920, H - 96);
        const slack = Math.max(0, free - width); // свободное место справа от значков: окно стоит посередине и сдвигается лесенкой
        const left = strip + Math.max(0, Math.min(slack, Math.round(slack / 2) + (n - 2) * 22));
        w.el.style.width = width + 'px';
        w.el.style.height = height + 'px';
        w.el.style.left = Math.max(6, Math.min(left, W - width - 6)) + 'px';
        w.el.style.top = (10 + n * 20) + 'px';
    }

    function createWindow(id) {
        const it = itemOf(id);
        const tab = document.getElementById(id);
        const el = document.createElement('section');
        el.className = 'desk-win';
        el.dataset.tab = id;
        el.setAttribute('role', 'dialog');
        el.setAttribute('aria-label', it.label);
        el.innerHTML =
            '<div class="desk-titlebar">' +
            `<span class="dt-icon">${iconSvg(id)}</span><span class="dt-title">${esc(it.label)}</span>` +
            '<span class="dt-btns">' +
            '<button type="button" class="dt-btn dt-min" title="Свернуть" aria-label="Свернуть"></button>' +
            '<button type="button" class="dt-btn dt-max" title="Развернуть" aria-label="Развернуть"></button>' +
            '<button type="button" class="dt-btn dt-close" title="Закрыть" aria-label="Закрыть"></button>' +
            '</span></div>' +
            '<div class="desk-body"><main></main></div>';
        const w = { id, el, tab, body: el.querySelector('.desk-body'), main: el.querySelector('main'), min: false, max: false };
        w.main.appendChild(tab);
        desk.appendChild(el);
        wins.set(id, w);
        order.unshift(id);
        placeWin(w);

        const bar = el.querySelector('.desk-titlebar');
        el.querySelector('.dt-min').addEventListener('click', () => { minimize(w); const f = frontWin(); if (f) focusWin(f); else syncIconStates(); sound('close'); });
        el.querySelector('.dt-max').addEventListener('click', () => toggleMax(w));
        el.querySelector('.dt-close').addEventListener('click', () => closeWin(id));
        bar.addEventListener('dblclick', (e) => { if (!e.target.closest('.dt-btn')) toggleMax(w); });
        el.addEventListener('pointerdown', () => { if (order[0] !== id && !w.min) focusWin(w); }, true);
        enableDrag(w, bar);
        return w;
    }

    function toggleMax(w) {
        if (!isWide()) return;
        w.max = !w.max;
        w.el.classList.toggle('is-max', w.max);
        const b = w.el.querySelector('.dt-max');
        b.title = w.max ? 'Восстановить' : 'Развернуть';
        b.setAttribute('aria-label', b.title);
        window.dispatchEvent(new Event('resize')); // диаграммы и полосы прокрутки подстраиваются
    }

    function enableDrag(w, bar) {
        bar.addEventListener('pointerdown', (e) => {
            if (e.button !== 0 || e.target.closest('.dt-btn') || !isWide() || w.max) return;
            const start = rectIn(w.el), sx = e.clientX, sy = e.clientY;
            try { bar.setPointerCapture(e.pointerId); } catch (err) {}
            const move = (ev) => {
                const W = desk.clientWidth, H = desk.clientHeight;
                w.el.style.left = Math.max(-start.w + 120, Math.min(W - 60, start.x + ev.clientX - sx)) + 'px';
                w.el.style.top = Math.max(0, Math.min(H - 34, start.y + ev.clientY - sy)) + 'px';
            };
            const up = () => {
                bar.removeEventListener('pointermove', move);
                bar.removeEventListener('pointerup', up);
                bar.removeEventListener('pointercancel', up);
                window.dispatchEvent(new Event('resize'));
            };
            bar.addEventListener('pointermove', move);
            bar.addEventListener('pointerup', up);
            bar.addEventListener('pointercancel', up);
        });
    }

    // ---------- анимация «рамка из значка в окно» (как в Windows 95) ----------
    function rectIn(el) {
        const r = el.getBoundingClientRect(), d = desk.getBoundingClientRect();
        return { x: r.left - d.left, y: r.top - d.top, w: r.width, h: r.height };
    }

    // Несколько пунктирных рамок ступенчато движутся от from к to, затем вызывается done
    function wire(from, to, ms, done) {
        if (reduceMotion() || !from || !to) { done(); return; }
        const N = 3, STEPS = 6, frames = [];
        for (let i = 0; i < N; i++) {
            const f = document.createElement('div');
            f.className = 'desk-wire';
            f.style.display = 'none';
            desk.appendChild(f);
            frames.push(f);
        }
        const t0 = performance.now();
        const lerp = (a, b, t) => a + (b - a) * t;
        const step = (now) => {
            const p = Math.min(1, (now - t0) / ms), k = Math.ceil(p * STEPS);
            frames.forEach((f, i) => {
                const kk = k - i;
                if (kk < 1) { f.style.display = 'none'; return; }
                const t = kk / STEPS;
                f.style.display = '';
                f.style.left = lerp(from.x, to.x, t) + 'px';
                f.style.top = lerp(from.y, to.y, t) + 'px';
                f.style.width = Math.max(2, lerp(from.w, to.w, t)) + 'px';
                f.style.height = Math.max(2, lerp(from.h, to.h, t)) + 'px';
            });
            if (p < 1 && k < STEPS + N) requestAnimationFrame(step);
            else { frames.forEach(f => f.remove()); done(); }
        };
        requestAnimationFrame(step);
    }

    // ---------- открыть / свернуть / закрыть ----------
    // Побочные действия обычного showTab (подсветка, «Котировки», «Цены», размеры блоков, журнал администратора),
    // при этом остальные открытые окна остаются видимыми
    function runShowTab(id) {
        if (orig.showTab) orig.showTab(id, null);
        wins.forEach(x => { if (!x.min) x.tab.style.display = ''; });
        if (typeof currentTabId === 'string') currentTabId = id;
    }

    function open(id, fromEl, instant) {
        if (!started || !itemOf(id) || !document.getElementById(id)) return;
        let w = wins.get(id);
        if (w && !w.min) { focusWin(w); return; } // уже открыто — на передний план
        const restoring = !!w;
        if (!w) w = createWindow(id);
        w.min = false;
        w.el.classList.remove('is-min');
        focusWin(w);
        sound('open');

        const reveal = () => {
            w.el.style.visibility = '';
            w.busy = false;
            if (w.min || wins.get(id) !== w) return;
            if (!instant) { w.el.classList.add('is-pop'); setTimeout(() => w.el.classList.remove('is-pop'), 200); }
            runShowTab(id);
            focusWin(w);
            window.dispatchEvent(new Event('resize'));
        };
        if (instant || reduceMotion()) { reveal(); return; }
        w.busy = true;
        w.el.style.visibility = 'hidden';
        const from = fromEl ? rectIn(fromEl.querySelector('.di-img') || fromEl) : (iconEl(id) ? rectIn(iconEl(id)) : null);
        wire(from, rectIn(w.el), 200, reveal);
    }

    function minimize(w) {
        if (w.min) return;
        w.min = true;
        const to = iconEl(w.id) ? rectIn(iconEl(w.id).querySelector('.di-img') || iconEl(w.id)) : null;
        const from = rectIn(w.el);
        const finish = () => { if (w.min) { w.el.classList.add('is-min'); w.el.style.visibility = ''; } placeHeader(); syncIconStates(); };
        if (reduceMotion() || w.busy || w.el.style.visibility === 'hidden') { finish(); return; }
        w.el.style.visibility = 'hidden';
        wire(from, to, 190, finish);
        placeHeader();
        syncIconStates();
    }

    function minimizeAll() {
        const list = order.map(id => wins.get(id)).filter(w => w && !w.min);
        if (!list.length) return;
        sound('close');
        list.forEach(minimize);
        placeHeader();
        syncIconStates();
    }

    function closeWin(id) {
        const w = wins.get(id);
        if (!w) return;
        sound('close');
        wins.delete(id);
        order = order.filter(x => x !== id);
        const f = frontWin();
        if (f) focusWin(f); else { placeHeader(); syncIconStates(); }
        const cleanup = () => {
            // раздел возвращается на скрытую обычную страницу (если его уже не забрало новое окно)
            if (w.tab.parentNode === w.main && origMain) { w.tab.style.display = 'none'; origMain.appendChild(w.tab); }
            if (header && w.body.contains(header)) placeHeader();
            w.el.remove();
            syncIconStates();
        };
        if (reduceMotion()) { cleanup(); return; }
        w.el.classList.add('is-closing');
        setTimeout(cleanup, 130);
    }

    // ---------- вход в тему и выход из неё ----------
    function enter(boot) {
        if (started || !isDesk()) return;
        if (!build()) return;
        started = true;
        const cur = typeof currentTabId === 'string' ? currentTabId : '';
        // страницы без окон спрятаны; при запуске приложения рабочий стол пуст
        document.querySelectorAll('main > .tab').forEach(t => { t.style.display = 'none'; });
        if (!boot && cur && itemOf(cur)) open(cur, null, true); // тему выбрали из настроек: текущая страница остаётся в окне
        syncIconStates();
    }

    function leave() {
        if (!started) return;
        started = false;
        const f = frontWin();
        const keep = (f && f.id) || (typeof currentTabId === 'string' ? currentTabId : 'transactions');
        wins.forEach(w => {
            if (origMain) { w.tab.style.display = 'none'; origMain.appendChild(w.tab); }
            w.el.remove();
        });
        wins.clear();
        order = [];
        cascade = 0;
        if (header && origWrap && header.parentNode !== origWrap) origWrap.insertBefore(header, origMain);
        if (desk) desk.remove();
        desk = iconsBox = minBtn = null;
        // обычный вид: открыта та страница, что была в верхнем окне
        if (orig.showTab) orig.showTab(itemOf(keep) ? keep : 'transactions', null);
        if (typeof renderMenus === 'function') { try { renderMenus(); } catch (e) {} }
        window.dispatchEvent(new Event('resize'));
    }

    // ---------- подключение к приложению ----------
    // showTab вызывают меню, свайпы, настройки: в теме «Пуск» это «открыть окно»
    if (orig.showTab) {
        window.showTab = function (tabId, btn) {
            if (started && isDesk()) { open(tabId); return; }
            return orig.showTab.apply(this, arguments);
        };
    }
    // перерисовка меню (порядок / скрытые пункты) обновляет и значки
    if (orig.renderMenus) {
        window.renderMenus = function () {
            const r = orig.renderMenus.apply(this, arguments);
            if (started) renderIcons();
            return r;
        };
    }
    // свайпы влево / вправо в окнах не листают разделы
    if (orig.swipeBlocked) {
        window.swipeBlocked = function () { return (started && isDesk()) || orig.swipeBlocked.apply(this, arguments); };
    }
    // правка записи: форма «Новая запись» прокручивается вверх внутри окна
    if (orig.editTx) {
        window.editTx = function () {
            const r = orig.editTx.apply(this, arguments);
            if (started) {
                const f = document.getElementById('edit-id');
                const body = f && f.closest('.desk-body');
                if (body) body.scrollTo(0, 0);
            }
            return r;
        };
    }

    window.addEventListener('w95-theme', (e) => {
        const id = e && e.detail && e.detail.id;
        if (id === THEME) enter(false); else leave();
    });

    // окно при изменении размера экрана остаётся в пределах стола
    window.addEventListener('resize', () => {
        if (!started || !desk) return;
        const W = desk.clientWidth, H = desk.clientHeight;
        wins.forEach(w => {
            if (w.max || !isWide()) return;
            if (!w.el.style.width) { placeWin(w); return; } // окно открыто на узком экране, экран стал широким
            const r = rectIn(w.el);
            if (r.x > W - 60) w.el.style.left = Math.max(0, W - r.w - 6) + 'px';
            if (r.y > H - 34) w.el.style.top = Math.max(0, H - 60) + 'px';
        });
    });

    // Запуск приложения с уже выбранной темой: пустой рабочий стол
    const boot = () => { if (isDesk()) enter(true); };
    if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', boot);
    else boot();

    // для проверки и других скриптов
    window.deskOpen = open;
    window.deskMinimizeAll = minimizeAll;
    window.deskCloseWindow = closeWin;
})();
