package kz.mymoney.widget

import android.content.Context
import android.content.SharedPreferences
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Google снова просит подтвердить вход (нужно открыть приложение виджета). */
class AuthRequiredException : Exception("Нужно войти через Google")

/**
 * Загрузка данных для виджета.
 * Баланс, лимит, копилка и имя — из файла my_money_data.json на Google Диске (его ведёт сайт My Money).
 * Курсы валют и погода — из тех же бесплатных источников, что и на сайте.
 */
object DataRepository {
    const val DRIVE_FILE_NAME = "my_money_data.json"

    private const val PREFS = "money_widget"
    const val K_SIGNED_IN = "signed_in"
    const val K_READONLY = "use_drive_readonly"
    const val K_EMAIL = "email"
    const val K_SITE_URL = "site_url"
    const val K_BALANCE = "balance"
    const val K_LIMIT = "limit"
    const val K_SAVINGS = "savings"
    const val K_NAME = "name"
    const val K_WEATHER = "weather"
    const val K_RATES = "rates"
    const val K_STATUS = "status"
    const val K_FILE_MISSING = "file_missing"
    const val K_UPDATED = "updated_at"
    const val K_REFRESH_STARTED = "refresh_started_at"

    private const val SCOPE_DRIVE_FILE = "https://www.googleapis.com/auth/drive.file"
    private const val SCOPE_DRIVE_READONLY = "https://www.googleapis.com/auth/drive.readonly"
    private const val SCOPE_EMAIL = "https://www.googleapis.com/auth/userinfo.email"

    private val RU: Locale = Locale.forLanguageTag("ru-RU")
    private val ALMATY: TimeZone = TimeZone.getTimeZone("GMT+05:00") // Казахстан: UTC+5 с марта 2024

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Запрос доступа. readonly=true — запасной вариант, если файл сайта не виден с правами drive.file. */
    fun authorizationRequest(readonly: Boolean): AuthorizationRequest {
        val scopes = mutableListOf(Scope(SCOPE_DRIVE_FILE), Scope(SCOPE_EMAIL))
        if (readonly) scopes.add(Scope(SCOPE_DRIVE_READONLY))
        return AuthorizationRequest.builder().setRequestedScopes(scopes).build()
    }

    /** Токен без окна входа: работает, если доступ уже выдан. null — нужно открыть приложение и войти. */
    suspend fun silentToken(context: Context): String? {
        val readonly = prefs(context).getBoolean(K_READONLY, false)
        val result = Identity.getAuthorizationClient(context.applicationContext)
            .authorize(authorizationRequest(readonly))
            .await()
        return if (result.hasResolution()) null else result.accessToken
    }

    suspend fun fetchEmail(token: String): String = withContext(Dispatchers.IO) {
        JSONObject(httpGet("https://www.googleapis.com/oauth2/v3/userinfo", token)).optString("email")
    }

    /** Обновляет всё, что показывает виджет, и сохраняет в настройки приложения. */
    suspend fun refresh(context: Context) = withContext(Dispatchers.IO) {
        val p = prefs(context)
        val edit = p.edit()
        var status = ""
        var fileMissing = false

        runCatching { loadRates() }.onSuccess { edit.putString(K_RATES, it) }
        runCatching { loadWeather() }.onSuccess { edit.putString(K_WEATHER, it) }

        if (p.getBoolean(K_SIGNED_IN, false)) {
            try {
                val token = silentToken(context) ?: throw AuthRequiredException()
                val data = loadDriveData(token)
                if (data == null) {
                    fileMissing = true
                    status = "Файл данных не найден на Google Диске"
                } else {
                    applyData(data, edit)
                }
            } catch (e: AuthRequiredException) {
                status = "Откройте приложение виджета и войдите снова"
            } catch (e: Exception) {
                status = "Ошибка: " + (e.message ?: e.javaClass.simpleName)
            }
        } else {
            status = "Войдите через Google в приложении виджета"
        }

        edit.putString(K_STATUS, status)
            .putBoolean(K_FILE_MISSING, fileMissing)
            .putLong(K_UPDATED, System.currentTimeMillis())
            .apply()
    }

    // --- Google Диск ---
    private fun loadDriveData(token: String): JSONObject? {
        val q = URLEncoder.encode("name='$DRIVE_FILE_NAME' and trashed=false", "UTF-8")
        val list = JSONObject(
            httpGet(
                "https://www.googleapis.com/drive/v3/files?q=$q&spaces=drive&orderBy=modifiedTime%20desc" +
                    "&pageSize=1&fields=files(id,modifiedTime)",
                token
            )
        )
        val files = list.optJSONArray("files") ?: return null
        if (files.length() == 0) return null
        val id = files.getJSONObject(0).getString("id")
        return JSONObject(httpGet("https://www.googleapis.com/drive/v3/files/$id?alt=media", token))
    }

    private fun applyData(json: JSONObject, edit: SharedPreferences.Editor) {
        var balance = 0.0
        for (t in asList(json.opt("tx"))) {
            val amount = t.optDouble("amount", 0.0).let { if (it.isNaN()) 0.0 else it }
            if (t.optString("type") == "income") balance += amount else balance -= amount
        }
        val savings = json.optDouble("savings", 0.0).let { if (it.isNaN()) 0.0 else it }
        val limit = json.optDouble("limit", 0.0).let { if (it.isNaN()) 0.0 else it }
        val name = json.optJSONObject("profile")?.optString("name").orEmpty()

        edit.putString(K_BALANCE, money(balance))
            .putString(K_SAVINGS, money(savings))
            .putString(K_LIMIT, if (limit > 0) money(limit) else "не установлен")
            .putString(K_NAME, name)
    }

    /** Записи могут прийти массивом или объектом (старые данные из Firebase). */
    private fun asList(value: Any?): List<JSONObject> = when (value) {
        is JSONArray -> (0 until value.length()).mapNotNull { value.optJSONObject(it) }
        is JSONObject -> value.keys().asSequence().mapNotNull { value.optJSONObject(it) }.toList()
        else -> emptyList()
    }

    // --- Курсы валют (тенге за 1 USD / EUR / RUB) ---
    private fun loadRates(): String {
        val sources = listOf(
            "https://latest.currency-api.pages.dev/v1/currencies/kzt.json",
            "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/kzt.json"
        )
        for (url in sources) {
            try {
                val kzt = JSONObject(httpGet(url, null)).getJSONObject("kzt")
                return formatRates(1 / kzt.getDouble("usd"), 1 / kzt.getDouble("eur"), 1 / kzt.getDouble("rub"))
            } catch (e: Exception) {
                // источник недоступен — пробуем следующий
            }
        }
        val rates = JSONObject(httpGet("https://open.er-api.com/v6/latest/KZT", null)).getJSONObject("rates")
        return formatRates(1 / rates.getDouble("USD"), 1 / rates.getDouble("EUR"), 1 / rates.getDouble("RUB"))
    }

    private fun formatRates(usd: Double, eur: Double, rub: Double): String =
        String.format(RU, "$ %.2f ₸   € %.2f ₸   ₽ %.2f ₸", usd, eur, rub)

    // --- Погода в Алматы (Open-Meteo) ---
    private fun loadWeather(): String {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=43.2389&longitude=76.8897" +
            "&current=temperature_2m,weather_code&timezone=GMT"
        val current = JSONObject(httpGet(url, null)).getJSONObject("current")
        val temp = Math.round(current.getDouble("temperature_2m"))
        val sign = if (temp > 0) "+" else ""
        return "Алматы $sign$temp°C, ${weatherText(current.optInt("weather_code", -1))}"
    }

    private fun weatherText(code: Int): String = when (code) {
        0 -> "ясно"
        1 -> "преимущественно ясно"
        2 -> "переменная облачность"
        3 -> "пасмурно"
        45, 48 -> "туман"
        51, 53, 55, 56, 57 -> "морось"
        61, 63, 80, 81 -> "дождь"
        65, 82 -> "сильный дождь"
        66, 67 -> "ледяной дождь"
        71, 73, 77, 85 -> "снег"
        75, 86 -> "сильный снег"
        95, 96, 99 -> "гроза"
        else -> "текущая погода"
    }

    // --- Вспомогательное ---
    fun money(value: Double): String = String.format(RU, "%,.0f ₸", value)

    fun almatyTime(millis: Long): String =
        SimpleDateFormat("HH:mm", RU).apply { timeZone = ALMATY }.format(Date(millis))

    private fun httpGet(url: String, token: String?): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.setRequestProperty("Accept", "application/json")
            if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
            val code = conn.responseCode
            if (code == 401) throw AuthRequiredException()
            if (code !in 200..299) throw Exception("HTTP $code")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
