package kz.mymoney.widget

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.CommonStatusCodes
import kotlinx.coroutines.launch

/** Экран настройки виджета: вход через Google, адрес сайта, ручное обновление. */
class MainActivity : ComponentActivity() {

    private lateinit var accountView: TextView
    private lateinit var statusView: TextView
    private lateinit var siteEdit: EditText
    private lateinit var signInButton: Button
    private lateinit var readonlyButton: Button
    private lateinit var signOutButton: Button

    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        val data = res.data
        if (data == null) {
            setStatus("Вход отменён. Нажмите «Войти через Google» ещё раз.")
            return@registerForActivityResult
        }
        try {
            val result = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data)
            onAuthorized(result.accessToken)
        } catch (e: ApiException) {
            setStatus("Вход не выполнен. Нажмите «Войти через Google» ещё раз.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        accountView = findViewById(R.id.account)
        statusView = findViewById(R.id.status)
        siteEdit = findViewById(R.id.site_url)
        signInButton = findViewById(R.id.btn_sign_in)
        readonlyButton = findViewById(R.id.btn_readonly)
        signOutButton = findViewById(R.id.btn_sign_out)

        val p = DataRepository.prefs(this)
        siteEdit.setText(p.getString(DataRepository.K_SITE_URL, "https://"))

        signInButton.setOnClickListener { signIn(readonly = p.getBoolean(DataRepository.K_READONLY, false)) }
        readonlyButton.setOnClickListener {
            p.edit().putBoolean(DataRepository.K_READONLY, true).apply()
            signIn(readonly = true)
        }
        signOutButton.setOnClickListener {
            p.edit()
                .putBoolean(DataRepository.K_SIGNED_IN, false)
                .putBoolean(DataRepository.K_READONLY, false)
                .remove(DataRepository.K_EMAIL)
                .remove(DataRepository.K_BALANCE).remove(DataRepository.K_SAVINGS)
                .remove(DataRepository.K_LIMIT).remove(DataRepository.K_NAME)
                .apply()
            refreshNow()
        }
        findViewById<Button>(R.id.btn_save_site).setOnClickListener {
            val url = siteEdit.text.toString().trim()
            if (!url.startsWith("https://") || url.length < 12) {
                Toast.makeText(this, "Адрес должен начинаться с https://", Toast.LENGTH_LONG).show()
            } else {
                p.edit().putString(DataRepository.K_SITE_URL, url).apply()
                WidgetRenderer.renderAll(this)
                Toast.makeText(this, "Адрес сохранён", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.btn_refresh).setOnClickListener { refreshNow() }

        RefreshWorker.schedulePeriodic(this)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun signIn(readonly: Boolean) {
        setStatus("Открываем вход Google…")
        Identity.getAuthorizationClient(this)
            .authorize(DataRepository.authorizationRequest(readonly))
            .addOnSuccessListener { result ->
                val pending = result.pendingIntent
                if (result.hasResolution() && pending != null) {
                    authLauncher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
                } else {
                    onAuthorized(result.accessToken)
                }
            }
            .addOnFailureListener { e ->
                val code = (e as? ApiException)?.statusCode
                setStatus(
                    if (code == CommonStatusCodes.DEVELOPER_ERROR) {
                        "Google не узнал приложение (ошибка 10). Проверьте в Google Cloud ключ «Android»: " +
                            "имя пакета kz.mymoney.widget и отпечаток SHA-1 из первой сборки."
                    } else {
                        "Ошибка входа: " + (e.message ?: e.javaClass.simpleName)
                    }
                )
            }
    }

    private fun onAuthorized(token: String?) {
        if (token.isNullOrBlank()) {
            setStatus("Google не выдал доступ. Попробуйте войти ещё раз.")
            return
        }
        val p = DataRepository.prefs(this)
        p.edit().putBoolean(DataRepository.K_SIGNED_IN, true).apply()
        lifecycleScope.launch {
            setStatus("Загружаем данные…")
            runCatching { DataRepository.fetchEmail(token) }
                .onSuccess { p.edit().putString(DataRepository.K_EMAIL, it).apply() }
            DataRepository.refresh(this@MainActivity)
            WidgetRenderer.renderAll(this@MainActivity)
            render()
        }
    }

    private fun refreshNow() {
        lifecycleScope.launch {
            setStatus("Обновление…")
            DataRepository.refresh(this@MainActivity)
            WidgetRenderer.renderAll(this@MainActivity)
            render()
        }
    }

    private fun render() {
        val p = DataRepository.prefs(this)
        val signedIn = p.getBoolean(DataRepository.K_SIGNED_IN, false)
        val email = p.getString(DataRepository.K_EMAIL, "").orEmpty()
        accountView.text = if (signedIn) {
            "Аккаунт Google: " + email.ifBlank { "подключён" } + "\nБаланс: " + p.getString(DataRepository.K_BALANCE, "—")
        } else {
            "Вы не вошли. Войдите тем же аккаунтом Google, что и на сайте My Money."
        }
        signInButton.text = if (signedIn) "Подключить Google заново" else "Войти через Google"
        signOutButton.visibility = if (signedIn) View.VISIBLE else View.GONE
        readonlyButton.visibility =
            if (signedIn && p.getBoolean(DataRepository.K_FILE_MISSING, false)) View.VISIBLE else View.GONE

        val status = p.getString(DataRepository.K_STATUS, "").orEmpty()
        val updated = p.getLong(DataRepository.K_UPDATED, 0)
        setStatus(
            when {
                status.isNotBlank() -> status
                updated > 0 -> "Данные обновлены в " + DataRepository.almatyTime(updated) + " (время Алматы)"
                else -> ""
            }
        )
    }

    private fun setStatus(text: String) {
        statusView.text = text
        statusView.visibility = if (text.isBlank()) View.GONE else View.VISIBLE
    }
}
