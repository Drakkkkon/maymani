package kz.mymoney.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

/** Рисует виджет из последних сохранённых данных. */
object WidgetRenderer {

    fun renderAll(context: Context, refreshing: Boolean = false) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, MoneyWidgetProvider::class.java))
        if (ids.isEmpty()) return
        manager.updateAppWidget(ids, build(context, refreshing))
    }

    private fun build(context: Context, refreshing: Boolean): RemoteViews {
        val p = DataRepository.prefs(context)
        val views = RemoteViews(context.packageName, R.layout.widget_money)

        val name = p.getString(DataRepository.K_NAME, "").orEmpty()
        views.setTextViewText(R.id.w_title, if (name.isNotBlank()) "Money Pro — $name" else "Money Pro")
        views.setTextViewText(R.id.w_balance, p.getString(DataRepository.K_BALANCE, "—"))
        views.setTextViewText(R.id.w_limit, "Лимит: " + p.getString(DataRepository.K_LIMIT, "—"))
        views.setTextViewText(R.id.w_savings, "Копилка: " + p.getString(DataRepository.K_SAVINGS, "—"))
        views.setTextViewText(R.id.w_weather, p.getString(DataRepository.K_WEATHER, "Погода загружается…"))
        views.setTextViewText(R.id.w_rates, p.getString(DataRepository.K_RATES, "Курсы загружаются…"))

        val status = p.getString(DataRepository.K_STATUS, "").orEmpty()
        val updated = p.getLong(DataRepository.K_UPDATED, 0)
        views.setTextViewText(
            R.id.w_status,
            when {
                refreshing -> "Обновление…"
                status.isNotBlank() -> status
                updated > 0 -> "Обновлено в " + DataRepository.almatyTime(updated)
                else -> "Нажмите «Обновить»"
            }
        )

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        // Нажатие на виджет открывает сайт My Money (адрес задаётся в приложении), иначе — само приложение виджета
        val site = p.getString(DataRepository.K_SITE_URL, "").orEmpty()
        val needsApp = !p.getBoolean(DataRepository.K_SIGNED_IN, false) || status.isNotBlank()
        val openIntent: Intent = if (site.startsWith("https://") && !needsApp) {
            Intent(Intent.ACTION_VIEW, Uri.parse(site))
        } else {
            Intent(context, MainActivity::class.java)
        }
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        views.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(context, 1, openIntent, flags))

        val refreshIntent = Intent(context, MoneyWidgetProvider::class.java).setAction(MoneyWidgetProvider.ACTION_REFRESH)
        views.setOnClickPendingIntent(R.id.w_refresh, PendingIntent.getBroadcast(context, 2, refreshIntent, flags))

        return views
    }
}
