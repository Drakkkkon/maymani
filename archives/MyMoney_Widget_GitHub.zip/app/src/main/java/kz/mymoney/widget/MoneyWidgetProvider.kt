package kz.mymoney.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

class MoneyWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetRenderer.renderAll(context)
        RefreshWorker.schedulePeriodic(context)
        // Защита от частых повторов: Android может присылать onUpdate несколько раз подряд
        val last = DataRepository.prefs(context).getLong(DataRepository.K_REFRESH_STARTED, 0)
        if (System.currentTimeMillis() - last > 60_000) RefreshWorker.enqueueNow(context)
    }

    override fun onEnabled(context: Context) {
        RefreshWorker.schedulePeriodic(context)
    }

    override fun onDisabled(context: Context) {
        RefreshWorker.cancelPeriodic(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            WidgetRenderer.renderAll(context, refreshing = true)
            RefreshWorker.enqueueNow(context)
        }
    }

    companion object {
        const val ACTION_REFRESH = "kz.mymoney.widget.ACTION_REFRESH"
    }
}
