document.addEventListener("DOMContentLoaded", () => {
    // --- 1. ЛОГИКА ПИН-КОДА ---
    let currentPin = "";
    const dots = document.querySelectorAll('.pin-dots .dot');
    const pinScreen = document.getElementById('pin-screen');
    const appWrapper = document.querySelector('.app-wrapper');

    function updateDots() {
        dots.forEach((dot, index) => {
            if (index < currentPin.length) {
                dot.classList.add('filled');
            } else {
                dot.classList.remove('filled');
            }
        });
    }

    updateDots();

    document.querySelectorAll('.pin-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const val = e.target.innerText.trim();
            
            if (val === 'C') {
                currentPin = "";
                updateDots();
            } else if (val === 'OK') {
                if (currentPin.length === 4) {
                    pinScreen.style.display = 'none';
                    appWrapper.style.display = 'flex';
                } else {
                    alert("ПИН-код должен содержать ровно 4 цифры.");
                }
            } else {
                if (currentPin.length < 4) {
                    currentPin += val;
                    updateDots();
                }
            }
        });
    });

    // --- 2. ЛОГИКА ПЕРЕКЛЮЧЕНИЯ ВЗКЛАДОК (МЕНЮ) ---
    const navButtons = document.querySelectorAll('.nav-btn');
    const tabs = document.querySelectorAll('.tab');

    navButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const targetId = btn.getAttribute('data-target');
            
            // 1. Делаем активными все кнопки с этим target (и в боковом меню, и в мобильном)
            navButtons.forEach(b => {
                if (b.getAttribute('data-target') === targetId) {
                    b.classList.add('active');
                } else {
                    b.classList.remove('active');
                }
            });

            // 2. Скрываем все вкладки и показываем нужную
            tabs.forEach(tab => {
                if (tab.id === targetId) {
                    tab.classList.add('active');
                } else {
                    tab.classList.remove('active');
                }
            });
        });
    });

    // --- 3. ИМИТАЦИЯ РАБОТЫ КНОПОК ФОРМЫ ---
    const amountInput = document.getElementById('amount-input');
    const categoryInput = document.getElementById('category-input');
    
    document.getElementById('btn-add-income').addEventListener('click', () => {
        if(!amountInput.value) { alert('Введите сумму!'); return; }
        alert(`Доход ${amountInput.value} ₸ добавлен!`);
        amountInput.value = '';
        categoryInput.value = '';
    });

    document.getElementById('btn-add-expense').addEventListener('click', () => {
        if(!amountInput.value) { alert('Введите сумму!'); return; }
        alert(`Расход ${amountInput.value} ₸ добавлен!`);
        amountInput.value = '';
        categoryInput.value = '';
    });

    // --- 4. НАСТРОЙКИ: ПЕРЕКЛЮЧЕНИЕ ТЕМ ---
    const themeSelector = document.getElementById('theme-selector');
    if (themeSelector) {
        themeSelector.addEventListener('change', (e) => {
            const selectedTheme = e.target.value;
            // Убираем все классы body
            document.body.className = '';
            // Если это не стандартная, добавляем класс темы
            if (selectedTheme !== 'win95') {
                document.body.classList.add('theme-' + selectedTheme);
            }
        });
    }
});
