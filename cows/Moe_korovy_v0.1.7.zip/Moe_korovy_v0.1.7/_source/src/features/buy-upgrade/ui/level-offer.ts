/* Покупка уровней: карточка улучшения или постройки и кнопки ×10 / ×25 / ×100. */
import { fmtShort, save, sound, ticker } from '@/shared/lib';
import { createChip } from '@/shared/ui';
import {
  createUpgradeCard, speedStepOf, progress, levelCost, bulkInfo, buyLevels, have, settle, costText, resIcon,
  TIERS, LV_MAX, BULK, type LevelDef,
} from '@/entities/farm';

function feedback(d: LevelDef, n: number): void {
  if (d.snd === 'chop') sound.chop(n > 1 || d.key === 'pens' ? 3 : 2); else sound.buy();
  save();
  ticker.emit('changed', undefined);
}

export function createLevelOffer(d: LevelDef) {
  const step = speedStepOf(d);
  const card = createUpgradeCard({
    name: d.name, emoji: d.emoji, art: d.art, effect: d.fx + (step ? ' · +' + Math.round(step * 100) + '% скорости' : ''), stars: TIERS.length,
    onClick: () => {
      settle();
      if (buyLevels(d, 1, levelCost(d))) { card.bump(); feedback(d, 1); } else card.shake();
    },
  });
  const chips = BULK.map((n, j) => {
    const chip = createChip(() => {
      settle();
      const info = bulkInfo(d)[j];
      if (buyLevels(d, info.n, info.cost)) { card.bump(); feedback(d, info.n); } else chip.shake();
    });
    return { chip, n };
  });
  card.addExtra(...chips.map((c) => c.chip.el));

  return {
    el: card.el,
    refresh(): void {
      const lv = progress.lv[d.key], maxed = lv >= LV_MAX, c = levelCost(d), money = have(d.res);
      card.update({
        level: d.unit ? lv + ' ' + d.unit : 'Ур. ' + lv,
        cost: maxed ? 'Максимум' : costText(d.res, c),
        progress: maxed ? 1 : money / c,
        can: !maxed && money >= c,
        owned: maxed,
        starsOn: (i) => lv >= TIERS[i],
      });
      const bi = bulkInfo(d);
      chips.forEach(({ chip, n }, j) => {
        const info = bi[j], mx = info.n <= 0;
        chip.set('×' + (mx ? n : info.n), mx ? 'макс.' : fmtShort(info.cost) + resIcon(d.res),
          mx ? '«' + d.name + '»: максимум' : 'Купить ' + info.n + ' × «' + d.name + '» за ' + costText(d.res, info.cost),
          mx ? 'Максимум' : '+' + info.n + ' за ' + costText(d.res, info.cost));
        chip.state(!mx && money >= info.cost, mx);
      });
    },
  };
}
