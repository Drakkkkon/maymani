/* Все улучшения игры. Цены, рост цены и эффекты меняются здесь.
   grp — страница (Ферма, Домики, Кормёжка), col — колонка на странице (build — «Постройки»). */

export type Res = 'milk' | 'cows' | 'logs' | 'grain';
export type Group = 'farm' | 'house' | 'feed';
export type Column = 'cow' | 'milk' | 'axe' | 'log' | 'field' | 'grain' | 'build';

export interface LevelDef {
  key: string;
  grp: Group;
  col: Column;
  name: string;
  emoji: string;         // эмодзи рядом с названием (таблица EMOJI ниже)
  res: Res;              // чем платим
  base: number;          // цена первого уровня
  g: number;             // во сколько раз дорожает каждый уровень
  start: 0 | 1;          // 1 — улучшение, 0 — постройка (загоны, стога)
  fx: string;
  unit?: string;
  snd?: 'chop' | 'buy';  // звук при покупке
  art?: string;          // картинка-фон под карточкой и её кнопками ×N: ui/art-<фон>-<имя>.jpg и строка в upgrade-card.css
}

/** cm/mm — коровы/молоко, ax/lg — топоры/полена, fd/gr — поля/зерно: множитель за звезду. */
export interface SuperDef {
  id: string;
  grp: Group;
  col: Column;
  name: string;
  emoji: string;
  res: Res;
  cost: number;          // цена первой звезды
  mul: number;           // во сколько раз дороже каждая следующая
  link: string[];        // уровни, которые открывают звёзды
  fx: string;
  cm?: number; mm?: number; ax?: number; lg?: number; fd?: number; gr?: number;
  hay?: number;          // прибавка к силе стогов за звезду
}

/** Эмодзи рядом с названием улучшения: ключ уровня или id суперулучшения. */
const EMOJI: Record<string, string> = {
  rate: '🐄', herd: '🐮', breeding: '💞', selection: '🧬', legend: '👑', yield: '🥛', quality: '🏅', milk1: '🥤',
  milk2: '🧀', milk3: '🏰', axes: '🪓', lumber: '🧔', smithy: '⚒️', guild: '🤝', legaxe: '⚔️', chop: '🪵',
  saw: '🪚', sledge: '🛷', river: '🌊', sawmill: '🏭', pens: '🚧', fields: '🌱', plough: '🐂', seeds: '🌰',
  irrig: '💧', kolkhoz: '🧑‍🌾', thresh: '🧺', sickle: '🗡️', mill: '⚙️', combine: '🚛', elevator: '🏗️', hay: '🌾',
  happy: '😊', mad: '🤪', sixteat: '🍼', royal: '👸', apocalypse: '☄️', korovan: '🐫', udoi: '📈', flow: '🏞️',
  vein: '⛏️', milkyway: '🌌', woodstore: '🛖', whetstone: '🪨', bear: '🐻', oakgrove: '🌳', perun: '⚡', woodpile: '🧱',
  beaver: '🦫', cart: '🐎', steamsaw: '🚂', taiga: '🌲', barn: '🏠', scarecrow: '🎃', raindance: '💃', summer: '☀️',
  harvest: '🌻', sacks: '🛍️', cat: '🐈', belarus: '🚜', windmill: '🌬️', goldear: '🌟',
};

/** Окна (id фона), для которых нарисованы картинки кнопок. У остальных окон кнопки без картинок. */
export const ART_BACKGROUNDS: readonly string[] = ['mountains'];

const L = (grp: Group, col: Column, key: string, name: string, base: number, g: number, fx: string, extra: Partial<LevelDef> = {}): LevelDef =>
  ({ key, grp, col, name, emoji: EMOJI[key] || '', res: 'milk', base, g, start: 1, fx, ...extra });

export const LEVELS: LevelDef[] = [
  L('farm', 'cow', 'rate', 'Прирост коров', 4, 1.14, '+1 корова за цикл', { art: 'rate' }),
  L('farm', 'cow', 'herd', 'Стадо', 250, 1.15, '+10% коров за уровень', { art: 'herd' }),
  L('farm', 'cow', 'breeding', 'Разведение', 8000, 1.16, '+25% коров за уровень', { art: 'breeding' }),
  L('farm', 'cow', 'selection', 'Селекция', 400000, 1.17, '+50% коров за уровень', { art: 'selection' }),
  L('farm', 'cow', 'legend', 'Легендарное стадо', 20000000, 1.18, '+100% коров за уровень', { art: 'legend' }),
  L('farm', 'milk', 'yield', 'Надои молока', 15, 1.14, '+1 базовый надой за цикл'),
  L('farm', 'milk', 'quality', 'Качество коров', 30, 1.15, '+20% молока с коровы'),
  L('farm', 'milk', 'milk1', 'Молочность', 900, 1.16, '+25% молока за уровень'),
  L('farm', 'milk', 'milk2', 'Переработка', 60000, 1.17, '+50% молока за уровень'),
  L('farm', 'milk', 'milk3', 'Молочная империя', 4000000, 1.18, '+100% молока за уровень'),

  L('house', 'axe', 'axes', 'Топоры', 40, 1.15, '+1 топор за уровень', { snd: 'chop' }),
  L('house', 'axe', 'lumber', 'Лесорубы', 300, 1.15, '+10% топоров за уровень', { snd: 'chop' }),
  L('house', 'axe', 'smithy', 'Кузница', 9000, 1.16, '+25% топоров за уровень', { snd: 'chop' }),
  L('house', 'axe', 'guild', 'Артель лесорубов', 450000, 1.17, '+50% топоров за уровень', { snd: 'chop' }),
  L('house', 'axe', 'legaxe', 'Легендарный топор', 20000000, 1.18, '+100% топоров за уровень', { snd: 'chop' }),
  L('house', 'log', 'chop', 'Полена', 120, 1.16, '+20% полен с каждого топора', { snd: 'chop' }),
  L('house', 'log', 'saw', 'Двуручная пила', 2000, 1.16, '+25% полен за уровень', { snd: 'chop' }),
  L('house', 'log', 'sledge', 'Сани для брёвен', 70000, 1.17, '+50% полен за уровень', { snd: 'chop' }),
  L('house', 'log', 'river', 'Сплав по реке', 3000000, 1.17, '+75% полен за уровень', { snd: 'chop' }),
  L('house', 'log', 'sawmill', 'Лесопилка', 150000000, 1.18, '+100% полен за уровень', { snd: 'chop' }),
  L('house', 'build', 'pens', 'Загоны', 10, 1.15, '+10% коров и молока за каждый', { res: 'logs', start: 0, unit: 'шт.', snd: 'chop' }),

  L('feed', 'field', 'fields', 'Поля', 40, 1.15, '+1 поле зерна за уровень'),
  L('feed', 'field', 'plough', 'Плуг', 300, 1.15, '+10% полей за уровень'),
  L('feed', 'field', 'seeds', 'Отборные семена', 9000, 1.16, '+25% полей за уровень'),
  L('feed', 'field', 'irrig', 'Полив', 450000, 1.17, '+50% полей за уровень'),
  L('feed', 'field', 'kolkhoz', 'Колхоз', 20000000, 1.18, '+100% полей за уровень'),
  L('feed', 'grain', 'thresh', 'Обмолот', 120, 1.16, '+20% зерна с каждого поля'),
  L('feed', 'grain', 'sickle', 'Серпы', 2000, 1.16, '+25% зерна за уровень'),
  L('feed', 'grain', 'mill', 'Мельница', 70000, 1.17, '+50% зерна за уровень'),
  L('feed', 'grain', 'combine', 'Комбайн', 3000000, 1.17, '+75% зерна за уровень'),
  L('feed', 'grain', 'elevator', 'Элеватор', 150000000, 1.18, '+100% зерна за уровень'),
  L('feed', 'build', 'hay', 'Стога сена', 10, 1.15, '+10% коров и молока за каждый', { res: 'grain', start: 0, unit: 'шт.' }),
];

const S = (grp: Group, col: Column, id: string, name: string, res: Res, cost: number, link: string[], fx: string, eff: Partial<SuperDef>): SuperDef =>
  ({ id, grp, col, name, emoji: EMOJI[id] || '', res, cost, mul: grp === 'farm' ? 25 : 12, link, fx, ...eff });

export const SUPERS: SuperDef[] = [
  S('farm', 'cow', 'happy', 'Коровье счастье', 'cows', 1000, ['rate'], '+10% коров за звезду', { cm: 1.1 }),
  S('farm', 'cow', 'mad', 'Бешеная корова', 'cows', 50000, ['herd'], 'Коров ×2 за звезду', { cm: 2 }),
  S('farm', 'cow', 'sixteat', 'Шестисисечная', 'cows', 2000000, ['breeding'], '+25% коров и молока за звезду', { cm: 1.25, mm: 1.25 }),
  S('farm', 'cow', 'royal', 'Королевская корова', 'cows', 100000000, ['selection'], 'Коров ×2 за звезду', { cm: 2 }),
  S('farm', 'cow', 'apocalypse', 'Коровий апокалипсис', 'cows', 5000000000, ['legend'], 'Коров ×3 за звезду', { cm: 3 }),
  S('farm', 'milk', 'korovan', 'Коророван', 'milk', 1000, ['yield'], '+10% молока за звезду', { mm: 1.1 }),
  S('farm', 'milk', 'udoi', 'Удои растут!', 'milk', 50000, ['quality'], 'Молоко ×2 за звезду', { mm: 2 }),
  S('farm', 'milk', 'flow', 'Молочная река', 'milk', 2000000, ['milk1'], '+25% молока за звезду', { mm: 1.25 }),
  S('farm', 'milk', 'vein', 'Молочная жила', 'milk', 100000000, ['milk2'], 'Молоко ×2 за звезду', { mm: 2 }),
  S('farm', 'milk', 'milkyway', 'Млечный путь', 'milk', 5000000000, ['milk3'], 'Молоко ×3 за звезду', { mm: 3 }),

  S('house', 'axe', 'woodstore', 'Древохранилище', 'logs', 200, ['axes', 'chop'], '+10% топоров и полен за звезду', { ax: 1.1, lg: 1.1 }),
  S('house', 'axe', 'whetstone', 'Точильный камень', 'logs', 3000, ['lumber'], 'Топоры ×1,5 за звезду', { ax: 1.5 }),
  S('house', 'axe', 'bear', 'Медведь-лесоруб', 'logs', 60000, ['smithy'], '+25% топоров и полен за звезду', { ax: 1.25, lg: 1.25 }),
  S('house', 'axe', 'oakgrove', 'Дубовая роща', 'logs', 2000000, ['guild'], 'Топоры ×2 за звезду', { ax: 2 }),
  S('house', 'axe', 'perun', 'Топор Перуна', 'logs', 80000000, ['legaxe'], 'Топоры ×3 за звезду', { ax: 3 }),
  S('house', 'log', 'woodpile', 'Ровная поленница', 'logs', 500, ['chop'], '+10% полен за звезду', { lg: 1.1 }),
  S('house', 'log', 'beaver', 'Бобры-помощники', 'logs', 8000, ['saw'], 'Полена ×2 за звезду', { lg: 2 }),
  S('house', 'log', 'cart', 'Телега с лошадью', 'logs', 150000, ['sledge'], '+25% полен за звезду', { lg: 1.25 }),
  S('house', 'log', 'steamsaw', 'Паровая пила', 'logs', 5000000, ['river'], 'Полена ×2 за звезду', { lg: 2 }),
  S('house', 'log', 'taiga', 'Бескрайняя тайга', 'logs', 200000000, ['sawmill'], 'Полена ×3 за звезду', { lg: 3 }),

  S('feed', 'field', 'barn', 'Амбары', 'grain', 200, ['fields', 'thresh'], '+10% зерна и силы стогов за звезду', { gr: 1.1, hay: 0.1 }),
  S('feed', 'field', 'scarecrow', 'Пугало', 'grain', 3000, ['plough'], 'Поля ×1,5 за звезду', { fd: 1.5 }),
  S('feed', 'field', 'raindance', 'Танец дождя', 'grain', 60000, ['seeds'], '+25% полей и зерна за звезду', { fd: 1.25, gr: 1.25 }),
  S('feed', 'field', 'summer', 'Тёплое лето', 'grain', 2000000, ['irrig'], 'Поля ×2 за звезду', { fd: 2 }),
  S('feed', 'field', 'harvest', 'Богиня урожая', 'grain', 80000000, ['kolkhoz'], 'Поля ×3 за звезду', { fd: 3 }),
  S('feed', 'grain', 'sacks', 'Льняные мешки', 'grain', 500, ['thresh'], '+10% зерна за звезду', { gr: 1.1 }),
  S('feed', 'grain', 'cat', 'Кот-мышелов', 'grain', 8000, ['sickle'], 'Зерно ×2 за звезду', { gr: 2 }),
  S('feed', 'grain', 'belarus', 'Трактор «Беларусь»', 'grain', 150000, ['mill'], '+25% зерна за звезду', { gr: 1.25 }),
  S('feed', 'grain', 'windmill', 'Ветряная мельница', 'grain', 5000000, ['combine'], 'Зерно ×2 за звезду', { gr: 2 }),
  S('feed', 'grain', 'goldear', 'Золотой колос', 'grain', 200000000, ['elevator'], 'Зерно ×3 за звезду', { gr: 3 }),
];

export const levelsOf = (grp: Group, col: Column): LevelDef[] => LEVELS.filter((d) => d.grp === grp && d.col === col);
export const supersOf = (grp: Group, col: Column): SuperDef[] => SUPERS.filter((d) => d.grp === grp && d.col === col);
