/* Показатели вверху страницы: что есть и сколько прибавляется. Набор карточек зависит от страницы. */
import { refreshWhileVisible, fmtBig, fmtMilk, fmtRate, fmtNum, fmtPercent, cows, cpsWord } from '@/shared/lib';
import { createStatCard, createStatGrid } from '@/shared/ui';
import { progress, rates, cyclePhase, type Group, type Cycle } from '@/entities/farm';

type Card = ReturnType<typeof createStatCard>;
interface Panel { cards: Card[]; refresh: () => void }

/** «Цикл: 5 с» — раз в столько секунд приходит порция ресурса. */
const cycleText = (r: Cycle): string => 'Цикл: ' + fmtRate(1 / rates.speed[r]) + ' с';
/** Полоска «до следующей порции». Когда циклы короче трети секунды, полоска просто полная — иначе рябит. */
function cycleTick(card: Card, r: Cycle) {
  let prev = 0;
  return () => {
    if (!card.tick) return;
    const fast = rates.speed[r] > 3, frac = fast ? 1 : cyclePhase(r);
    /* при начале нового цикла — без анимации назад */
    card.tick.fill.style.transition = frac < prev ? 'none' : '';
    card.tick.set(frac);
    prev = frac;
  };
}

function farmPanel(): Panel {
  const herd = createStatCard('Коровы', { lines: ['🐄', '⏱️'], tick: true });
  const milk = createStatCard('Молоко', { lines: ['🥛', '⏱️', '✨'], tick: true });
  const herdTick = cycleTick(herd, 'cows'), milkTick = cycleTick(milk, 'milk');
  return {
    cards: [herd, milk],
    refresh() {
      const n = Math.floor(progress.cows);
      herd.value(n >= 1e6 ? fmtBig(n) + ' коров' : n.toLocaleString('ru-RU') + ' ' + cows(n));
      herd.line(0, fmtRate(rates.cps) + ' ' + cpsWord(rates.cps) + ' в секунду');
      herd.line(1, cycleText('cows'));
      herdTick();
      milk.value(fmtMilk(progress.milk) + ' л');
      milk.line(0, fmtRate(progress.cows * rates.perCow) + ' л в секунду');
      milk.line(1, cycleText('milk'));
      milk.line(2, 'Загоны и стога: ' + fmtPercent(rates.bonus));
      milkTick();
    },
  };
}

function housePanel(): Panel {
  const axes = createStatCard('Топоры', { emoji: '🪓' });
  const logs = createStatCard('Полена', { emoji: '🪵', lines: ['', '⏱️'], tick: true });
  const logsTick = cycleTick(logs, 'logs');
  const pens = createStatCard('Загоны', { emoji: '🚧' });
  return {
    cards: [axes, logs, pens],
    refresh() {
      axes.value(fmtNum(rates.axes)); axes.line(0, 'рубят деревья');
      logs.value(fmtNum(progress.logs)); logs.line(0, fmtRate(rates.lps) + ' в секунду'); logs.line(1, cycleText('logs')); logsTick();
      pens.value(String(progress.lv.pens)); pens.line(0, '+' + progress.lv.pens * 10 + '% коров и молока');
    },
  };
}

function feedPanel(): Panel {
  const fields = createStatCard('Поля', { emoji: '🌱' });
  const grain = createStatCard('Зерно', { emoji: '🌽', lines: ['', '⏱️'], tick: true });
  const grainTick = cycleTick(grain, 'grain');
  const hay = createStatCard('Стога сена', { emoji: '🌾' });
  return {
    cards: [fields, grain, hay],
    refresh() {
      fields.value(fmtNum(rates.fields)); fields.line(0, 'засеяно');
      grain.value(fmtNum(progress.grain)); grain.line(0, fmtRate(rates.gps) + ' в секунду'); grain.line(1, cycleText('grain')); grainTick();
      hay.value(String(progress.lv.hay)); hay.line(0, '+' + fmtRate(progress.lv.hay * rates.hayEach) + '% коров и молока');
    },
  };
}

const PANELS: Record<Group, () => Panel> = { farm: farmPanel, house: housePanel, feed: feedPanel };

export function createResourceStats(group: Group): HTMLElement {
  const panel = PANELS[group]();
  const el = createStatGrid(...panel.cards.map((c) => c.el));
  refreshWhileVisible(el, panel.refresh);
  panel.refresh();
  return el;
}
