/* Страница «Ферма»: коровы и молоко. */
import { h } from '@/shared/lib';
import { pageTitle, note } from '@/shared/ui';
import { createResourceStats } from '@/widgets/resource-stats';
import { createClickBonus } from './click-bonus';
import { createUpgradeBoard } from '@/widgets/upgrade-board';

export function createFarmPage(): HTMLElement {
  return h('div', { class: 'page' },
    pageTitle('Ферма'),
    createResourceStats('farm'),
    createClickBonus(),
    createUpgradeBoard('farm'),
    note('Коровы и молоко приходят порциями, раз в цикл. Каждый уровень улучшения увеличивает порцию и ускоряет циклы. Уровни — до 200, суперулучшения — до 5★. Каждая звезда открывается уровнем своей фермы, а ещё уровнями «Топоров» и «Полен» в Домиках и «Полей» и «Обмолота» в Кормёжке.'));
}
