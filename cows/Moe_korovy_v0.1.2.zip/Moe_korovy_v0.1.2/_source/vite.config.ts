import { defineConfig } from 'vite';
import { fileURLToPath, URL } from 'node:url';

/* base: './' — собранная игра работает из любой папки: GitHub Pages, itch.io, Netlify */
export default defineConfig({
  base: './',
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
  server: { port: 5173 },
  build: { outDir: 'dist', assetsInlineLimit: 0 },
});
