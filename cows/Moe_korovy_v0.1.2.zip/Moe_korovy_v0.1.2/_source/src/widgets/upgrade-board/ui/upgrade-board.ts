/* Доска улучшений одной страницы: постройки сверху и две колонки «улучшения + суперулучшения».
   Одна и та же доска для Фермы, Домиков и Кормёжки — отличается только конфигом. */
import { h, refreshWhileVisible } from '@/shared/lib';
import { sectionTitle } from '@/shared/ui';
import { levelsOf, supersOf, type Group, type Column } from '@/entities/farm';
import { createLevelOffer, createStarOffer } from '@/features/buy-upgrade';
import './upgrade-board.css';

interface BoardColumn { col: Column; title: string; superTitle: string }
interface BoardConfig { build?: string; columns: [BoardColumn, BoardColumn] }

const BOARDS: Record<Group, BoardConfig> = {
  farm: {
    columns: [
      { col: 'cow', title: 'Ферма · коровы', superTitle: 'Суперулучшения · коровы' },
      { col: 'milk', title: 'Ферма · молоко', superTitle: 'Суперулучшения · молоко' },
    ],
  },
  house: {
    build: 'Постройки · за полена',
    columns: [
      { col: 'axe', title: 'Домики · топоры', superTitle: 'Суперулучшения · топоры' },
      { col: 'log', title: 'Домики · полена', superTitle: 'Суперулучшения · полена' },
    ],
  },
  feed: {
    build: 'Постройки · за зерно',
    columns: [
      { col: 'field', title: 'Кормёжка · поля', superTitle: 'Суперулучшения · поля' },
      { col: 'grain', title: 'Кормёжка · зерно', superTitle: 'Суперулучшения · зерно' },
    ],
  },
};

export function createUpgradeBoard(group: Group): HTMLElement {
  const cfg = BOARDS[group];
  const offers: { el: HTMLElement; refresh: () => void }[] = [];
  const list = (items: { el: HTMLElement; refresh: () => void }[]) => {
    offers.push(...items);
    return h('ul', { class: 'items' }, ...items.map((o) => o.el));
  };
  const column = (c: BoardColumn) => h('div', { class: 'up-col' },
    sectionTitle(c.title), list(levelsOf(group, c.col).map(createLevelOffer)),
    sectionTitle(c.superTitle, true), list(supersOf(group, c.col).map(createStarOffer)));

  const el = h('div', { class: 'board' },
    cfg.build ? h('div', { class: 'up-col build' }, sectionTitle(cfg.build), list(levelsOf(group, 'build').map(createLevelOffer))) : null,
    h('div', { class: 'up-grid' }, column(cfg.columns[0]), column(cfg.columns[1])));
  refreshWhileVisible(el, () => offers.forEach((o) => o.refresh()));
  return el;
}
