/* Вкладки внизу: на компьютере — внизу правой колонки, на телефоне — внизу экрана. */
import { h } from '@/shared/lib';
import './tab-bar.css';

export interface Tab { id: string; label: string; icon: string; mobileOnly?: boolean; also?: string[] }

export function createTabBar(tabs: Tab[], onSelect: (id: string) => void) {
  const buttons = tabs.map((t) =>
    h('button', { type: 'button', class: t.mobileOnly ? 'tab-mobile' : null, on: { click: () => onSelect(t.id) } },
      h('span', { html: t.icon }), h('span', { text: t.label })));
  const el = h('nav', { class: 'tabbar', 'aria-label': 'Разделы' }, ...buttons);
  return {
    el,
    /** Подсвечивает вкладку страницы (also — вложенные страницы, например «Темы» внутри «Настроек»). */
    setCurrent(page: string): void {
      tabs.forEach((t, i) => {
        if (t.id === page || t.also?.includes(page)) buttons[i].setAttribute('aria-current', 'page');
        else buttons[i].removeAttribute('aria-current');
      });
    },
  };
}
