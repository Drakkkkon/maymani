export { createResourceStats } from './ui/resource-stats';
