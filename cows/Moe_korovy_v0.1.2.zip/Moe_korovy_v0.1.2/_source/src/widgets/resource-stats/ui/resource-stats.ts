/* Показатели вверху страницы: что есть и сколько прибавляется. Набор карточек зависит от страницы. */
import { refreshWhileVisible, fmtBig, fmtMilk, fmtRate, fmtNum, fmtPercent, cows, cpsWord } from '@/shared/lib';
import { createStatCard, createStatGrid } from '@/shared/ui';
import { progress, rates, type Group } from '@/entities/farm';

type Card = ReturnType<typeof createStatCard>;
interface Panel { cards: Card[]; refresh: () => void }

function farmPanel(): Panel {
  const herd = createStatCard('Коровы', { lines: ['🐄'], tick: true });
  const milk = createStatCard('Молоко', { lines: ['🥛', '✨'] });
  let prevFrac = 0;
  return {
    cards: [herd, milk],
    refresh() {
      const n = Math.floor(progress.cows), frac = progress.cows - n;
      herd.value(n >= 1e6 ? fmtBig(n) + ' коров' : n.toLocaleString('ru-RU') + ' ' + cows(n));
      herd.line(0, fmtRate(rates.cps) + ' ' + cpsWord(rates.cps) + ' в секунду');
      /* полоска «следующая корова»: при переходе через целое — без анимации назад */
      if (herd.tick) { herd.tick.fill.style.transition = frac < prevFrac ? 'none' : ''; herd.tick.set(frac); }
      prevFrac = frac;
      milk.value(fmtMilk(progress.milk) + ' л');
      milk.line(0, fmtRate(progress.cows * rates.perCow) + ' л в секунду');
      milk.line(1, 'Загоны и стога: ' + fmtPercent(rates.bonus));
    },
  };
}

function housePanel(): Panel {
  const axes = createStatCard('Топоры', { emoji: '🪓' });
  const logs = createStatCard('Полена', { emoji: '🪵' });
  const pens = createStatCard('Загоны', { emoji: '🚧' });
  return {
    cards: [axes, logs, pens],
    refresh() {
      axes.value(fmtNum(rates.axes)); axes.line(0, 'рубят деревья');
      logs.value(fmtNum(progress.logs)); logs.line(0, fmtRate(rates.lps) + ' в секунду');
      pens.value(String(progress.lv.pens)); pens.line(0, '+' + progress.lv.pens * 10 + '% коров и молока');
    },
  };
}

function feedPanel(): Panel {
  const fields = createStatCard('Поля', { emoji: '🌱' });
  const grain = createStatCard('Зерно', { emoji: '🌽' });
  const hay = createStatCard('Стога сена', { emoji: '🌾' });
  return {
    cards: [fields, grain, hay],
    refresh() {
      fields.value(fmtNum(rates.fields)); fields.line(0, 'засеяно');
      grain.value(fmtNum(progress.grain)); grain.line(0, fmtRate(rates.gps) + ' в секунду');
      hay.value(String(progress.lv.hay)); hay.line(0, '+' + fmtRate(progress.lv.hay * rates.hayEach) + '% коров и молока');
    },
  };
}

const PANELS: Record<Group, () => Panel> = { farm: farmPanel, house: housePanel, feed: feedPanel };

export function createResourceStats(group: Group): HTMLElement {
  const panel = PANELS[group]();
  const el = createStatGrid(...panel.cards.map((c) => c.el));
  refreshWhileVisible(el, panel.refresh);
  panel.refresh();
  return el;
}
