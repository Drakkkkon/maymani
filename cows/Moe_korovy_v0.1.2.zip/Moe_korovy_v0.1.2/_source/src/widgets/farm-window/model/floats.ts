/* Всплывающие надписи над окном: «+12 л», «+5 🥛» (зелёный стакан — знак {am} в тексте), облачка с репликами коров. */
import { h, reduceMotion } from '@/shared/lib';
import { withAlienMilk } from '@/shared/ui';

export function createFloats(layer: HTMLElement) {
  function xy(x: number, y: number, text: string, cls?: string): void {
    const d = h('span', { class: 'float' + (cls ? ' ' + cls : ''), style: 'left:' + x + 'px;top:' + y + 'px' }, ...withAlienMilk(text));
    layer.appendChild(d);
    const drop = () => d.remove();
    d.addEventListener('animationend', drop);
    if (reduceMotion) window.setTimeout(drop, 1200);
  }
  /** Надпись в точке клика, а если клика нет (клавиатура) — над элементом. */
  function at(e: MouseEvent, text: string, cls?: string): void {
    const r = layer.getBoundingClientRect();
    let x = (e.clientX || 0) - r.left, y = (e.clientY || 0) - r.top;
    if (x < 4 || y < 4) {
      const t = e.currentTarget as Element | null;
      if (t) { const b = t.getBoundingClientRect(); x = b.left + b.width / 2 - r.left; y = b.top + b.height / 2 - r.top; }
      else { x = r.width / 2; y = r.height / 2; }
    }
    xy(x, y, text, cls);
  }
  /** Облачко с репликой над коровой. */
  function say(e: MouseEvent, phrase: string): void {
    const r = layer.getBoundingClientRect(), t = e.currentTarget as Element | null;
    let x = r.width / 2, y = r.height / 2;
    if (t) { const b = t.getBoundingClientRect(); x = b.left + b.width / 2 - r.left; y = b.top - r.top - 4; }
    xy(Math.max(70, Math.min(r.width - 70, x)), Math.max(40, y), phrase, 'say');
  }
  return { xy, at, say };
}

export type Floats = ReturnType<typeof createFloats>;
