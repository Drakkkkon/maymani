/* Стадо: коровы летают на крыльях, садятся пастись на луга и снова взлетают.
   Координаты хранятся в долях картинки, поэтому при смене размера окна коровы остаются на своих местах. */
import { rand, reduceMotion } from '@/shared/lib';
import { createCowSprite, COW_RATIO, type CowSprite } from '../ui/cow-sprite';
import type { Meadow } from '@/entities/background';
import type { SceneView } from './view';

type Mode = 'fly' | 'land' | 'graze';
type Pt = [number, number];
interface Rect { x0: number; x1: number; y0: number; y1: number }
interface Cow {
  sprite: CowSprite;
  mode: Mode;
  x: number; y: number;     // полёт: центр; пастбище: копыта (доли картинки)
  tx: number; ty: number;   // цель полёта
  vx: number; vy: number;   // скорость, пиксели в секунду
  ang: number; timer: number; wait: number;
  slow: boolean; size: number; landSize: number; needsSpot: boolean;
}

export interface FlockOptions {
  host: HTMLElement;              // куда добавлять коров
  before: Node;                   // перед каким элементом (луч и пришелец должны быть выше)
  view: SceneView;
  isVisible: () => boolean;
  onPet: (e: MouseEvent) => void; // клик по корове
}

export function createFlock(o: FlockOptions) {
  const { view } = o;
  const list: Cow[] = [];
  let raf = 0, lastT = 0, panicUntil = 0;

  function vis(): Rect {
    return {
      x0: (view.vx - view.left) / view.iw, x1: (view.vx + view.vw - view.left) / view.iw,
      y0: (view.vy - view.top) / view.ih, y1: (view.vy + view.vh - view.top) / view.ih,
    };
  }
  /** Где можно летать: видимая часть с отступами на размер коровы. */
  function sky(): Rect {
    const V = vis(), mx = view.cw * 0.62 / view.iw, top = (view.vh * 0.08 + view.ch * 0.8) / view.ih, bot = (view.vh * 0.1 + view.ch * 0.6) / view.ih;
    const r = { x0: V.x0 + mx, x1: V.x1 - mx, y0: V.y0 + top, y1: V.y1 - bot };
    if (r.x1 < r.x0) r.x0 = r.x1 = (V.x0 + V.x1) / 2;
    if (r.y1 < r.y0) r.y0 = r.y1 = (V.y0 + V.y1) / 2;
    return r;
  }
  const skyPoint = (): Pt => { const r = sky(); return [rand(r.x0, r.x1), rand(r.y0, r.y1)]; };

  /** Луга, которые сейчас видны в окне (с запасом на размер коровы). */
  function meadows(): Meadow[] {
    if (!view.bg) return [];
    const V = vis(), hx = view.cw * 0.6 / view.iw, hy = view.ch * 1.1 / view.ih;
    return view.bg.meadows
      .map((m): Meadow => [Math.max(m[0], V.x0 + hx), Math.max(m[1], V.y0 + hy), Math.min(m[2], V.x1 - hx), Math.min(m[3], V.y1 - 0.01)])
      .filter((r) => r[2] - r[0] > 0.02 && r[3] - r[1] > 0.004);
  }
  function meadowPoint(): Pt | null {
    const ms = meadows();
    if (!ms.length) return null;
    const area = (r: Meadow) => (r[2] - r[0]) * (r[3] - r[1]);
    let k = Math.random() * ms.reduce((s, r) => s + area(r), 0);
    for (let i = 0; i < ms.length; i++) {
      const r = ms[i];
      if (k <= area(r) || i === ms.length - 1) return [rand(r[0], r[2]), rand(r[1], r[3])];
      k -= area(r);
    }
    return null;
  }
  const onMeadow = (c: Cow): boolean => meadows().some((r) => c.x >= r[0] - 0.01 && c.x <= r[2] + 0.01 && c.y >= r[1] - 0.01 && c.y <= r[3] + 0.01);
  /** Ближе к низу картинки корова на лугу чуть крупнее. */
  function depth(iy: number): number {
    const ms = view.bg ? view.bg.meadows : [];
    const lo = Math.min(1, ...ms.map((m) => m[1])), hi = Math.max(0, ...ms.map((m) => m[3]));
    const t = hi > lo ? (iy - lo) / (hi - lo) : 0.5;
    return 0.8 + Math.max(0, Math.min(1, t)) * 0.35;
  }

  function graze(c: Cow, p: Pt): void {
    c.mode = 'graze'; [c.x, c.y] = p; c.vx = c.vy = 0; c.ang = 0;
    c.size = depth(p[1]); c.timer = rand(9, 26);
    c.sprite.grazing(true);
    c.sprite.face(Math.random() < 0.5 ? -1 : 1);
  }
  function takeOff(c: Cow): void {
    if (c.mode === 'graze') c.y -= (view.ch * c.size * 0.5) / view.ih;
    c.mode = 'fly'; c.size = 1; c.timer = rand(6, 18); c.wait = 0;
    c.sprite.grazing(false);
    [c.tx, c.ty] = skyPoint();
    c.vy = -(18 + 0.08 * Math.min(view.vw, view.vh));
  }
  function spot(c: Cow): void {
    const m = Math.random() < 0.5 ? meadowPoint() : null;
    if (m) graze(c, m);
    else { [c.x, c.y] = skyPoint(); [c.tx, c.ty] = skyPoint(); }
  }
  function make(): Cow {
    const sprite = createCowSprite(o.onPet);
    o.host.insertBefore(sprite.el, o.before);
    const c: Cow = { sprite, mode: 'fly', x: 0.5, y: 0.5, tx: 0.5, ty: 0.5, vx: 0, vy: 0, ang: 0, timer: rand(3, 14), wait: 0, slow: false, size: 1, landSize: 1, needsSpot: false };
    /* под курсором корова почти зависает — так легче попасть */
    const on = () => { c.slow = true; }, off = () => { c.slow = false; };
    sprite.el.addEventListener('pointerenter', on); sprite.el.addEventListener('pointerleave', off);
    sprite.el.addEventListener('focus', on); sprite.el.addEventListener('blur', off);
    if (view.vw) spot(c); else c.needsSpot = true;
    return c;
  }
  function draw(c: Cow): void {
    const w = view.cw * c.size, hgt = w * COW_RATIO;
    const px = view.left + c.x * view.iw;
    let py = view.top + c.y * view.ih;
    if (c.mode === 'graze') py -= hgt / 2;
    c.sprite.place(px - w / 2, py - hgt / 2, w, c.mode === 'graze' ? 100 + Math.round(c.y * 100) : 300);
  }

  function place(): void {
    if (!view.vw) return;
    list.forEach((c) => {
      if (c.needsSpot) { c.needsSpot = false; spot(c); }
      else if (c.mode === 'graze' && !onMeadow(c)) takeOff(c);
      else if (c.mode !== 'graze') {
        const r = sky();
        c.x = Math.max(r.x0, Math.min(r.x1, c.x)); c.y = Math.max(r.y0, Math.min(r.y1, c.y));
      }
      draw(c);
    });
  }

  function step(t: number): void {
    raf = requestAnimationFrame(step);
    const dt = Math.min(0.05, (t - (lastT || t)) / 1000);
    lastT = t;
    if (!dt || !view.vw || !o.isVisible() || !list.length) return;
    const panic = Date.now() < panicUntil, R = sky();
    const base = 18 + 0.08 * Math.min(view.vw, view.vh);
    const { iw, ih } = view;
    for (let i = 0; i < list.length; i++) {
      const c = list[i];
      if (c.mode === 'graze') {
        c.timer -= dt;
        if (panic || c.timer <= 0) takeOff(c);
        else { draw(c); continue; }
      }
      let x = view.left + c.x * iw, y = view.top + c.y * ih;
      const tx = view.left + c.tx * iw;
      let ty = view.top + c.ty * ih;
      if (c.mode === 'land') ty -= view.ch * c.landSize * 0.5;
      const dx = tx - x, dy = ty - y, d = Math.hypot(dx, dy) || 1;
      let sp = base * (panic ? 2.8 : 1) * (c.slow ? 0.15 : 1);
      if (c.wait > 0 && !panic) { c.wait -= dt; sp *= 0.08; }
      sp *= Math.min(1, d / (view.cw * 1.2) + (c.mode === 'land' ? 0.12 : 0.25));
      let ax = dx / d * sp, ay = dy / d * sp;
      /* не толкаться друг с другом */
      for (let j = 0; j < list.length; j++) {
        const q = list[j];
        if (j === i || q.mode === 'graze') continue;
        const ox = x - (view.left + q.x * iw), oy = y - (view.top + q.y * ih), od = Math.hypot(ox, oy) || 1, lim = view.cw * 1.2;
        if (od < lim) { ax += ox / od * base * (1 - od / lim) * 1.4; ay += oy / od * base * (1 - od / lim) * 1.4; }
      }
      const k = Math.min(1, dt * (panic ? 3 : 1.4));
      c.vx += (ax - c.vx) * k; c.vy += (ay - c.vy) * k;
      x += c.vx * dt; y += c.vy * dt;
      c.x = (x - view.left) / iw; c.y = (y - view.top) / ih;
      if (c.mode === 'fly') {
        c.x = Math.max(R.x0, Math.min(R.x1, c.x)); c.y = Math.max(R.y0, Math.min(R.y1, c.y));
        c.timer -= dt;
        if (d < view.cw * 0.5) { [c.tx, c.ty] = skyPoint(); c.wait = Math.random() < 0.4 ? rand(0.4, 2) : 0; }
        if (c.timer <= 0 && !panic) {
          const m = meadowPoint();
          if (m) { c.mode = 'land'; [c.tx, c.ty] = m; c.landSize = depth(m[1]); c.wait = 0; }
          else c.timer = rand(4, 9);
        }
      } else if (c.mode === 'land') {
        if (panic) { c.mode = 'fly'; c.timer = rand(5, 12); }
        else if (d < Math.max(3, view.cw * 0.12)) { graze(c, [c.tx, c.ty]); draw(c); continue; }
      }
      if (c.vx > 6) c.sprite.face(1); else if (c.vx < -6) c.sprite.face(-1);
      c.ang += (Math.max(-14, Math.min(14, c.vy / base * 12)) - c.ang) * Math.min(1, dt * 4);
      c.sprite.tilt(c.ang);
      draw(c);
    }
  }

  return {
    place,
    setCount(n: number): void {
      n = Math.max(0, n | 0);
      while (list.length < n) list.push(make());
      while (list.length > n) list.pop()!.sprite.el.remove();
      place();
    },
    /** На новой картинке луга в других местах: все взлетают, часть потом сядет. */
    newBackground(): void {
      list.forEach((c) => {
        if (c.mode !== 'fly') { c.mode = 'fly'; c.size = 1; c.sprite.grazing(false); }
        [c.x, c.y] = skyPoint(); [c.tx, c.ty] = skyPoint();
        c.timer = rand(1, 10);
      });
      place();
    },
    /** Испуг (инопланетная корова): пасущиеся взлетают, все мечутся. */
    panic(ms: number): void {
      panicUntil = Date.now() + ms;
      list.forEach((c) => { if (c.mode !== 'graze') { [c.tx, c.ty] = skyPoint(); c.wait = 0; } });
    },
    start(): void { if (!raf && !reduceMotion) raf = requestAnimationFrame(step); },
  };
}

export type Flock = ReturnType<typeof createFlock>;
