/* Фон окна: два слоя для плавной смены, картинка или видео без звука, размытая подложка по краям. */
import { h, reduceMotion } from '@/shared/lib';
import { fitBackground, type Background } from '@/entities/background';
import type { SceneView } from './view';

interface Layer { el: HTMLElement; img: HTMLImageElement; vid: HTMLVideoElement; blur: HTMLElement; bg: Background | null }

function createLayer(): Layer {
  const img = h('img', { class: 'bg', alt: '', decoding: 'async' });
  const vid = h('video', { class: 'bg', muted: true, loop: true, playsinline: true, preload: 'auto', disablepictureinpicture: true, disableremoteplayback: true, 'aria-hidden': 'true', hidden: true });
  /* звук из видео не нужен никогда — только звуки игры */
  vid.muted = true; vid.defaultMuted = true; vid.volume = 0;
  const blur = h('div', { class: 'blur' });
  return { el: h('div', { class: 'layer' }, blur, img, vid), img, vid, blur, bg: null };
}

const playSafe = (v: HTMLVideoElement): void => { if (!reduceMotion) v.play().catch(() => { /* останется заставка */ }); };

export function createBackdrop(view: SceneView, onChange: () => void) {
  const layers = [createLayer(), createLayer()];
  let front = -1, token = 0;

  function layoutLayer(L: Layer): void {
    if (!L.bg) return;
    const f = fitBackground(L.bg, view.pw, view.ph);
    [L.img, L.vid].forEach((m) => {
      m.style.left = f.left.toFixed(1) + 'px'; m.style.top = f.top.toFixed(1) + 'px';
      m.style.width = f.iw.toFixed(1) + 'px'; m.style.height = f.ih.toFixed(1) + 'px';
    });
    L.el.classList.toggle('lb', f.letterbox);
  }

  /** Пересчитывает видимую часть текущего фона под размер области pw × ph. */
  function layout(pw: number, ph: number): void {
    view.pw = pw; view.ph = ph;
    layers.forEach(layoutLayer);
    if (!view.bg) return;
    const f = fitBackground(view.bg, pw, ph);
    view.left = f.left; view.top = f.top; view.iw = f.iw; view.ih = f.ih;
    view.vx = Math.max(0, f.left); view.vy = Math.max(0, f.top);
    view.vw = Math.min(pw, f.left + f.iw) - view.vx;
    view.vh = Math.min(ph, f.top + f.ih) - view.vy;
    /* корова растёт и уменьшается вместе с картинкой, но не меньше 30px — чтобы попасть пальцем */
    const cw = Math.max(30, Math.min(0.07 * Math.min(f.iw, f.ih) * view.bg.cowScale, 0.16 * Math.min(view.vw, view.vh)));
    view.cw = cw; view.ch = cw * 105 / 139;
  }

  function setVideo(L: Layer, bg: Background): void {
    if (bg.video) {
      if (L.vid.getAttribute('src') !== bg.video) { L.vid.poster = bg.src; L.vid.src = bg.video; }
      L.vid.hidden = false; L.vid.muted = true;
      playSafe(L.vid);
    } else { L.vid.pause(); L.vid.hidden = true; }
  }

  /** Показывает фон; animate — плавная смена (ждём загрузки картинки). */
  function show(bg: Background, animate: boolean): void {
    const ni = front < 0 ? 0 : 1 - front, L = layers[ni], prev = front < 0 ? null : layers[front];
    const my = ++token;
    L.el.classList.remove('on');
    L.bg = bg;
    L.blur.style.backgroundImage = 'url("' + bg.src + '")';
    const commit = () => {
      if (my !== token) return;
      view.bg = bg; front = ni;
      setVideo(L, bg);
      onChange();
      const instant = !animate || reduceMotion;
      if (instant) { L.el.style.transition = 'none'; L.img.style.transition = 'none'; }
      void L.el.offsetWidth;
      L.el.classList.add('on');
      if (instant) { void L.el.offsetWidth; L.el.style.transition = ''; L.img.style.transition = ''; }
      if (prev) {
        const off = () => { prev.el.classList.remove('on'); prev.vid.pause(); };
        if (instant) off(); else window.setTimeout(() => { if (my === token) off(); }, 900);
      }
    };
    if (animate && !reduceMotion) {
      let done = false;
      const once = () => { if (!done) { done = true; commit(); } };
      L.img.onload = once; L.img.onerror = once;
      L.img.src = bg.src;
      if (L.img.complete && L.img.naturalWidth) once();
    } else {
      L.img.onload = null; L.img.onerror = null;
      L.img.src = bg.src;
      commit();
    }
  }

  /* видео не крутится, пока вкладка скрыта */
  document.addEventListener('visibilitychange', () => {
    if (front < 0) return;
    const L = layers[front];
    if (!L.bg?.video) return;
    if (document.hidden) L.vid.pause(); else playSafe(L.vid);
  });

  return { els: layers.map((l) => l.el), layout, show };
}
