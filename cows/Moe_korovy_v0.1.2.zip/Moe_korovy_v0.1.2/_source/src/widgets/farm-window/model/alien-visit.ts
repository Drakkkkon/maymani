/* Визиты инопланетной коровы: прилетает в луче раз в 1–2,5 минуты, грозно мычит, пугает стадо и улетает.
   Награда (5 или 1 инопланетного молока) — в фиче catch-alien. */
import { rand, reduceMotion } from '@/shared/lib';
import { catchAlien, missAlien, alienRoar } from '@/features/catch-alien';
import type { SceneView } from './view';
import type { Flock } from './flock';
import type { Floats } from './floats';

type State = 'off' | 'in' | 'roar' | 'out';

export interface AlienOptions {
  el: HTMLButtonElement; beam: HTMLElement; scene: HTMLElement;
  view: SceneView; flock: Flock; floats: Floats;
  isVisible: () => boolean;
}

export function createAlienVisits(o: AlienOptions) {
  const { el, beam, view } = o;
  let state: State = 'off', timer = 0, caught = false;
  let spot = { u: 0.5, v: 0.88, flip: 1 };

  function place(): void {
    if (!view.vw) return;
    const aw = Math.min(view.cw * 2.7, view.vw * 0.42, view.vh * 0.5);
    const x = view.vx + view.vw * spot.u, y = view.vy + view.vh * spot.v;
    el.style.width = aw.toFixed(1) + 'px';
    el.style.left = x.toFixed(1) + 'px';
    el.style.top = y.toFixed(1) + 'px';
    el.style.setProperty('--aflip', String(spot.flip));
    const bw = aw * 1.35;
    beam.style.left = (x - bw / 2).toFixed(1) + 'px';
    beam.style.width = bw.toFixed(1) + 'px';
    beam.style.top = view.vy.toFixed(1) + 'px';
    beam.style.height = Math.max(0, y - view.vy + aw * 0.05).toFixed(1) + 'px';
  }

  function schedule(first = false): void {
    clearTimeout(timer);
    timer = window.setTimeout(visit, first ? rand(40e3, 90e3) : rand(70e3, 160e3));
  }

  function visit(): void {
    if (state !== 'off') return;
    /* окно не видно — подождём, чтобы корова не прилетала впустую */
    if (document.hidden || !o.isVisible() || !view.vw) { timer = window.setTimeout(visit, 4000); return; }
    spot = { u: rand(0.28, 0.72), v: rand(0.84, 0.93), flip: Math.random() < 0.5 ? -1 : 1 };
    place();
    state = 'in'; caught = false;
    el.hidden = false;
    el.className = 'alien in';
    beam.classList.add('on');
    timer = window.setTimeout(() => {
      beam.classList.remove('on');
      state = 'roar';
      el.className = 'alien roar';
      alienRoar();
      o.flock.panic(3500);
      if (!reduceMotion) {
        o.scene.classList.remove('quake'); void o.scene.offsetWidth; o.scene.classList.add('quake');
        window.setTimeout(() => o.scene.classList.remove('quake'), 1500);
      }
      timer = window.setTimeout(leave, rand(4500, 6500));
    }, (reduceMotion ? 0 : 1100) + 50);
  }

  function leave(): void {
    if (state === 'out' || state === 'off') return;
    state = 'out';
    if (!caught) {
      /* пропустили — оставляет только одну каплю */
      const n = missAlien();
      const ax = parseFloat(el.style.left) || view.pw / 2, ay = parseFloat(el.style.top) || view.ph / 2;
      o.floats.xy(ax, ay - (parseFloat(el.style.width) || 100) * 0.6, '+' + n + ' {am} (упустили)', 'alien-float');
    }
    beam.classList.add('on');
    el.className = 'alien out';
    clearTimeout(timer);
    timer = window.setTimeout(() => {
      el.hidden = true;
      el.className = 'alien';
      beam.classList.remove('on');
      state = 'off';
      schedule();
    }, reduceMotion ? 50 : 950);
  }

  el.addEventListener('click', (e) => {
    if (el.hidden || caught || state === 'out' || state === 'off') return;
    caught = true;
    const n = catchAlien();
    o.floats.at(e, '+' + n + ' {am} инопл. молока', 'alien-float');
    clearTimeout(timer);
    timer = window.setTimeout(leave, 500);
  });

  return { place, schedule };
}
