/* Видимая часть картинки в окне. Общая для фона, стада и инопланетной коровы. */
import type { Background } from '@/entities/background';

export interface SceneView {
  /** размер области картинки */
  pw: number; ph: number;
  /** видимая часть картинки внутри области */
  vx: number; vy: number; vw: number; vh: number;
  /** где лежит вся картинка (может выходить за край) */
  left: number; top: number; iw: number; ih: number;
  /** размер коровы */
  cw: number; ch: number;
  bg: Background | null;
}

export const createView = (): SceneView => ({ pw: 0, ph: 0, vx: 0, vy: 0, vw: 0, vh: 0, left: 0, top: 0, iw: 1, ih: 1, cw: 40, ch: 30, bg: null });
