/* Окно фермы: рамка, живой фон, стадо, инопланетная корова, стрелки смены фона.
   На компьютере окно по формату картинки во всю высоту экрана, на телефоне — во всю свободную высоту. */
import { h, isDesktop, fmtMilk } from '@/shared/lib';
import { BACKGROUNDS, backgroundById } from '@/entities/background';
import { settings } from '@/entities/player';
import { petCow } from '@/features/pet-cow';
import { createBackgroundSwitcher } from '@/features/switch-background';
import { createView } from '../model/view';
import { createFloats } from '../model/floats';
import { createBackdrop } from '../model/backdrop';
import { createFlock } from '../model/flock';
import { createAlienVisits } from '../model/alien-visit';
import './farm-window.css';

const INSET = 12;
const DESKTOP_RESERVE = 92;   // место под круглой кнопкой хранилища
const MOBILE_RESERVE = 80;

export interface FarmWindowOptions {
  /** Высота нижней панели вкладок на телефоне. */
  bottomBar: () => number;
}

export function createFarmWindow(opts: FarmWindowOptions) {
  const view = createView();
  const bgNum = h('span'), bgName = h('b');
  const floatsLayer = h('div', { class: 'floats', 'aria-hidden': 'true' });
  const beam = h('div', { class: 'beam', 'aria-hidden': 'true' });
  const alienEl = h('button', { class: 'alien', type: 'button', hidden: true, 'aria-label': 'Инопланетная корова: поймать и получить 5 инопланетного молока' },
    h('span', { class: 'al' }, h('span', { class: 'al2' }, h('img', { src: 'alien-cow.png', alt: '', decoding: 'async' }))));
  const scene = h('div', { class: 'scene' });
  const pic = h('div', { class: 'pic' }, scene);
  const glass = h('div', { class: 'glass' }, pic);
  const el = h('section', { class: 'stage', 'aria-label': 'Окно' },
    h('h1', { class: 'title' }, h('span', { class: 'seal', 'aria-hidden': 'true', text: '牛' }), 'Мое_коровы'),
    h('p', { class: 'plate' }, 'Окно ', bgNum, ' · ', bgName),
    h('div', { class: 'frame' }, h('div', { class: 'window' }, glass, createBackgroundSwitcher()), h('div', { class: 'sill' })));

  const isVisible = (): boolean => pic.offsetParent !== null;
  const floats = createFloats(floatsLayer);
  const flock = createFlock({
    host: scene, before: beam, view, isVisible,
    onPet: (e) => {
      const r = petCow();
      floats.say(e, r.phrase);
      if (r.milk > 0) floats.at(e, '+' + fmtMilk(r.milk) + ' л');
    },
  });
  const alien = createAlienVisits({ el: alienEl, beam, scene, view, flock, floats, isVisible });

  function layoutScene(): void {
    if (!pic.clientWidth || !pic.clientHeight) return;
    backdrop.layout(pic.clientWidth, pic.clientHeight);
    flock.place();
    alien.place();
  }
  const backdrop = createBackdrop(view, () => { relayout(); layoutScene(); flock.newBackground(); });
  scene.append(...backdrop.els, beam, alienEl, floatsLayer);

  /** Размер окна под экран и формат текущего фона. */
  function relayout(): void {
    if (!el.offsetParent) return;
    const bg = view.bg || backgroundById(settings.get().bg), ar = bg.w / bg.h;
    const vh = window.innerHeight || 700, vw = window.innerWidth || 1000;
    const chrome = el.offsetHeight - glass.offsetHeight, B = 2 * INSET + 2.4;
    let hgt: number;
    if (isDesktop()) {
      hgt = Math.max(320, vh - 16 - chrome - DESKTOP_RESERVE);
      let w = (hgt - B) * ar + B;
      const maxW = Math.max(300, vw * 0.5 - 48);
      if (w > maxW) { w = maxW; hgt = (w - B) / ar + B; }
      glass.style.width = Math.round(w) + 'px';
    } else {
      hgt = Math.max(240, vh - 16 - chrome - (opts.bottomBar() || 60) - MOBILE_RESERVE);
      glass.style.width = '';
    }
    glass.style.height = Math.round(hgt) + 'px';
  }

  function showBg(animate: boolean): void {
    const bg = backgroundById(settings.get().bg);
    bgNum.textContent = String(BACKGROUNDS.indexOf(bg) + 1);
    bgName.textContent = bg.name;
    backdrop.show(bg, animate);
  }

  return {
    el,
    relayout,
    /** Запуск после того, как окно вставлено на страницу. */
    start(): void {
      new ResizeObserver(layoutScene).observe(pic);
      let t = 0;
      window.addEventListener('resize', () => { clearTimeout(t); t = window.setTimeout(() => { relayout(); layoutScene(); }, 40); });
      document.fonts?.ready.then(relayout);
      settings.subscribe((s, p) => {
        if (s.bg !== p.bg) showBg(true);
        if (s.cowCount !== p.cowCount) flock.setCount(s.cowCount);
        if (s.skin !== p.skin) relayout();
      });
      showBg(false);
      flock.setCount(settings.get().cowCount);
      flock.start();
      alien.schedule(true);
      /* предзагрузка, чтобы стрелки переключали без задержки */
      window.setTimeout(() => BACKGROUNDS.forEach((b) => { new Image().src = b.src; }), 2500);
    },
  };
}

export type FarmWindow = ReturnType<typeof createFarmWindow>;
