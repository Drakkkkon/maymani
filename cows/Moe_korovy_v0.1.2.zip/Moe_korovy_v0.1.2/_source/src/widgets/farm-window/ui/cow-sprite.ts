/* Корова в окне: кадр из cows.webp и два машущих крыла. Режимы: летит или пасётся (крылья сложены, жуёт траву).
   Где корова и куда летит — решает стадо (виджет окна), здесь только внешний вид. */
import { h, rand } from '@/shared/lib';
import './cow-sprite.css';

const WING = '<svg viewBox="0 0 100 70" aria-hidden="true"><path d="M92 64C86 40 64 14 30 4C20 1 8 2 2 6C10 8 16 10 20 12L10 18C18 20 26 22 30 24L20 30C30 32 38 34 42 36L34 42C44 44 52 46 56 48L50 54C60 56 68 58 72 60Q82 68 92 64Z"/><path class="fe" d="M88 60C70 44 46 22 20 12M84 62C68 50 50 32 30 24M80 63C66 54 54 42 42 36M76 63C66 58 60 50 56 48"/></svg>';

/** Пропорции кадра коровы. */
export const COW_RATIO = 105 / 139;

export function createCowSprite(onClick: (e: MouseEvent) => void) {
  const tilt = h('span', { class: 'tilt' },
    h('span', { class: 'bob' },
      h('span', { class: 'wing wb', html: WING }),
      h('span', { class: 'cow' }, h('i')),
      h('span', { class: 'wing wf', html: WING })));
  const el = h('button', { type: 'button', class: 'cow-slot', 'aria-label': 'Корова: погладить, услышать мычание', on: { click: onClick as EventListener } },
    h('span', { class: 'flip' }, tilt));
  el.style.setProperty('--fl', rand(0.28, 0.4).toFixed(2) + 's');   // скорость взмахов
  el.style.setProperty('--gd', (-rand(0, 24)).toFixed(1) + 's');    // сдвиг анимации жевания
  el.style.setProperty('--flip', '1');

  let dir = 1, width = 0, z = 0;
  return {
    el,
    /** 1 — смотрит вправо, -1 — влево. */
    face(d: number): void { if (d !== dir) { dir = d; el.style.setProperty('--flip', String(d)); } },
    grazing(on: boolean): void { el.classList.toggle('g', on); },
    tilt(deg: number): void { tilt.style.transform = 'rotate(' + deg.toFixed(1) + 'deg)'; },
    /** Ставит корову: x, y — левый верхний угол, w — ширина. */
    place(x: number, y: number, w: number, layer: number): void {
      if (Math.abs(w - width) > 0.4) { width = w; el.style.width = w.toFixed(1) + 'px'; }
      el.style.transform = 'translate3d(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px,0)';
      if (layer !== z) { z = layer; el.style.zIndex = String(layer); }
    },
  };
}

export type CowSprite = ReturnType<typeof createCowSprite>;
