/* Хранилище: круглая кнопка слева внизу и окошко-сетка рядом с ней.
   В каждой ячейке эмодзи и количество в правом нижнем углу, подробности — под сеткой. */
import { h, setText, fmtMilk, fmtRate, fmtNum, fmtTiny, refreshWhileVisible } from '@/shared/lib';
import { progress, rates, starsOf, alienNeed } from '@/entities/farm';
import { alienMilkIcon } from '@/shared/ui';
import './storage.css';

interface Cell { green?: boolean; emoji: string; label: string; count: () => string; details: () => string }

const CELLS: Cell[] = [
  { emoji: '🥛', label: 'Молоко', count: () => fmtTiny(progress.milk), details: () => fmtMilk(progress.milk) + ' л · +' + fmtRate(progress.cows * rates.perCow) + ' л в секунду' },
  { emoji: '🥛', green: true, label: 'Инопланетное молоко', count: () => fmtTiny(progress.alienMilk), details: () => progress.alienMilk.toLocaleString('ru-RU') + ' · для Игры+ нужно ' + alienNeed() },
  { emoji: '🐄', label: 'Коровы', count: () => fmtTiny(progress.cows), details: () => fmtNum(progress.cows) + ' · +' + fmtRate(rates.cps) + ' в секунду' },
  { emoji: '🛸', label: 'Инопланетные коровы', count: () => fmtTiny(progress.alienCows), details: () => progress.alienCows.toLocaleString('ru-RU') + ' поймано' },
  { emoji: '🌾', label: 'Стога сена', count: () => String(progress.lv.hay), details: () => progress.lv.hay + ' шт. · +' + fmtRate(progress.lv.hay * rates.hayEach) + '% коров и молока' },
  { emoji: '🚧', label: 'Загоны', count: () => String(progress.lv.pens), details: () => progress.lv.pens + ' шт. · +' + progress.lv.pens * 10 + '% коров и молока' },
  { emoji: '🪓', label: 'Топоры', count: () => fmtTiny(rates.axes), details: () => fmtNum(rates.axes) + ' в работе' },
  { emoji: '🪵', label: 'Полена', count: () => fmtTiny(progress.logs), details: () => fmtNum(progress.logs) + ' · +' + fmtRate(rates.lps) + ' в секунду' },
  { emoji: '🛖', label: 'Древохранилища', count: () => starsOf('woodstore') + '★', details: () => starsOf('woodstore') + ' из 5★ · +' + starsOf('woodstore') * 10 + '% топоров и полен' },
  { emoji: '🌽', label: 'Зерно', count: () => fmtTiny(progress.grain), details: () => fmtNum(progress.grain) + ' · +' + fmtRate(rates.gps) + ' в секунду' },
  { emoji: '🏠', label: 'Амбары', count: () => starsOf('barn') + '★', details: () => starsOf('barn') + ' из 5★ · +' + starsOf('barn') * 10 + '% зерна и силы стогов' },
];

export function createStorage(): HTMLElement[] {
  let selected = -1;
  const cap = h('p', { class: 'store-cap', text: 'Наведите на ячейку или нажмите на неё, чтобы увидеть подробности.' });
  const cells = CELLS.map((c, i) => {
    const count = h('span', { class: 'sv' });
    const li = h('li', { tabindex: 0, title: c.label }, c.green ? alienMilkIcon('se') : h('span', { class: 'se', 'aria-hidden': 'true', text: c.emoji }), count);
    const choose = () => { selected = i; cells.forEach((x, j) => x.li.classList.toggle('sel', j === i)); refresh(); };
    li.addEventListener('mouseenter', choose); li.addEventListener('focus', choose); li.addEventListener('click', choose);
    return { li, count };
  });
  const pop = h('div', { class: 'store-pop', role: 'dialog', 'aria-label': 'Хранилище', hidden: true },
    h('h2', { text: 'Хранилище' }), h('ul', { class: 'store-list' }, ...cells.map((c) => c.li)), cap);
  const btn = h('button', { class: 'store-btn', type: 'button', 'aria-expanded': 'false', 'aria-label': 'Хранилище', title: 'Хранилище', text: '📦' });

  function refresh(): void {
    if (pop.hidden) return;
    CELLS.forEach((c, i) => {
      const n = c.count();
      setText(cells[i].count, n);
      cells[i].li.setAttribute('aria-label', c.label + ': ' + n);
    });
    if (selected >= 0) {
      const c = CELLS[selected], d = c.details();
      if (cap.dataset.d !== c.label + d) {
        cap.dataset.d = c.label + d;
        cap.replaceChildren(c.green ? alienMilkIcon('') : c.emoji, ' ', h('b', { text: c.label }), ': ' + d);
      }
    }
  }
  function open(on: boolean): void {
    pop.hidden = !on;
    btn.setAttribute('aria-expanded', on ? 'true' : 'false');
    refresh();
  }
  btn.addEventListener('click', (e) => { e.stopPropagation(); open(pop.hidden !== false); });
  document.addEventListener('click', (e) => { if (!pop.hidden && !pop.contains(e.target as Node) && e.target !== btn) open(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !pop.hidden) { open(false); btn.focus(); } });
  refreshWhileVisible(pop, refresh);
  return [btn, pop];
}
