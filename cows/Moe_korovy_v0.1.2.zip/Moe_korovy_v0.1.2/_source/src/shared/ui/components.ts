/* Маленькие общие компоненты. Каждый возвращает корневой элемент и методы обновления. */
import { h, setText, setScale, replayClass, nextId } from '@/shared/lib';
import { icons } from './icons';
import './components.css';

/* ---------- полоска прогресса ---------- */
export function createProgressBar(cls = 'bar') {
  const fill = h('i');
  const el = h('div', { class: cls, 'aria-hidden': 'true' }, fill);
  return { el, set: (frac: number) => setScale(fill, frac), fill };
}

/* ---------- ряд звёзд ---------- */
export function createStars(count: number) {
  const stars = Array.from({ length: count }, () => h('i', { class: 'star' }));
  const on: boolean[] = [];
  const el = h('span', { class: 'stars', 'aria-hidden': 'true' }, ...stars);
  return {
    el,
    /** Включает звёзды, для которых isOn(i) истинно. */
    set(isOn: (i: number) => boolean): void {
      stars.forEach((s, i) => { const v = isOn(i); if (on[i] !== v) { on[i] = v; s.classList.toggle('on', v); } });
    },
  };
}

/* ---------- кнопка-плашка: крупная подпись и мелкая строка (×10 / цена) ---------- */
export function createChip(onClick: () => void) {
  const b = h('b'), s = h('small');
  const el = h('button', { type: 'button', class: 'chip meadow', on: { click: onClick } }, b, s);
  el.addEventListener('animationend', (e) => { if (e.animationName === 'nope') el.classList.remove('nope'); });
  return {
    el,
    set(title: string, sub: string, label: string, hint: string): void {
      if (b.textContent === title && s.textContent === sub) return;
      setText(b, title); setText(s, sub);
      el.setAttribute('aria-label', label); el.title = hint;
    },
    state(can: boolean, max: boolean): void { el.classList.toggle('can', can); el.classList.toggle('max', max); },
    shake(): void { replayClass(el, 'nope'); },
  };
}

/* ---------- инопланетное молоко: зелёный стакан (обычный 🥛, перекрашенный в CSS) ---------- */
export const alienMilkIcon = (cls = 'emo'): HTMLElement => h('span', { class: (cls ? cls + ' ' : '') + 'gmilk', 'aria-hidden': 'true', text: '🥛' });
/** Текст, где каждый знак {am} заменён зелёным стаканом. */
export function withAlienMilk(text: string): (string | HTMLElement)[] {
  const out: (string | HTMLElement)[] = [];
  text.split('{am}').forEach((part, i) => { if (i) out.push(alienMilkIcon('')); if (part) out.push(part); });
  return out;
}

/* ---------- карточка показателя: подпись, значение, строки ниже ---------- */
const emo = (e?: string) => (e ? h('span', { class: 'emo', 'aria-hidden': 'true', text: e }) : null);
/** lines — эмодзи перед каждой строкой ('' — без эмодзи). */
export function createStatCard(label: string, opts: { emoji?: string; lines?: string[]; tick?: boolean } = {}) {
  const value = h('span');
  const lineEmoji = opts.lines ?? [''];
  const lines = lineEmoji.map(() => h('span'));
  const tick = opts.tick ? createProgressBar('tick') : null;
  const el = h('div', { class: 'stat' },
    h('p', { class: 'stat-k', text: label }),
    h('p', { class: 'stat-v' }, emo(opts.emoji), value),
    ...lines.map((l, i) => h('p', { class: 'stat-r' }, emo(lineEmoji[i]), l)),
    tick ? tick.el : null);
  return {
    el,
    value: (v: string) => setText(value, v),
    line: (i: number, v: string) => setText(lines[i], v),
    tick,
  };
}

export function createStatGrid(...cards: HTMLElement[]): HTMLElement {
  return h('div', { class: 'stats' + (cards.length === 3 ? ' three' : '') }, ...cards);
}

/* ---------- раздел страницы с заголовком ---------- */
export function createCard(title: string, ...children: (Node | null)[]): HTMLElement {
  const id = nextId('card');
  return h('section', { class: 'card', 'aria-labelledby': id }, h('h2', { id, text: title }), ...children);
}

export const pageTitle = (text: string): HTMLElement => h('h2', { class: 'page-h', text });
export const hint = (text: string): HTMLElement => h('p', { class: 'hint', text });
export const note = (text: string): HTMLElement => h('p', { class: 'note', text });
export const footnote = (text: string): HTMLElement => h('p', { class: 'foot', text });
export const sectionTitle = (text: string, sub = false): HTMLElement => h('h2', { class: sub ? 'sub' : null, text });

/* ---------- ползунок с подписью и значением ---------- */
export function createRangeField(o: {
  label: string; min: number; max: number; value: number; suffix?: string; hint?: string;
  onInput: (v: number) => void; onChange?: () => void;
}) {
  const id = nextId('range');
  const input = h('input', { id, type: 'range', min: o.min, max: o.max, step: 1, value: o.value });
  const out = h('output', { for: id });
  const paint = () => {
    input.style.setProperty('--p', ((Number(input.value) - o.min) / (o.max - o.min) * 100) + '%');
    out.textContent = input.value + (o.suffix ?? '');
  };
  paint();
  input.addEventListener('input', () => { paint(); o.onInput(Number(input.value)); });
  if (o.onChange) input.addEventListener('change', o.onChange);
  const el = h('div', { class: 'ctl' },
    h('div', { class: 'ctl-top' }, h('label', { for: id, text: o.label }), out),
    input,
    o.hint ? hint(o.hint) : null);
  return { el, input };
}

/* ---------- строка с переключателем ---------- */
export function createSwitchRow(label: string, onToggle: () => void) {
  const id = nextId('sw');
  const state = h('span', { class: 'state', 'aria-hidden': 'true' });
  const btn = h('button', { class: 'switch', type: 'button', role: 'switch', 'aria-checked': 'false', 'aria-labelledby': id, on: { click: onToggle } },
    h('span', { class: 'track' }, h('span', { class: 'thumb' })));
  const el = h('div', { class: 'ctl-row' }, h('span', { id, text: label }), h('div', { class: 'ctl-right' }, state, btn));
  return {
    el,
    set(on: boolean): void { btn.setAttribute('aria-checked', on ? 'true' : 'false'); state.textContent = on ? 'Вкл' : 'Выкл'; },
  };
}

/* ---------- обычные кнопки ---------- */
export function createButton(text: string, onClick: () => void, opts: { primary?: boolean; disabled?: boolean } = {}): HTMLButtonElement {
  return h('button', { class: 'btn' + (opts.primary ? ' primary' : ''), type: 'button', disabled: !!opts.disabled, on: { click: onClick }, text });
}
export const buttonRow = (...btns: HTMLElement[]): HTMLElement => h('div', { class: 'btn-row' }, ...btns);

/* ---------- строка-переход в настройках ---------- */
export function createNavRow(label: string, onClick: () => void) {
  const val = h('span', { class: 'nval' });
  const el = h('button', { class: 'navrow', type: 'button', on: { click: onClick } },
    h('span', { html: icons.folder }), h('span', { class: 'nlabel', text: label }), val, h('span', { html: icons.next }));
  return { el, setValue: (v: string) => setText(val, v) };
}

export function createBackButton(text: string, onClick: () => void): HTMLButtonElement {
  return h('button', { class: 'back', type: 'button', on: { click: onClick }, html: icons.back }, text);
}

/* ---------- раскрывающаяся папка ---------- */
export function createFolder(name: string, count: string, ...content: HTMLElement[]): HTMLElement {
  const bodyId = nextId('fold');
  const body = h('div', { class: 'fbody', id: bodyId }, ...content);
  const head = h('button', { class: 'folder', type: 'button', 'aria-expanded': 'true', 'aria-controls': bodyId },
    h('span', { html: icons.folder }), h('span', { class: 'fname', text: name }), h('span', { class: 'fcount', text: count }), h('span', { html: icons.chevron }));
  head.addEventListener('click', () => {
    const open = head.getAttribute('aria-expanded') !== 'true';
    head.setAttribute('aria-expanded', open ? 'true' : 'false');
    body.hidden = !open;
  });
  return h('section', {}, head, body);
}
