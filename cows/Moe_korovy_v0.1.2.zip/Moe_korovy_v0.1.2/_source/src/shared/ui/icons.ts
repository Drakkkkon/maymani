/* SVG-иконки интерфейса (рисунок 24×24, обводка — currentColor). */
const svg = (d: string, extra = ''): string => '<svg viewBox="0 0 24 24" aria-hidden="true"' + extra + '>' + d + '</svg>';

export const icons = {
  chevronLeft: svg('<path d="M15 5l-7 7 7 7"/>'),
  chevronRight: svg('<path d="M9 5l7 7-7 7"/>'),
  back: svg('<path d="M15 6l-6 6 6 6"/>'),
  next: svg('<path d="M9 6l6 6-6 6"/>'),
  folder: svg('<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>'),
  chevron: svg('<path d="M9 6l6 6-6 6"/>', ' class="chev"'),
  window: svg('<rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M3 8h18"/>'),
  milk: svg('<path d="M9 3h6M10 3v3L8 9v11h8V9l-2-3V3"/><path d="M8 13h8"/>'),
  house: svg('<path d="M4 11l8-6 8 6v9H4z"/><path d="M10 20v-5h4v5"/>'),
  wheat: svg('<path d="M12 21V8"/><path d="M12 8c-3 0-4-2-4-5 3 0 4 2 4 5zM12 8c3 0 4-2 4-5-3 0-4 2-4 5zM12 13c-3 0-4-2-4-4 3 0 4 1 4 4zM12 13c3 0 4-2 4-4-3 0-4 1-4 4zM12 18c-3 0-4-2-4-4 3 0 4 1 4 4zM12 18c3 0 4-2 4-4-3 0-4 1-4 4z"/>'),
  plus: svg('<circle cx="12" cy="12" r="8.5"/><path d="M12 8v8M8 12h8"/>'),
  sliders: svg('<path d="M4 7h16M4 12h16M4 17h16"/><circle cx="9" cy="7" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="8" cy="17" r="2"/>'),
} as const;
