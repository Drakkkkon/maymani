/* Звуки игры: какие куски каких записей играть и с какой громкостью.
   Записи лежат в public/sounds. Что есть что (разобрано по спектру и огибающей):
   cow-field   — одиночные мычания в поле, 6 штук с паузами
   cow-3       — три мычания подряд          cow-1 — одно мычание
   sound_05508 — две коровы мычат в коровнике (гул доильной техники)
   cows-stall  — стадо в стойле, мычание без перерыва (фон)
   milking     — доение руками, струйки молока в ведро
   woodwork    — удары топора по дереву примерно раз в секунду
   tree-fall   — треск и падение дерева
   village     — атмосфера деревни (фон)     wind-trees — ветер в кронах (фон)
   field-wind  — сильный ветер в поле (фон, очень тихая запись)
   tractor     — трактор на полевых работах (фон)
   music-*     — мелодии окон: у каждого фона своя, меняется вместе с фоном */

export type Clip = readonly [file: string, offset: number, duration: number];

export interface SoundBank {
  base: string;
  /** Множители громкости: громкие участки всех записей звучат примерно одинаково. */
  gain: Record<string, number>;
  /** Короткие звуки целиком загружаются в память. */
  preload: string[];
  clips: Record<string, Clip[]>;
  /** Фон страниц: записи-петли с громкостью и, по желанию, повторяющийся звук. */
  /** Мелодии окон: id фона → запись. Играют поверх фона страницы, громкость — ползунок «Музыка». */
  music: Record<string, string>;
  ambience: Record<string, { loops: [file: string, level: number][]; every?: { clips: string; min: number; max: number; gain: number } }>;
}

export const SOUND_BANK: SoundBank = {
  base: 'sounds/',
  gain: {
    'cow-field': 0.93, 'cow-3': 0.7, 'cow-1': 0.62, 'sound_05508': 0.76, 'milking': 2, 'woodwork': 0.3, 'tree-fall': 0.42,
    'village': 1.5, 'wind-trees': 0.6, 'field-wind': 12, 'cows-stall': 1, 'tractor': 1.2,
    'music-mountains': 0.9, 'music-night': 0.9, 'music-city': 0.9, 'music-florence': 0.9,
  },
  preload: ['cow-field', 'cow-3', 'cow-1', 'sound_05508', 'milking', 'woodwork', 'tree-fall'],
  clips: {
    moo: [['cow-field', 0.7, 0.85], ['cow-field', 5.75, 1.3], ['cow-field', 10.15, 0.7], ['cow-field', 14.85, 1.2], ['cow-field', 18.95, 1], ['cow-field', 23.8, 1.1],
      ['cow-3', 0.8, 1.15], ['cow-3', 3.25, 2], ['cow-3', 6.55, 1.4], ['cow-1', 0.85, 1.1], ['sound_05508', 5.45, 1.3], ['sound_05508', 8.35, 1.85]],
    milk: [['milking', 1.05, 1.45], ['milking', 3.65, 1.5], ['milking', 5.35, 2.4]],
    chop: [0.62, 1.67, 2.62, 3.62, 4.97, 6.27, 7.92, 8.87, 10.72, 12.72, 13.87, 15.22].map((t): Clip => ['woodwork', t, 0.42]),
    fall: [['tree-fall', 0.1, 3.4]],
  },
  music: { mountains: 'music-mountains', night: 'music-night', city: 'music-city', florence: 'music-florence' },
  ambience: {
    window: { loops: [['village', 1]] },
    farm: { loops: [['village', 1]] },
    /* в Домиках лесорубы работают: изредка слышно топор */
    houses: { loops: [['wind-trees', 1]], every: { clips: 'chop', min: 1.8, max: 4.6, gain: 0.5 } },
    feed: { loops: [['field-wind', 0.8], ['tractor', 0.45]] },
    gameplus: { loops: [['field-wind', 1]] },
    settings: { loops: [['cows-stall', 0.9]] },
  },
};
