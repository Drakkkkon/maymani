/* Звуковой движок: короткие звуки из памяти, фон потоком, выравнивание громкости.
   С сайта (http/https) работает через Web Audio: можно усиливать тихие записи и есть компрессор.
   С локального файла (file://) — запасной путь через <audio>, громкость там не выше 1. */
import type { Clip, SoundBank } from '@/shared/config';
import { rand, pick } from './env';

export interface ClipOptions { rate?: number; gain?: number; delay?: number }
interface Ambient { a: HTMLAudioElement; node: GainNode | null; started: boolean; iv: number; pt: number }

const level = (v: number): number => { const x = v / 100; return x * x; };

export function createAudioEngine(bank: SoundBank) {
  let ctx: AudioContext | null = null;
  let sfxBus: GainNode | null = null, ambBus: GainNode | null = null;
  let unlocked = false, web = false, hidden = false;
  const vol = { sfx: 60, amb: 40 };
  const buffers: Record<string, AudioBuffer> = {}, loading: Record<string, boolean> = {}, loops: Record<string, Ambient> = {};
  let scene = '', music = '', everyT = 0;
  const isMusic = (f: string): boolean => Object.values(bank.music).includes(f);

  function build(): void {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC || location.protocol === 'file:') return;
    try { ctx = new AC(); } catch { ctx = null; return; }
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.knee.value = 10; comp.ratio.value = 4; comp.attack.value = 0.005; comp.release.value = 0.25;
    sfxBus = ctx.createGain(); ambBus = ctx.createGain();
    sfxBus.gain.value = level(vol.sfx); ambBus.gain.value = level(vol.amb);
    sfxBus.connect(comp); ambBus.connect(comp); comp.connect(ctx.destination);
    web = true;
    bank.preload.forEach(load);
  }

  function load(f: string): void {
    if (buffers[f] || loading[f] || !ctx) return;
    loading[f] = true;
    const c = ctx;
    fetch(bank.base + f + '.mp3')
      .then((r) => { if (!r.ok) throw new Error(String(r.status)); return r.arrayBuffer(); })
      .then((b) => new Promise<AudioBuffer>((res, rej) => { c.decodeAudioData(b, res, rej); }))
      .then((ab) => { buffers[f] = ab; }, () => { loading[f] = false; });
  }

  /** Играет кусок записи с мягким началом и концом. */
  function play(clip: Clip, opt: ClipOptions = {}): void {
    if (!unlocked || vol.sfx <= 0 || hidden) return;
    const [f, off, dur] = clip, rate = opt.rate || 1, g = (bank.gain[f] || 1) * (opt.gain || 1);
    if (web && ctx && sfxBus && ctx.state === 'running' && buffers[f]) {
      const t = ctx.currentTime + (opt.delay || 0) + 0.005, len = dur / rate;
      const src = ctx.createBufferSource(), gn = ctx.createGain();
      src.buffer = buffers[f]; src.playbackRate.value = rate;
      gn.gain.setValueAtTime(0, t);
      gn.gain.linearRampToValueAtTime(g, t + 0.012);
      gn.gain.setValueAtTime(g, t + Math.max(0.02, len - 0.09));
      gn.gain.linearRampToValueAtTime(0, t + len);
      src.connect(gn); gn.connect(sfxBus);
      src.start(t, off, dur + 0.05); src.stop(t + len + 0.06);
      return;
    }
    window.setTimeout(() => {
      try {
        const a = new Audio(bank.base + f + '.mp3#t=' + off + ',' + (off + dur));
        a.volume = Math.min(1, g * level(vol.sfx));
        if (rate !== 1) { a.preservesPitch = false; a.playbackRate = rate; }
        a.play().catch(() => { /* браузер не дал играть */ });
      } catch { /* нет поддержки звука */ }
    }, (opt.delay || 0) * 1000);
  }

  function clips(group: string): readonly Clip[] { return bank.clips[group] || []; }

  /* ---------- фон: записи идут потоком через <audio>, чтобы не держать минуты звука в памяти ---------- */
  function loop(f: string): Ambient {
    if (loops[f]) return loops[f];
    const a = new Audio(bank.base + f + '.mp3');
    a.loop = true; a.preload = 'none';
    const o: Ambient = { a, node: null, started: false, iv: 0, pt: 0 };
    if (web && ctx && ambBus) {
      try {
        const src = ctx.createMediaElementSource(a);
        o.node = ctx.createGain(); o.node.gain.value = 0;
        src.connect(o.node); o.node.connect(ambBus);
      } catch { o.node = null; }
    }
    if (!o.node) a.volume = 0;
    loops[f] = o;
    return o;
  }
  function fade(o: Ambient, g: number, on: boolean): void {
    clearTimeout(o.pt); clearInterval(o.iv);
    if (o.node && ctx) {
      const t = ctx.currentTime;
      o.node.gain.cancelScheduledValues(t);
      o.node.gain.setValueAtTime(o.node.gain.value, t);
      o.node.gain.linearRampToValueAtTime(on ? g : 0, t + 1.4);
    } else {
      const from = o.a.volume, to = on ? Math.min(1, g * level(vol.amb)) : 0, t0 = Date.now();
      o.iv = window.setInterval(() => {
        const k = Math.min(1, (Date.now() - t0) / 1400);
        o.a.volume = Math.max(0, Math.min(1, from + (to - from) * k));
        if (k >= 1) clearInterval(o.iv);
      }, 50);
    }
    if (!on) o.pt = window.setTimeout(() => o.a.pause(), 1500);
  }
  function applyAmbience(): void {
    if (!unlocked) return;
    const want: Record<string, number> = {};
    const amb = bank.ambience[scene];
    if (!hidden && vol.amb > 0 && amb) amb.loops.forEach(([f, w]) => { want[f] = w; });
    /* мелодия окна звучит на всех страницах и меняется вместе с фоном */
    const tune = bank.music[music];
    if (!hidden && vol.amb > 0 && tune) want[tune] = 1;
    Object.keys(want).forEach(loop);
    Object.keys(loops).forEach((f) => {
      const o = loops[f], w = want[f] || 0;
      if (w > 0 && o.a.paused) {
        if (!o.started) {
          o.started = true;
          /* каждый раз с нового места записи, чтобы фон не повторялся */
          o.a.addEventListener('loadedmetadata', () => {
            try { if (!isMusic(f) && o.a.duration > 40) o.a.currentTime = Math.random() * (o.a.duration - 30); } catch { /* ещё не готово */ }
          });
        }
        o.a.play().catch(() => { /* браузер не дал играть */ });
      }
      fade(o, w * (bank.gain[f] || 1), w > 0);
    });
  }
  function everyLoop(): void {
    clearTimeout(everyT);
    const ev = bank.ambience[scene]?.every;
    everyT = window.setTimeout(() => {
      const cur = bank.ambience[scene]?.every;
      if (cur && !hidden) play(pick(clips(cur.clips)), { gain: cur.gain });
      everyLoop();
    }, ev ? rand(ev.min, ev.max) * 1000 : 3000);
  }

  return {
    play,
    clips,
    /** Звук включается только после первого касания — так требуют браузеры. */
    unlock(): void {
      const first = !unlocked;
      if (first) { unlocked = true; build(); everyLoop(); }
      if (ctx && ctx.state !== 'running') ctx.resume().then(applyAmbience, () => { /* ждём жеста */ });
      else if (first) applyAmbience();
    },
    setAmbience(name: string): void {
      if (name === scene) return;
      scene = name;
      applyAmbience();
    },
    /** Мелодия окна: id фона из банка звуков; старая плавно затихает. */
    setMusic(id: string): void {
      if (id === music) return;
      music = id;
      applyAmbience();
    },
    setVolume(kind: 'sfx' | 'amb', v: number): void {
      vol[kind] = v;
      const bus = kind === 'sfx' ? sfxBus : ambBus;
      if (bus && ctx) bus.gain.setTargetAtTime(level(v), ctx.currentTime, 0.05);
      if (kind === 'amb') applyAmbience();
    },
    setVisible(on: boolean): void {
      hidden = !on;
      if (ctx && unlocked) {
        if (on) { if (ctx.state !== 'running') ctx.resume().then(applyAmbience, () => { /* ждём жеста */ }); }
        else if (ctx.state === 'running') ctx.suspend();
      }
      applyAmbience();
    },
  };
}
