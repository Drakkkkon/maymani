/* Создание и обновление DOM без фреймворка. */

type Child = Node | string | null | undefined | false;
type Handlers = Record<string, EventListener>;
interface Attrs {
  class?: string | null;
  html?: string;              // innerHTML (только для своих SVG-иконок)
  text?: string;
  style?: string;
  on?: Handlers;
  [attr: string]: string | number | boolean | null | undefined | Handlers;
}

/** Короткая запись createElement: h('button', { class: 'btn', on: { click } }, 'Текст'). */
export function h<K extends keyof HTMLElementTagNameMap>(tag: K, attrs: Attrs = {}, ...children: Child[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = String(v);
    else if (k === 'html') el.innerHTML = String(v);
    else if (k === 'text') el.textContent = String(v);
    else if (k === 'style') el.setAttribute('style', String(v));
    else if (k === 'on') {
      for (const [ev, fn] of Object.entries(v as Handlers)) el.addEventListener(ev, fn);
    } else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, String(v));
  }
  for (const c of children) if (c) el.append(c);
  return el;
}

/** Текст меняется, только если он другой: меньше работы для браузера при обновлении 10 раз в секунду. */
export function setText(node: Node, v: string): void {
  if (node.textContent !== v) node.textContent = v;
}

/** Ширина полоски прогресса через transform: дёшево для анимации. */
export function setScale(node: HTMLElement, frac: number): void {
  node.style.transform = 'scaleX(' + Math.max(0, Math.min(1, frac)).toFixed(3) + ')';
}

/** Перезапуск CSS-анимации класса (например, «тряска» при нехватке ресурсов). */
export function replayClass(node: Element, cls: string): void {
  node.classList.remove(cls);
  void (node as HTMLElement).offsetWidth;
  node.classList.add(cls);
}

let uid = 0;
export const nextId = (prefix: string): string => prefix + '-' + (++uid);
