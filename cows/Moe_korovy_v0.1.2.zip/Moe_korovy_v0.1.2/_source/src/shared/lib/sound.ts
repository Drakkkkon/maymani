/* Звуки игры простыми словами: moo, buy, chop… Поверх общего движка и банка звуков. */
import { SOUND_BANK, type Clip } from '@/shared/config';
import { createAudioEngine } from './audio-engine';
import { pick, pickOther } from './env';

const engine = createAudioEngine(SOUND_BANK);
let lastMoo = -1;

function mooClip(): Clip {
  const all = engine.clips('moo');
  lastMoo = pickOther(all.length, lastMoo);
  return all[lastMoo];
}

export const sound = {
  unlock: engine.unlock,
  setAmbience: engine.setAmbience,
  setMusic: engine.setMusic,
  setVolume: engine.setVolume,
  setVisible: engine.setVisible,
  /** Мычание. scary — инопланетная: две коровы, замедленные и пониженные. */
  moo(scary = false): void {
    if (!scary) { engine.play(mooClip()); return; }
    engine.play(mooClip(), { rate: 0.6, gain: 1.3 });
    engine.play(mooClip(), { rate: 0.47, gain: 0.9, delay: 0.15 });
  },
  /** Покупка: доение или мычание. */
  buy(): void {
    if (Math.random() < 0.5) engine.play(pick(engine.clips('milk'))); else sound.moo();
  },
  /** Удары топора, n штук подряд. */
  chop(n = 2, gain = 1): void {
    for (let i = 0; i < n; i++) engine.play(pick(engine.clips('chop')), { delay: i * 0.34, gain, rate: 0.94 + Math.random() * 0.12 });
  },
  fall(): void { engine.play(engine.clips('fall')[0]); },
  /** Суперулучшение: доение и мычание. */
  special(): void {
    engine.play(pick(engine.clips('milk')));
    engine.play(mooClip(), { delay: 0.4 });
  },
};
