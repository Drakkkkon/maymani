/* Среда: размер экрана, предпочтения пользователя, случайные числа. */

/** Компьютер: окно слева и меню справа. Телефон: одна колонка и вкладки внизу. Граница — 900px. */
export const desktopQuery = window.matchMedia('(min-width:900px)');
export const isDesktop = (): boolean => desktopQuery.matches;

export const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
export const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');

export const rand = (a: number, b: number): number => a + Math.random() * (b - a);
export const pick = <T>(a: readonly T[]): T => a[Math.floor(Math.random() * a.length)];

/** Случайный индекс, не равный предыдущему: чтобы фраза или звук не повторялись подряд. */
export function pickOther(len: number, prev: number): number {
  if (len < 2) return 0;
  let i: number;
  do { i = Math.floor(Math.random() * len); } while (i === prev);
  return i;
}
