/* Сохранение в браузере. Каждая сущность регистрирует свою часть,
   а на диск пишется один общий объект — формат совпадает со старыми версиями игры. */
import { SAVE_KEY } from '@/shared/config';

type Part = () => Record<string, unknown>;
const parts: Part[] = [];
let blocked = false;

function readRaw(): Record<string, unknown> | null {
  try {
    const o = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null');
    return o && typeof o === 'object' ? o : null;
  } catch { return null; }
}

/** Сохранение, прочитанное при запуске. Сущности берут из него свою часть. */
export const initialSave = readRaw();

export function registerSavePart(part: Part): void { parts.push(part); }

/** Полный снимок для файла и облака. */
export function snapshot(): Record<string, unknown> {
  const o: Record<string, unknown> = {};
  parts.forEach((p) => Object.assign(o, p()));
  o.savedAt = Date.now();
  return o;
}

let lastSavedAt = Number(initialSave?.savedAt) || 0;
export const savedAt = (): number => lastSavedAt;

export function save(): void {
  if (blocked) return;
  const o = snapshot();
  lastSavedAt = o.savedAt as number;
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(o)); } catch { /* память браузера недоступна */ }
}

export const isSaveBlocked = (): boolean => blocked;

/** Подменяет сохранение (из файла или облака) и перезапускает игру. */
export function replaceSave(o: unknown): void {
  blocked = true;
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(o)); } catch { /* ничего не поделать */ }
  location.reload();
}

/** Число из сохранения в допустимых пределах, иначе null. */
export function num(v: unknown, lo: number, hi: number): number | null {
  const n = Number(v);
  return v !== null && v !== undefined && isFinite(n) ? Math.min(hi, Math.max(lo, n)) : null;
}
