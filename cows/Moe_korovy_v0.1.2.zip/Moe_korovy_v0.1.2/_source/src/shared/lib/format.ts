/* Числа и склонение по-русски. */

export function cows(n: number): string {
  const a = n % 100, b = n % 10;
  if (a > 10 && a < 15) return 'коров';
  if (b === 1) return 'корова';
  if (b >= 2 && b <= 4) return 'коровы';
  return 'коров';
}

export function ru(x: number, d = 0): string {
  return x.toLocaleString('ru-RU', { minimumFractionDigits: d, maximumFractionDigits: d });
}

const BIG: [number, string][] = [[1e12, 'трлн'], [1e9, 'млрд'], [1e6, 'млн']];
const UNITS: [number, string][] = [[1e12, 'трлн'], [1e9, 'млрд'], [1e6, 'млн'], [1e3, 'тыс']];

/** 1 234 · 5,67 млн · 1,23 ×10^15 */
export function fmtBig(n: number): string {
  if (!isFinite(n)) return '∞';
  if (n >= 1e15) return n.toExponential(2).replace('.', ',').replace('e+', ' ×10^');
  for (const [lim, word] of BIG) {
    if (n >= lim) return (Math.round(n / lim * 100) / 100).toLocaleString('ru-RU', { maximumFractionDigits: 2 }) + ' ' + word;
  }
  return Math.floor(n).toLocaleString('ru-RU');
}

/** Скорость: 0,25 · 12,5 · 340 · 1 200 */
export function fmtRate(x: number): string {
  if (!isFinite(x)) return '∞';
  if (x >= 1e6) return fmtBig(x);
  if (x >= 1000) return Math.round(x).toLocaleString('ru-RU');
  const d = x >= 100 ? 0 : (x >= 10 ? 1 : 2), p = Math.pow(10, d);
  return (Math.round(x * p) / p).toLocaleString('ru-RU', { maximumFractionDigits: d });
}

/** Литры: до сотни с одной цифрой после запятой. */
export function fmtMilk(v: number): string {
  if (!isFinite(v)) return '∞';
  if (v < 100) return ru(Math.floor(v * 10) / 10, 1);
  return fmtBig(v);
}

export function cpsWord(x: number): string {
  if (x >= 1e6) return 'коров';
  if (Math.abs(x - Math.round(x)) > 1e-9) return 'коровы';
  return cows(Math.round(x));
}

export function mmss(ms: number): string {
  let s = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(s / 60);
  s %= 60;
  return m + ':' + (s < 10 ? '0' : '') + s;
}

function withUnits(n: number, digits: (v: number) => number): string {
  for (const [lim, word] of UNITS) {
    if (n >= lim) { const v = n / lim; return v.toLocaleString('ru-RU', { maximumFractionDigits: digits(v) }) + ' ' + word; }
  }
  return String(Math.floor(n));
}

/** Для кнопок ×10/×25/×100: 9 999 · 12,5 тыс · 1,25 млн. */
export function fmtShort(n: number): string {
  if (!isFinite(n)) return '∞';
  if (n < 1e4) return Math.floor(n).toLocaleString('ru-RU');
  if (n >= 1e15) return n.toExponential(1).replace('.', ',').replace('e+', 'e');
  return withUnits(n, (v) => (v < 10 ? 2 : v < 100 ? 1 : 0));
}

/** Количество с одной цифрой после запятой: 1,5 · 120 · 3,4 млн. */
export function fmtNum(x: number): string {
  if (!isFinite(x)) return '∞';
  if (x >= 1e6) return fmtBig(x);
  if (x >= 100) return Math.floor(x).toLocaleString('ru-RU');
  return (Math.floor(x * 10) / 10).toLocaleString('ru-RU', { maximumFractionDigits: 1 });
}

/** Самое короткое число — для угла ячейки: 950 · 12 тыс · 3,1 млн. */
export function fmtTiny(n: number): string {
  if (!isFinite(n)) return '∞';
  if (n < 1000) return n < 10 && n % 1 ? (Math.floor(n * 10) / 10).toLocaleString('ru-RU') : Math.floor(n).toLocaleString('ru-RU');
  if (n >= 1e15) return n.toExponential(1).replace('.', ',').replace('e+', 'e');
  return withUnits(n, (v) => (v < 10 ? 1 : 0));
}

export const fmtPercent = (mult: number): string => '+' + fmtRate((mult - 1) * 100) + '%';
