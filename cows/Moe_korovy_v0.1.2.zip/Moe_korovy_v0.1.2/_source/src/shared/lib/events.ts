/* Простые события и наблюдаемое состояние: слои общаются через них, а не вызывая друг друга напрямую. */

type Listener<T> = (v: T) => void;

export interface Emitter<E extends Record<string, unknown>> {
  on<K extends keyof E>(name: K, fn: Listener<E[K]>): () => void;
  emit<K extends keyof E>(name: K, v: E[K]): void;
}

export function createEmitter<E extends Record<string, unknown>>(): Emitter<E> {
  const map = new Map<keyof E, Set<Listener<never>>>();
  return {
    on(name, fn) {
      if (!map.has(name)) map.set(name, new Set());
      map.get(name)!.add(fn as Listener<never>);
      return () => { map.get(name)!.delete(fn as Listener<never>); };
    },
    emit(name, v) {
      map.get(name)?.forEach((fn) => (fn as Listener<typeof v>)(v));
    },
  };
}

/** Хранилище значения с подпиской: get, set (частично) и уведомление подписчиков. */
export interface Store<S extends object> {
  get(): Readonly<S>;
  set(patch: Partial<S>): void;
  subscribe(fn: (s: Readonly<S>, prev: Readonly<S>) => void): () => void;
}

export function createStore<S extends object>(initial: S): Store<S> {
  let state = { ...initial };
  const subs = new Set<(s: S, p: S) => void>();
  return {
    get: () => state,
    set(patch) {
      const prev = state;
      state = { ...state, ...patch };
      subs.forEach((fn) => fn(state, prev));
    },
    subscribe(fn) { subs.add(fn); return () => { subs.delete(fn); }; },
  };
}

/** Общие тики интерфейса: frame — 10 раз в секунду, changed — сразу после действия игрока. */
export const ticker = createEmitter<{ frame: void; changed: void }>();

/** Обновлять компонент на каждом тике, но только пока он виден на экране. */
export function refreshWhileVisible(el: HTMLElement, refresh: () => void): void {
  const run = () => { if (el.offsetParent !== null || getComputedStyle(el).position === 'fixed') refresh(); };
  ticker.on('frame', run);
  ticker.on('changed', run);
}
