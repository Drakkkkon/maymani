/* Google Диск: один JSON-файл в скрытой папке приложения (доступ drive.appdata).
   Приложение видит только свой файл, остальные файлы Диска ему недоступны. */

interface TokenResponse { access_token?: string; expires_in?: number | string; error?: string }
interface TokenClient { requestAccessToken(o?: { prompt?: string }): void }
declare global {
  interface Window {
    google?: { accounts?: { oauth2?: { initTokenClient(cfg: { client_id: string; scope: string; callback: (r: TokenResponse) => void }): TokenClient } } };
  }
}

const SCOPE = 'https://www.googleapis.com/auth/drive.appdata';
const FILES = 'https://www.googleapis.com/drive/v3/files';
const UPLOAD = 'https://www.googleapis.com/upload/drive/v3/files';

export function createDriveFile(clientId: string, fileName: string) {
  let token: string | null = null, expires = 0, fileId: string | null = null, client: TokenClient | null = null;

  const connected = (): boolean => !!token && Date.now() < expires;

  function loadScript(): Promise<void> {
    if (window.google?.accounts?.oauth2) return Promise.resolve();
    return new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = 'https://accounts.google.com/gsi/client'; s.async = true;
      s.onload = () => res(); s.onerror = () => rej(new Error('Нет связи с Google'));
      document.head.appendChild(s);
    });
  }

  function api(url: string, opt: RequestInit = {}): Promise<Response> {
    const headers = new Headers(opt.headers);
    headers.set('Authorization', 'Bearer ' + token);
    return fetch(url, { ...opt, headers }).then((r) => {
      if (r.status === 401) { token = null; throw new Error('auth'); }
      if (!r.ok) throw new Error('http ' + r.status);
      return r;
    });
  }

  async function find(): Promise<string | null> {
    const q = encodeURIComponent("name='" + fileName + "'");
    const j = await api(FILES + '?spaces=appDataFolder&fields=files(id)&q=' + q).then((r) => r.json()) as { files?: { id: string }[] };
    fileId = j.files && j.files[0] ? j.files[0].id : null;
    return fileId;
  }

  return {
    connected,
    /** Вход Google; при успехе вызывается onReady. */
    async connect(onReady: () => void): Promise<void> {
      await loadScript();
      const oauth = window.google?.accounts?.oauth2;
      if (!oauth) throw new Error('Ошибка входа');
      client = client || oauth.initTokenClient({
        client_id: clientId,
        scope: SCOPE,
        callback: (r) => {
          if (!r || r.error || !r.access_token) return;
          token = r.access_token;
          expires = Date.now() + ((Number(r.expires_in) || 3600) - 60) * 1000;
          onReady();
        },
      });
      client.requestAccessToken({ prompt: '' });
    },
    /** Содержимое файла или null, если его ещё нет. */
    async read<T>(): Promise<T | null> {
      const id = await find();
      if (!id) return null;
      return api(FILES + '/' + id + '?alt=media').then((r) => r.json() as Promise<T>);
    },
    async write(data: unknown): Promise<void> {
      const body = JSON.stringify(data);
      if (!fileId) await find();
      if (fileId) {
        await api(UPLOAD + '/' + fileId + '?uploadType=media', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body });
        return;
      }
      const b = 'korovy' + Date.now();
      const multipart = '--' + b + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' +
        JSON.stringify({ name: fileName, parents: ['appDataFolder'] }) + '\r\n--' + b + '\r\nContent-Type: application/json\r\n\r\n' + body + '\r\n--' + b + '--';
      const j = await api(UPLOAD + '?uploadType=multipart&fields=id',
        { method: 'POST', headers: { 'Content-Type': 'multipart/related; boundary=' + b }, body: multipart }).then((r) => r.json()) as { id: string };
      fileId = j.id;
    },
  };
}

export type DriveFile = ReturnType<typeof createDriveFile>;
