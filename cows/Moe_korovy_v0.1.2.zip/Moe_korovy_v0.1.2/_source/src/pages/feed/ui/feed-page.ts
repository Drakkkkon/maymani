/* Страница «Кормёжка»: поля, зерно, стога сена. */
import { h } from '@/shared/lib';
import { pageTitle, hint, note } from '@/shared/ui';
import { createResourceStats } from '@/widgets/resource-stats';
import { createUpgradeBoard } from '@/widgets/upgrade-board';

export function createFeedPage(): HTMLElement {
  return h('div', { class: 'page' },
    pageTitle('Кормёжка'),
    hint('Поля дают зерно. Из зерна складываются стога сена: каждый стог даёт +10% к коровам и молоку.'),
    createResourceStats('feed'),
    createUpgradeBoard('feed'),
    note('Улучшения покупаются за молоко, суперулучшения и стога — за зерно. Каждая звезда суперулучшения открывается уровнем своего улучшения.'));
}
