export { createFeedPage } from './ui/feed-page';
