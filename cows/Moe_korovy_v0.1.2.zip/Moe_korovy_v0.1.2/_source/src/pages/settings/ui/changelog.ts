/* Список изменений: поле с прокруткой, версии идут от первой к последней. */
import { h } from '@/shared/lib';
import { CHANGELOG } from '../config/changelog';
import './changelog.css';

export function createChangelog(): HTMLElement {
  return h('div', { class: 'changelog', tabindex: 0, role: 'region', 'aria-label': 'Список изменений по версиям' },
    ...CHANGELOG.map((r) => h('section', { class: 'cl-ver' },
      h('h3', {}, h('b', { text: r.v }), ' ', r.title),
      r.date ? h('p', { class: 'cl-date', text: r.date }) : null,
      h('ul', {}, ...r.items.map((t) => h('li', { text: t }))))));
}
