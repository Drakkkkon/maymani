/* Страница «Настройки»: громкость, окно, оформление, сохранение, список изменений. */
import { h } from '@/shared/lib';
import { APP_VERSION } from '@/shared/config';
import { createCard, createNavRow, hint, footnote } from '@/shared/ui';
import { settings } from '@/entities/player';
import { createVolumeControls } from '@/features/adjust-volume';
import { createHerdSizeControl } from '@/features/set-herd-size';
import { createNightSwitch } from '@/features/toggle-theme';
import { skinName } from '@/features/select-skin';
import { createSaveFileButtons } from '@/features/save-to-file';
import { createCloudSync } from '@/features/cloud-sync';
import { createChangelog } from './changelog';

export function createSettingsPage(openThemes: () => void): HTMLElement {
  const themes = createNavRow('Темы оформления', openThemes);
  const syncSkin = () => themes.setValue(skinName(settings.get().skin));
  settings.subscribe((s, p) => { if (s.skin !== p.skin) syncSkin(); });
  syncSkin();

  return h('div', { class: 'page narrow' },
    createCard('Громкость', ...createVolumeControls()),
    createCard('Окно', createHerdSizeControl()),
    createCard('Оформление', createNightSwitch(), themes.el),
    createCard('Сохранение',
      hint('Прогресс сам сохраняется в этом браузере. Чтобы перенести его на другое устройство — скачайте файл сохранения (его можно положить на Google Диск) или подключите Google Диск для синхронизации.'),
      createSaveFileButtons(),
      createCloudSync()),
    createCard('Что нового', createChangelog()),
    footnote('Мое_коровы · версия ' + APP_VERSION));
}
