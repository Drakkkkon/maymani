/* Карточка «Клик по корове»: сколько осталось до следующего бонуса +10%. */
import { h, setText, mmss, refreshWhileVisible } from '@/shared/lib';
import { createProgressBar } from '@/shared/ui';
import { clickCooldownLeft, CLICK_COOLDOWN } from '@/entities/farm';
import './click-bonus.css';

export function createClickBonus(): HTMLElement {
  const note = h('span', { class: 'click-note' });
  const bar = createProgressBar('clickbar');
  const el = h('div', { class: 'click-card' },
    h('div', { class: 'click-top' }, h('h2', { text: 'Клик по корове' }), note),
    h('p', { class: 'click-sub', text: '+10% молока за клик. Перезарядка — 5 минут.' }),
    bar.el);
  const refresh = () => {
    const left = clickCooldownLeft(), ready = left <= 0;
    bar.set(ready ? 1 : 1 - left / CLICK_COOLDOWN);
    setText(note, ready ? 'Готово' : mmss(left));
    el.classList.toggle('ready', ready);
  };
  refreshWhileVisible(el, refresh);
  refresh();
  return el;
}
