/* Игра+: бонус, прогресс к сбросу (суперулучшения и инопланетное молоко), кнопка сброса и счёт пришельцев. */
import { h, setText, refreshWhileVisible } from '@/shared/lib';
import { createCard, createProgressBar, hint, note, alienMilkIcon } from '@/shared/ui';
import { progress, SUPERS, supersDone, alienNeed } from '@/entities/farm';
import { createPrestigeButton } from '@/features/prestige-reset';
import './game-plus-panel.css';

function progressRow(icon?: HTMLElement) {
  const bar = createProgressBar();
  const text = h('span');
  const el = h('div', { class: 'gp-progress' }, bar.el, h('p', {}, icon, text));
  return {
    el,
    set(frac: number, label: string, done: boolean): void { bar.set(frac); setText(text, label); el.classList.toggle('done', done); },
  };
}

export function createGamePlus(onReset: () => void): HTMLElement[] {
  const bonus = h('b');
  const supers = progressRow(), alien = progressRow(alienMilkIcon());
  const button = createPrestigeButton(onReset);
  const resetNote = note('');
  const alienMilk = h('b'), alienCows = h('b');

  const main = createCard('Игра+',
    h('p', { class: 'big-bonus' }, 'Бонус к приросту: ', bonus),
    hint('Каждый сброс даёт +100% ко всему приросту навсегда. Для сброса нужно прокачать все суперулучшения до 5★ и добыть инопланетное молоко — с каждой новой Игрой+ его нужно больше.'),
    supers.el, alien.el, button.el, resetNote);
  const visitor = createCard('Инопланетная корова',
    hint('Изредка прилетает в окно в зелёном луче и грозно мычит. Успеете кликнуть — сразу +5 инопланетного молока. Пропустите — она улетит и оставит только 1.'),
    h('p', { class: 'alien-val' }, alienMilkIcon(), alienMilk, ' инопланетного молока'),
    h('p', { class: 'alien-val' }, h('span', { class: 'emo', 'aria-hidden': 'true', text: '🛸' }), alienCows, ' поймано инопланетных коров'));

  const refresh = () => {
    const n = supersDone(), N = SUPERS.length, need = alienNeed(), have = progress.alienMilk;
    setText(bonus, '+' + progress.prestige * 100 + '%');
    supers.set(n / N, 'Суперулучшения на 5★: ' + n + ' из ' + N, n === N);
    alien.set(have / need, 'Инопланетное молоко: ' + Math.min(have, need).toLocaleString('ru-RU') + ' из ' + need, have >= need);
    button.refresh();
    setText(resetNote, n === N && have >= need
      ? 'Сброс обнулит коров, молоко, полена, зерно, все уровни и звёзды и заберёт ' + need + ' инопланетного молока. Бонус станет +' + (progress.prestige + 1) * 100 + '%.'
      : 'Нужно: все ' + N + ' суперулучшений на 5★ и ' + need + ' инопланетного молока.');
    setText(alienMilk, progress.alienMilk.toLocaleString('ru-RU'));
    setText(alienCows, progress.alienCows.toLocaleString('ru-RU'));
  };
  refreshWhileVisible(main, refresh);
  refresh();
  return [main, visitor];
}
