/* Страница «Игра+». После сброса игра возвращает игрока на главную. */
import { h } from '@/shared/lib';
import { createGamePlus } from './game-plus-panel';

export function createGamePlusPage(onReset: () => void): HTMLElement {
  return h('div', { class: 'page narrow' }, ...createGamePlus(onReset));
}
