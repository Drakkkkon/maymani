/* Страница «Домики»: топоры, полена, загоны. */
import { h } from '@/shared/lib';
import { pageTitle, hint, note } from '@/shared/ui';
import { createResourceStats } from '@/widgets/resource-stats';
import { createUpgradeBoard } from '@/widgets/upgrade-board';

export function createHousesPage(): HTMLElement {
  return h('div', { class: 'page' },
    pageTitle('Домики'),
    hint('Топоры рубят деревья и приносят полена. Из полен строятся загоны: каждый загон даёт +10% к коровам и молоку.'),
    createResourceStats('house'),
    createUpgradeBoard('house'),
    note('Улучшения покупаются за молоко, суперулучшения и загоны — за полена. Каждая звезда суперулучшения открывается уровнем своего улучшения.'));
}
