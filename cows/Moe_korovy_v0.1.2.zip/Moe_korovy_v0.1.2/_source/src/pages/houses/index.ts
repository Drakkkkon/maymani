export { createHousesPage } from './ui/houses-page';
