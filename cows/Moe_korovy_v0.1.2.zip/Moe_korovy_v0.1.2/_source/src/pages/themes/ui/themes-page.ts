/* Страница «Темы оформления» (открывается из Настроек). */
import { h } from '@/shared/lib';
import { createBackButton } from '@/shared/ui';
import { createSkinPicker } from '@/features/select-skin';
import './themes-page.css';

export function createThemesPage(back: () => void): HTMLElement {
  return h('div', { class: 'page narrow' },
    h('div', { class: 'sub-head' }, createBackButton('Настройки', back), h('h2', { class: 'sub-title', text: 'Темы оформления' })),
    createSkinPicker());
}
