export { createThemesPage } from './ui/themes-page';
