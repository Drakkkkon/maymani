/* Фоны окна. Картинки и видео лежат в public. */

export type BgId = 'mountains' | 'city' | 'night' | 'florence';
export type Meadow = [x0: number, y0: number, x1: number, y1: number];

export interface Background {
  id: BgId;
  name: string;
  src: string;            // картинка (у видео — заставка до загрузки)
  video?: string;         // живой фон: играет без звука
  w: number; h: number;   // размер картинки или видео
  fx: number; fy: number; // какую часть держать в кадре при обрезке (0 — левый/верхний край, 1 — правый/нижний)
  cowScale: number;       // множитель размера коров
  meadows: Meadow[];      // луга в долях картинки (по копытам)
}

export const BACKGROUNDS: Background[] = [
  { id: 'mountains', name: 'Горы', src: 'mountains.jpg', video: 'japan.mp4', w: 720, h: 1280, fx: 0.5, fy: 0.72, cowScale: 1,
    meadows: [[0.48, 0.648, 0.80, 0.70]] },
  { id: 'city', name: 'Город', src: 'bg-city.jpg', w: 1438, h: 2576, fx: 0.5, fy: 0.9, cowScale: 1,
    meadows: [[0.07, 0.875, 0.45, 0.955], [0.56, 0.885, 0.93, 0.962]] },
  { id: 'night', name: 'Звёздная ночь', src: 'bg-night.jpg', w: 1438, h: 2576, fx: 0.5, fy: 0.88, cowScale: 1,
    meadows: [[0.06, 0.845, 0.6, 0.965]] },
  { id: 'florence', name: 'Флоренция', src: 'bg-florence.jpg', w: 1438, h: 2576, fx: 0.5, fy: 0.88, cowScale: 1,
    meadows: [[0.05, 0.80, 0.55, 0.945], [0.62, 0.865, 0.95, 0.955]] },
];

export const backgroundById = (id: string): Background => BACKGROUNDS.find((b) => b.id === id) || BACKGROUNDS[0];
