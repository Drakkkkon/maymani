/* Как вписать фон в окно: «обложка», но обрезка не сильнее, чем до 45% картинки.
   Если окно слишком вытянуто — картинка уменьшается, а по краям видна её размытая копия. */
import type { Background } from '../config/catalog';

const MIN_VISIBLE = 0.45;

export interface Fit { iw: number; ih: number; left: number; top: number; letterbox: boolean }

export function fitBackground(bg: Background, pw: number, ph: number): Fit {
  const cover = Math.max(pw / bg.w, ph / bg.h), contain = Math.min(pw / bg.w, ph / bg.h);
  const lim = Math.min(ph / (MIN_VISIBLE * bg.h), pw / (MIN_VISIBLE * bg.w));
  let s = Math.min(cover, Math.max(contain, lim));
  if (s > cover * 0.93) s = cover; // полоски по краям тоньше нескольких процентов не нужны
  const iw = bg.w * s, ih = bg.h * s;
  return {
    iw, ih,
    left: iw > pw ? (pw - iw) * bg.fx : (pw - iw) / 2,
    top: ih > ph ? (ph - ih) * bg.fy : (ph - ih) / 2,
    letterbox: iw < pw - 1 || ih < ph - 1,
  };
}
