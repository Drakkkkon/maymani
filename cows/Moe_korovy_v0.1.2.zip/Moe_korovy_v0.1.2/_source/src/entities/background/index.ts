export { BACKGROUNDS, backgroundById, type Background, type Meadow, type BgId } from './config/catalog';
export { fitBackground, type Fit } from './lib/fit';
