/* Подписи цен по типу ресурса. */
import { fmtBig, cows } from '@/shared/lib';
import type { Res } from '../config/upgrades';

export function costText(r: Res, c: number): string {
  if (r === 'milk') return fmtBig(c) + ' л';
  if (r === 'logs') return fmtBig(c) + ' полен';
  if (r === 'grain') return fmtBig(c) + ' зерна';
  return fmtBig(c) + ' ' + (c >= 1e6 ? 'коров' : cows(Math.round(c)));
}

export const resIcon = (r: Res): string => (r === 'milk' ? ' л' : r === 'logs' ? ' 🪵' : r === 'grain' ? ' 🌽' : ' 🐄');
