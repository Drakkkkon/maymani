/* Правила игры, общие для всех улучшений. */
export const TIERS = [10, 25, 50, 100, 200]; // звёзды уровней и пороги звёзд суперулучшений
export const HT = [5, 10, 25, 50, 100];      // сколько уровней Домиков/Кормёжки нужно звёздам Фермы
export const LV_MAX = 200;
export const STAR_MAX = 5;
export const BULK = [10, 25, 100];           // покупка пачкой
export const CLICK_COOLDOWN = 5 * 60 * 1000; // клик по корове: +10% молока раз в 5 минут
export const CLICK_BONUS = 0.1;
export const ALIEN_CATCH = 5;                // поймали инопланетную корову
export const ALIEN_MISS = 1;                 // пропустили
export const ALIEN_NEED_STEP = 5;            // столько инопланетного молока нужно на каждую Игру+
