/* Формулы: скорости, цены, требования звёзд, прирост, награды, Игра+. */
import { TIERS, HT, LV_MAX, STAR_MAX, BULK, CLICK_COOLDOWN, CLICK_BONUS, ALIEN_CATCH, ALIEN_MISS, ALIEN_NEED_STEP } from '../config/rules';
import { LEVELS, SUPERS, type LevelDef, type SuperDef, type Res } from '../config/upgrades';
import { progress, rates, resetLevels } from './state';

const LV_NAME: Record<string, string> = {};
LEVELS.forEach((d) => { LV_NAME[d.key] = d.name; });

export const lvOf = (k: string): number => progress.lv[k];
export const starsOf = (id: string): number => progress.stars[id] || 0;

export function have(r: Res): number { return progress[r]; }
function spend(r: Res, v: number): void { progress[r] -= v; }

export const levelCost = (d: LevelDef): number => Math.min(1e300, Math.ceil(d.base * Math.pow(d.g, progress.lv[d.key] - d.start)));
export const starCost = (d: SuperDef): number => Math.min(1e300, d.cost * Math.pow(d.mul, starsOf(d.id)));

export interface Req { label: string; have: number; need: number }

/** Что нужно для следующей звезды суперулучшения. */
export function starRequirements(d: SuperDef): Req[] {
  const s = starsOf(d.id);
  if (s >= STAR_MAX) return [];
  const out: Req[] = d.link.map((k) => ({ label: '«' + LV_NAME[k] + '»', have: lvOf(k), need: TIERS[s] }));
  if (d.grp === 'farm') {
    /* звёзды Фермы ещё требуют Домики и Кормёжку */
    out.push(
      { label: 'Топоры', have: lvOf('axes'), need: HT[s] }, { label: 'Полена', have: lvOf('chop'), need: HT[s] },
      { label: 'Поля', have: lvOf('fields'), need: HT[s] }, { label: 'Обмолот', have: lvOf('thresh'), need: HT[s] },
    );
  }
  return out;
}
export const requirementsMet = (rs: Req[]): boolean => rs.every((q) => q.have >= q.need);

/** Пересчёт всех скоростей по уровням, звёздам и Игре+. */
export function recalc(): void {
  const m = { cm: 1, mm: 1, ax: 1, lg: 1, fd: 1, gr: 1 };
  let hayBoost = 1;
  const lv = progress.lv, P = 1 + progress.prestige;
  SUPERS.forEach((d) => {
    const s = starsOf(d.id);
    if (!s) return;
    (Object.keys(m) as (keyof typeof m)[]).forEach((k) => { const f = d[k]; if (f) m[k] *= Math.pow(f, s); });
    if (d.hay) hayBoost += d.hay * s;
  });
  rates.bonus = (1 + 0.1 * lv.pens) * (1 + 0.1 * hayBoost * lv.hay);
  rates.cps = lv.rate * (1 + 0.1 * (lv.herd - 1)) * (1 + 0.25 * (lv.breeding - 1)) * (1 + 0.5 * (lv.selection - 1)) * lv.legend * m.cm * P * rates.bonus;
  rates.perCow = 0.01 * lv.yield * (1 + 0.2 * (lv.quality - 1)) * (1 + 0.25 * (lv.milk1 - 1)) * (1 + 0.5 * (lv.milk2 - 1)) * lv.milk3 * m.mm * P * rates.bonus;
  rates.axes = lv.axes * (1 + 0.1 * (lv.lumber - 1)) * (1 + 0.25 * (lv.smithy - 1)) * (1 + 0.5 * (lv.guild - 1)) * lv.legaxe * m.ax;
  rates.lps = rates.axes * 0.5 * (1 + 0.2 * (lv.chop - 1)) * (1 + 0.25 * (lv.saw - 1)) * (1 + 0.5 * (lv.sledge - 1)) * (1 + 0.75 * (lv.river - 1)) * lv.sawmill * m.lg * P;
  rates.fields = lv.fields * (1 + 0.1 * (lv.plough - 1)) * (1 + 0.25 * (lv.seeds - 1)) * (1 + 0.5 * (lv.irrig - 1)) * lv.kolkhoz * m.fd;
  rates.gps = rates.fields * 0.5 * (1 + 0.2 * (lv.thresh - 1)) * (1 + 0.25 * (lv.sickle - 1)) * (1 + 0.5 * (lv.mill - 1)) * (1 + 0.75 * (lv.combine - 1)) * lv.elevator * m.gr * P;
  rates.hayEach = 10 * hayBoost;
  (['cps', 'perCow', 'axes', 'lps', 'fields', 'gps'] as const).forEach((k) => { if (!isFinite(rates[k])) rates[k] = 1e300; });
}

/* ---------- прирост: начисляется по часам, поэтому перед покупкой достаточно вызвать settle() ---------- */
let clock = Date.now();
/** Начисляет ресурсы за время с прошлого вызова. Молоко считается точно, с учётом роста коров. */
export function settle(): void {
  const now = Date.now(), dt = (now - clock) / 1000;
  clock = now;
  if (dt <= 0) return;
  progress.milk += rates.perCow * (progress.cows * dt + rates.cps * dt * dt / 2);
  progress.cows += rates.cps * dt;
  progress.logs += rates.lps * dt;
  progress.grain += rates.gps * dt;
  (['milk', 'cows', 'logs', 'grain'] as const).forEach((k) => { if (!isFinite(progress[k])) progress[k] = 1e300; });
}

/* ---------- покупки ---------- */
export interface BulkInfo { n: number; cost: number }
let bulkCache: Record<string, BulkInfo[]> = {};
/** Цена пачек ×10/×25/×100 (каждый следующий уровень дороже). У потолка — сколько осталось. */
export function bulkInfo(d: LevelDef): BulkInfo[] {
  const lv = progress.lv[d.key], ck = d.key + ':' + lv;
  if (bulkCache[ck]) return bulkCache[ck];
  const room = Math.max(0, LV_MAX - lv), top = Math.min(BULK[BULK.length - 1], room), cum = [0];
  let sum = 0;
  for (let k = 0; k < top; k++) {
    sum = Math.min(1e300, sum + Math.ceil(d.base * Math.pow(d.g, lv - d.start + k)));
    cum.push(sum);
  }
  return (bulkCache[ck] = BULK.map((n) => { const m = Math.min(n, room); return { n: m, cost: cum[m] }; }));
}

/** Покупает n уровней за cost. false — не хватило или уже максимум. */
export function buyLevels(d: LevelDef, n: number, cost: number): boolean {
  if (n <= 0 || progress.lv[d.key] >= LV_MAX || have(d.res) < cost) return false;
  spend(d.res, cost);
  progress.lv[d.key] = Math.min(LV_MAX, progress.lv[d.key] + n);
  recalc();
  return true;
}

/** Покупает следующую звезду. false — закрыта, не хватило или уже 5★. */
export function buyStar(d: SuperDef): boolean {
  if (starsOf(d.id) >= STAR_MAX || !requirementsMet(starRequirements(d))) return false;
  const c = starCost(d);
  if (have(d.res) < c) return false;
  spend(d.res, c);
  progress.stars[d.id] = starsOf(d.id) + 1;
  recalc();
  return true;
}

/* ---------- клик по корове ---------- */
export const clickCooldownLeft = (): number => progress.clickReadyAt - Date.now();
/** +10% молока, если перезарядка прошла. Возвращает прибавку или 0. */
export function claimClickBonus(): number {
  if (clickCooldownLeft() > 0 || progress.milk < 1) return 0;
  const gain = progress.milk * CLICK_BONUS;
  progress.milk += gain;
  progress.clickReadyAt = Date.now() + CLICK_COOLDOWN;
  return gain;
}

/* ---------- инопланетная корова ---------- */
export function alienCaught(): number { progress.alienMilk += ALIEN_CATCH; progress.alienCows += 1; return ALIEN_CATCH; }
export function alienMissed(): number { progress.alienMilk += ALIEN_MISS; return ALIEN_MISS; }

/* ---------- Игра+ ---------- */
export const supersDone = (): number => SUPERS.filter((d) => starsOf(d.id) >= STAR_MAX).length;
export const alienNeed = (): number => ALIEN_NEED_STEP * (progress.prestige + 1);
export const gamePlusReady = (): boolean => supersDone() === SUPERS.length && progress.alienMilk >= alienNeed();

/** Сброс: забирает инопланетное молоко, обнуляет ресурсы, уровни и звёзды, даёт +100% навсегда. */
export function prestigeReset(): void {
  progress.alienMilk = Math.max(0, progress.alienMilk - alienNeed());
  progress.prestige += 1;
  progress.cows = 0; progress.milk = 0; progress.logs = 0; progress.grain = 0;
  progress.clickReadyAt = 0;
  resetLevels();
  bulkCache = {};
  clock = Date.now();
  recalc();
}
