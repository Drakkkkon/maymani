/* Прогресс фермы: ресурсы, уровни, звёзды, Игра+. Загружается из сохранения и сохраняется вместе с ним. */
import { initialSave, registerSavePart, num } from '@/shared/lib';
import { LEVELS, SUPERS } from '../config/upgrades';
import { LV_MAX, STAR_MAX, CLICK_COOLDOWN } from '../config/rules';

export const LV_KEYS = LEVELS.filter((d) => d.start === 1).map((d) => d.key);
export const CNT_KEYS = LEVELS.filter((d) => d.start === 0).map((d) => d.key);
export const SUPER_KEYS = SUPERS.map((d) => d.id);

/** То, что сохраняется. */
export interface Progress {
  cows: number; milk: number; logs: number; grain: number;
  lv: Record<string, number>;
  stars: Record<string, number>;
  prestige: number;
  alienMilk: number;
  alienCows: number;
  clickReadyAt: number;
}

/** То, что считается из прогресса (скорости и бонусы). */
export interface Rates {
  cps: number; perCow: number;
  axes: number; lps: number;
  fields: number; gps: number;
  bonus: number; hayEach: number;
}

export const progress: Progress = {
  cows: 0, milk: 0, logs: 0, grain: 0, lv: {}, stars: {}, prestige: 0, alienMilk: 0, alienCows: 0, clickReadyAt: 0,
};
export const rates: Rates = { cps: 1, perCow: 0, axes: 1, lps: 0, fields: 1, gps: 0, bonus: 1, hayEach: 10 };

export function resetLevels(): void {
  LV_KEYS.forEach((k) => { progress.lv[k] = 1; });
  CNT_KEYS.forEach((k) => { progress.lv[k] = 0; });
  SUPER_KEYS.forEach((k) => { progress.stars[k] = 0; });
}
resetLevels();

/* ---------- загрузка: всё проверяется, битое значение просто пропускается ---------- */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function hydrate(o: any): void {
  if (!o) return;
  const res = (key: 'cows' | 'milk' | 'logs' | 'grain', src: string) => { const v = num(o[src], 0, 1e300); if (v !== null) progress[key] = v; };
  res('cows', 'total'); res('milk', 'milk'); res('logs', 'logs'); res('grain', 'grain');
  if (o.lv && typeof o.lv === 'object') {
    LV_KEYS.forEach((k) => {
      let src = o.lv[k];
      if (k === 'yield' && src === undefined) src = o.lv.milk; // очень старые сохранения
      const v = num(src, 1, LV_MAX); if (v !== null) progress.lv[k] = Math.floor(v);
    });
    CNT_KEYS.forEach((k) => { const v = num(o.lv[k], 0, LV_MAX); if (v !== null) progress.lv[k] = Math.floor(v); });
  }
  if (o.stars && typeof o.stars === 'object') {
    SUPER_KEYS.forEach((k) => { const v = num(o.stars[k], 0, STAR_MAX); if (v !== null) progress.stars[k] = Math.floor(v); });
  } else if (o.own && typeof o.own === 'object') {
    SUPER_KEYS.forEach((k) => { if (o.own[k]) progress.stars[k] = 1; }); // старые: купленное = 1 звезда
  }
  const p = num(o.prestige, 0, 1000); if (p !== null) progress.prestige = Math.floor(p);
  const am = num(o.alienMilk, 0, 1e15); if (am !== null) progress.alienMilk = Math.floor(am);
  const ac = num(o.alienCows, 0, 1e15); if (ac !== null) progress.alienCows = Math.floor(ac);
  const cr = num(o.clickReadyAt, 0, Date.now() + CLICK_COOLDOWN); if (cr !== null) progress.clickReadyAt = cr;
}
hydrate(initialSave);

/* имена полей в сохранении те же, что в старых версиях (коровы — total) */
registerSavePart(() => ({
  total: progress.cows, milk: progress.milk, logs: progress.logs, grain: progress.grain,
  lv: { ...progress.lv }, stars: { ...progress.stars },
  prestige: progress.prestige, alienMilk: progress.alienMilk, alienCows: progress.alienCows, clickReadyAt: progress.clickReadyAt,
}));
