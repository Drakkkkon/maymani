export { settings, type Settings, type Skin, type Theme } from './model/settings';
