/* Настройки игрока: тема, громкость, число коров, фон окна. Хранятся вместе с прогрессом. */
import { createStore, initialSave, registerSavePart, num } from '@/shared/lib';

export type Skin = 'main' | 'japan';
export type Theme = 'dark' | 'light' | null;

export interface Settings {
  theme: Theme;      // null — как в системе
  skin: Skin;
  sfx: number;       // громкость звуков, 0–100
  mus: number;       // громкость фона, 0–100
  cowCount: number;  // коров в окне, 0–50
  bg: string;        // id фона; неизвестный id окно заменит на первый фон
}

const initial: Settings = { theme: null, skin: 'main', sfx: 60, mus: 40, cowCount: 6, bg: 'mountains' };

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function hydrate(o: any): Settings {
  const s = { ...initial };
  if (!o) return s;
  if (o.theme === 'dark' || o.theme === 'light') s.theme = o.theme;
  if (o.skin === 'japan') s.skin = 'japan';
  const a = num(o.sfx, 0, 100); if (a !== null) s.sfx = a;
  const b = num(o.mus, 0, 100); if (b !== null) s.mus = b;
  const c = num(o.cowCount, 0, 50); if (c !== null) s.cowCount = Math.round(c);
  if (typeof o.bg === 'string' && o.bg.length < 40) s.bg = o.bg;
  return s;
}

export const settings = createStore<Settings>(hydrate(initialSave));
registerSavePart(() => ({ ...settings.get() }));
