/* Кнопка Игры+: сброс прогресса за +100% навсегда. Подтверждение — вторым нажатием в течение 4 секунд. */
import { h, setText, save, sound, ticker } from '@/shared/lib';
import { gamePlusReady, prestigeReset } from '@/entities/farm';
import './prestige-button.css';

export function createPrestigeButton(onDone: () => void) {
  let armed = false, timer = 0;
  const btn = h('button', { class: 'reset', type: 'button', disabled: true });
  const refresh = (): void => {
    const ready = gamePlusReady();
    btn.disabled = !ready;
    if (!ready) armed = false;
    setText(btn, armed ? 'Точно? Нажмите ещё раз' : 'Сбросить всё и получить +100%');
    btn.classList.toggle('armed', armed);
  };
  btn.addEventListener('click', () => {
    if (btn.disabled) return;
    clearTimeout(timer);
    if (!armed) {
      armed = true;
      refresh();
      timer = window.setTimeout(() => { armed = false; refresh(); }, 4000);
      return;
    }
    armed = false;
    prestigeReset();
    save();
    sound.special();
    ticker.emit('changed', undefined);
    onDone();
  });
  refresh();
  return { el: btn, refresh };
}
