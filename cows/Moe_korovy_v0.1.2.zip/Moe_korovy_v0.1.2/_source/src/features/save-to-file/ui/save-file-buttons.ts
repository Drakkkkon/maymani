/* Файл сохранения: скачать и загрузить обратно (например, через Google Диск вручную). */
import { h, snapshot, replaceSave } from '@/shared/lib';
import { createButton, buttonRow } from '@/shared/ui';

function download(): void {
  const data = JSON.stringify(snapshot(), null, 1);
  const d = new Date(), pad = (n: number) => (n < 10 ? '0' : '') + n;
  const name = 'moe-korovy-save-' + d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + '.json';
  try {
    const url = URL.createObjectURL(new Blob([data], { type: 'application/json' }));
    const a = h('a', { href: url, download: name });
    document.body.appendChild(a); a.click(); a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 2000);
  } catch { alert('Не удалось скачать файл.'); }
}

function upload(input: HTMLInputElement): void {
  const f = input.files && input.files[0];
  if (!f) return;
  const rd = new FileReader();
  rd.onload = () => {
    try {
      const o = JSON.parse(String(rd.result));
      if (!o || typeof o !== 'object' || !o.lv) throw new Error('bad');
      if (!confirm('Загрузить сохранение из файла? Текущий прогресс в этом браузере будет заменён.')) return;
      replaceSave(o);
    } catch { alert('Это не файл сохранения «Мое_коровы».'); }
  };
  rd.readAsText(f);
  input.value = '';
}

export function createSaveFileButtons(): HTMLElement {
  const input = h('input', { type: 'file', accept: '.json,application/json', hidden: true });
  input.addEventListener('change', () => upload(input));
  return buttonRow(createButton('Скачать файл сохранения', download), createButton('Загрузить из файла', () => input.click()), input);
}
