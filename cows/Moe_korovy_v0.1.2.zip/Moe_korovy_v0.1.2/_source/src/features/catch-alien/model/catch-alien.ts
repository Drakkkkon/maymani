/* Награда за инопланетную корову: поймал — +5, пропустил — она оставит только 1. */
import { save, sound, ticker } from '@/shared/lib';
import { alienCaught, alienMissed } from '@/entities/farm';

export function catchAlien(): number {
  sound.moo(true);
  const n = alienCaught();
  save();
  ticker.emit('changed', undefined);
  return n;
}

export function missAlien(): number {
  const n = alienMissed();
  save();
  ticker.emit('changed', undefined);
  return n;
}

/** Грозное мычание при появлении. */
export const alienRoar = (): void => sound.moo(true);
