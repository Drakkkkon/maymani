export { catchAlien, missAlien, alienRoar } from './model/catch-alien';
