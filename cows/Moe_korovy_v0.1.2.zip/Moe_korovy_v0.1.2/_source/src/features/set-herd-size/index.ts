export { createHerdSizeControl, MAX_COWS } from './ui/herd-size';
