/* Сколько коров в окне: 0–50. Только для красоты, на доход не влияет. */
import { sound } from '@/shared/lib';
import { createRangeField } from '@/shared/ui';
import { settings } from '@/entities/player';

export const MAX_COWS = 50;

export function createHerdSizeControl(): HTMLElement {
  return createRangeField({
    label: 'Коров на экране', min: 0, max: MAX_COWS, value: settings.get().cowCount,
    hint: 'Часть коров летает, часть пасётся на лугу, потом они меняются. На доход это не влияет.',
    onInput: (v) => settings.set({ cowCount: v }),
    onChange: () => sound.moo(),
  }).el;
}
