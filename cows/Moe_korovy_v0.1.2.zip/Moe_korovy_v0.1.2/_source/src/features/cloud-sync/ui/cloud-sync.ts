/* Синхронизация через Google Диск. Включается, когда в shared/config указан GOOGLE_CLIENT_ID.
   При подключении предлагает более новое облачное сохранение, потом отправляет прогресс каждые 2 минуты. */
import { h, snapshot, replaceSave, savedAt, isSaveBlocked } from '@/shared/lib';
import { GOOGLE_CLIENT_ID } from '@/shared/config';
import { createDriveFile } from '@/shared/api';
import { createButton, buttonRow, hint } from '@/shared/ui';

interface CloudSave { savedAt?: number; lv?: unknown }

export function createCloudSync(): HTMLElement {
  const drive = createDriveFile(GOOGLE_CLIENT_ID, 'moe-korovy-save.json');
  const state = h('span', { class: 'state', text: 'Не подключён' });
  const status = (t: string) => { state.textContent = t; };
  let timer = 0;

  const connectBtn = createButton('Подключить Google Диск', connect, { primary: true });
  const pushBtn = createButton('Сохранить в облако', () => { status('Сохраняю…'); push(); }, { disabled: true });
  const pullBtn = createButton('Загрузить из облака', () => pull(false), { disabled: true });
  const info = hint('');

  function sync(): void {
    const on = drive.connected();
    pushBtn.disabled = !on; pullBtn.disabled = !on;
    connectBtn.textContent = on ? 'Переподключить' : 'Подключить Google Диск';
  }
  function push(): Promise<void> {
    if (!drive.connected()) return Promise.resolve();
    return drive.write(snapshot()).then(
      () => status('Сохранено ' + new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })),
      () => { sync(); status(drive.connected() ? 'Ошибка сохранения' : 'Нужно переподключить'); },
    );
  }
  /** auto — при подключении: облако предлагается, только если оно новее. */
  function pull(auto: boolean): void {
    if (!drive.connected()) return;
    status('Проверяю облако…');
    drive.read<CloudSave>().then((o) => {
      if (!o) { status('В облаке пусто — сохраняю'); return push(); }
      const remote = Number(o.savedAt) || 0;
      if (o.lv && (!auto || remote > savedAt() + 3000)) {
        const when = remote ? new Date(remote).toLocaleString('ru-RU') : 'неизвестно';
        const msg = auto
          ? 'В облаке более новое сохранение (' + when + '). Загрузить его на это устройство?'
          : 'Загрузить сохранение из облака (' + when + ')? Прогресс на этом устройстве будет заменён.';
        if (confirm(msg)) { replaceSave(o); return; }
      }
      return push();
    }).catch(() => { sync(); status(drive.connected() ? 'Ошибка связи' : 'Нужно переподключить'); });
  }
  function connect(): void {
    drive.connect(() => {
      sync(); status('Подключено');
      pull(true);
      clearInterval(timer);
      timer = window.setInterval(() => {
        if (drive.connected()) push(); else { sync(); status('Нужно переподключить'); }
      }, 120000);
    }).catch((e: Error) => status(e.message || 'Ошибка входа'));
  }

  if (!GOOGLE_CLIENT_ID) {
    connectBtn.disabled = true;
    info.textContent = 'Синхронизация пока выключена: в игре не указан Client ID Google. Как его получить — в ИНСТРУКЦИЯ.txt. До этого пользуйтесь файлом сохранения.';
  } else if (location.protocol === 'file:') {
    connectBtn.disabled = true;
    info.textContent = 'Вход Google не работает, если игра открыта как файл с компьютера. Откройте игру с сайта (https://…).';
  } else {
    info.textContent = 'Сохранение хранится в скрытой папке приложения на вашем Google Диске. Игра видит только свой файл, остальные файлы Диска ей недоступны.';
  }
  window.addEventListener('pagehide', () => { if (drive.connected() && !isSaveBlocked()) push(); });

  return h('div', {},
    h('div', { class: 'ctl-row' }, h('span', { text: 'Google Диск' }), state),
    buttonRow(connectBtn, pushBtn, pullBtn),
    info);
}
