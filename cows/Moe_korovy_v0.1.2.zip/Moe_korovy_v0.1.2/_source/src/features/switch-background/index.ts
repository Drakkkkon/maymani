export { createBackgroundSwitcher } from './ui/background-switcher';
