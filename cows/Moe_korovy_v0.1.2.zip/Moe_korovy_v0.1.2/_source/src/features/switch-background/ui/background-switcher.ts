/* Стрелки на нижней планке рамки: листают фоны по кругу, точки показывают текущий. */
import { h } from '@/shared/lib';
import { icons } from '@/shared/ui';
import { BACKGROUNDS, backgroundById } from '@/entities/background';
import { settings } from '@/entities/player';
import './background-switcher.css';

function step(d: number): void {
  const i = BACKGROUNDS.indexOf(backgroundById(settings.get().bg));
  settings.set({ bg: BACKGROUNDS[(i + d + BACKGROUNDS.length) % BACKGROUNDS.length].id });
}

export function createBackgroundSwitcher(): HTMLElement {
  const dots = BACKGROUNDS.map(() => h('i'));
  const paint = () => {
    const cur = backgroundById(settings.get().bg);
    dots.forEach((d, i) => d.classList.toggle('on', BACKGROUNDS[i] === cur));
  };
  settings.subscribe((s, p) => { if (s.bg !== p.bg) paint(); });
  paint();
  return h('div', { class: 'wnav', role: 'group', 'aria-label': 'Фон окна' },
    h('button', { class: 'warrow', type: 'button', 'aria-label': 'Предыдущий фон', html: icons.chevronLeft, on: { click: () => step(-1) } }),
    h('span', { class: 'wdots', 'aria-hidden': 'true' }, ...dots),
    h('button', { class: 'warrow', type: 'button', 'aria-label': 'Следующий фон', html: icons.chevronRight, on: { click: () => step(1) } }));
}
