/* Громкость звуков и музыки с фоном страниц. Сами звуки подписаны на настройки (app/setup). */
import { sound } from '@/shared/lib';
import { createRangeField } from '@/shared/ui';
import { settings } from '@/entities/player';

export function createVolumeControls(): HTMLElement[] {
  const s = settings.get();
  return [
    createRangeField({
      label: 'Звук', min: 0, max: 100, value: s.sfx, suffix: '%',
      onInput: (v) => settings.set({ sfx: v }),
      onChange: () => sound.moo(),
    }).el,
    createRangeField({
      label: 'Музыка и фон', min: 0, max: 100, value: s.mus, suffix: '%',
      hint: 'У каждого окна своя мелодия: она меняется вместе с фоном окна. У каждой страницы свой фон: на Ферме — деревня, в Домиках — ветер в лесу и топоры, в Кормёжке — поле и трактор, в Игре+ — ветер, в Настройках — коровник. Звук включается после первого касания экрана.',
      onInput: (v) => settings.set({ mus: v }),
    }).el,
  ];
}
