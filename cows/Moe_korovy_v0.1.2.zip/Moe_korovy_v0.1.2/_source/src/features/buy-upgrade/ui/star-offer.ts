/* Покупка звезды суперулучшения: показывает, чего не хватает для следующей звезды. */
import { save, sound, ticker } from '@/shared/lib';
import {
  createUpgradeCard, starsOf, starCost, starRequirements, requirementsMet, buyStar, have, settle, costText,
  STAR_MAX, type SuperDef,
} from '@/entities/farm';

export function createStarOffer(d: SuperDef) {
  const card = createUpgradeCard({
    name: d.name, emoji: d.emoji, effect: d.fx, stars: STAR_MAX, withRequirements: true,
    onClick: () => {
      if (starsOf(d.id) >= STAR_MAX) return;
      settle();
      if (!buyStar(d)) { card.shake(); return; }
      card.bump();
      if (d.grp === 'house') sound.fall(); else sound.special();
      save();
      ticker.emit('changed', undefined);
    },
  });

  return {
    el: card.el,
    refresh(): void {
      const s = starsOf(d.id), full = s >= STAR_MAX, rs = starRequirements(d), open = requirementsMet(rs);
      const c = full ? 0 : starCost(d), money = have(d.res);
      card.update({
        level: s + '/5★',
        cost: full ? '5★ — максимум' : costText(d.res, c),
        progress: full ? 1 : money / c,
        can: !full && open && money >= c,
        owned: full,
        locked: !full && !open,
        starsOn: (i) => i < s,
      });
      card.requirements(
        full ? 'Все звёзды собраны'
          : open ? 'Звезда ' + (s + 1) + ' открыта'
            : 'Для ' + (s + 1) + '★: ' + rs.filter((q) => q.have < q.need).map((q) => q.label + ' ' + q.have + '/' + q.need).join(' · '),
        full || open);
    },
  };
}
