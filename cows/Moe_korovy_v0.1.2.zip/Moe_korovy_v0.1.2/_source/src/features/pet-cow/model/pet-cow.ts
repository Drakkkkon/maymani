/* Погладить корову: мычит, говорит фразу и раз в 5 минут даёт +10% молока. */
import { pickOther, save, sound, ticker } from '@/shared/lib';
import { claimClickBonus } from '@/entities/farm';

/* что говорят коровы: «Му!» и пять смешных фраз */
const PHRASES = ['Му!', 'Не трогай вымя без записи!', 'Я не толстая, это крылья пушистые!', 'Му-у… а где мой Wi-Fi на лугу?', 'Сам ты корова!', 'Молоко по подписке — 99 ₽ в месяц!'];
let last = -1;

export interface PetResult { phrase: string; milk: number }

export function petCow(): PetResult {
  sound.moo();
  last = pickOther(PHRASES.length, last);
  const milk = claimClickBonus();
  if (milk > 0) save();
  ticker.emit('changed', undefined);
  return { phrase: PHRASES[last], milk };
}
