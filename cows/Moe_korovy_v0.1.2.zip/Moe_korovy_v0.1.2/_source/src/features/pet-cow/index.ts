export { petCow, type PetResult } from './model/pet-cow';
