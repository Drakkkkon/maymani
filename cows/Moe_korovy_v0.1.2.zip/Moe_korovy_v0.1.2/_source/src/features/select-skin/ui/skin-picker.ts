/* Выбор темы оформления: папки с карточками тем. */
import { h } from '@/shared/lib';
import { createFolder } from '@/shared/ui';
import { settings, type Skin } from '@/entities/player';
import './skin-picker.css';

interface SkinInfo { id: Skin; folder: string; name: string; desc: string; swatches: string[] }

export const SKINS: SkinInfo[] = [
  { id: 'main', folder: 'Основная', name: 'Минимализм',
    desc: 'Белый лист, тонкие линии, шрифты IBM Plex. Мягкие звуки и спокойная музыка.',
    swatches: ['#ffffff', '#f5f7f9', '#e3e8ed', '#34404b', '#1c2630'] },
  { id: 'japan', folder: 'Эпохи', name: 'Старая Япония, XIX век',
    desc: 'Бумага васи, тушь и киноварная печать. Звучат кото, бамбуковая флейта, деревянные трещотки и храмовый колокол.',
    swatches: ['#f0e7d3', '#f6efdf', '#d9c5a0', '#b0342a', '#241b17'] },
];

export const skinName = (id: Skin): string => (id === 'japan' ? 'Старая Япония' : 'Минимализм');

export function createSkinPicker(): HTMLElement {
  const cards = SKINS.map((s) => {
    const card = h('button', { class: 'theme', type: 'button', role: 'radio', 'aria-checked': 'false', on: { click: () => settings.set({ skin: s.id }) } },
      h('span', { class: 'theme-top' }, h('span', { class: 'tname', text: s.name }), h('span', { class: 'ttag', text: 'Выбрана' })),
      h('span', { class: 'tdesc', text: s.desc }),
      h('span', { class: 'sw', 'aria-hidden': 'true' }, ...s.swatches.map((c) => h('i', { style: 'background:' + c }))));
    return { s, card };
  });
  const sync = () => cards.forEach(({ s, card }) => card.setAttribute('aria-checked', settings.get().skin === s.id ? 'true' : 'false'));
  settings.subscribe((s, p) => { if (s.skin !== p.skin) sync(); });
  sync();
  return h('div', { class: 'folders', role: 'radiogroup', 'aria-label': 'Тема оформления' },
    ...cards.map(({ s, card }) => createFolder(s.folder, '1 тема', card)));
}
