/* Ночная тема: переключатель. Пока игрок не выбрал сам, тема как в системе. */
import { darkQuery } from '@/shared/lib';
import { createSwitchRow } from '@/shared/ui';
import { settings } from '@/entities/player';

export const isDark = (): boolean => {
  const t = settings.get().theme;
  return t ? t === 'dark' : darkQuery.matches;
};

export function createNightSwitch(): HTMLElement {
  const row = createSwitchRow('Ночная тема', () => settings.set({ theme: isDark() ? 'light' : 'dark' }));
  const sync = () => row.set(isDark());
  settings.subscribe((s, p) => { if (s.theme !== p.theme) sync(); });
  darkQuery.addEventListener('change', sync);
  sync();
  return row.el;
}
