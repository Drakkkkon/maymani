/* Звук: у каждого фона окна своя мелодия; включается по первому касанию (так требуют браузеры), громкость — из настроек, пауза в фоне. */
import { sound } from '@/shared/lib';
import { settings } from '@/entities/player';
import { backgroundById } from '@/entities/background';

export function initSound(): void {
  ['pointerdown', 'touchend', 'click', 'keydown'].forEach((ev) => document.addEventListener(ev, () => sound.unlock(), true));
  const apply = () => { const s = settings.get(); sound.setVolume('sfx', s.sfx); sound.setVolume('amb', s.mus); };
  settings.subscribe((s, p) => { if (s.sfx !== p.sfx || s.mus !== p.mus) apply(); });
  apply();
  sound.setMusic(backgroundById(settings.get().bg).id);
  settings.subscribe((s, p) => { if (s.bg !== p.bg) sound.setMusic(backgroundById(s.bg).id); });
  document.addEventListener('visibilitychange', () => sound.setVisible(!document.hidden));
}
