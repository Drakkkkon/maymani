/* Игровой цикл: 10 раз в секунду начисляем ресурсы и обновляем экран, раз в 5 секунд сохраняем.
   Изменения настроек сохраняются сразу. */
import { save, ticker } from '@/shared/lib';
import { settle, recalc } from '@/entities/farm';
import { settings } from '@/entities/player';

export function startGameLoop(): void {
  recalc();
  const frame = () => { settle(); ticker.emit('frame', undefined); };
  window.setInterval(frame, 100);
  window.setInterval(save, 5000);
  settings.subscribe(save);
  window.addEventListener('pagehide', save);
  document.addEventListener('visibilitychange', () => { if (document.hidden) save(); else frame(); });
  frame();
}
