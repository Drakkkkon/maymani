/* Тема и оформление: атрибуты data-theme и data-skin на <html> следуют за настройками. */
import { settings } from '@/entities/player';

export function initTheme(): void {
  const root = document.documentElement;
  const apply = () => {
    const s = settings.get();
    if (s.skin === 'japan') root.setAttribute('data-skin', 'japan'); else root.removeAttribute('data-skin');
    if (s.theme) root.setAttribute('data-theme', s.theme); else root.removeAttribute('data-theme');
  };
  settings.subscribe(apply);
  apply();
}
