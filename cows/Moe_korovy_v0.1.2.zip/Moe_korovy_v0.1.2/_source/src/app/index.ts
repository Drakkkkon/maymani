/* Точка входа: стили, провайдеры, раскладка страниц и запуск игры. */
import './styles/tokens.css';
import './styles/base.css';
import { h } from '@/shared/lib';
import { createFarmWindow } from '@/widgets/farm-window';
import { createTabBar } from '@/widgets/tab-bar';
import { createStorage } from '@/widgets/storage';
import { createFarmPage } from '@/pages/farm';
import { createHousesPage } from '@/pages/houses';
import { createFeedPage } from '@/pages/feed';
import { createGamePlusPage } from '@/pages/game-plus';
import { createSettingsPage } from '@/pages/settings';
import { createThemesPage } from '@/pages/themes';
import { initTheme } from './setup/theme';
import { initSound } from './setup/sound';
import { startGameLoop } from './setup/game-loop';
import { createRouter, ROUTES } from './router';

initTheme();
initSound();

const go = (id: string) => router.go(id);
const pages = {
  farm: createFarmPage(),
  houses: createHousesPage(),
  feed: createFeedPage(),
  gameplus: createGamePlusPage(() => go(router.home())),
  prefs: createSettingsPage(() => go('themes')),
  themes: createThemesPage(() => go('prefs')),
};

const tabs = createTabBar(
  ROUTES.filter((r) => r.tab).map((r) => ({ id: r.id, label: r.tab!.label, icon: r.tab!.icon, mobileOnly: r.tab!.mobileOnly, also: ROUTES.filter((c) => c.parent === r.id).map((c) => c.id) })),
  go);
const farmWindow = createFarmWindow({ bottomBar: () => tabs.el.offsetHeight });
const layout = h('div', { class: 'layout' },
  farmWindow.el,
  h('div', { class: 'side' }, h('main', { class: 'pages' }, ...Object.values(pages)), tabs.el));

const router = createRouter({
  pages,
  onShow: (id) => {
    layout.classList.toggle('v-window', id === 'window');
    tabs.setCurrent(id);
    farmWindow.relayout();
  },
});

document.getElementById('app')!.replaceWith(layout, ...createStorage());
router.start();
farmWindow.start();
startGameLoop();
