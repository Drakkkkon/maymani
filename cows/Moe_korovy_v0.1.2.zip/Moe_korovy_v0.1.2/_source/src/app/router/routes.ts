/* Страницы игры: адрес (#farm), фон звука, вкладка. Адреса совпадают со старыми версиями. */
import { icons } from '@/shared/ui';

export type RouteId = 'window' | 'farm' | 'houses' | 'feed' | 'gameplus' | 'prefs' | 'themes';

export interface Route {
  id: RouteId;
  ambience: string;          // какой фон звучит (shared/config/sound-bank)
  tab?: { label: string; icon: string; mobileOnly?: boolean };
  parent?: RouteId;          // вложенная страница подсвечивает вкладку родителя
}

export const ROUTES: Route[] = [
  { id: 'window', ambience: 'window', tab: { label: 'Окно', icon: icons.window, mobileOnly: true } },
  { id: 'farm', ambience: 'farm', tab: { label: 'Ферма', icon: icons.milk } },
  { id: 'houses', ambience: 'houses', tab: { label: 'Домики', icon: icons.house } },
  { id: 'feed', ambience: 'feed', tab: { label: 'Кормёжка', icon: icons.wheat } },
  { id: 'gameplus', ambience: 'gameplus', tab: { label: 'Игра+', icon: icons.plus } },
  { id: 'prefs', ambience: 'settings', tab: { label: 'Настройки', icon: icons.sliders } },
  { id: 'themes', ambience: 'settings', parent: 'prefs' },
];
