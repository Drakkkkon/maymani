/* Переходы между страницами по адресу (#farm). На компьютере окно видно всегда, поэтому #window ведёт на Ферму. */
import { isDesktop, desktopQuery, sound } from '@/shared/lib';
import { ROUTES, type RouteId } from './routes';

export interface RouterOptions {
  pages: Partial<Record<RouteId, HTMLElement>>;
  onShow: (id: RouteId) => void;
}

export function createRouter(o: RouterOptions) {
  let current: RouteId = 'farm';
  const valid = (id: string): id is RouteId => ROUTES.some((r) => r.id === id);
  const home = (): RouteId => (isDesktop() ? 'farm' : 'window');

  function show(name: string): void {
    let id: RouteId = valid(name) ? name : home();
    if (id === 'window' && isDesktop()) id = 'farm';
    current = id;
    (Object.keys(o.pages) as RouteId[]).forEach((k) => { o.pages[k]!.hidden = k !== id; });
    sound.setAmbience(ROUTES.find((r) => r.id === id)!.ambience);
    o.onShow(id);
  }
  function go(name: string): void {
    show(name);
    try { if (location.hash !== '#' + name) location.hash = name; } catch { /* без истории */ }
    if (!isDesktop() || name !== 'window') window.scrollTo(0, 0);
  }

  window.addEventListener('hashchange', () => {
    const h = location.hash.replace('#', '');
    if (h && h !== current) show(h);
  });
  desktopQuery.addEventListener('change', () => show(current));

  return { show, go, home, start: () => show(location.hash.replace('#', '') || home()) };
}
