import { defineConfig } from 'steiger';
import fsd from '@feature-sliced/steiger-plugin';

/* Проверка архитектуры Feature-Sliced Design: npm run lint:fsd */
export default defineConfig([
  ...fsd.configs.recommended,
  {
    /* Каждая фича — отдельное действие игрока (купить, погладить, сбросить, сохранить в облако).
       Пусть пока каждую использует одна страница: держим их отдельно, чтобы действие можно было
       переиспользовать (например, кнопку «Сохранить в облако» в меню паузы) и тестировать само по себе.
       entities/background на самом деле используют двое (фича switch-background и виджет окна),
       но после исключения features Steiger перестаёт видеть ссылку из фичи — поэтому она здесь же. */
    files: ['./src/features/**', './src/entities/background/**'],
    rules: { 'fsd/insignificant-slice': 'off' },
  },
]);
