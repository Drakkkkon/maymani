Исходники версии 0.1.3 (Vite + TypeScript).
Картинки, видео и звуки лежат в папке сайта уровнем выше (всё, кроме index.html и assets).
Чтобы собрать игру заново: скопируйте их в _source/public, затем npm install и npm run build.
Как устроен проект — в README.md.
