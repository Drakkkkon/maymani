/* Настройки окружения игры. */

/* Google Диск: чтобы включить синхронизацию, вставьте сюда свой Client ID (см. ИНСТРУКЦИЯ.txt).
   Пример: '1234567890-abc123.apps.googleusercontent.com' */
export const GOOGLE_CLIENT_ID = '';

export const SAVE_KEY = 'moe-korovy';
export const APP_VERSION = '0.1.4 альфа';

export { SOUND_BANK, type SoundBank, type Clip } from './sound-bank';
