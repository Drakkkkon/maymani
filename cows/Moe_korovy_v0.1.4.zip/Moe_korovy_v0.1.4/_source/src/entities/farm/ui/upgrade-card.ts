/* Карточка улучшения: название, уровень, эффект, полоска «сколько накоплено», цена, звёзды,
   по желанию — строка требований и слот для дополнительных кнопок (×10/×25/×100).
   Одна и та же карточка для обычных улучшений, построек и суперулучшений. */
import { h, setText, replayClass } from '@/shared/lib';
import { createProgressBar, createStars } from '@/shared/ui';
import './upgrade-card.css';

export interface UpgradeCardOptions {
  name: string;
  emoji?: string;          // эмодзи перед названием
  effect: string;
  stars: number;           // сколько звёзд в ряду
  art?: boolean;           // картинка-фон под карточкой и кнопками ×N (одна на всех)
  withRequirements?: boolean;
  onClick: () => void;
}

export function createUpgradeCard(o: UpgradeCardOptions) {
  const level = h('span', { class: 'ilv' });
  const cost = h('span', { class: 'icost' });
  const bar = createProgressBar();
  const stars = createStars(o.stars);
  const req = o.withRequirements ? h('span', { class: 'req' }) : null;
  const btn = h('button', { type: 'button', class: 'item', on: { click: o.onClick } },
    h('span', { class: 'item-top' }, h('span', { class: 'iname' }, o.emoji ? h('span', { class: 'emo', 'aria-hidden': 'true', text: o.emoji }) : null, o.name), level),
    h('span', { class: 'ifx', text: o.effect }),
    h('span', { class: 'item-bar' }, bar.el, cost, stars.el),
    req);
  btn.addEventListener('animationend', (e) => { if (e.animationName === 'nope') btn.classList.remove('nope'); });
  const extra = h('div', { class: 'bulk' });
  const el = h('li', { class: o.art ? 'art' : null }, btn);

  return {
    el,
    /** Слот под карточкой для дополнительных кнопок. */
    addExtra(...nodes: HTMLElement[]): void { extra.append(...nodes); if (!extra.parentNode) el.append(extra); },
    update(s: { level: string; cost: string; progress: number; can: boolean; owned?: boolean; locked?: boolean; starsOn: (i: number) => boolean }): void {
      setText(level, s.level);
      setText(cost, s.cost);
      bar.set(s.progress);
      stars.set(s.starsOn);
      btn.classList.toggle('can', s.can);
      btn.classList.toggle('owned', !!s.owned);
      btn.classList.toggle('locked', !!s.locked);
      btn.setAttribute('aria-disabled', s.owned ? 'true' : 'false');
    },
    requirements(text: string, ok: boolean): void {
      if (!req) return;
      setText(req, text);
      req.classList.toggle('ok', ok);
    },
    /** Купили — уровень коротко увеличивается. */
    bump(): void { replayClass(level, 'bump'); },
    /** Не хватило — карточка трясётся. */
    shake(): void { replayClass(btn, 'nope'); },
  };
}

export type UpgradeCard = ReturnType<typeof createUpgradeCard>;
