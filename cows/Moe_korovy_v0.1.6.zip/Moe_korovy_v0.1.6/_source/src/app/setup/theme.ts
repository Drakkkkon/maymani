/* Тема и оформление: атрибуты data-theme и data-skin на <html> следуют за настройками.
   data-art — id окна, если для него есть картинки кнопок улучшений: при смене окна картинки меняются. */
import { settings } from '@/entities/player';
import { backgroundById } from '@/entities/background';
import { ART_BACKGROUNDS } from '@/entities/farm';

export function initTheme(): void {
  const root = document.documentElement;
  const apply = () => {
    const s = settings.get();
    if (s.skin === 'japan') root.setAttribute('data-skin', 'japan'); else root.removeAttribute('data-skin');
    if (s.theme) root.setAttribute('data-theme', s.theme); else root.removeAttribute('data-theme');
    const bg = backgroundById(s.bg).id;
    if (ART_BACKGROUNDS.includes(bg)) root.setAttribute('data-art', bg); else root.removeAttribute('data-art');
  };
  settings.subscribe(apply);
  apply();
}
