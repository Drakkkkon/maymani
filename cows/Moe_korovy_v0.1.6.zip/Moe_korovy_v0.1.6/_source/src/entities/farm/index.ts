/* Ферма: правила, улучшения, прогресс игрока и формулы. */
export { TIERS, HT, LV_MAX, STAR_MAX, BULK, CLICK_COOLDOWN } from './config/rules';
export {
  LEVELS, SUPERS, levelsOf, supersOf,
  type LevelDef, type SuperDef, type Res, type Group, type Column, ART_BACKGROUNDS } from './config/upgrades';
export { progress, rates, type Progress, type Rates } from './model/state';
export {
  lvOf, starsOf, have, levelCost, starCost, starRequirements, requirementsMet, recalc, settle,
  bulkInfo, buyLevels, buyStar, clickCooldownLeft, claimClickBonus, alienCaught, alienMissed,
  supersDone, alienNeed, gamePlusReady, prestigeReset,
  type Req, type BulkInfo,
} from './model/economy';
export { costText, resIcon } from './lib/cost-text';
export { createUpgradeCard, type UpgradeCard } from './ui/upgrade-card';
