# Мое_коровы

Кликер про летающих коров. Vite + TypeScript без фреймворков, архитектура — [Feature-Sliced Design](https://feature-sliced.design/ru/).

## Команды

```
npm install        # один раз: Vite, TypeScript, Steiger
npm run dev        # игра с автообновлением: http://localhost:5173
npm run check      # проверка типов и архитектуры
npm run lint:fsd   # только архитектура (Steiger)
npm run build      # проверки + готовая игра в папке dist — её и выкладывать на сайт
npm run preview    # посмотреть собранную dist: http://localhost:4173
```

## Слои

Импортировать можно только из слоёв ниже. Слайсы одного слоя друг друга не импортируют.
Снаружи слайса — только через его `index.ts`. Импорты пишутся от корня: `@/entities/farm`.

```
app/        запуск: стили темы, setup (тема, звук, игровой цикл), router, раскладка
pages/      страницы: farm, houses, feed, game-plus, settings, themes
widgets/    крупные блоки:
              farm-window      окно — фон (картинка/видео), стадо, инопланетная корова
              upgrade-board    доска улучшений страницы (одна на Ферму, Домики, Кормёжку)
              resource-stats   показатели вверху страницы
              storage          хранилище (кнопка 📦 и сетка)
              tab-bar          вкладки внизу
features/   действия игрока:
              buy-upgrade, pet-cow, catch-alien, switch-background, prestige-reset,
              toggle-theme, select-skin, adjust-volume, set-herd-size, save-to-file, cloud-sync
entities/   данные игры:
              farm             правила, ВСЕ улучшения (config/upgrades.ts), прогресс, формулы,
                               карточка улучшения
              player           настройки игрока: тема, громкость, коровы в окне, фон
              background       каталог фонов, луга, вписывание в окно
shared/     ничего не знает про игру:
              lib              h(), форматы чисел, события, сохранение, звуковой движок
              ui               полоски, звёзды, кнопки ×N, ползунки, переключатели, карточки, иконки
              api              Google Диск (файл в скрытой папке приложения)
              config           Client ID Google, ключ сохранения, банк звуков
public/     картинки, видео, звуки — копируются в dist как есть
```

## Как связаны слои

- Ресурсы начисляет `entities/farm` (`settle()`); `app/setup/game-loop` вызывает его 10 раз в секунду.
- После каждого тика и действия игрока летят события `ticker` (`frame`, `changed`) из `shared/lib`.
  Виджеты на них подписаны и обновляются, только пока их видно.
- Настройки — наблюдаемое хранилище (`entities/player`): фичи меняют его, а тема, звук
  и окно подписаны на изменения.
- Сохранение собирается из частей: `farm` и `player` сами регистрируют свои поля в `shared/lib/persist`.
  Формат совпадает со старыми версиями, поэтому старые сохранения подхватываются.

## Частые правки

- **Новое улучшение:** строка в `entities/farm/config/upgrades.ts` (`grp` — страница, `col` — колонка).
  Если у него новый эффект — формула в `recalc()` в `entities/farm/model/economy.ts`.
- **Новый фон:** запись в `entities/background/config/catalog.ts` (с лугами для выпаса) и файл в `public/`.
- **Звуки:** куски записей, громкость и фон страниц — `shared/config/sound-bank.ts`.
- **Картинки кнопок для окна:** файлы `entities/farm/ui/art-<id фона>-<имя>.jpg`, блок строк в `upgrade-card.css`
  и id фона в `ART_BACKGROUNDS` (`entities/farm/config/upgrades.ts`).
- **Мелодия окна:** файл `public/sounds/music-<id фона>.mp3` и строка в `music` там же.
- **Список изменений:** новая версия дописывается в конец `pages/settings/config/changelog.ts`,
  номер версии — в `shared/config/index.ts` и `package.json`.
- **Новая страница:** слайс в `pages/`, адрес и вкладка в `app/router/routes.ts`, подключение в `app/index.ts`.
- **Google Диск:** Client ID в `shared/config/index.ts` (подробно — `public/ИНСТРУКЦИЯ.txt`).
